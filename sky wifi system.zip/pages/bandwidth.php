<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Bandwidth Monitor Page - Loaded from external file
 * 
 * Sellers can monitor real-time bandwidth usage, historical traffic,
 * latency, packet loss, and connected device counts per router
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE MANUAL SAMPLE RECORD
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_sample'])) {
    $routerId = intval($_POST['router_id'] ?? 0);
    
    if ($routerId) {
        // Verify router ownership
        $check = $conn->prepare("SELECT id FROM routers WHERE id = ? AND user_id = ?");
        $check->bind_param("ii", $routerId, $userId);
        $check->execute();
        
        if ($check->get_result()->num_rows === 0) {
            $msg = '<div class="alert alert-danger">Router not found or access denied</div>';
        } else {
            // Generate sample bandwidth data (simulated)
            $download = round(rand(10, 500) / 10, 2);
            $upload = round(rand(5, 200) / 10, 2);
            $latency = rand(5, 80);
            $packetLoss = round(rand(0, 50) / 10, 2);
            $clients = 0;
            $cpu = round(rand(10, 80), 2);
            $memory = round(rand(20, 90), 2);
            
            // Get actual connected clients for this router
            try {
                $res = $conn->query("SELECT COUNT(*) as c FROM wifi_sessions WHERE router_id = $routerId AND status = 'active'");
                if ($res) $clients = $res->fetch_assoc()['c'];
            } catch (Throwable $e) {}
            
            $stmt = $conn->prepare("INSERT INTO router_bandwidth (router_id, download_mbps, upload_mbps, latency_ms, packet_loss_percent, connected_clients, cpu_usage_percent, memory_usage_percent) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("idddiidd", $routerId, $download, $upload, $latency, $packetLoss, $clients, $cpu, $memory);
            if ($stmt->execute()) {
                $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Bandwidth sample recorded successfully!</div>';
                redirectTo('?page=bandwidth&router_id=' . $routerId);
            } else {
                $msg = '<div class="alert alert-danger">Failed to record sample</div>';
            }
        }
    }
}

// ============================================
// HANDLE CLEAR OLD DATA
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_old_data'])) {
    $days = intval($_POST['days'] ?? 30);
    if ($days < 1) $days = 30;
    
    try {
        $stmt = $conn->prepare("
            DELETE rb FROM router_bandwidth rb
            JOIN routers r ON rb.router_id = r.id
            WHERE r.user_id = ? AND rb.recorded_at < DATE_SUB(NOW(), INTERVAL ? DAY)
        ");
        $stmt->bind_param("ii", $userId, $days);
        $stmt->execute();
        $deleted = $stmt->affected_rows;
        
        $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Deleted ' . $deleted . ' old records (older than ' . $days . ' days)</div>';
        redirectTo('?page=bandwidth');
    } catch (Throwable $e) {
        $msg = '<div class="alert alert-danger">Failed to clear data: ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}

// ============================================
// HANDLE EXPORT TO CSV
// ============================================
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $exportRouter = intval($_GET['router'] ?? 0);
    $exportHours = intval($_GET['hours'] ?? 24);
    
    if ($exportHours < 1 || $exportHours > 720) $exportHours = 24;
    
    $sql = "SELECT rb.*, r.device_name as router_name, r.ssid
            FROM router_bandwidth rb
            JOIN routers r ON rb.router_id = r.id
            WHERE r.user_id = ?";
    $params = [$userId];
    $types = "i";
    
    if ($exportRouter) {
        $sql .= " AND rb.router_id = ?";
        $params[] = $exportRouter;
        $types .= "i";
    }
    
    $sql .= " AND rb.recorded_at >= DATE_SUB(NOW(), INTERVAL ? HOUR) ORDER BY rb.recorded_at DESC";
    $params[] = $exportHours;
    $types .= "i";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $exportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    while (ob_get_level() > 0) ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="bandwidth_' . date('Y-m-d_His') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Timestamp', 'Router', 'SSID', 'Download (Mbps)', 'Upload (Mbps)', 'Latency (ms)', 'Packet Loss (%)', 'Connected Clients', 'CPU (%)', 'Memory (%)']);
    
    foreach ($exportData as $row) {
        fputcsv($output, [
            $row['recorded_at'],
            $row['router_name'],
            $row['ssid'] ?? '',
            $row['download_mbps'],
            $row['upload_mbps'],
            $row['latency_ms'],
            $row['packet_loss_percent'],
            $row['connected_clients'],
            $row['cpu_usage_percent'],
            $row['memory_usage_percent']
        ]);
    }
    fclose($output);
    exit;
}

// ============================================
// FETCH FILTERS
// ============================================
$routerFilter = intval($_GET['router_id'] ?? 0);
$hoursFilter = intval($_GET['hours'] ?? 24);
if ($hoursFilter < 1 || $hoursFilter > 720) $hoursFilter = 24;

// ============================================
// FETCH ROUTERS
// ============================================
$routers = $router->getRouters($userId);

// ============================================
// FETCH LIVE SNAPSHOT DATA
// ============================================
$liveData = [];
foreach ($routers as $r) {
    // Get the most recent bandwidth record
    $latest = null;
    try {
        $stmt = $conn->prepare("
            SELECT * FROM router_bandwidth 
            WHERE router_id = ? 
            ORDER BY recorded_at DESC 
            LIMIT 1
        ");
        $stmt->bind_param("i", $r['id']);
        $stmt->execute();
        $latest = $stmt->get_result()->fetch_assoc();
    } catch (Throwable $e) {}
    
    // Get connected device count
    $deviceCount = 0;
    try {
        $res = $conn->query("SELECT COUNT(*) as c FROM wifi_sessions WHERE router_id = {$r['id']} AND status = 'active'");
        if ($res) $deviceCount = $res->fetch_assoc()['c'];
    } catch (Throwable $e) {}
    
    // Get 24h average
    $avg24h = null;
    try {
        $stmt = $conn->prepare("
            SELECT 
                AVG(download_mbps) as avg_download,
                AVG(upload_mbps) as avg_upload,
                AVG(latency_ms) as avg_latency,
                AVG(packet_loss_percent) as avg_packet_loss,
                MAX(download_mbps) as peak_download,
                MAX(upload_mbps) as peak_upload,
                COUNT(*) as sample_count
            FROM router_bandwidth 
            WHERE router_id = ? AND recorded_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ");
        $stmt->bind_param("i", $r['id']);
        $stmt->execute();
        $avg24h = $stmt->get_result()->fetch_assoc();
    } catch (Throwable $e) {}
    
    $liveData[] = [
        'router' => $r,
        'latest' => $latest,
        'avg24h' => $avg24h,
        'device_count' => $deviceCount
    ];
}

// ============================================
// FETCH HISTORICAL DATA
// ============================================
$historicalData = [];
try {
    $sql = "SELECT rb.*, r.device_name as router_name, r.status as router_status, r.ssid
            FROM router_bandwidth rb
            JOIN routers r ON rb.router_id = r.id
            WHERE r.user_id = ? AND rb.recorded_at >= DATE_SUB(NOW(), INTERVAL ? HOUR)";
    $params = [$userId, $hoursFilter];
    $types = "ii";
    
    if ($routerFilter) {
        $sql .= " AND rb.router_id = ?";
        $params[] = $routerFilter;
        $types .= "i";
    }
    
    $sql .= " ORDER BY rb.recorded_at DESC LIMIT 500";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $historicalData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// CHART DATA (aggregated hourly for selected period)
// ============================================
$chartData = [];
$chartLabels = [];

if ($routerFilter) {
    // Chart for specific router
    try {
        $stmt = $conn->prepare("
            SELECT 
                DATE_FORMAT(recorded_at, '%Y-%m-%d %H:00') as hour_bucket,
                AVG(download_mbps) as avg_download,
                AVG(upload_mbps) as avg_upload,
                AVG(latency_ms) as avg_latency
            FROM router_bandwidth
            WHERE router_id = ? AND recorded_at >= DATE_SUB(NOW(), INTERVAL ? HOUR)
            GROUP BY hour_bucket
            ORDER BY hour_bucket ASC
        ");
        $stmt->bind_param("ii", $routerFilter, $hoursFilter);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        foreach ($rows as $row) {
            $chartLabels[] = date('H:i', strtotime($row['hour_bucket']));
            $chartData[] = [
                'download' => round($row['avg_download'], 2),
                'upload' => round($row['avg_upload'], 2),
                'latency' => round($row['avg_latency'], 0)
            ];
        }
    } catch (Throwable $e) {}
} else {
    // Chart for all routers combined
    try {
        $stmt = $conn->prepare("
            SELECT 
                DATE_FORMAT(rb.recorded_at, '%Y-%m-%d %H:00') as hour_bucket,
                AVG(rb.download_mbps) as avg_download,
                AVG(rb.upload_mbps) as avg_upload,
                AVG(rb.latency_ms) as avg_latency
            FROM router_bandwidth rb
            JOIN routers r ON rb.router_id = r.id
            WHERE r.user_id = ? AND rb.recorded_at >= DATE_SUB(NOW(), INTERVAL ? HOUR)
            GROUP BY hour_bucket
            ORDER BY hour_bucket ASC
        ");
        $stmt->bind_param("ii", $userId, $hoursFilter);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        foreach ($rows as $row) {
            $chartLabels[] = date('H:i', strtotime($row['hour_bucket']));
            $chartData[] = [
                'download' => round($row['avg_download'], 2),
                'upload' => round($row['avg_upload'], 2),
                'latency' => round($row['avg_latency'], 0)
            ];
        }
    } catch (Throwable $e) {}
}

// ============================================
// OVERALL STATS
// ============================================
$overallStats = [
    'total_routers' => count($routers),
    'online_routers' => 0,
    'total_devices' => 0,
    'avg_download' => 0,
    'avg_upload' => 0,
    'avg_latency' => 0,
    'peak_download' => 0,
    'peak_upload' => 0,
    'total_samples' => count($historicalData)
];

foreach ($routers as $r) {
    if ($r['status'] === 'online') $overallStats['online_routers']++;
}
foreach ($liveData as $ld) {
    $overallStats['total_devices'] += $ld['device_count'];
}

// Compute averages from chart data
if (count($chartData) > 0) {
    $overallStats['avg_download'] = round(array_sum(array_column($chartData, 'download')) / count($chartData), 2);
    $overallStats['avg_upload'] = round(array_sum(array_column($chartData, 'upload')) / count($chartData), 2);
    $overallStats['avg_latency'] = round(array_sum(array_column($chartData, 'latency')) / count($chartData), 0);
    $overallStats['peak_download'] = max(array_column($chartData, 'download'));
    $overallStats['peak_upload'] = max(array_column($chartData, 'upload'));
}

// Determine health status
$healthStatus = 'healthy';
$healthMessage = 'All systems operating normally';

if ($overallStats['online_routers'] < $overallStats['total_routers'] * 0.5) {
    $healthStatus = 'critical';
    $healthMessage = 'Less than half of routers are online';
} elseif ($overallStats['online_routers'] < $overallStats['total_routers']) {
    $healthStatus = 'warning';
    $healthMessage = ($overallStats['total_routers'] - $overallStats['online_routers']) . ' router(s) offline';
}

if ($overallStats['avg_latency'] > 100) {
    $healthStatus = 'warning';
    $healthMessage = 'High latency detected (' . $overallStats['avg_latency'] . 'ms)';
}
if ($overallStats['avg_latency'] > 200) {
    $healthStatus = 'critical';
    $healthMessage = 'Very high latency: ' . $overallStats['avg_latency'] . 'ms';
}

// Chart max for scaling
$chartMaxDownload = max(array_merge([1], array_column($chartData, 'download')));
$chartMaxUpload = max(array_merge([1], array_column($chartData, 'upload')));

// Determine time range label
$rangeLabel = $hoursFilter . ' hours';
if ($hoursFilter >= 24) {
    $rangeLabel = round($hoursFilter / 24, 1) . ' days';
}

?>

<!-- ============================================ -->
<!-- BANDWIDTH MONITOR HEADER                    -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-chart-area"></i> <?php echo t('bandwidth_monitor'); ?></h2>
        <small class="text-muted">Real-time traffic monitoring across all your routers</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a href="?page=bandwidth&export=csv&router=<?php echo $routerFilter; ?>&hours=<?php echo $hoursFilter; ?>" 
           class="btn btn-outline-success btn-sm">
            <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
        </a>
        <button type="button" class="btn btn-outline-info btn-sm" onclick="location.reload()">
            <i class="fas fa-sync"></i> Refresh
        </button>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- HEALTH STATUS BANNER                        -->
<!-- ============================================ -->
<?php if ($overallStats['total_routers'] > 0): ?>
<div class="alert alert-<?php echo $healthStatus === 'healthy' ? 'success' : ($healthStatus === 'warning' ? 'warning' : 'danger'); ?> d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">
    <div>
        <i class="fas fa-<?php echo $healthStatus === 'healthy' ? 'check-circle' : ($healthStatus === 'warning' ? 'exclamation-triangle' : 'times-circle'); ?>"></i>
        <strong>System Status:</strong> <?php echo htmlspecialchars($healthMessage); ?>
    </div>
    <span class="health-indicator <?php echo $healthStatus; ?>">
        <i class="fas fa-circle"></i> <?php echo ucfirst($healthStatus); ?>
    </span>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- OVERALL STATS                               -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-download text-primary"></i> <?php echo t('download_speed'); ?></div>
            <div class="metric-value" style="font-size:1.5rem;">
                <?php echo number_format($overallStats['avg_download'], 1); ?>
                <small style="font-size:0.7rem;">Mbps</small>
            </div>
            <small class="text-muted">Peak: <?php echo number_format($overallStats['peak_download'], 1); ?></small>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-upload text-success"></i> <?php echo t('upload_speed'); ?></div>
            <div class="metric-value text-success" style="font-size:1.5rem;">
                <?php echo number_format($overallStats['avg_upload'], 1); ?>
                <small style="font-size:0.7rem;">Mbps</small>
            </div>
            <small class="text-muted">Peak: <?php echo number_format($overallStats['peak_upload'], 1); ?></small>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-clock text-info"></i> <?php echo t('latency'); ?></div>
            <div class="metric-value text-info" style="font-size:1.5rem;">
                <?php echo $overallStats['avg_latency']; ?>
                <small style="font-size:0.7rem;">ms</small>
            </div>
            <small class="text-muted">
                <?php if ($overallStats['avg_latency'] < 30): ?>
                    <span class="text-success">Excellent</span>
                <?php elseif ($overallStats['avg_latency'] < 80): ?>
                    <span class="text-success">Good</span>
                <?php elseif ($overallStats['avg_latency'] < 150): ?>
                    <span class="text-warning">Fair</span>
                <?php else: ?>
                    <span class="text-danger">Poor</span>
                <?php endif; ?>
            </small>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-laptop text-warning"></i> <?php echo t('connected_devices'); ?></div>
            <div class="metric-value text-warning" style="font-size:1.5rem;"><?php echo $overallStats['total_devices']; ?></div>
            <small class="text-muted">
                <?php echo $overallStats['online_routers']; ?>/<?php echo $overallStats['total_routers']; ?> routers online
            </small>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- FILTERS                                     -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-body py-3">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small mb-1"><i class="fas fa-wifi"></i> <?php echo t('router'); ?></label>
                <select class="form-select form-select-sm" id="routerSelect" onchange="applyFilters()">
                    <option value="0"><?php echo t('all_routers'); ?></option>
                    <?php foreach ($routers as $r): ?>
                    <option value="<?php echo $r['id']; ?>" <?php echo $routerFilter == $r['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($r['device_name']); ?>
                        <?php if ($r['status'] !== 'online'): ?>
                        [<?php echo $r['status']; ?>]
                        <?php endif; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-4">
                <label class="form-label small mb-1"><i class="fas fa-clock"></i> Time Range</label>
                <select class="form-select form-select-sm" id="hoursSelect" onchange="applyFilters()">
                    <option value="1" <?php echo $hoursFilter === 1 ? 'selected' : ''; ?>>Last 1 hour</option>
                    <option value="6" <?php echo $hoursFilter === 6 ? 'selected' : ''; ?>>Last 6 hours</option>
                    <option value="24" <?php echo $hoursFilter === 24 ? 'selected' : ''; ?>>Last 24 hours</option>
                    <option value="168" <?php echo $hoursFilter === 168 ? 'selected' : ''; ?>>Last 7 days</option>
                    <option value="720" <?php echo $hoursFilter === 720 ? 'selected' : ''; ?>>Last 30 days</option>
                </select>
            </div>
            
            <div class="col-md-4">
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-primary btn-sm flex-grow-1" onclick="applyFilters()">
                        <i class="fas fa-filter"></i> <?php echo t('filter'); ?>
                    </button>
                    <a href="?page=bandwidth" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-times"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- TRAFFIC CHART                               -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="mb-0">
            <i class="fas fa-chart-line text-primary"></i> 
            Traffic Overview - <?php echo $rangeLabel; ?>
            <?php if ($routerFilter): 
                foreach ($routers as $r) if ($r['id'] == $routerFilter) {
                    echo ' - ' . htmlspecialchars($r['device_name']);
                    break;
                }
            endif; ?>
        </h6>
        <div class="d-flex gap-3 small">
            <span><i class="fas fa-circle text-primary"></i> Download</span>
            <span><i class="fas fa-circle text-success"></i> Upload</span>
        </div>
    </div>
    <div class="card-body">
        <?php if (count($chartData) > 0): ?>
            <!-- Bar Chart -->
            <div class="chart-bar" style="height: 180px;">
                <?php foreach ($chartData as $i => $point): 
                    $downloadHeight = ($point['download'] / $chartMaxDownload) * 100;
                    $uploadHeight = ($point['upload'] / $chartMaxUpload) * 100;
                ?>
                <div class="bar" 
                     style="height: <?php echo max($downloadHeight, 2); ?>%; background: linear-gradient(to top, var(--primary), var(--primary-light));"
                     title="<?php echo $chartLabels[$i]; ?>: ↓<?php echo $point['download']; ?> Mbps / ↑<?php echo $point['upload']; ?> Mbps / <?php echo $point['latency']; ?>ms">
                </div>
                <?php endforeach; ?>
            </div>
            <div class="d-flex justify-content-between mt-2 small text-muted">
                <span><?php echo $chartLabels[0] ?? ''; ?></span>
                <span><?php echo $chartLabels[floor(count($chartLabels) / 2)] ?? ''; ?></span>
                <span><?php echo end($chartLabels) ?: ''; ?></span>
            </div>
            
            <!-- Summary Stats -->
            <div class="row mt-4 pt-3 border-top" style="border-color:var(--border-color) !important;">
                <div class="col-4 text-center">
                    <div class="text-muted small"><?php echo t('download_speed'); ?></div>
                    <div class="fw-bold text-primary"><?php echo number_format($overallStats['avg_download'], 1); ?> Mbps</div>
                    <small class="text-muted">Peak: <?php echo number_format($overallStats['peak_download'], 1); ?></small>
                </div>
                <div class="col-4 text-center">
                    <div class="text-muted small"><?php echo t('upload_speed'); ?></div>
                    <div class="fw-bold text-success"><?php echo number_format($overallStats['avg_upload'], 1); ?> Mbps</div>
                    <small class="text-muted">Peak: <?php echo number_format($overallStats['peak_upload'], 1); ?></small>
                </div>
                <div class="col-4 text-center">
                    <div class="text-muted small"><?php echo t('latency'); ?></div>
                    <div class="fw-bold text-info"><?php echo $overallStats['avg_latency']; ?> ms</div>
                    <small class="text-muted">Average</small>
                </div>
            </div>
        <?php else: ?>
            <div class="empty-state py-5">
                <i class="fas fa-chart-area"></i>
                <h5><?php echo t('no_data'); ?></h5>
                <p>No bandwidth data recorded for the selected period.</p>
                <small class="text-muted">
                    Data is recorded automatically when routers report their bandwidth status. 
                    You can also record a manual sample below.
                </small>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================ -->
<!-- LIVE SNAPSHOTS PER ROUTER                   -->
<!-- ============================================ -->
<?php if (count($liveData) > 0): ?>
<h5 class="mb-3"><i class="fas fa-broadcast-tower text-success"></i> <?php echo t('live_traffic'); ?> — Per Router</h5>

<div class="row mb-4">
    <?php foreach ($liveData as $ld): 
        $r = $ld['router'];
        $latest = $ld['latest'];
        $avg = $ld['avg24h'];
        $isOnline = ($r['status'] === 'online');
    ?>
    <div class="col-md-6 col-lg-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div style="min-width:0;flex:1;">
                        <h6 class="mb-1 text-truncate">
                            <span class="router-status-indicator <?php echo $r['status']; ?>"></span>
                            <?php echo htmlspecialchars($r['device_name']); ?>
                        </h6>
                        <small class="text-muted text-truncate d-block">
                            <i class="fas fa-wifi"></i> <?php echo htmlspecialchars($r['ssid'] ?: 'No SSID'); ?>
                        </small>
                    </div>
                    <span class="badge bg-<?php echo $isOnline ? 'success' : 'danger'; ?>">
                        <?php echo t($r['status']); ?>
                    </span>
                </div>
                
                <?php if ($latest): 
                    $downloadPct = min(($latest['download_mbps'] / 100) * 100, 100);
                    $uploadPct = min(($latest['upload_mbps'] / 100) * 100, 100);
                ?>
                <!-- Live Metrics -->
                <div class="mb-2">
                    <div class="d-flex justify-content-between align-items-center small mb-1">
                        <span><i class="fas fa-download text-primary"></i> Download</span>
                        <strong class="text-primary"><?php echo $latest['download_mbps']; ?> Mbps</strong>
                    </div>
                    <div class="bandwidth-meter">
                        <div class="fill download" style="width: <?php echo $downloadPct; ?>%"></div>
                    </div>
                </div>
                
                <div class="mb-2">
                    <div class="d-flex justify-content-between align-items-center small mb-1">
                        <span><i class="fas fa-upload text-success"></i> Upload</span>
                        <strong class="text-success"><?php echo $latest['upload_mbps']; ?> Mbps</strong>
                    </div>
                    <div class="bandwidth-meter">
                        <div class="fill upload" style="width: <?php echo $uploadPct; ?>%"></div>
                    </div>
                </div>
                
                <!-- Details Grid -->
                <div class="row g-1 mt-3 small">
                    <div class="col-6">
                        <div class="text-muted" style="font-size:0.7rem;">LATENCY</div>
                        <div class="fw-bold <?php echo $latest['latency_ms'] > 100 ? 'text-danger' : 'text-success'; ?>">
                            <?php echo $latest['latency_ms']; ?> ms
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted" style="font-size:0.7rem;">PACKET LOSS</div>
                        <div class="fw-bold <?php echo $latest['packet_loss_percent'] > 2 ? 'text-warning' : 'text-success'; ?>">
                            <?php echo $latest['packet_loss_percent']; ?>%
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted" style="font-size:0.7rem;">CLIENTS</div>
                        <div class="fw-bold">
                            <i class="fas fa-users text-info"></i> <?php echo $ld['device_count']; ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted" style="font-size:0.7rem;">UPDATED</div>
                        <div class="fw-bold" style="font-size:0.8rem;">
                            <?php 
                            $diff = time() - strtotime($latest['recorded_at']);
                            if ($diff < 60) echo t('just_now');
                            elseif ($diff < 3600) echo floor($diff / 60) . 'm ago';
                            elseif ($diff < 86400) echo floor($diff / 3600) . 'h ago';
                            else echo floor($diff / 86400) . 'd ago';
                            ?>
                        </div>
                    </div>
                </div>
                
                <?php if ($avg && $avg['sample_count'] > 0): ?>
                <!-- 24h Averages -->
                <div class="mt-3 pt-2 border-top" style="border-color:var(--border-color) !important;">
                    <div class="text-muted small mb-1" style="font-size:0.7rem;">24H AVERAGE (<?php echo $avg['sample_count']; ?> samples)</div>
                    <div class="d-flex justify-content-between small">
                        <span><i class="fas fa-download text-primary"></i> <?php echo number_format($avg['avg_download'], 1); ?></span>
                        <span><i class="fas fa-upload text-success"></i> <?php echo number_format($avg['avg_upload'], 1); ?></span>
                        <span><i class="fas fa-clock text-info"></i> <?php echo round($avg['avg_latency']); ?>ms</span>
                        <span class="text-warning"><i class="fas fa-arrow-up"></i> <?php echo number_format($avg['peak_download'], 1); ?></span>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php else: ?>
                <!-- No Data State -->
                <div class="text-center py-4">
                    <i class="fas fa-chart-line text-muted" style="font-size:2rem;opacity:0.5;"></i>
                    <p class="text-muted small mt-2 mb-0">No bandwidth data yet</p>
                    <p class="text-muted small">Record a manual sample to start tracking</p>
                </div>
                <?php endif; ?>
                
                <!-- Actions -->
                <div class="d-flex gap-2 mt-3">
                    <form method="POST" class="flex-grow-1">
                        <input type="hidden" name="router_id" value="<?php echo $r['id']; ?>">
                        <button type="submit" name="record_sample" class="btn btn-sm btn-outline-primary w-100" 
                                onclick="return confirm('Record a manual bandwidth sample for this router?');">
                            <i class="fas fa-plus-circle"></i> Record Sample
                        </button>
                    </form>
                    <a href="?page=bandwidth&router_id=<?php echo $r['id']; ?>&hours=<?php echo $hoursFilter; ?>" 
                       class="btn btn-sm btn-outline-info" title="View history">
                        <i class="fas fa-chart-line"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
<div class="card mb-4">
    <div class="card-body">
        <div class="empty-state py-5">
            <i class="fas fa-broadcast-tower"></i>
            <h5><?php echo t('no_routers'); ?></h5>
            <p>Add routers to start monitoring bandwidth.</p>
            <a href="?page=connect" class="btn btn-primary mt-3">
                <i class="fas fa-plus-circle"></i> Add Router
            </a>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- HISTORICAL DATA TABLE                       -->
<!-- ============================================ -->
<?php if (count($historicalData) > 0): ?>
<div class="card mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="mb-0">
            <i class="fas fa-history text-info"></i> 
            Historical Data — Last <?php echo $rangeLabel; ?>
            <small class="text-muted ms-2">(<?php echo count($historicalData); ?> records)</small>
        </h6>
        <div class="d-flex gap-2 align-items-center">
            <button type="button" class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#clearOldModal">
                <i class="fas fa-broom"></i> Clear Old
            </button>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive" style="max-height: 500px;overflow-y: auto;">
            <table class="table table-hover mobile-card-table mb-0">
                <thead style="position: sticky;top: 0;background: var(--bg-card);z-index: 2;">
                    <tr>
                        <th><?php echo t('date'); ?></th>
                        <?php if (!$routerFilter): ?>
                        <th><?php echo t('router'); ?></th>
                        <?php endif; ?>
                        <th><?php echo t('download_speed'); ?></th>
                        <th><?php echo t('upload_speed'); ?></th>
                        <th><?php echo t('latency'); ?></th>
                        <th><?php echo t('packet_loss'); ?></th>
                        <th><?php echo t('connected_devices'); ?></th>
                        <th>CPU</th>
                        <th>RAM</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($historicalData as $row): 
                        $latencyClass = $row['latency_ms'] > 150 ? 'text-danger' : ($row['latency_ms'] > 80 ? 'text-warning' : 'text-success');
                        $packetClass = $row['packet_loss_percent'] > 5 ? 'text-danger' : ($row['packet_loss_percent'] > 2 ? 'text-warning' : 'text-success');
                    ?>
                    <tr>
                        <td data-label="<?php echo t('date'); ?>">
                            <div><?php echo date('d M', strtotime($row['recorded_at'])); ?></div>
                            <small class="text-muted"><?php echo date('H:i:s', strtotime($row['recorded_at'])); ?></small>
                        </td>
                        <?php if (!$routerFilter): ?>
                        <td data-label="<?php echo t('router'); ?>">
                            <div class="small">
                                <span class="router-status-indicator <?php echo $row['router_status'] ?? 'offline'; ?>"></span>
                                <?php echo htmlspecialchars($row['router_name']); ?>
                            </div>
                        </td>
                        <?php endif; ?>
                        <td data-label="<?php echo t('download_speed'); ?>">
                            <span class="text-primary fw-bold"><?php echo $row['download_mbps']; ?></span>
                            <small class="text-muted">Mbps</small>
                        </td>
                        <td data-label="<?php echo t('upload_speed'); ?>">
                            <span class="text-success fw-bold"><?php echo $row['upload_mbps']; ?></span>
                            <small class="text-muted">Mbps</small>
                        </td>
                        <td data-label="<?php echo t('latency'); ?>">
                            <span class="<?php echo $latencyClass; ?> fw-bold"><?php echo $row['latency_ms']; ?></span>
                            <small class="text-muted">ms</small>
                        </td>
                        <td data-label="<?php echo t('packet_loss'); ?>">
                            <span class="<?php echo $packetClass; ?> fw-bold"><?php echo $row['packet_loss_percent']; ?></span>
                            <small class="text-muted">%</small>
                        </td>
                        <td data-label="<?php echo t('connected_devices'); ?>">
                            <span class="badge bg-info"><?php echo $row['connected_clients']; ?></span>
                        </td>
                        <td data-label="CPU">
                            <div class="progress" style="width:60px;height:6px;">
                                <div class="progress-bar bg-<?php echo $row['cpu_usage_percent'] > 80 ? 'danger' : ($row['cpu_usage_percent'] > 60 ? 'warning' : 'success'); ?>" 
                                     style="width: <?php echo $row['cpu_usage_percent']; ?>%"></div>
                            </div>
                            <small><?php echo $row['cpu_usage_percent']; ?>%</small>
                        </td>
                        <td data-label="RAM">
                            <div class="progress" style="width:60px;height:6px;">
                                <div class="progress-bar bg-<?php echo $row['memory_usage_percent'] > 80 ? 'danger' : ($row['memory_usage_percent'] > 60 ? 'warning' : 'success'); ?>" 
                                     style="width: <?php echo $row['memory_usage_percent']; ?>%"></div>
                            </div>
                            <small><?php echo $row['memory_usage_percent']; ?>%</small>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- HOW IT WORKS                                -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-info-circle text-info"></i> About Bandwidth Monitoring</h6>
            </div>
            <div class="card-body">
                <p class="text-muted small mb-3">
                    Bandwidth monitoring tracks the performance of your WiFi routers over time. Data is collected when:
                </p>
                <ul class="text-muted small mb-0">
                    <li><i class="fas fa-check text-success"></i> Routers report their status automatically</li>
                    <li><i class="fas fa-check text-success"></i> You record a manual sample from this page</li>
                    <li><i class="fas fa-check text-success"></i> A scheduled task queries the router API</li>
                </ul>
                <p class="text-muted small mt-3 mb-0">
                    <strong>Metrics tracked:</strong>
                </p>
                <div class="row g-2 mt-2">
                    <div class="col-6">
                        <small><i class="fas fa-download text-primary"></i> Download speed</small>
                    </div>
                    <div class="col-6">
                        <small><i class="fas fa-upload text-success"></i> Upload speed</small>
                    </div>
                    <div class="col-6">
                        <small><i class="fas fa-clock text-info"></i> Latency</small>
                    </div>
                    <div class="col-6">
                        <small><i class="fas fa-exclamation-triangle text-warning"></i> Packet loss</small>
                    </div>
                    <div class="col-6">
                        <small><i class="fas fa-users text-primary"></i> Client count</small>
                    </div>
                    <div class="col-6">
                        <small><i class="fas fa-microchip text-danger"></i> CPU / RAM usage</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-lightbulb text-warning"></i> Performance Tips</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="fw-semibold small">
                        <i class="fas fa-clock text-success"></i> Latency
                    </div>
                    <ul class="text-muted small mb-0">
                        <li><strong>&lt;30ms</strong> — Excellent (gaming, video calls)</li>
                        <li><strong>30-80ms</strong> — Good (general use)</li>
                        <li><strong>80-150ms</strong> — Fair (browsing OK)</li>
                        <li><strong>&gt;150ms</strong> — Poor (investigate)</li>
                    </ul>
                </div>
                
                <div class="mb-3">
                    <div class="fw-semibold small">
                        <i class="fas fa-exclamation-triangle text-warning"></i> Packet Loss
                    </div>
                    <ul class="text-muted small mb-0">
                        <li><strong>0%</strong> — Perfect</li>
                        <li><strong>0.1-2%</strong> — Normal</li>
                        <li><strong>2-5%</strong> — Degraded</li>
                        <li><strong>&gt;5%</strong> — Severe problems</li>
                    </ul>
                </div>
                
                <div>
                    <div class="fw-semibold small">
                        <i class="fas fa-bolt text-danger"></i> Common Issues
                    </div>
                    <ul class="text-muted small mb-0">
                        <li>High CPU — too many devices, upgrade router</li>
                        <li>High latency — ISP issue or congestion</li>
                        <li>Low throughput — bandwidth limit reached</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- CLEAR OLD DATA MODAL                        -->
<!-- ============================================ -->
<div class="modal fade" id="clearOldModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-broom text-warning"></i> Clear Old Bandwidth Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Delete bandwidth records older than:</p>
                    <div class="mb-3">
                        <select name="days" class="form-select">
                            <option value="7">7 days</option>
                            <option value="30" selected>30 days</option>
                            <option value="60">60 days</option>
                            <option value="90">90 days</option>
                            <option value="180">180 days</option>
                        </select>
                    </div>
                    <div class="alert alert-warning small">
                        <i class="fas fa-exclamation-triangle"></i>
                        This will permanently delete historical bandwidth records older than the selected period. This action cannot be undone.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="submit" name="clear_old_data" class="btn btn-warning" 
                            onclick="return confirm('Delete old bandwidth data?');">
                        <i class="fas fa-broom"></i> Clear Data
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Apply filters
function applyFilters() {
    const routerId = document.getElementById('routerSelect').value;
    const hours = document.getElementById('hoursSelect').value;
    window.location.href = '?page=bandwidth&router_id=' + routerId + '&hours=' + hours;
}

// Auto-refresh every 60 seconds if no modal is open
(function() {
    setInterval(function() {
        if (document.querySelector('.modal.show')) return;
        if (document.activeElement && 
            (document.activeElement.tagName === 'INPUT' || 
             document.activeElement.tagName === 'SELECT')) return;
        
        // Silent refresh with cache bypass
        const url = new URL(window.location.href);
        url.searchParams.set('_t', Date.now());
        
        fetch(url.toString(), { 
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then(res => {
            // Only reload if there's actual new data (simple heuristic)
            // Skip auto-reload to avoid disruption
        }).catch(() => {});
    }, 60000);
})();

// Animate progress bars on load
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.bandwidth-meter .fill').forEach(el => {
        const width = el.style.width;
        el.style.width = '0%';
        setTimeout(() => {
            el.style.width = width;
        }, 100);
    });
});
</script>