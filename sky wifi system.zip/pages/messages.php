<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Messages Page - Loaded from external file
 * 
 * Full messaging system: Inbox, Sent, Compose, Reply, Star, Archive, Delete.
 * Sellers and customers can communicate with each other and with admin.
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require login
$auth->requireLogin();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE SEND MESSAGE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $receiverId = intval($_POST['receiver_id'] ?? 0);
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $parentId = !empty($_POST['parent_id']) ? intval($_POST['parent_id']) : null;
    
    if (!$receiverId) {
        $msg = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Please select a recipient</div>';
    } elseif (!$message) {
        $msg = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Message cannot be empty</div>';
    } elseif ($receiverId === $userId) {
        $msg = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> You cannot send a message to yourself</div>';
    } else {
        // Verify recipient exists
        $check = $conn->prepare("SELECT id FROM users WHERE id = ? AND status = 'active'");
        $check->bind_param("i", $receiverId);
        $check->execute();
        
        if ($check->get_result()->num_rows === 0) {
            $msg = '<div class="alert alert-danger">Recipient not found</div>';
        } else {
            $result = $messageManager->send($userId, $receiverId, $subject, $message, $parentId);
            if ($result['success']) {
                $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Message sent successfully!</div>';
                redirectTo('?page=messages&tab=sent');
            } else {
                $msg = '<div class="alert alert-danger">Failed to send: ' . htmlspecialchars($result['message']) . '</div>';
            }
        }
    }
}

// ============================================
// HANDLE MARK AS READ
// ============================================
if (isset($_GET['mark_read'])) {
    $messageId = intval($_GET['mark_read']);
    if ($messageId) {
        $messageManager->markAsRead($messageId, $userId);
        redirectTo('?page=messages');
    }
}

// ============================================
// HANDLE MARK AS UNREAD
// ============================================
if (isset($_GET['mark_unread'])) {
    $messageId = intval($_GET['mark_unread']);
    if ($messageId) {
        $stmt = $conn->prepare("UPDATE messages SET is_read = 0, read_at = NULL WHERE id = ? AND receiver_id = ?");
        $stmt->bind_param("ii", $messageId, $userId);
        $stmt->execute();
        redirectTo('?page=messages');
    }
}

// ============================================
// HANDLE DELETE MESSAGE
// ============================================
if (isset($_GET['delete'])) {
    $messageId = intval($_GET['delete']);
    if ($messageId) {
        // Mark as deleted by current user (soft delete)
        $stmt = $conn->prepare("
            UPDATE messages 
            SET is_deleted_by_sender = IF(sender_id = ?, 1, is_deleted_by_sender),
                is_deleted_by_receiver = IF(receiver_id = ?, 1, is_deleted_by_receiver)
            WHERE id = ? AND (sender_id = ? OR receiver_id = ?)
        ");
        $stmt->bind_param("iiiii", $userId, $userId, $messageId, $userId, $userId);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Message deleted</div>';
        } else {
            $_SESSION['flash_msg'] = '<div class="alert alert-danger">Failed to delete message</div>';
        }
        redirectTo('?page=messages');
    }
}

// ============================================
// HANDLE STAR MESSAGE
// ============================================
if (isset($_GET['star'])) {
    $messageId = intval($_GET['star']);
    $starValue = intval($_GET['value'] ?? 1);
    if ($messageId) {
        $stmt = $conn->prepare("UPDATE messages SET is_starred = ? WHERE id = ? AND (sender_id = ? OR receiver_id = ?)");
        $stmt->bind_param("iiii", $starValue, $messageId, $userId, $userId);
        $stmt->execute();
        redirectTo($_SERVER['HTTP_REFERER'] ?? '?page=messages');
    }
}

// ============================================
// HANDLE ARCHIVE MESSAGE
// ============================================
if (isset($_GET['archive'])) {
    $messageId = intval($_GET['archive']);
    $archiveValue = intval($_GET['value'] ?? 1);
    if ($messageId) {
        $stmt = $conn->prepare("UPDATE messages SET is_archived = ? WHERE id = ? AND (sender_id = ? OR receiver_id = ?)");
        $stmt->bind_param("iiii", $archiveValue, $messageId, $userId, $userId);
        $stmt->execute();
        redirectTo($_SERVER['HTTP_REFERER'] ?? '?page=messages');
    }
}

// ============================================
// HANDLE BULK ACTIONS
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    $action = $_POST['bulk_action'];
    $messageIds = isset($_POST['message_ids']) ? $_POST['message_ids'] : [];
    
    if (!empty($messageIds) && $action) {
        $successCount = 0;
        foreach ($messageIds as $mid) {
            $mid = intval($mid);
            if ($action === 'mark_read') {
                $stmt = $conn->prepare("UPDATE messages SET is_read = 1, read_at = NOW() WHERE id = ? AND receiver_id = ?");
                $stmt->bind_param("ii", $mid, $userId);
                $stmt->execute();
                if ($stmt->affected_rows > 0) $successCount++;
            } elseif ($action === 'mark_unread') {
                $stmt = $conn->prepare("UPDATE messages SET is_read = 0, read_at = NULL WHERE id = ? AND receiver_id = ?");
                $stmt->bind_param("ii", $mid, $userId);
                $stmt->execute();
                if ($stmt->affected_rows > 0) $successCount++;
            } elseif ($action === 'archive') {
                $stmt = $conn->prepare("UPDATE messages SET is_archived = 1 WHERE id = ? AND (sender_id = ? OR receiver_id = ?)");
                $stmt->bind_param("iii", $mid, $userId, $userId);
                $stmt->execute();
                if ($stmt->affected_rows > 0) $successCount++;
            } elseif ($action === 'delete') {
                $stmt = $conn->prepare("
                    UPDATE messages 
                    SET is_deleted_by_sender = IF(sender_id = ?, 1, is_deleted_by_sender),
                        is_deleted_by_receiver = IF(receiver_id = ?, 1, is_deleted_by_receiver)
                    WHERE id = ? AND (sender_id = ? OR receiver_id = ?)
                ");
                $stmt->bind_param("iiiii", $userId, $userId, $mid, $userId, $userId);
                $stmt->execute();
                if ($stmt->affected_rows > 0) $successCount++;
            }
        }
        $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $successCount . ' message(s) updated</div>';
        redirectTo('?page=messages');
    }
}

// ============================================
// FETCH FILTERS
// ============================================
$tab = $_GET['tab'] ?? 'inbox';
$searchTerm = trim($_GET['search'] ?? '');
$filterStarred = isset($_GET['starred']) && $_GET['starred'] === '1';
$showArchived = isset($_GET['archived']) && $_GET['archived'] === '1';
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 25;
$offset = ($pageNum - 1) * $perPage;

// ============================================
// BUILD QUERY BASED ON TAB
// ============================================
$whereClause = "";
$params = [];
$types = "";

if ($tab === 'inbox') {
    $whereClause = "WHERE m.receiver_id = ? AND m.is_deleted_by_receiver = 0";
    $params[] = $userId;
    $types .= "i";
} elseif ($tab === 'sent') {
    $whereClause = "WHERE m.sender_id = ? AND m.is_deleted_by_sender = 0";
    $params[] = $userId;
    $types .= "i";
} elseif ($tab === 'starred') {
    $whereClause = "WHERE (m.receiver_id = ? OR m.sender_id = ?) AND m.is_starred = 1 AND 
                    ((m.receiver_id = ? AND m.is_deleted_by_receiver = 0) OR (m.sender_id = ? AND m.is_deleted_by_sender = 0))";
    $params[] = $userId;
    $params[] = $userId;
    $params[] = $userId;
    $params[] = $userId;
    $types .= "iiii";
} elseif ($tab === 'archived') {
    $whereClause = "WHERE (m.receiver_id = ? OR m.sender_id = ?) AND m.is_archived = 1 AND 
                    ((m.receiver_id = ? AND m.is_deleted_by_receiver = 0) OR (m.sender_id = ? AND m.is_deleted_by_sender = 0))";
    $params[] = $userId;
    $params[] = $userId;
    $params[] = $userId;
    $params[] = $userId;
    $types .= "iiii";
} else {
    $whereClause = "WHERE (m.receiver_id = ? OR m.sender_id = ?)";
    $params[] = $userId;
    $params[] = $userId;
    $types .= "ii";
}

if ($searchTerm) {
    $whereClause .= " AND (m.subject LIKE ? OR m.message LIKE ?)";
    $searchLike = "%$searchTerm%";
    $params[] = $searchLike;
    $params[] = $searchLike;
    $types .= "ss";
}

// Count total
$countSql = "SELECT COUNT(*) as total FROM messages m $whereClause";
$countStmt = $conn->prepare($countSql);
$countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalMessages = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = max(1, ceil($totalMessages / $perPage));

// Fetch messages
$sql = "SELECT m.*, 
               sender.full_name as sender_name, sender.username as sender_username, sender.user_type as sender_type,
               receiver.full_name as receiver_name, receiver.username as receiver_username, receiver.user_type as receiver_type
        FROM messages m
        JOIN users sender ON m.sender_id = sender.id
        JOIN users receiver ON m.receiver_id = receiver.id
        $whereClause
        ORDER BY m.created_at DESC
        LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;
$types .= "ii";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ============================================
// FETCH STATS
// ============================================
$stats = [
    'inbox_total' => 0,
    'inbox_unread' => 0,
    'sent_total' => 0,
    'starred' => 0,
    'archived' => 0
];

try {
    $res = $conn->query("SELECT COUNT(*) as c FROM messages WHERE receiver_id = $userId AND is_deleted_by_receiver = 0");
    if ($res) $stats['inbox_total'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM messages WHERE receiver_id = $userId AND is_read = 0 AND is_deleted_by_receiver = 0");
    if ($res) $stats['inbox_unread'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM messages WHERE sender_id = $userId AND is_deleted_by_sender = 0");
    if ($res) $stats['sent_total'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM messages WHERE (receiver_id = $userId OR sender_id = $userId) AND is_starred = 1");
    if ($res) $stats['starred'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM messages WHERE (receiver_id = $userId OR sender_id = $userId) AND is_archived = 1");
    if ($res) $stats['archived'] = $res->fetch_assoc()['c'];
} catch (Throwable $e) {}

// ============================================
// FETCH RECIPIENTS (for compose)
// ============================================
$recipients = [];
try {
    // Get all active users except current user
    $res = $conn->query("
        SELECT id, full_name, username, user_type, phone 
        FROM users 
        WHERE id != $userId AND status = 'active' 
        ORDER BY user_type DESC, full_name ASC
    ");
    if ($res) $recipients = $res->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// FETCH FULL MESSAGE (for viewing)
// ============================================
$viewMessage = null;
$conversation = [];

if (isset($_GET['view'])) {
    $viewId = intval($_GET['view']);
    if ($viewId) {
        $stmt = $conn->prepare("
            SELECT m.*, 
                   sender.full_name as sender_name, sender.username as sender_username, sender.user_type as sender_type,
                   receiver.full_name as receiver_name, receiver.username as receiver_username, receiver.user_type as receiver_type
            FROM messages m
            JOIN users sender ON m.sender_id = sender.id
            JOIN users receiver ON m.receiver_id = receiver.id
            WHERE m.id = ? AND (m.receiver_id = ? OR m.sender_id = ?)
        ");
        $stmt->bind_param("iii", $viewId, $userId, $userId);
        $stmt->execute();
        $viewMessage = $stmt->get_result()->fetch_assoc();
        
        if ($viewMessage) {
            // Mark as read if current user is receiver
            if ($viewMessage['receiver_id'] == $userId && !$viewMessage['is_read']) {
                $messageManager->markAsRead($viewId, $userId);
                $viewMessage['is_read'] = 1;
            }
            
            // Get conversation thread (if this is a reply)
            $otherUserId = ($viewMessage['sender_id'] == $userId) ? $viewMessage['receiver_id'] : $viewMessage['sender_id'];
            $conversation = $messageManager->getConversation($userId, $otherUserId);
        }
    }
}

// Helper: Format user type
function userTypeBadge($type) {
    $map = [
        'admin' => ['bg-danger', 'crown', 'Admin'],
        'seller' => ['bg-primary', 'store', 'Seller'],
        'customer' => ['bg-info', 'user', 'Customer']
    ];
    $info = $map[$type] ?? ['bg-secondary', 'user', ucfirst($type)];
    return '<span class="badge ' . $info[0] . '" style="font-size:0.65rem;"><i class="fas fa-' . $info[1] . '"></i> ' . $info[2] . '</span>';
}

?>

<!-- ============================================ -->
<!-- MESSAGES HEADER                             -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-envelope"></i> <?php echo t('messages'); ?></h2>
        <small class="text-muted">Communicate with sellers, customers, and admins</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#composeModal">
            <i class="fas fa-pen"></i> <?php echo t('new_message'); ?>
        </button>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<?php if ($viewMessage): ?>
<!-- ============================================ -->
<!-- MESSAGE VIEW MODE                           -->
<!-- ============================================ -->
<div class="row">
    <!-- Message List (Sidebar) -->
    <div class="col-lg-4 mb-3">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-inbox"></i> Recent Messages</h6>
                <a href="?page=messages" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-times"></i>
                </a>
            </div>
            <div class="card-body p-0" style="max-height:600px;overflow-y:auto;">
                <?php
                // Fetch recent inbox for sidebar
                try {
                    $recentStmt = $conn->prepare("
                        SELECT m.*, u.full_name as sender_name, u.username as sender_username
                        FROM messages m
                        JOIN users u ON m.sender_id = u.id
                        WHERE m.receiver_id = ? AND m.is_deleted_by_receiver = 0
                        ORDER BY m.created_at DESC
                        LIMIT 15
                    ");
                    $recentStmt->bind_param("i", $userId);
                    $recentStmt->execute();
                    $recentMessages = $recentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
                } catch (Throwable $e) {
                    $recentMessages = [];
                }
                ?>
                
                <?php if (count($recentMessages) > 0): ?>
                    <?php foreach ($recentMessages as $rm): 
                        $isCurrentView = ($rm['id'] == $viewMessage['id']);
                    ?>
                    <a href="?page=messages&view=<?php echo $rm['id']; ?>" 
                       class="d-block p-3 text-decoration-none border-bottom <?php echo $isCurrentView ? 'bg-primary bg-opacity-10' : ($rm['is_read'] ? '' : 'bg-info bg-opacity-10'); ?>"
                       style="border-color:var(--border-color) !important;">
                        <div class="d-flex align-items-start gap-2">
                            <div class="avatar" style="width:32px;height:32px;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:0.8rem;flex-shrink:0;">
                                <?php echo strtoupper(substr($rm['sender_name'], 0, 1)); ?>
                            </div>
                            <div style="min-width:0;flex:1;">
                                <div class="fw-semibold text-truncate small" style="color:var(--text-primary);">
                                    <?php echo htmlspecialchars($rm['sender_name']); ?>
                                    <?php if (!$rm['is_read']): ?>
                                    <span class="badge bg-primary ms-1" style="font-size:0.55rem;">NEW</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-truncate small" style="color:var(--text-body);">
                                    <?php echo htmlspecialchars($rm['subject'] ?: 'No subject'); ?>
                                </div>
                                <div class="text-muted" style="font-size:0.7rem;">
                                    <?php 
                                    $diff = time() - strtotime($rm['created_at']);
                                    if ($diff < 60) echo 'Just now';
                                    elseif ($diff < 3600) echo floor($diff / 60) . 'm ago';
                                    elseif ($diff < 86400) echo floor($diff / 3600) . 'h ago';
                                    else echo date('d M', strtotime($rm['created_at']));
                                    ?>
                                </div>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="p-4 text-center text-muted">
                        <i class="fas fa-inbox"></i>
                        <p class="small mb-0">No messages</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Message Detail -->
    <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header bg-white">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div>
                        <h5 class="mb-1"><?php echo htmlspecialchars($viewMessage['subject'] ?: '(No Subject)'); ?></h5>
                        <div class="small text-muted">
                            <?php echo userTypeBadge($viewMessage['sender_type']); ?>
                            From: <strong><?php echo htmlspecialchars($viewMessage['sender_name']); ?></strong>
                            &lt;<?php echo htmlspecialchars($viewMessage['sender_username']); ?>&gt;
                        </div>
                    </div>
                    <div class="text-end">
                        <div class="small text-muted">
                            <?php echo date('d M Y H:i', strtotime($viewMessage['created_at'])); ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card-body">
                <!-- Recipient -->
                <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom" style="border-color:var(--border-color) !important;">
                    <div class="small">
                        <?php echo t('to'); ?>: <?php echo userTypeBadge($viewMessage['receiver_type']); ?>
                        <strong><?php echo htmlspecialchars($viewMessage['receiver_name']); ?></strong>
                        &lt;<?php echo htmlspecialchars($viewMessage['receiver_username']); ?>&gt;
                    </div>
                    <div class="d-flex gap-1">
                        <?php if ($viewMessage['receiver_id'] == $userId): ?>
                        <a href="?page=messages&mark_unread=<?php echo $viewMessage['id']; ?>" 
                           class="btn btn-sm btn-outline-secondary" title="Mark unread">
                            <i class="fas fa-envelope"></i>
                        </a>
                        <?php endif; ?>
                        <a href="?page=messages&star=<?php echo $viewMessage['id']; ?>&value=<?php echo $viewMessage['is_starred'] ? 0 : 1; ?>" 
                           class="btn btn-sm btn-outline-<?php echo $viewMessage['is_starred'] ? 'warning' : 'secondary'; ?>">
                            <i class="fas fa-star<?php echo $viewMessage['is_starred'] ? '' : '-o'; ?>"></i>
                        </a>
                        <a href="?page=messages&archive=<?php echo $viewMessage['id']; ?>&value=<?php echo $viewMessage['is_archived'] ? 0 : 1; ?>" 
                           class="btn btn-sm btn-outline-info" title="<?php echo $viewMessage['is_archived'] ? 'Unarchive' : 'Archive'; ?>">
                            <i class="fas fa-archive"></i>
                        </a>
                        <a href="?page=messages&delete=<?php echo $viewMessage['id']; ?>" 
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Delete this message?');">
                            <i class="fas fa-trash"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Message Content -->
                <div class="mb-4" style="white-space:pre-wrap;line-height:1.7;">
                    <?php echo nl2br(htmlspecialchars($viewMessage['message'])); ?>
                </div>
                
                <!-- Reply / Actions -->
                <hr style="border-color:var(--border-color);">
                
                <div class="d-flex gap-2 flex-wrap">
                    <?php 
                    $replyTo = ($viewMessage['sender_id'] == $userId) ? $viewMessage['receiver_id'] : $viewMessage['sender_id'];
                    $replyName = ($viewMessage['sender_id'] == $userId) ? $viewMessage['receiver_name'] : $viewMessage['sender_name'];
                    ?>
                    <button type="button" class="btn btn-primary btn-sm" 
                            onclick="openReply(<?php echo $replyTo; ?>, '<?php echo addslashes('Re: ' . ($viewMessage['subject'] ?: 'No Subject')); ?>', <?php echo $viewMessage['id']; ?>)">
                        <i class="fas fa-reply"></i> <?php echo t('reply'); ?> to <?php echo htmlspecialchars($replyName); ?>
                    </button>
                    <button type="button" class="btn btn-outline-primary btn-sm"
                            onclick="openReply(<?php echo $replyTo; ?>, '<?php echo addslashes('Re: ' . ($viewMessage['subject'] ?: 'No Subject')); ?>', <?php echo $viewMessage['id']; ?>)">
                        <i class="fas fa-reply-all"></i> Reply
                    </button>
                    <a href="?page=messages" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left"></i> Back to Inbox
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Conversation Thread -->
        <?php if (count($conversation) > 1): ?>
        <div class="card mt-3">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-comments"></i> Conversation Thread (<?php echo count($conversation); ?> messages)</h6>
            </div>
            <div class="card-body p-0" style="max-height:400px;overflow-y:auto;">
                <?php foreach ($conversation as $convMsg): 
                    $isOwn = ($convMsg['sender_id'] == $userId);
                    $isCurrent = ($convMsg['id'] == $viewMessage['id']);
                ?>
                <div class="p-3 border-bottom <?php echo $isCurrent ? 'bg-primary bg-opacity-10' : ''; ?>" 
                     style="border-color:var(--border-color) !important;">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <div class="small fw-semibold <?php echo $isOwn ? 'text-primary' : 'text-info'; ?>">
                            <i class="fas fa-<?php echo $isOwn ? 'paper-plane' : 'user'; ?>"></i>
                            <?php echo $isOwn ? 'You' : htmlspecialchars($convMsg['sender_name']); ?>
                            <?php if ($isCurrent): ?>
                            <span class="badge bg-primary" style="font-size:0.6rem;">Current</span>
                            <?php endif; ?>
                        </div>
                        <small class="text-muted"><?php echo date('d M H:i', strtotime($convMsg['created_at'])); ?></small>
                    </div>
                    <div class="small text-truncate" style="color:var(--text-body);">
                        <?php echo htmlspecialchars(substr($convMsg['message'], 0, 100)); ?><?php echo strlen($convMsg['message']) > 100 ? '...' : ''; ?>
                    </div>
                    <?php if (!$isCurrent): ?>
                    <a href="?page=messages&view=<?php echo $convMsg['id']; ?>" class="small">
                        <i class="fas fa-eye"></i> View
                    </a>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php else: ?>
<!-- ============================================ -->
<!-- MESSAGES LIST MODE                          -->
<!-- ============================================ -->

<!-- Stats Cards -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-2">
        <a href="?page=messages&tab=inbox" class="text-decoration-none">
            <div class="analytics-card text-center <?php echo $tab === 'inbox' ? 'border-primary' : ''; ?>">
                <div class="metric-label"><i class="fas fa-inbox text-primary"></i> <?php echo t('inbox'); ?></div>
                <div class="metric-value"><?php echo number_format($stats['inbox_total']); ?></div>
                <?php if ($stats['inbox_unread'] > 0): ?>
                <small class="text-danger">
                    <i class="fas fa-circle"></i> <?php echo $stats['inbox_unread']; ?> unread
                </small>
                <?php endif; ?>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <a href="?page=messages&tab=sent" class="text-decoration-none">
            <div class="analytics-card text-center <?php echo $tab === 'sent' ? 'border-primary' : ''; ?>">
                <div class="metric-label"><i class="fas fa-paper-plane text-success"></i> <?php echo t('sent'); ?></div>
                <div class="metric-value text-success"><?php echo number_format($stats['sent_total']); ?></div>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <a href="?page=messages&tab=starred" class="text-decoration-none">
            <div class="analytics-card text-center <?php echo $tab === 'starred' ? 'border-primary' : ''; ?>">
                <div class="metric-label"><i class="fas fa-star text-warning"></i> Starred</div>
                <div class="metric-value text-warning"><?php echo number_format($stats['starred']); ?></div>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <a href="?page=messages&tab=archived" class="text-decoration-none">
            <div class="analytics-card text-center <?php echo $tab === 'archived' ? 'border-primary' : ''; ?>">
                <div class="metric-label"><i class="fas fa-archive text-info"></i> Archived</div>
                <div class="metric-value text-info"><?php echo number_format($stats['archived']); ?></div>
            </div>
        </a>
    </div>
</div>

<!-- Tabs & Search -->
<div class="card mb-4">
    <div class="card-body py-3">
        <div class="row g-2 align-items-center">
            <div class="col-md-6">
                <ul class="nav nav-tabs border-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $tab === 'inbox' ? 'active' : ''; ?>" href="?page=messages&tab=inbox">
                            <i class="fas fa-inbox"></i> <?php echo t('inbox'); ?>
                            <?php if ($stats['inbox_unread'] > 0): ?>
                            <span class="badge bg-danger ms-1"><?php echo $stats['inbox_unread']; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $tab === 'sent' ? 'active' : ''; ?>" href="?page=messages&tab=sent">
                            <i class="fas fa-paper-plane"></i> <?php echo t('sent'); ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $tab === 'starred' ? 'active' : ''; ?>" href="?page=messages&tab=starred">
                            <i class="fas fa-star"></i> Starred
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $tab === 'archived' ? 'active' : ''; ?>" href="?page=messages&tab=archived">
                            <i class="fas fa-archive"></i> Archive
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-6">
                <form method="GET" class="d-flex gap-2">
                    <input type="hidden" name="page" value="messages">
                    <input type="hidden" name="tab" value="<?php echo htmlspecialchars($tab); ?>">
                    <input type="text" name="search" class="form-control form-control-sm" 
                           placeholder="<?php echo t('search_placeholder'); ?>" value="<?php echo htmlspecialchars($searchTerm); ?>">
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="fas fa-search"></i>
                    </button>
                    <?php if ($searchTerm): ?>
                    <a href="?page=messages&tab=<?php echo $tab; ?>" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-times"></i>
                    </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Messages Table -->
<form method="POST" id="bulkForm">
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h6 class="mb-0">
                <i class="fas fa-<?php 
                    echo $tab === 'inbox' ? 'inbox' : 
                        ($tab === 'sent' ? 'paper-plane' : 
                        ($tab === 'starred' ? 'star' : 'archive')); 
                ?>"></i> 
                <?php echo ucfirst($tab); ?>
                <small class="text-muted ms-2">(<?php echo number_format($totalMessages); ?> messages)</small>
            </h6>
            <?php if (count($messages) > 0): ?>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="selectAllMessages" onchange="toggleAll(this)">
                <label class="form-check-label small" for="selectAllMessages">Select all</label>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="card-body p-0">
            <?php if (count($messages) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th style="width:40px;"></th>
                                <th style="width:40px;"></th>
                                <th style="width:40px;"></th>
                                <th>
                                    <?php echo $tab === 'sent' ? 'To' : 'From'; ?>
                                </th>
                                <th>Subject</th>
                                <th style="width:120px;">Date</th>
                                <th style="width:80px;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($messages as $m): 
                                $isInbox = ($m['receiver_id'] == $userId);
                                $otherName = $isInbox ? $m['sender_name'] : $m['receiver_name'];
                                $otherUsername = $isInbox ? $m['sender_username'] : $m['receiver_username'];
                                $otherType = $isInbox ? $m['sender_type'] : $m['receiver_type'];
                                $isUnread = $isInbox && !$m['is_read'];
                            ?>
                            <tr class="<?php echo $isUnread ? 'bg-primary bg-opacity-10 fw-semibold' : ''; ?>">
                                <td>
                                    <input type="checkbox" name="message_ids[]" value="<?php echo $m['id']; ?>" 
                                           class="message-checkbox session-checkbox" onchange="updateBulkBar()">
                                </td>
                                <td>
                                    <a href="?page=messages&star=<?php echo $m['id']; ?>&value=<?php echo $m['is_starred'] ? 0 : 1; ?>" 
                                       class="text-decoration-none" title="<?php echo $m['is_starred'] ? 'Unstar' : 'Star'; ?>">
                                        <i class="fas fa-star<?php echo $m['is_starred'] ? ' text-warning' : '-o text-muted'; ?>"></i>
                                    </a>
                                </td>
                                <td>
                                    <?php if ($isUnread): ?>
                                    <i class="fas fa-circle text-primary" style="font-size:0.6rem;"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="avatar" style="width:28px;height:28px;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:0.7rem;flex-shrink:0;">
                                            <?php echo strtoupper(substr($otherName, 0, 1)); ?>
                                        </div>
                                        <div style="min-width:0;">
                                            <div class="text-truncate" style="font-size:0.85rem;">
                                                <?php echo htmlspecialchars($otherName); ?>
                                            </div>
                                            <div class="text-muted" style="font-size:0.7rem;">
                                                <?php echo userTypeBadge($otherType); ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <a href="?page=messages&view=<?php echo $m['id']; ?>" 
                                       class="text-decoration-none" style="color:var(--text-body);">
                                        <div class="text-truncate" style="max-width:300px;">
                                            <?php echo htmlspecialchars($m['subject'] ?: '(No Subject)'); ?>
                                        </div>
                                        <div class="text-muted text-truncate" style="font-size:0.75rem;max-width:300px;">
                                            <?php echo htmlspecialchars(substr($m['message'], 0, 60)); ?><?php echo strlen($m['message']) > 60 ? '...' : ''; ?>
                                        </div>
                                    </a>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php 
                                        $diff = time() - strtotime($m['created_at']);
                                        if ($diff < 60) echo 'Just now';
                                        elseif ($diff < 3600) echo floor($diff / 60) . 'm ago';
                                        elseif ($diff < 86400) echo floor($diff / 3600) . 'h ago';
                                        elseif ($diff < 604800) echo floor($diff / 86400) . 'd ago';
                                        else echo date('d M Y', strtotime($m['created_at']));
                                        ?>
                                    </small>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item" href="?page=messages&view=<?php echo $m['id']; ?>">
                                                <i class="fas fa-eye"></i> <?php echo t('view'); ?? 'View'; ?>
                                            </a></li>
                                            <?php if ($isInbox && !$m['is_read']): ?>
                                            <li><a class="dropdown-item" href="?page=messages&mark_read=<?php echo $m['id']; ?>">
                                                <i class="fas fa-check"></i> Mark Read
                                            </a></li>
                                            <?php endif; ?>
                                            <?php if ($isInbox && $m['is_read']): ?>
                                            <li><a class="dropdown-item" href="?page=messages&mark_unread=<?php echo $m['id']; ?>">
                                                <i class="fas fa-envelope"></i> Mark Unread
                                            </a></li>
                                            <?php endif; ?>
                                            <li><a class="dropdown-item" href="?page=messages&star=<?php echo $m['id']; ?>&value=<?php echo $m['is_starred'] ? 0 : 1; ?>">
                                                <i class="fas fa-star"></i> <?php echo $m['is_starred'] ? 'Unstar' : 'Star'; ?>
                                            </a></li>
                                            <li><a class="dropdown-item" href="?page=messages&archive=<?php echo $m['id']; ?>&value=<?php echo $m['is_archived'] ? 0 : 1; ?>">
                                                <i class="fas fa-archive"></i> <?php echo $m['is_archived'] ? 'Unarchive' : 'Archive'; ?>
                                            </a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item text-danger" href="?page=messages&delete=<?php echo $m['id']; ?>"
                                                   onclick="return confirm('Delete this message?');">
                                                <i class="fas fa-trash"></i> <?php echo t('delete'); ?? 'Delete'; ?>
                                            </a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Bulk Actions Bar -->
                <div class="bulk-actions-bar" id="bulkActionsBar" style="display:none;">
                    <div>
                        <span id="selectedCount">0</span> message(s) selected
                    </div>
                    <div class="d-flex gap-2 flex-wrap">
                        <button type="submit" name="bulk_action" value="mark_read" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-check"></i> Mark Read
                        </button>
                        <button type="submit" name="bulk_action" value="mark_unread" class="btn btn-sm btn-outline-info">
                            <i class="fas fa-envelope"></i> Mark Unread
                        </button>
                        <button type="submit" name="bulk_action" value="archive" class="btn btn-sm btn-outline-warning">
                            <i class="fas fa-archive"></i> Archive
                        </button>
                        <button type="submit" name="bulk_action" value="delete" class="btn btn-sm btn-danger"
                                onclick="return confirm('Delete selected messages?');">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                </div>
            <?php else: ?>
                <div class="empty-state py-5">
                    <i class="fas fa-<?php 
                        echo $tab === 'inbox' ? 'inbox' : 
                            ($tab === 'sent' ? 'paper-plane' : 
                            ($tab === 'starred' ? 'star' : 'archive')); 
                    ?>"></i>
                    <h5>
                        <?php if ($searchTerm): ?>
                            No matching messages
                        <?php elseif ($tab === 'inbox'): ?>
                            Your inbox is empty
                        <?php elseif ($tab === 'sent'): ?>
                            No sent messages
                        <?php elseif ($tab === 'starred'): ?>
                            No starred messages
                        <?php else: ?>
                            No archived messages
                        <?php endif; ?>
                    </h5>
                    <p class="text-muted">
                        <?php if ($searchTerm): ?>
                            Try a different search term. <a href="?page=messages&tab=<?php echo $tab; ?>">Clear search</a>
                        <?php else: ?>
                            Messages you receive will appear here.
                        <?php endif; ?>
                    </p>
                    <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#composeModal">
                        <i class="fas fa-pen"></i> <?php echo t('new_message'); ?>
                    </button>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="card-footer bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <small class="text-muted">
                <?php echo t('page'); ?> <?php echo $pageNum; ?> <?php echo t('of'); ?> <?php echo $totalPages; ?>
            </small>
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($pageNum > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=messages&tab=<?php echo $tab; ?>&p=<?php echo $pageNum - 1; ?>&search=<?php echo urlencode($searchTerm); ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php
                    $startPage = max(1, $pageNum - 2);
                    $endPage = min($totalPages, $pageNum + 2);
                    for ($i = $startPage; $i <= $endPage; $i++):
                    ?>
                    <li class="page-item <?php echo $i == $pageNum ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=messages&tab=<?php echo $tab; ?>&p=<?php echo $i; ?>&search=<?php echo urlencode($searchTerm); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if ($pageNum < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=messages&tab=<?php echo $tab; ?>&p=<?php echo $pageNum + 1; ?>&search=<?php echo urlencode($searchTerm); ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</form>

<?php endif; ?>

<!-- ============================================ -->
<!-- COMPOSE MESSAGE MODAL                       -->
<!-- ============================================ -->
<div class="modal fade" id="composeModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="composeForm">
                <input type="hidden" name="parent_id" id="composeParentId" value="">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-pen text-primary"></i> <?php echo t('new_message'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('to'); ?> <span class="text-danger">*</span></label>
                        <select name="receiver_id" class="form-select" id="composeReceiver" required>
                            <option value="">-- Select recipient --</option>
                            <?php 
                            $groupedRecipients = ['admin' => [], 'seller' => [], 'customer' => []];
                            foreach ($recipients as $rec) {
                                $groupedRecipients[$rec['user_type']][] = $rec;
                            }
                            ?>
                            <?php if (!empty($groupedRecipients['admin'])): ?>
                            <optgroup label="Admins">
                                <?php foreach ($groupedRecipients['admin'] as $rec): ?>
                                <option value="<?php echo $rec['id']; ?>">
                                    <?php echo htmlspecialchars($rec['full_name']); ?> (<?php echo htmlspecialchars($rec['username']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endif; ?>
                            
                            <?php if (!empty($groupedRecipients['seller'])): ?>
                            <optgroup label="Sellers">
                                <?php foreach ($groupedRecipients['seller'] as $rec): ?>
                                <option value="<?php echo $rec['id']; ?>">
                                    <?php echo htmlspecialchars($rec['full_name']); ?> (<?php echo htmlspecialchars($rec['username']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endif; ?>
                            
                            <?php if (!empty($groupedRecipients['customer'])): ?>
                            <optgroup label="Customers">
                                <?php foreach ($groupedRecipients['customer'] as $rec): ?>
                                <option value="<?php echo $rec['id']; ?>">
                                    <?php echo htmlspecialchars($rec['full_name']); ?> (<?php echo htmlspecialchars($rec['username']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('subject'); ?></label>
                        <input type="text" name="subject" class="form-control" id="composeSubject" 
                               placeholder="Message subject" maxlength="255">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('message'); ?> <span class="text-danger">*</span></label>
                        <textarea name="message" class="form-control" id="composeMessage" rows="8" 
                                  placeholder="Type your message here..." required></textarea>
                        <div class="d-flex justify-content-between mt-1">
                            <small class="text-muted">
                                <i class="fas fa-info-circle"></i> 
                                Be clear and professional
                            </small>
                            <small class="text-muted" id="charCount">0 characters</small>
                        </div>
                    </div>
                    
                    <div class="alert alert-info small mb-0">
                        <i class="fas fa-shield-alt"></i>
                        Messages are private between you and the recipient. Admins may review for support purposes.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="submit" name="send_message" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> <?php echo t('send'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- QUICK REPLY MODAL                           -->
<!-- ============================================ -->
<div class="modal fade" id="quickReplyModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="receiver_id" id="quickReplyReceiver">
                <input type="hidden" name="parent_id" id="quickReplyParent">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-reply text-primary"></i> Quick Reply</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info small" id="quickReplyInfo">
                        Replying to message...
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('subject'); ?></label>
                        <input type="text" name="subject" class="form-control" id="quickReplySubject">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('message'); ?> <span class="text-danger">*</span></label>
                        <textarea name="message" class="form-control" rows="5" required 
                                  placeholder="Type your reply..." autofocus></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="submit" name="send_message" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> <?php echo t('send'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Toggle all checkboxes
function toggleAll(checkbox) {
    document.querySelectorAll('.message-checkbox').forEach(cb => cb.checked = checkbox.checked);
    updateBulkBar();
}

// Update bulk actions bar
function updateBulkBar() {
    const checked = document.querySelectorAll('.message-checkbox:checked');
    const bar = document.getElementById('bulkActionsBar');
    const count = document.getElementById('selectedCount');
    if (bar) bar.style.display = checked.length > 0 ? 'flex' : 'none';
    if (count) count.textContent = checked.length;
}

// Open reply modal
function openReply(userId, subject, parentId) {
    document.getElementById('quickReplyReceiver').value = userId;
    document.getElementById('quickReplySubject').value = subject;
    document.getElementById('quickReplyParent').value = parentId || '';
    new bootstrap.Modal(document.getElementById('quickReplyModal')).show();
}

// Character counter for compose
document.addEventListener('DOMContentLoaded', function() {
    const composeMessage = document.getElementById('composeMessage');
    const charCount = document.getElementById('charCount');
    
    if (composeMessage && charCount) {
        composeMessage.addEventListener('input', function() {
            charCount.textContent = this.value.length + ' characters';
        });
    }
    
    // Auto-focus first input in modals
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('shown.bs.modal', function() {
            const firstInput = this.querySelector('input:not([type="hidden"]), textarea');
            if (firstInput) firstInput.focus();
        });
    });
});

// Auto-refresh unread count
(function() {
    setInterval(function() {
        if (document.querySelector('.modal.show')) return;
        fetch('?ajax=get_unread_counts')
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    // Update sidebar badges silently
                    document.querySelectorAll('.notification-bell .badge').forEach(el => {
                        if (data.messages > 0) {
                            el.textContent = data.messages > 9 ? '9+' : data.messages;
                            el.style.display = 'block';
                        }
                    });
                }
            })
            .catch(() => {});
    }, 60000);
})();
</script>