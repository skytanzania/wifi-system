<?php
/**
 * ============================================================================
 *  SKYTANZA WIFI — OMADA EAP225 + EXTERNAL RADIUS EDITION (v6.6.1 · Admin-managed Omada · Sonic Pesa · HTTPS browserauth)
 *  ONE file (index.php) that is BOTH:
 *    1) the website on cPanel shared hosting (sellers, vouchers, captive portal, payments)
 *    2) the EXTERNAL RADIUS SERVER when started on a VPS/PC:  php index.php radius-server
 *  PHP 8.0+  |  MySQL 5.7+ / MariaDB 10.3+ (website only — the RADIUS box needs no database)
 * ============================================================================
 *
 *   Phone ──WiFi──► EAP225 ──► Omada Controller (Software / OC200 / Cloud)
 *     │                               │  RADIUS  UDP 1812 (auth)  /  UDP 1813 (accounting)
 *     │ captive portal (HTTPS)         ▼
 *     └──► index.php?page=portal    RADIUS SERVER = this same file running on a VPS/PC
 *              ▲                       │   php index.php radius-server
 *              └──── HTTPS API ◄───────┘   (?radius=clients / authorize / accounting / dae_queue)
 *
 *  • Every EAP225 a seller adds gets its OWN auto-generated RADIUS passwords, shown on
 *    Devices → "RADIUS settings" ready to copy into Omada:
 *       RADIUS Server IP · Authentication Port 1812 (fixed) · Authentication Password
 *       Accounting Server IP · Accounting Port 1813 (fixed) · Accounting Password
 *  • v5.1 — NAS ID FROM OMADA: the NAS ID is whatever TP-Link Omada sends in the
 *    NAS-Identifier attribute. The RADIUS server identifies each hotspot by its own
 *    passwords (Message-Authenticator / PAP / Accounting authenticator), reads the NAS ID
 *    Omada sent and saves it on the device automatically.
 *  • v5.2 — NEW UI: fresh design system (dark + light themes), glass captive portal,
 *    modern printable voucher cards, non-blocking font/icon loading, deferred scripts,
 *    background-tab-aware live polling. All features and logic unchanged.
 *  • Replies carry Session-Timeout, Idle-Timeout, Acct-Interim-Interval (60 s) and
 *    WISPr bandwidth. Accounting (Start / Interim / Stop) tracks time and data per voucher.
 *  • Kick / block uses RFC 5176 Disconnect-Request to the NAS on UDP 3799 (optional),
 *    carrying the NAS-Identifier exactly as Omada sent it.
 *  • Housekeeping runs as "lazy cron" on RADIUS traffic — a cPanel cron job is optional.
 *  • v5.3 — OMADA CONTROLLER INTEGRATION (official Omada Open API, Client Credentials mode):
 *      - "Omada Controller" page: connect a Software Controller / OC200 / OC300 / Cloud-Based
 *        Controller with Omada ID + Client ID + Client Secret (Settings → Platform Integration).
 *      - Controller Inform URL: stored per controller and shown with step-by-step adoption
 *        instructions (EAP225 standalone UI / Omada Discovery Utility, ports 29810-29817).
 *      - Lists sites and APs live from the controller, adopts (claims) PENDING EAPs with the
 *        device username/password, reboots APs, imports APs as hotspots in one click.
 *      - Background sync keeps each hotspot's Omada status (CONNECTED / PENDING / OFFLINE),
 *        model, IP, firmware and client count; the seller is notified when an AP goes offline.
 *      - Endpoint paths are auto-checked against the controller's own OpenAPI spec.
 *  • v5.3 FIXES: redirects after "Save device" use an absolute path (303); the website URL is
 *    auto-detected (no more wrong default domain); the External Web Portal URL is now a clean
 *    URL without "?page=portal" (Omada appends "?clientMac=..." itself) and broken legacy
 *    portal URLs are repaired automatically.
 *  • v5.4 — OMADA CLOUD AUTO-SETUP FROM THE INFORM URL:
 *      - Paste the device Inform URL from Omada Central, e.g.
 *          omada://euw1-omada-essential-device.tplinkcloud.com?dPort=29810&mPort=443&omadacId=...
 *        The Omada ID and the regional Open API address (https://euw1-omada-northbound.tplinkcloud.com)
 *        are read from it automatically. The Inform URL alone registers the controller and is shown
 *        to the seller for provisioning the EAP225.
 *      - With an Open API app (Client ID + Client Secret, Settings → Platform Integration → Open API —
 *        TP-Link offers it on Omada Central Standard / local controllers, not on Essentials), "Add EAP225"
 *        does EVERYTHING through the Omada Open API: create the site (or use one), add the EAP225 by
 *        serial number, create the SSID, the RADIUS profile (this server's passwords), the External RADIUS
 *        portal with NAS ID + External Web Portal URL, Pre-Authentication Access, and the vouchers
 *        (SkyTanza RADIUS vouchers, or Omada Hotspot voucher groups generated in Omada).
 *      - "Start provisioning": the seller sets the Inform URL on the EAP225, presses the button and watches
 *        it go PENDING → ADOPTING → PROVISIONING → CONNECTED (adopted automatically through the API).
 *  • v5.4.1 FIXES: no more HTTP 500 on hosts that disable set_time_limit / usleep / sleep / gethostbyname
 *    (calls go through canCall()); the auto-setup works inside the host's time limit and continues on
 *    "Run setup again"; any crash now shows a readable error page (admins see the exact message) and is
 *    listed under Admin → RADIUS Setup → Recent server errors.
 *  • v5.5 — ROUTERS + HOTSPOT MENUS (Omada Cloud without Client ID / Client Secret):
 *      - Side menu "Routers": Add router → choose the model (TP-Link Omada EAP225) → enter all router data
 *        (name, AP MAC, serial, EAP225 login, SSID, Omada Cloud Inform URL, site, location, payment info, vouchers).
 *      - Side menu "Hotspot": pick a router → provision & connect it (Inform URL on the EAP225, adopt in Omada Central,
 *        RADIUS profile + External RADIUS portal sheet, live "Provision & connect" check until the first RADIUS login).
 *      - Modern Omada Cloud (Omada Central) does not show a Client ID / Client Secret, so the system no longer asks for them:
 *        an Omada Cloud is linked with its Inform URL only. Keys saved by older versions keep working unchanged.
 *      - New tables (created automatically): hs_router_models (supported router models) and hs_provision_runs
 *        (provisioning / connection history per router). hs_devices gets router_model_id.
 *
 *  • v5.6 — FULL OMADA OPEN API (Client ID + Client Secret) — optional, added on top of v5.5:
 *      - Menu "Omada Cloud" / Routers → Add router: paste the Inform URL AND (optionally) the Open API Client ID +
 *        Client Secret (Omada → Global View → Settings → Platform Integration → Open API → Add New App, mode "Client").
 *        With the keys every router is provisioned automatically through the Open API: site, EAP225 by S/N, adoption,
 *        SSID, RADIUS profile, External RADIUS portal, Pre-Authentication Access and vouchers. Without the keys v5.5
 *        works exactly as before (Inform URL + settings sheet).
 *      - "Check all Open API features": probes token, sites, scenarios, devices, clients, WLANs/SSIDs, RADIUS profiles,
 *        portals, access control and hotspot voucher groups and reports what this controller allows.
 *      - Seller management linked to the controller: live Omada clients per site and per EAP225, Block / Unblock /
 *        Reconnect from the website; "Disconnect" and "Block device" on Live Sessions are also applied in Omada;
 *        create Omada sites from the website; admin sees each seller's controllers and Open API status.
 *
 *  • v5.7 — OMADA LINK ENGINE (Router ↔ Omada controller ↔ RADIUS server ↔ website):
 *      - Hotspot → router → "Connection health": 14 live checks along the chain Phone → EAP225 → Omada → RADIUS → Website
 *        (RADIUS Server IP, RADIUS box heartbeat + version, wrong passwords seen by the RADIUS box, Omada token, site, EAP225
 *        status, SSID open, RADIUS profile IP/ports, portal NAS ID / SSID / External Web Portal URL, Pre-Authentication Access,
 *        phones reaching the portal, RADIUS traffic). "Fix automatically" re-runs the idempotent Open API setup and adoption.
 *      - Omada request bodies are sent in several shapes (newer / older firmware) until the controller accepts one.
 *      - SSID management per Omada site: list, create hotspot (open) or private WPA2 SSIDs, delete.
 *      - Changing the RADIUS Server IP / website URL marks every Omada router for a push: admin "Push to all Omada routers",
 *        seller "Sync all my routers with Omada"; sellers without Open API keys are notified to update Omada by hand.
 *      - The portal records when Omada redirects a phone and where Omada's portal service lives (used for browserauth).
 *      - RADIUS server answers Status-Server (RFC 5997); Omada Open API calls work on hosts without gethostbyname()
 *        and always send a JSON body on POST/PATCH (adopt, reboot, block, reconnect).
 *      - New columns (created automatically): hs_devices.health_json, health_at, portal_seen_at, portal_target.
 *
 *  • v5.7.1 — SECURITY + FIXES:
 *      - No passwords or API keys inside index.php any more: the database password and the Sonic Pesa keys come only from
 *        config.local.php (so "Download index.php" for the RADIUS box no longer ships them). A missing DB password shows a
 *        clear setup page instead of a blank error.
 *      - Admin → "Security check": default admin password, default APP_SECRET / CRON / webhook / RADIUS keys, missing
 *        config.local.php and missing Sonic Pesa keys, with ready-to-paste config lines.
 *      - Changing APP_SECRET no longer loses saved EAP225 logins (old secret is tried when opening them).
 *      - The RADIUS API key is accepted only in the X-API-KEY header (never in the URL, where it ends up in access logs).
 *      - FIX: changing the Public website URL now correctly marks every Omada router for a push.
 *      - FIX: the serial number (S/N) typed on Routers → Edit router is saved even without "Run setup again".
 *      - FIX: the first automatic health check on a Hotspot page is limited to ~15 s so the page never hangs.
 *      - Withdrawals are refused with a clear message (no API call) while the Sonic Pesa keys are not configured.
 *
 *  • v5.7.2 — REDIRECT-PROOF RADIUS ↔ WEBSITE LINK:
 *      - Hosts that rewrite /index.php → /index (or http → https, www ↔ no-www) answered the RADIUS box with
 *        "301 Moved Permanently", so it could not reach the website. The RADIUS box now follows those redirects itself
 *        and keeps POST + body + X-API-KEY (only to the SAME host, never https → http), tries /index, /index.php and /
 *        when the API answers with something that is not JSON, and remembers the address that works
 *        (radius-api-url.json next to index.php). "--test" prints the exact RADIUS_API_URL to put in config.local.php.
 *      - Admin → RADIUS Setup → "Website API endpoint": the website checks its own API address, shows any redirect,
 *        puts the working address in the RADIUS box config and gives the .htaccess lines that stop the redirect.
 *      - Payment callbacks, the External Web Portal URL and the PWA service worker use the working address too,
 *        and redirects after a form POST stay on the address the browser already uses (no extra 301 hop).
 *
 *  • v5.8 — ONE OMADA INFORM URL FOR EVERY ROUTER:
 *      - The system uses this Omada Inform URL (Omada Cloud format) for every router that is added:
 *          omada://65.109.35.14?dPort=29810&mPort=29814&omadacId=6acf85545651212b5ca146e6
 *        Each seller gets an Omada controller link for it automatically (Omada ID read from the URL), every new router —
 *        and every router that was not linked yet — is linked to it, and its Inform URL is shown on Routers / Hotspot.
 *      - Inform URLs of a self-hosted controller (an IP instead of *.tplinkcloud.com) are accepted everywhere now; the
 *        Open API address defaults to https://<IP>:8043 and the reachability check uses the mPort from the URL.
 *      - Change it under Admin → RADIUS Setup ("Default Omada Inform URL") or with define('OMADA_DEFAULT_INFORM_URL', '...').
 *
 *  • v5.9 — OMADA RELAY THROUGH THE EXTERNAL RADIUS SERVER (for shared hosting):
 *      - cPanel shared hosting usually blocks outgoing connections to ports such as 8043 / 29814, so the website could not
 *        reach a self-hosted Omada controller (e.g. 65.109.35.14). Every Omada Open API call can now travel through the
 *        RADIUS box: the website queues the request in the database, the RADIUS box (which already talks to the website over
 *        HTTPS) picks it up with a long-poll, calls the controller itself and sends the answer back. No extra port is opened
 *        on the VPS — the RADIUS box only makes outgoing connections, exactly like before.
 *      - "php index.php radius-server" starts the relay automatically as a second process (pcntl). Without pcntl run
 *        "php index.php omada-relay" as its own service. "--test" also checks that the RADIUS box reaches every controller.
 *      - Each Omada controller has a "Connection route": Automatic (self-hosted controllers go through the RADIUS server,
 *        TP-Link cloud goes direct and falls back to the relay on a connection error) · Direct · Via RADIUS server.
 *      - Admin → RADIUS Setup: default Open API Client ID + Client Secret for the default Inform URL controller, shared with
 *        every seller automatically (each seller only sees the Omada sites of his own routers).
 *      - The reachability check of a self-hosted controller now tests the API port (8043) and the device port (mPort) from
 *        the RADIUS server, with clear messages instead of "Omada Cloud device gateway is not reachable".
 *
 *  • v6.0 — OMADA MANAGER (Omada Open API, controller on your VPS / OC200 / Omada Cloud):
 *      - New menu "Omada Manager": pick a controller + site and manage everything from the website —
 *        Sites: create (owned by the seller, also with shared platform keys), delete, live counts.
 *        Devices: add an EAP225 by serial number, adopt PENDING, rename, locate, reboot, forget, and turn it into a hotspot
 *        (router record + full auto-setup: SSID, RADIUS profile, External RADIUS portal, Pre-Authentication Access) in one form.
 *        Vouchers: create Omada Hotspot voucher groups from packages, import groups made in Omada, print them, see every code's
 *        state (unused / in use / expired), delete one code or a whole group; states sync back into the website automatically.
 *        Clients: live phones per site with block / unblock / reconnect.
 *      - Admin: copy-paste VPS kit to install the Omada Software Controller (Docker) next to the RADIUS server.
 *      - New tables (created automatically): hs_omada_sites, hs_omada_vgroups; hs_vouchers gets ext_vid.
 *
 *  • v6.1 — OMADA CONTROLLER ONLY (Platform Integration / Open API is REQUIRED):
 *      - Omada Cloud (Omada Central, *.tplinkcloud.com) is no longer supported. Every controller is your own Omada Software
 *        Controller / OC200 / OC300 and MUST have: Controller URL (https://IP:8043), Omada ID, Client ID and Client Secret
 *        (Omada → Global View → Settings → Platform Integration → Open API → Add New App, mode "Client").
 *      - Routers → Add router creates EVERYTHING in your controller automatically from the website: site, SSID, RADIUS profile
 *        (this RADIUS server), External RADIUS portal, Pre-Authentication Access, vouchers — then "Provision & connect" starts by
 *        itself and adopts the EAP225 as soon as it reports PENDING (Inform URL = controller IP).
 *      - Shared hosting: every Open API call goes through the Omada relay of the external RADIUS server (php index.php radius-server).
 *
 *  • v6.1.2 — PUBLIC OMADA CONTROLLER ON YOUR VPS (https://169.58.93.38:8043):
 *      - FIX "Token refused (HTTP 400)": the Open API is HTTPS only. A controller saved as http://IP:8043 (or :8088 / no port)
 *        is now always called as https://IP:8043; old rows are repaired automatically, and the token request also retries
 *        with the Omada ID read from https://IP:8043/api/info when the saved Omada ID is wrong / from another controller.
 *      - Omada ID is read automatically from /api/info (typing it is optional now). Clearer token errors (errorCode + reason).
 *      - FIX Inform URL: the EAP225 gets the controller IP of the Controller URL (169.58.93.38) — old Inform URLs that point
 *        to another host (e.g. 65.109.35.14) are rewritten to the controller host; the default Inform URL now uses the VPS.
 *      - REMOVED the local / private-LAN controller features of v6.1.1 (LAN relay routing, LAN relay kit, private-LAN banners,
 *        private LAN controller addresses). The controller is reached on its public address — directly, or through the
 *        RADIUS server relay when the shared hosting blocks port 8043 (unchanged).
 *
 *  • v6.2 — ENGLISH ONLY + ADMIN-MANAGED OMADA:
 *      - Swahili translation removed: the website, the captive portal and every RADIUS reply use English only.
 *      - Omada Controller, Omada Manager and RADIUS Setup are managed by the administrator only. Sellers only:
 *        Routers → Add router (fill the EAP225 data) → Hotspot → Provision & connect → Start / Stop the hotspot.
 *        Every seller router is linked automatically to the admin's default Omada Controller (Admin → RADIUS Setup:
 *        Default Inform URL + Open API keys); routers added before the admin finished that setup are linked as soon as it is done.
 *      - Admin → All Routers: every seller's router with model, site, Omada status, provisioning state and health;
 *        the admin can open any seller's Hotspot page, run the setup, check / fix health, start / stop or delete a router,
 *        and link every unlinked router to the default controller in one click.
 *      - Hotspot Start / Stop for sellers (a stopped hotspot is refused by the RADIUS server and live users are disconnected).
 *      - Seller dashboard "Quick start" checklist, admin broadcast notifications to all sellers, admin switch to open / close
 *        seller self-registration.
 *
 *  • v6.3 — MOBILE MONEY FIRST CAPTIVE PORTAL (Sonic Pesa from portal.php):
 *      - Portal (dark only): packages as horizontal cards (name, price, LIPIA) → popup asks the phone number → Sonic Pesa push
 *        (POST {SONIC_PESA_API_BASE}/payment/create_order, X-API-KEY + X-SECRET-KEY) → voucher issued, seller balance credited,
 *        phone connected automatically. Voucher login stays as the secondary option ("Una vocha?").
 *      - Payment confirmation three ways: callback ?webhook=sonicpesa (trusted with the secret, otherwise verified with Sonic Pesa),
 *        portal polling (order_status every 8 s) and the "Nimekwisha lipa" button (also notifies the seller).
 *        Without Sonic Pesa keys the portal falls back to Lipa Namba + seller confirmation exactly as before.
 *      - Customer care button = the seller's phone; "JE UNATAKA MFUMO HUU?" opens the platform contact (Admin → Platform settings).
 *      - Auto-connect: browserauth falls back to the controller portal port 8843 (never this website, never 8043).
 *      - Sellers add / delete extra WiFi names (SSIDs) on their router (Hotspot page); hotspot SSIDs join the same portal.
 *      - Withdraw page shows ONE withdrawal fee (platform + Sonic Pesa combined, exact %).
 *
 *  • v6.4 — EARNINGS + PAYMENT RECOVERY:
 *      - The captive portal shows the WiFi name (SSID) the phone actually joined (Omada "ssidName"), so every
 *        extra SSID of a router shows its own name.
 *      - A voucher entered on the portal is counted in the seller's balance the first time it is used
 *        (SkyTanza RADIUS vouchers and Omada vouchers; vouchers bought with mobile money are not counted twice).
 *      - Dashboard + Transactions: earnings from mobile money, earnings from vouchers, total earnings, withdrawn and
 *        available balance. Withdrawals are deducted from total earnings.
 *      - Transactions → Payments: every portal payment (pending / failed / expired / paid / cancelled) — the seller sees
 *        his own, the admin sees all. Confirm paid, check again with Sonic Pesa, mark failed, cancel, connect customer.
 *        A confirmed payment connects the customer automatically: the portal keeps waiting for the confirmation,
 *        recognises the phone again (MAC + hotspot) when the WiFi login page reopens, and phones on routers with the
 *        Omada Open API are reconnected by the controller so their login page reopens by itself.
 *
 *  • v6.5 — SONIC PESA PAYMENT STATUS FIX:
 *      - Payment status is read from POST {SONIC_PESA_API_BASE}/payment/order_status {"order_id": "sp_..."} exactly as documented:
 *        data.payment_status / transaction.status = SUCCESS · PENDING · CANCELLED · USERCANCELLED · REJECTED.
 *      - Background polling of every unconfirmed payment (RADIUS heartbeat, cron, dashboard) — the status updates even when the
 *        customer closed the WiFi login page or the callback never arrived. SUCCESS → voucher created, seller credited, phone connected.
 *      - The portal keeps polling when its session is lost (order recognised by phone MAC / hotspot IP) and checks order_status on reopen.
 *      - Transactions → Payments → "Update status": seller / admin sets paid / pending / failed / cancelled / expired;
 *        "paid" creates the voucher for that package automatically and connects the customer.
 *
 *  • v6.6.1 — CAPTIVE PORTAL SSL FIX (browserauth on https://omada.skytanzania.co.tz):
 *      - The phone now posts the voucher to ONE fixed HTTPS address with a valid certificate:
 *        https://omada.skytanzania.co.tz/portal/radius/browserauth (nginx on the VPS → Omada portal port 8843).
 *        It is never built from the controller IP any more (https://169.58.93.38:8843 = self-signed = "certificate error").
 *      - Admin → Platform settings → "Omada browserauth URL" (empty = the default above, or OMADA_PORTAL_AUTH_URL in
 *        config.local.php) + "Test the SSL certificate" button. http://, IP addresses and ports are flagged.
 *      - Provisioning adds the browserauth host (and its IP) to Omada Pre-Authentication Access so phones reach it before login.
 *      - VPS kit shows the nginx + Let's Encrypt setup for the browserauth domain.
 *
 *  • v6.6 — SONIC PESA LIKE MIKEKA APP + PAYMENT CONFIRMATION FIX:
 *      - FIX "Could not confirm the payment (the voucher could not be issued)": the voucher of a paid order is issued by its own
 *        code (package, or the copy of the package saved on the order), the ledger insert can no longer collide, older tables are
 *        repaired automatically (payment_method ENUM, missing columns), and the exact database error is shown instead of a generic text.
 *      - FIX portal payments staying "pending" after the customer paid: the Sonic Pesa callback {"event":"payment.success"} is now
 *        understood (it was ignored before), the status check reads transaction.status first exactly like MIKEKA APP, and only the
 *        API key is required (X-API-KEY; the secret is optional). Background checks also run from housekeeping (RADIUS traffic, cron).
 *      - Captive portal keeps polling the payment even when the captive browser loses its cookie (order recognised by phone MAC / IP).
 *      - Admin → Platform settings: Sonic Pesa API key / secret (stored sealed in the database) + "Test the key".
 *      - Transactions → Payments: Sonic Pesa status, transaction id, last error, full event log per payment, "Check all with Sonic Pesa now".
 *      - New table hs_payment_events and new hs_orders columns (sp_*, fulfill_*, pkg_*) — created automatically (schema v16).
 *
 *  • v6.7 — SONIC PESA FROM MIKEKA APP (automatic pay → automatic WiFi connection, no administrator needed):
 *      - The Sonic Pesa key that already works in MIKEKA APP is built in as the default (X-API-KEY only, same as MIKEKA APP),
 *        so the portal sends the USSD push out of the box. A key in config.local.php or Admin → Platform settings still wins.
 *      - create_order / order_status / callback handled exactly like MIKEKA APP: order_status is paid when
 *        transaction.status / data.payment_status = SUCCESS or COMPLETED; the callback {"event":"payment.success"} that matches
 *        one of our Sonic Pesa order ids issues the voucher at once (verified with order_status first when possible).
 *      - The captive portal voucher check also works after the captive browser lost its cookie, so a paid phone is connected
 *        automatically; payout requests send the secret headers only when a secret is set (same as collections).
 *      - New hs_orders columns sp_event + sp_webhook_count (created automatically, schema v17).
 *
 *  • v6.7.1 — NO MORE "CONTACT ADMINISTRATOR" WHEN THE PUSH FAILS:
 *      - With a Sonic Pesa key the portal never falls back to "Contact: <seller phone> + Ref" any more. If Sonic Pesa refuses
 *        the push, the customer sees "try again", the order is marked failed and the exact Sonic Pesa answer is saved
 *        (Transactions → Payments → Log, Admin → Platform settings → "Last USSD push error") and sent to the seller/admin.
 *      - A refused push (HTTP 4xx) is retried once with MIKEKA APP's exact payload (customer@mikekaapp.com / "Customer").
 *      - Admin → Platform settings → "Send a test USSD push": real push to any number with the full Sonic Pesa answer.
 *      - "Lipa Namba" manual confirmation is used only when no Sonic Pesa key exists at all.
 *
 *  • v6.7.2 — SONIC PESA ANSWER ON THE CAPTIVE PORTAL + NO "CONTACT ADMINISTRATOR" AT ALL:
 *      - The first USSD push now sends MIKEKA APP's exact payload (customer@mikekaapp.com, "Customer", metadata user_id /
 *        package_type / phone_number) — the same request that works in MIKEKA APP.
 *      - After the customer enters the phone number, the portal shows Sonic Pesa's own answer (HTTP code + JSON) under the
 *        payment form, and while waiting it shows the live order_status answer, so the exact problem is visible on the phone.
 *      - The manual "Lipa Namba / Contact: seller phone + Ref" fallback is removed completely: without a key the portal says the
 *        Sonic Pesa key is missing; when Sonic Pesa refuses, its answer is shown and the customer can try again.
 *
 *  • v6.7.3 — FIXED SONIC PESA ADDRESSES (exactly MIKEKA APP):
 *      - FIX HTTP 404 "route api/v1/https//api.sonicpesa.com/...create_order_simple could not be found": a full URL typed in the
 *        old "Sonic Pesa collection endpoint" setting was glued onto the base address. Payments now ALWAYS use MIKEKA APP's
 *        fixed addresses: https://api.sonicpesa.com/api/v1/payment/create_order and .../payment/order_status
 *        (the endpoint setting, SONIC_PESA_COLLECT_ENDPOINT and SONIC_PESA_API_BASE are ignored; the admin page shows the
 *        fixed addresses instead of the editable field).
 *
 *  Secrets go in config.local.php (same folder) as define('NAME','value'); — see Admin → Security check.
 * ============================================================================
 */

ob_start();
date_default_timezone_set('Africa/Dar_es_Salaam');

// ============================================================
// v5.4.1 — READABLE ERRORS: a crash shows a clear page (admins see the exact error, file and line)
// and is written to the server error log + Admin → RADIUS Setup, instead of a blank "HTTP ERROR 500".
// ============================================================
function skyFatal(string $msg, string $file, int $line): void {
    static $done = false;
    if ($done) return;
    $done = true;
    $ref = strtoupper(substr(md5($msg . $file . $line . microtime()), 0, 8));
    $where = basename($file) . ':' . $line;
    error_log("SkyTanza WiFi [$ref] $msg in $file:$line");
    try {   // keep the last 15 errors for the admin page (only when the database is up)
        if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli && function_exists('getSetting')) {
            $list = json_decode(getSetting('server_errors', '[]'), true) ?: [];
            array_unshift($list, ['ref' => $ref, 'at' => date('Y-m-d H:i:s'), 'msg' => substr($msg, 0, 400), 'where' => $where,
                'url' => substr((string)($_SERVER['REQUEST_URI'] ?? 'cli'), 0, 200)]);
            setSetting('server_errors', (string)json_encode(array_slice($list, 0, 15), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
    } catch (Throwable $t) { error_log('SkyTanza: could not store error: ' . $t->getMessage()); }
    if (PHP_SAPI === 'cli') { fwrite(STDERR, "[$ref] $msg ($where)\n"); return; }
    while (ob_get_level() > 0) @ob_end_clean();
    $admin = isset($_SESSION) && (($_SESSION['user_type'] ?? '') === 'admin');
    $detail = $admin ? $msg . ' — ' . $where : '';
    if (!headers_sent()) { http_response_code(500); header('Cache-Control: no-store'); }
    if (isset($_GET['ajax']) || isset($_GET['radius']) || isset($_GET['webhook']) || isset($_GET['cron'])) {
        if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'success' => false, 'error' => 'server_error', 'ref' => $ref, 'done' => false, 'phase' => 'error',
            'msg' => 'Server error ' . $ref . ($detail !== '' ? ': ' . $detail : ''), 'message' => 'Server error ' . $ref]);
        return;
    }
    if (!headers_sent()) header('Content-Type: text/html; charset=utf-8');
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Error ' . $e($ref) . '</title>'
       . '<style>body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;background:#060a13;color:#e6ebf5;margin:0;display:grid;place-items:center;min-height:100vh;padding:16px}'
       . '.c{max-width:620px;width:100%;background:#0c1320;border:1px solid #25324d;border-radius:18px;padding:26px}h1{font-size:1.25rem;margin:0 0 8px}p{color:#9fb0c8;line-height:1.5}'
       . 'code{display:block;white-space:pre-wrap;word-break:break-word;background:#05080f;border:1px solid #25324d;border-radius:10px;padding:12px;color:#fca5a5;font-size:.85rem;margin:12px 0}'
       . 'a{display:inline-block;margin-top:10px;background:linear-gradient(135deg,#5b8cff,#8b5cf6);color:#fff;text-decoration:none;padding:10px 16px;border-radius:10px;font-weight:700}</style></head><body><div class="c">'
       . '<h1>⚠️ Something went wrong</h1><p>Reference: <b>' . $e($ref) . '</b>. ' . ($admin ? 'Details (shown to administrators only):' : 'Please try again. If it keeps happening, give this reference to the administrator.') . '</p>'
       . ($detail !== '' ? '<code>' . $e($detail) . '</code>' : '') . '<a href="?page=dashboard">← Dashboard</a></div></body></html>';
}
set_exception_handler(function (Throwable $ex) {
    $via = [];   // the calling lines (e.g. which page called the failing database query)
    foreach (array_slice($ex->getTrace(), 0, 6) as $f) if (isset($f['line']) && ($f['file'] ?? '') === $ex->getFile() && (int)$f['line'] !== $ex->getLine()) $via[] = $f['line'];
    skyFatal(get_class($ex) . ': ' . $ex->getMessage() . ($via ? ' [called from line ' . implode(' ← ', array_unique($via)) . ']' : ''), $ex->getFile(), $ex->getLine());
});
register_shutdown_function(function () {
    $er = error_get_last();
    if ($er && in_array($er['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) skyFatal($er['message'], $er['file'], (int)$er['line']);
});

if (is_file(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';

function cfg(string $name, string $env, $default): void {
    if (defined($name)) return;
    $v = getenv($env);
    define($name, ($v !== false && $v !== '') ? $v : $default);
}

// ============================================================
// CONFIG
// ============================================================
cfg('DB_HOST', 'SKY_DB_HOST', 'localhost');
cfg('DB_USER', 'SKY_DB_USER', 'skytanza_wifi');
cfg('DB_PASS', 'SKY_DB_PASS', '');                 // v5.7.1: set it in config.local.php
cfg('DB_NAME', 'SKY_DB_NAME', 'skytanza_wifi');

cfg('SITE_NAME', 'SKY_SITE_NAME', 'SkyTanza WiFi');
// Leave SITE_URL empty to auto-detect it (recommended). Set it only to force a URL, e.g. 'https://wifi.example.co.tz'.
cfg('SITE_URL', 'SKY_SITE_URL', '');
cfg('CURRENCY', 'SKY_CURRENCY', 'TZS');
cfg('APP_VERSION', 'SKY_APP_VERSION', '6.7.4');

// ---- Omada Controller Open API ----
cfg('OMADA_HTTP_TIMEOUT', 'SKY_OMADA_TIMEOUT', 10);   // seconds per Open API call
cfg('OMADA_SYNC_EVERY', 'SKY_OMADA_SYNC', 180);       // seconds between automatic status syncs per controller
// v5.8 — Omada Inform URL used for EVERY added router (admin setting "Default Omada Inform URL" overrides it)
cfg('OMADA_DEFAULT_INFORM_URL', 'SKY_OMADA_INFORM_URL', 'omada://169.58.93.38?dPort=29810&mPort=29814');   // v6.1.2: public controller on the VPS (Omada ID read from /api/info)
// v6.1.2 — public Omada Controller (Interface Access Address). The Open API is ALWAYS https on port 8043.
cfg('OMADA_CONTROLLER_URL', 'SKY_OMADA_CONTROLLER_URL', 'https://169.58.93.38:8043');
// v6.6.1 — where the phone's browser POSTs the voucher (Omada External RADIUS portal "browserauth").
// MUST be a domain with a VALID SSL certificate (nginx + Let's Encrypt on the VPS → Omada portal port 8843).
// Never use https://IP:8843 here — the controller's self-signed certificate makes phones show an SSL error.
cfg('OMADA_PORTAL_AUTH_URL', 'SKY_OMADA_PORTAL_AUTH_URL', 'https://omada.skytanzania.co.tz/portal/radius/browserauth');

// CHANGE ALL OF THESE ON PRODUCTION (long random strings)
cfg('APP_SECRET', 'SKY_APP_SECRET', 'change-me-please-32bytes-secret!!');
define('APP_SECRET_LEGACY', 'change-me-please-32bytes-secret!!');   // v5.7.1: still opens EAP225 logins saved before APP_SECRET was changed
cfg('RADIUS_API_KEY', 'SKY_RADIUS_API_KEY', 'change-radius-api-key-to-a-long-random-string');
cfg('CRON_SECRET', 'SKY_CRON_SECRET', 'cron-secret-change-me');
cfg('PAYMENT_WEBHOOK_SECRET', 'SKY_WEBHOOK_SECRET', 'webhook-secret-change-me');

// Payouts (Sonic Pesa) — v5.7.1: the keys live ONLY in config.local.php (empty here = payouts switched off)
cfg('WITHDRAWAL_FEE_PERCENT', 'SKY_WITHDRAWAL_FEE', 4);
cfg('SONIC_PESA_FEE_PERCENT', 'SKY_SONIC_FEE', 6);
cfg('SONIC_PESA_API_KEY', 'SKY_SONIC_KEY', '');
cfg('SONIC_PESA_API_SECRET', 'SKY_SONIC_SECRET', '');
// v6.7 — the Sonic Pesa key that works in MIKEKA APP; used only when no key is set in config.local.php or Admin → Platform settings
cfg('SONIC_PESA_DEFAULT_KEY', 'SKY_SONIC_DEFAULT_KEY', 'sk_live_7j16qyGqFqoUi2hY0r6a2ODxCcEkojeNU2jyjMMT');
cfg('SONIC_PESA_API_BASE', 'SKY_SONIC_BASE', 'https://api.sonicpesa.com/api/v1');
cfg('SONIC_PESA_MIN_PAYOUT', 'SKY_SONIC_MIN', 30000);
// Mobile-money COLLECTION (customer pays on the portal). Leave '' to use "Lipa Namba" manual
// confirmation. When Sonic Pesa gives you the collection path (e.g. '/payments/create'), put it here.
cfg('SONIC_PESA_COLLECT_ENDPOINT', 'SKY_SONIC_COLLECT', '');   // v6.7.3: no longer used — MIKEKA APP's fixed address is used
// v6.7.3 — MIKEKA APP: const SP_URL = 'https://api.sonicpesa.com/api/v1' (create_order + order_status, fixed)
define('SONIC_PESA_MIKEKA_URL', 'https://api.sonicpesa.com/api/v1');

cfg('SESSION_TIMEOUT', 'SKY_SESSION_TIMEOUT', 3600);
cfg('RADIUS_INTERIM', 'SKY_RADIUS_INTERIM', 60);

// ---- External RADIUS server ----
// Ports are STATIC (Omada: Authentication Port 1812, Accounting Port 1813). Disconnect/CoA goes to the NAS on 3799.
define('RADIUS_AUTH_PORT', 1812);
define('RADIUS_ACCT_PORT', 1813);
define('RADIUS_DAE_PORT', 3799);
cfg('RADIUS_BIND_IP', 'SKY_RADIUS_BIND_IP', '0.0.0.0');                       // RADIUS box: interface to listen on
cfg('RADIUS_API_URL', 'SKY_RADIUS_API_URL', (SITE_URL !== '' ? rtrim(SITE_URL, '/') : 'https://wifi.skytanzania.co.tz') . '/index.php'); // RADIUS box: where the website lives
cfg('RADIUS_DAE_POLL', 'SKY_RADIUS_DAE_POLL', 15);                            // seconds between disconnect-queue polls
// ---- v5.9 Omada relay (RADIUS box → Omada controller, for websites on shared hosting) ----
cfg('OMADA_RELAY', 'SKY_OMADA_RELAY', '1');                                   // RADIUS box: '0' = do not start the Omada relay
cfg('OMADA_RELAY_WAIT', 'SKY_OMADA_RELAY_WAIT', 20);                          // seconds the website holds one relay long-poll open (0 = short polls)
cfg('OMADA_RELAY_ALLOW_LOCAL', 'SKY_OMADA_RELAY_LOCAL', '0');                 // RADIUS box: '1' = also allow 127.x (controller on the same VPS)
cfg('OMADA_DEFAULT_CLIENT_ID', 'SKY_OMADA_CLIENT_ID', '');                    // Open API keys for the default Inform URL controller
cfg('OMADA_DEFAULT_CLIENT_SECRET', 'SKY_OMADA_CLIENT_SECRET', '');            //   (Admin → RADIUS Setup overrides these)

// ============================================================
// SMALL HELPERS
// ============================================================
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($a): string { return CURRENCY . ' ' . number_format((float)$a, 0); }
function normMac($s): string {
    $hex = strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', substr((string)$s, 0, 17)));
    if (strlen($hex) < 12) return '';
    return implode(':', str_split(substr($hex, 0, 12), 2));
}
function dashMac(string $mac): string { return str_replace(':', '-', $mac); }
function normalizePhone(string $p): string {
    $d = preg_replace('/\D/', '', $p);
    if (strlen($d) === 12 && substr($d, 0, 3) === '255') $d = '0' . substr($d, 3);
    if (strlen($d) === 9) $d = '0' . $d;
    return $d;
}
function genCode(int $len = 8): string {
    $c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I confusion
    $o = '';
    for ($i = 0; $i < $len; $i++) $o .= $c[random_int(0, strlen($c) - 1)];
    return $o;
}
function fmtDur(int $min): string {
    if ($min >= 1440 && $min % 1440 === 0) { $d = $min / 1440; return $d . ' ' . ($d == 1 ? t('day') : t('days')); }
    if ($min >= 60 && $min % 60 === 0) { $x = $min / 60; return $x . ' ' . ($x == 1 ? t('hour') : t('hours')); }
    return $min . ' ' . t('min_short');
}
function fmtSecs(int $s): string {
    if ($s <= 0) return '0' . t('min_short');
    $d = intdiv($s, 86400); $h = intdiv($s % 86400, 3600); $m = intdiv($s % 3600, 60);
    $out = [];
    if ($d) $out[] = $d . 'd';
    if ($h) $out[] = $h . 'h';
    if ($m || !$out) $out[] = max(1, $m) . 'm';
    return implode(' ', $out);
}
function fmtBytes($b): string {
    $b = (float)$b;
    foreach (['B', 'KB', 'MB', 'GB', 'TB'] as $u) { if ($b < 1024) return round($b, 1) . ' ' . $u; $b /= 1024; }
    return round($b, 1) . ' PB';
}
function jsonOut($data, int $code = 200): void {
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function noContent(): void { while (ob_get_level() > 0) ob_end_clean(); http_response_code(204); exit; }
/** Path of this script on the server, e.g. /index.php or /wifi/index.php. */
function scriptPath(): string {
    $p = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    return ($p !== '' && $p[0] === '/') ? $p : '/index.php';
}
/**
 * Path of this script as the browser sees it. v5.7.2: hosts that rewrite /index.php → /index (or serve it as /) keep that
 * form, so redirects and form posts do not bounce through an extra "301 Moved Permanently".
 */
function selfPath(): string {
    $p = scriptPath();
    $req = (string)parse_url('http://x' . (string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    if ($req !== '' && $req !== $p) {
        $noExt = (string)preg_replace('/\.php$/i', '', $p);
        $dir = rtrim(dirname($p), '/') . '/';
        if ($req === $noExt || $req === $dir) return $req;
    }
    return $p;
}
/**
 * v5.3 FIX: redirects such as "?page=hotspot&id=5" are turned into "/index.php?page=hotspot&id=5" and sent with 303,
 * so every browser, PWA and proxy lands on the right page after a form POST (e.g. after "Save device").
 */
function redirectTo(string $url): void {
    while (ob_get_level() > 0) ob_end_clean();
    if ($url === '' || $url[0] === '?') $url = selfPath() . $url;
    elseif ($url[0] === '#') $url = selfPath() . '?page=dashboard' . $url;
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!headers_sent()) {
        header('Cache-Control: no-store');
        header('Location: ' . $url, true, $method === 'POST' ? 303 : 302);
    }
    $u = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    echo '<!DOCTYPE html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=' . $u . '"><script>location.replace(' . json_encode($url) . ')</script><a href="' . $u . '">Continue</a>';
    exit;
}
/** Base URL of this installation detected from the current request (scheme + host + folder), '' on CLI. */
function detectedBaseUrl(): string {
    if (PHP_SAPI === 'cli' || empty($_SERVER['HTTP_HOST'])) return '';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '') === 'on') || (string)($_SERVER['SERVER_PORT'] ?? '') === '443';
    $host = strtolower(preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', (string)$_SERVER['HTTP_HOST']));
    if ($host === '') return '';
    $dir = rtrim(str_replace('\\', '/', dirname(scriptPath())), '/.');
    return ($https ? 'https' : 'http') . '://' . $host . $dir;
}
function clientIp(): string { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }

/** Random password for Omada RADIUS profiles — letters/digits only (no symbols Omada might reject, no 0/O/1/l/I). */
function genSecret(int $len = 20): string {
    $c = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    $o = '';
    for ($i = 0; $i < $len; $i++) $o .= $c[random_int(0, strlen($c) - 1)];
    return $o;
}
function asciiClean(string $s, int $max): string { return substr(preg_replace('/[^\x20-\x7E]/', '?', $s), 0, $max); }
function radiusApiKeyWeak(): bool { return strlen((string)RADIUS_API_KEY) < 24 || RADIUS_API_KEY === 'change-radius-api-key-to-a-long-random-string'; }
/**
 * v5.4.1 — shared hosting (cPanel) often lists set_time_limit, usleep, sleep or gethostbyname in disable_functions.
 * Since PHP 8 calling a disabled function is a FATAL error (even with @), so every such call goes through these helpers.
 */
function canCall(string $fn): bool {
    static $off = null;
    if ($off === null) $off = array_filter(array_map('trim', explode(',', strtolower((string)ini_get('disable_functions')))));
    return function_exists($fn) && !in_array(strtolower($fn), $off, true);
}
/** Ask for more execution time; false when the host does not allow it. */
function extendTimeLimit(int $sec): bool { return canCall('set_time_limit') ? (bool)@set_time_limit($sec) : false; }
/** Seconds this request may still use for slow work (Omada calls), leaving a safety margin. */
function workBudget(int $wanted): int {
    if (extendTimeLimit($wanted + 30)) return $wanted;
    $max = (int)ini_get('max_execution_time');
    return $max <= 0 ? $wanted : max(8, min($wanted, $max - 6));
}
function pauseMs(int $ms): void {
    if ($ms <= 0) return;
    if (canCall('usleep')) { usleep($ms * 1000); return; }
    if (canCall('time_nanosleep')) { @time_nanosleep(intdiv($ms, 1000), ($ms % 1000) * 1000000); return; }
    // no sleep function on this host: continue without waiting
}
function resolveHost(string $host): string { return canCall('gethostbyname') ? (string)gethostbyname($host) : $host; }

// ============================================================
// EXTERNAL RADIUS SERVER (CLI daemon)  —  php index.php radius-server [--test] [--debug]
// Pure PHP: UDP 1812 (Access-Request) + UDP 1813 (Accounting-Request) + RFC 5176 Disconnect client.
// Each hotspot is recognised by its OWN passwords; the NAS ID is taken as Omada sends it and learned.
// Every decision comes from the website over HTTPS, so the RADIUS box needs NO database.
// ============================================================
final class RadiusServer
{
    const VERSION = '6.2.0';
    /** Attributes we read: type => [name, datatype] */
    const DICT = [
        1 => ['User-Name', 'string'], 4 => ['NAS-IP-Address', 'ipaddr'], 5 => ['NAS-Port', 'integer'], 6 => ['Service-Type', 'integer'],
        8 => ['Framed-IP-Address', 'ipaddr'], 25 => ['Class', 'string'], 30 => ['Called-Station-Id', 'string'], 31 => ['Calling-Station-Id', 'string'],
        32 => ['NAS-Identifier', 'string'], 40 => ['Acct-Status-Type', 'integer'], 41 => ['Acct-Delay-Time', 'integer'],
        42 => ['Acct-Input-Octets', 'integer'], 43 => ['Acct-Output-Octets', 'integer'], 44 => ['Acct-Session-Id', 'string'],
        46 => ['Acct-Session-Time', 'integer'], 47 => ['Acct-Input-Packets', 'integer'], 48 => ['Acct-Output-Packets', 'integer'],
        49 => ['Acct-Terminate-Cause', 'integer'], 50 => ['Acct-Multi-Session-Id', 'string'], 52 => ['Acct-Input-Gigawords', 'integer'],
        53 => ['Acct-Output-Gigawords', 'integer'], 55 => ['Event-Timestamp', 'integer'], 61 => ['NAS-Port-Type', 'integer'],
        87 => ['NAS-Port-Id', 'string'], 101 => ['Error-Cause', 'integer'],
    ];
    /** Attributes we send: name => [type, vendor, vendor-type, datatype] */
    const ENC = [
        'User-Name' => [1, 0, 0, 'string'], 'NAS-IP-Address' => [4, 0, 0, 'ipaddr'], 'Framed-IP-Address' => [8, 0, 0, 'ipaddr'],
        'Reply-Message' => [18, 0, 0, 'string'], 'Class' => [25, 0, 0, 'string'], 'Session-Timeout' => [27, 0, 0, 'integer'],
        'Idle-Timeout' => [28, 0, 0, 'integer'], 'Calling-Station-Id' => [31, 0, 0, 'string'], 'NAS-Identifier' => [32, 0, 0, 'string'],
        'Acct-Session-Id' => [44, 0, 0, 'string'], 'Event-Timestamp' => [55, 0, 0, 'integer'], 'Acct-Interim-Interval' => [85, 0, 0, 'integer'],
        'WISPr-Bandwidth-Max-Up' => [26, 14122, 7, 'integer'], 'WISPr-Bandwidth-Max-Down' => [26, 14122, 8, 'integer'],
    ];
    const STATUS = [1 => 'Start', 2 => 'Stop', 3 => 'Interim-Update', 7 => 'Accounting-On', 8 => 'Accounting-Off'];
    const CAUSE = [1 => 'User-Request', 2 => 'Lost-Carrier', 3 => 'Lost-Service', 4 => 'Idle-Timeout', 5 => 'Session-Timeout',
        6 => 'Admin-Reset', 7 => 'Admin-Reboot', 8 => 'Port-Error', 9 => 'NAS-Error', 10 => 'NAS-Request', 11 => 'NAS-Reboot',
        12 => 'Port-Unneeded', 13 => 'Port-Preempted', 14 => 'Port-Suspended', 15 => 'Service-Unavailable', 16 => 'Callback',
        17 => 'User-Error', 18 => 'Host-Request'];
    const BUSY = 'Service unavailable, please try again';

    private $authSock = null, $acctSock = null, $daeSock = null, $curl = null;
    private string $api, $apiConfigured, $apiFile, $key, $spool, $lastErr = '';
    private bool $debug, $stop = false, $daeEnabled = true;
    private array $clients = [], $queue = [], $dedupe = [], $dae = [], $unknown = [], $badpw = [], $logged = [];
    private int $clientsAt = 0, $lastForce = 0, $nextFlush = 0, $backoff = 1, $nextDaePoll = 0, $daeSeq = 0, $started, $nextProbe = 0, $lastCode = 0;
    private array $stats = ['accept' => 0, 'reject' => 0, 'acct' => 0, 'dropped' => 0, 'dae_ok' => 0, 'dae_fail' => 0, 'api_errors' => 0, 'learned' => 0];
    // v5.9 — Omada relay (child process): runs the website's Omada Open API calls from this box
    private int $relayPid = 0, $relayNext = 0, $relayStarted = 0;
    private bool $isRelay = false, $standalone = false;
    private array $relayStats = ['jobs' => 0, 'ok' => 0, 'fail' => 0, 'last_ms' => 0, 'last_at' => '', 'last_error' => ''];

    function __construct(string $api, string $key, bool $debug) {
        $this->api = $this->apiConfigured = $api; $this->key = $key; $this->debug = $debug; $this->started = time();
        $this->spool = __DIR__ . '/radius-spool.json';
        $this->apiFile = __DIR__ . '/radius-api-url.json';
        // v5.7.2: the address that answered last time (after following the host's redirects) — reset when RADIUS_API_URL changes
        $saved = is_file($this->apiFile) ? json_decode((string)@file_get_contents($this->apiFile), true) : null;
        if (is_array($saved) && ($saved['from'] ?? '') === $api && is_string($saved['to'] ?? null)) {
            $ok = self::redirectBase($api, (string)$saved['to']);
            if ($ok !== null) $this->api = $ok;
        }
    }

    static function main(array $argv): void {
        $o = [];
        foreach (array_slice($argv, 2) as $a) if (preg_match('/^--([a-z-]+)(?:=(.*))?$/', $a, $m)) $o[$m[1]] = $m[2] ?? '1';
        $s = new self(trim((string)($o['api'] ?? RADIUS_API_URL)), (string)($o['key'] ?? RADIUS_API_KEY), isset($o['debug']));
        if (($argv[1] ?? '') === 'omada-relay') $s->standalone = true;   // relay as its own service (also for --test)
        if (isset($o['test'])) exit($s->selfTest() ? 0 : 1);
        if (($argv[1] ?? '') === 'omada-relay') { $s->runRelayOnly(); return; }   // v5.9: relay as its own service (no pcntl)
        $s->run();
    }

    // ---------------------------------------------------------------- main loop
    private function run(): void {
        extendTimeLimit(0);
        if ($this->keyWeak()) { $this->log('FATAL: RADIUS_API_KEY is not set. Put the same key as the website in config.local.php next to index.php.'); exit(1); }
        if (function_exists('pcntl_async_signals')) {
            pcntl_async_signals(true);
            foreach ([SIGTERM, SIGINT] as $sig) pcntl_signal($sig, function () { $this->stop = true; });
        }
        $this->authSock = $this->bind(RADIUS_AUTH_PORT);
        $this->acctSock = $this->bind(RADIUS_ACCT_PORT);
        $this->daeSock = $this->bind(0);
        $this->startRelay();   // v5.9: Omada relay child process (website → RADIUS box → Omada controller)
        $this->loadSpool();
        $this->refreshClients(false);
        $this->log('SkyTanza RADIUS ' . self::VERSION . ' listening on ' . RADIUS_BIND_IP . ' UDP ' . RADIUS_AUTH_PORT . ' (auth) + ' . RADIUS_ACCT_PORT
            . ' (accounting) | API ' . $this->api . ' | ' . count($this->clients) . ' hotspot(s) | NAS ID: as sent by Omada (auto-learned)');
        if ($this->api !== $this->apiConfigured) $this->log("NOTE: RADIUS_API_URL is {$this->apiConfigured} but the website answers at {$this->api} — set define('RADIUS_API_URL', '{$this->api}'); in config.local.php");
        while (!$this->stop) {
            $r = [$this->authSock, $this->acctSock, $this->daeSock]; $w = null; $e = null;
            $n = @stream_select($r, $w, $e, 1, 0);
            if ($n === false) pauseMs(200);
            elseif ($n > 0) {
                foreach ($r as $sock) {
                    for ($i = 0; $i < 100; $i++) {
                        $peer = '';
                        $data = @stream_socket_recvfrom($sock, 4096, 0, $peer);
                        if ($data === false || $data === '') break;
                        try {
                            if ($sock === $this->authSock) $this->onAuth($data, $peer);
                            elseif ($sock === $this->acctSock) $this->onAcct($data, $peer);
                            else $this->onDaeReply($data, $peer);
                        } catch (Throwable $ex) { $this->log('ERROR ' . $ex->getMessage()); }
                    }
                }
            }
            $this->tick();
        }
        $this->stopRelay();
        $this->saveSpool();
        $this->log('Stopped.');
    }

    private function tick(): void {
        $now = time();
        $this->watchRelay();
        $this->refreshClients(false);
        if ($this->queue && $now >= $this->nextFlush) $this->flush();
        if ($this->daeEnabled && $now >= $this->nextDaePoll) { $this->nextDaePoll = $now + max(5, (int)RADIUS_DAE_POLL); $this->pollDae(); }
        foreach ($this->dae as $rid => $x) {
            if ($now - $x['sent'] < 3) continue;
            if ($x['tries'] < 3) { $this->send($this->daeSock, $x['pkt'], $x['dest']); $this->dae[$rid]['tries']++; $this->dae[$rid]['sent'] = $now; continue; }
            unset($this->dae[$rid]);
            $this->stats['dae_fail']++;
            $this->log('DISCONNECT timeout ' . $x['user'] . ' → ' . $x['dest']);
            $this->api('dae_ack', ['id' => $x['job'], 'ok' => false, 'result' => 'No reply from ' . $x['dest'] . ' (is UDP ' . RADIUS_DAE_PORT . ' reachable?)']);
        }
        foreach ($this->dedupe as $k => $d) if ($now - $d[0] > 30) unset($this->dedupe[$k]);
        if (count($this->logged) > 500) $this->logged = array_filter($this->logged, fn($t) => $t > $now - 300);
    }

    // ---------------------------------------------------------------- Access-Request (UDP 1812)
    private function onAuth(string $data, string $peer): void {
        $p = self::parse($data);
        if ($p && $p['code'] === 12) { $this->onStatusServer($p, $peer); return; }   // v5.7: Omada / tools probing "is the RADIUS server alive?"
        if (!$p || $p['code'] !== 1) { $this->stats['dropped']++; return; }
        $dk = $peer . '|' . $p['id'] . '|' . $p['auth'];
        if (isset($this->dedupe[$dk])) { $this->send($this->authSock, $this->dedupe[$dk][1], $peer); return; } // retransmission
        $ip = self::ip($peer);
        $a = self::decode($p);
        $hasMA = self::rawAttr($p, 80) !== null;
        $papEnc = self::rawAttr($p, 2);
        // The router's own Authentication Password proves which hotspot sent this packet — whatever NAS ID Omada put in it.
        $verify = function (array $c) use ($p, $hasMA, $papEnc): ?bool {
            $s = (string)$c['auth'];
            if ($hasMA) return self::checkMA($p, $s);
            if ($papEnc !== null) return !preg_match('/[^\x20-\x7E]/', self::papDecrypt($papEnc, $s, $p['auth']));
            return null; // CHAP without Message-Authenticator cannot be verified here
        };
        [$key, $c, $nas] = $this->resolve((string)($a['NAS-Identifier'] ?? ''), $ip, $verify, 'auth');
        if (!$c) { $this->stats['dropped']++; return; }
        $secret = (string)$c['auth'];
        $auth = ['type' => 'none'];
        if ($papEnc !== null) {
            $pw = self::papDecrypt($papEnc, $secret, $p['auth']);
            $auth = ['type' => 'pap', 'password' => $pw, 'garbled' => (bool)preg_match('/[^\x20-\x7E]/', $pw)];
            if ($auth['garbled']) $this->log("WARN hotspot=$key nas=$nas: password unreadable — Authentication Password in Omada does not match", 'garb' . $key);
        } elseif (($ch = self::rawAttr($p, 3)) !== null && strlen($ch) === 17) {
            $chal = self::rawAttr($p, 60) ?? $p['auth'];
            $auth = ['type' => 'chap', 'id' => bin2hex($ch[0]), 'response' => bin2hex(substr($ch, 1)), 'challenge' => bin2hex($chal)];
        }
        // nas_id = our hotspot key; omada_nas_id = NAS-Identifier exactly as Omada sent it (saved on the device by the website)
        $d = $this->api('authorize', ['nas_id' => $key, 'omada_nas_id' => $nas, 'src_ip' => $ip, 'attrs' => $a, 'auth' => $auth]);
        $accept = is_array($d) && ($d['decision'] ?? '') === 'accept';
        $reply = is_array($d) && is_array($d['reply'] ?? null) ? $d['reply'] : ['Reply-Message' => self::BUSY];
        $attrs = '';
        foreach ($reply as $k => $v) $attrs .= self::enc((string)$k, $v);
        $out = self::reply($accept ? 2 : 3, $p['id'], $p['auth'], $attrs, $secret, true);
        $this->send($this->authSock, $out, $peer);
        $this->dedupe[$dk] = [time(), $out];
        $this->stats[$accept ? 'accept' : 'reject']++;
        $this->log(($accept ? 'ACCEPT ' : 'REJECT ') . ($a['User-Name'] ?? '-') . ' mac=' . ($a['Calling-Station-Id'] ?? '-') . ' nas=' . ($nas !== '' ? $nas : '-') . " [$key] from $ip"
            . ($accept ? ' timeout=' . ($reply['Session-Timeout'] ?? '-') . 's' : ' (' . ($d['message'] ?? 'website API unreachable') . ')'));
    }

    /** RFC 5997 Status-Server: answered with Access-Accept when a hotspot's password verifies the Message-Authenticator. */
    private function onStatusServer(array $p, string $peer): void {
        if (self::rawAttr($p, 80) === null) { $this->stats['dropped']++; return; }
        $a = self::decode($p);
        [$key, $c] = $this->resolve((string)($a['NAS-Identifier'] ?? ''), self::ip($peer), fn(array $c) => self::checkMA($p, (string)$c['auth']), 'auth');
        if (!$c) { $this->stats['dropped']++; return; }
        $this->send($this->authSock, self::reply(2, $p['id'], $p['auth'], self::enc('Reply-Message', 'SkyTanza RADIUS OK'), (string)$c['auth'], true), $peer);
        if ($this->debug) $this->log("STATUS-SERVER from " . self::ip($peer) . " [$key] → OK");
    }

    // ---------------------------------------------------------------- Accounting-Request (UDP 1813)
    private function onAcct(string $data, string $peer): void {
        $p = self::parse($data);
        if (!$p || $p['code'] !== 4) { $this->stats['dropped']++; return; }
        $dk = $peer . '|' . $p['id'] . '|' . $p['auth'];
        if (isset($this->dedupe[$dk])) { $this->send($this->acctSock, $this->dedupe[$dk][1], $peer); return; }
        $ip = self::ip($peer);
        $a = self::decode($p);
        $signed = substr($p['buf'], 0, 4) . str_repeat("\0", 16) . substr($p['buf'], 20);
        [$key, $c, $nas] = $this->resolve((string)($a['NAS-Identifier'] ?? ''), $ip, fn(array $c) => hash_equals(md5($signed . $c['acct'], true), $p['auth']), 'acct');
        if (!$c) { $this->stats['dropped']++; return; }
        $this->queue[] = ['nas_id' => $key, 'omada_nas_id' => $nas, 'src_ip' => $ip, 'attrs' => $a, 'ts' => time()];
        if (count($this->queue) > 20000) array_splice($this->queue, 0, count($this->queue) - 20000);
        $out = self::reply(5, $p['id'], $p['auth'], '', (string)$c['acct'], false);
        $this->send($this->acctSock, $out, $peer);
        $this->dedupe[$dk] = [time(), $out];
        $this->stats['acct']++;
        $st = $a['Acct-Status-Type'] ?? '?';
        if ($this->debug || $st !== 'Interim-Update') $this->log("ACCT $st " . ($a['User-Name'] ?? '-') . ' nas=' . ($nas !== '' ? $nas : '-') . " [$key] from $ip");
    }

    /**
     * Find the hotspot that sent a packet. Returns [hotspot key, client, NAS ID as Omada sent it].
     *  1) hotspots whose saved Omada NAS ID (or old v5 system NAS ID) equals what Omada sent, checked with their passwords;
     *  2) otherwise ANY hotspot whose passwords verify the packet — the NAS ID Omada sent is then learned for it;
     *  3) otherwise the hotspot last seen on that public IP (only when the packet cannot be verified, e.g. CHAP).
     */
    private function resolve(string $rawNas, string $ip, callable $verify, string $kind): array {
        $nas = asciiClean(trim($rawNas), 64);
        $want = strtoupper($nas);
        $wrongKey = '';
        for ($pass = 0; $pass < 2; $pass++) {
            if ($pass === 1 && !$this->refreshClients(true)) break;   // passwords may have just been (re)generated on the website
            $named = [];
            if ($want !== '') foreach ($this->clients as $k => $c)
                if (strtoupper((string)($c['nas'] ?? '')) === $want || (string)$k === $want) $named[] = (string)$k;
            foreach ($named as $k) {
                $v = $verify($this->clients[$k]);
                if ($v === true || ($v === null && count($named) === 1)) return $this->found($k, $nas, $ip);
                if ($v === false && $wrongKey === '') $wrongKey = $k;
            }
            foreach ($this->clients as $k => $c) {
                if (in_array((string)$k, $named, true)) continue;
                if ($verify($c) === true) return $this->found((string)$k, $nas, $ip);
            }
        }
        $byIp = [];
        foreach ($this->clients as $k => $c) if (($c['ip'] ?? '') === $ip && $verify($c) === null) $byIp[] = (string)$k;
        if (count($byIp) === 1) return $this->found($byIp[0], $nas, $ip);
        if ($wrongKey !== '') $this->badPassword($wrongKey, $nas, $ip, $kind);
        else $this->unknownNas($nas !== '' ? $nas : '(empty)', $ip);
        return ['', null, $nas];
    }

    private function found(string $key, string $nas, string $ip): array {
        $this->clients[$key]['ip'] = $ip;
        if ($nas !== '' && strtoupper((string)($this->clients[$key]['nas'] ?? '')) !== strtoupper($nas)) {
            $this->log("LEARN NAS ID '$nas' sent by Omada → hotspot $key", 'learn' . $key . $nas);
            $this->clients[$key]['nas'] = $nas;          // the website saves it on the device with this request
            $this->stats['learned']++;
        }
        return [$key, $this->clients[$key], $nas];
    }

    private function badPassword(string $key, string $nas, string $ip, string $kind): void {
        $k = $key . '|' . $kind;
        $what = $kind === 'auth' ? 'Authentication Password' : 'Accounting Password';
        $this->badpw[$k] = ['key' => $key, 'nas' => $nas, 'ip' => $ip, 'kind' => $what, 'time' => date('c'), 'ts' => time(), 'count' => ($this->badpw[$k]['count'] ?? 0) + 1];
        if (count($this->badpw) > 50) array_shift($this->badpw);
        $this->log("DROP $kind from $ip nas=$nas [$key]: wrong $what in Omada for this hotspot", 'bad' . $k);
    }

    private function unknownNas(string $nas, string $ip): void {
        $k = $nas . '|' . $ip;
        $this->unknown[$k] = ['nas' => $nas, 'ip' => $ip, 'time' => date('c'), 'ts' => time(), 'count' => ($this->unknown[$k]['count'] ?? 0) + 1];
        if (count($this->unknown) > 50) array_shift($this->unknown);
        $this->log("DROP request from $ip (NAS ID '$nas'): no registered hotspot's RADIUS password matches — copy the passwords from Devices → RADIUS settings into Omada", 'unk' . $k);
    }

    // ---------------------------------------------------------------- Disconnect-Request (RFC 5176)
    private function pollDae(): void {
        if (count($this->dae) > 200) return;
        $d = $this->api('dae_queue', []);
        if (!is_array($d)) return;
        foreach ((array)($d['jobs'] ?? []) as $j) if (is_array($j)) $this->sendDae($j);
    }

    private function sendDae(array $j): void {
        $dest = (string)($j['dest'] ?? '');
        $secret = (string)($j['secret'] ?? '');
        if (!preg_match('/^\d{1,3}(\.\d{1,3}){3}:\d{1,5}$/', $dest) || $secret === '') {
            $this->api('dae_ack', ['id' => (int)($j['id'] ?? 0), 'ok' => false, 'result' => 'No NAS address']);
            return;
        }
        $rid = null;
        for ($i = 0; $i < 256; $i++) { $try = ($this->daeSeq++) & 0xFF; if (!isset($this->dae[$try])) { $rid = $try; break; } }
        if ($rid === null) return;
        $attrs = '';
        // NAS-Identifier is sent exactly as Omada reported it (empty = attribute left out)
        foreach (['User-Name' => $j['username'] ?? '', 'Acct-Session-Id' => $j['acct_session_id'] ?? '', 'Calling-Station-Id' => $j['mac'] ?? '',
                  'NAS-Identifier' => $j['nas_id'] ?? '', 'NAS-IP-Address' => $j['nas_ip'] ?? '', 'Framed-IP-Address' => $j['framed_ip'] ?? '',
                  'Event-Timestamp' => time()] as $k => $v) $attrs .= self::enc($k, $v);
        $pkt = self::request(40, $rid, $attrs, $secret);
        $this->send($this->daeSock, $pkt, $dest);
        $this->dae[$rid] = ['job' => (int)$j['id'], 'dest' => $dest, 'pkt' => $pkt, 'auth' => substr($pkt, 4, 16), 'secret' => $secret,
            'sent' => time(), 'tries' => 1, 'user' => (string)($j['username'] ?? '')];
        $this->log('DISCONNECT ' . ($j['username'] ?? '') . ' mac=' . ($j['mac'] ?? '') . ' nas=' . ($j['nas_id'] ?? '') . " → $dest");
    }

    private function onDaeReply(string $data, string $peer): void {
        $p = self::parse($data);
        if (!$p || !isset($this->dae[$p['id']])) return;
        $x = $this->dae[$p['id']];
        if (self::ip($peer) !== self::ip($x['dest'])) return;
        if (!hash_equals(md5(substr($p['buf'], 0, 4) . $x['auth'] . substr($p['buf'], 20) . $x['secret'], true), $p['auth'])) return;
        unset($this->dae[$p['id']]);
        $ok = in_array($p['code'], [41, 44], true);
        $a = self::decode($p);
        $res = $ok ? 'ACK' : 'NAK' . (isset($a['Error-Cause']) ? ' Error-Cause ' . $a['Error-Cause'] : '');
        $this->stats[$ok ? 'dae_ok' : 'dae_fail']++;
        $this->log("DISCONNECT {$x['user']} → $res");
        $this->api('dae_ack', ['id' => $x['job'], 'ok' => $ok, 'result' => $res]);
    }

    // ---------------------------------------------------------------- website API
    /** Reload the hotspot list (key → passwords + NAS ID Omada sends). Returns true when a fresh list was loaded. */
    private function refreshClients(bool $force): bool {
        $now = time();
        if ($force) { if ($now - $this->lastForce < 10) return false; $this->lastForce = $now; }
        elseif ($now - $this->clientsAt < 60) return false;
        $this->badpw = array_filter($this->badpw, fn($x) => $x['ts'] > $now - 900);      // forget problems that stopped 15 min ago
        $this->unknown = array_filter($this->unknown, fn($x) => $x['ts'] > $now - 3600);
        $d = $this->api('clients', ['server' => ['version' => self::VERSION, 'host' => (string)gethostname(), 'uptime' => $now - $this->started,
            'relay_pid' => $this->relayPid, 'relay_mode' => (string)OMADA_RELAY === '0' ? 'off' : (function_exists('pcntl_fork') ? 'child' : 'separate'),
            'queue' => count($this->queue), 'stats' => $this->stats, 'unknown' => array_values(array_slice($this->unknown, -10)),
            'badpw' => array_values(array_slice($this->badpw, -20))]]);
        if (is_array($d) && isset($d['clients']) && is_array($d['clients'])) {
            $fresh = [];
            foreach ($d['clients'] as $k => $c) {
                if (!is_array($c) || empty($c['auth'])) continue;
                $k = strtoupper((string)$k);
                $c += ['acct' => $c['auth'], 'ip' => '', 'nas' => ''];
                if ((string)$c['nas'] === '' && !empty($this->clients[$k]['nas'])) $c['nas'] = $this->clients[$k]['nas']; // learned, not yet saved
                $fresh[$k] = $c;
            }
            $this->clients = $fresh;
            $this->daeEnabled = !empty($d['dae']);
            $this->clientsAt = $now;
            return true;
        }
        $this->clientsAt = $now - 45; // keep the cached list, retry in ~15 s
        return false;
    }

    private function flush(): void {
        $batch = array_slice($this->queue, 0, 200);
        $d = $this->api('accounting', ['records' => $batch], 20);
        if (is_array($d) && !empty($d['ok'])) {
            array_splice($this->queue, 0, count($batch));
            $this->backoff = 1;
            $this->nextFlush = $this->queue ? 0 : time() + 1;
            if (!$this->queue && is_file($this->spool)) @unlink($this->spool);
        } else {
            $this->backoff = min(60, $this->backoff * 2);
            $this->nextFlush = time() + $this->backoff;
            $this->saveSpool();
        }
    }

    /**
     * v5.7.2 — call the website API. Redirects (/index.php → /index, http → https, www) are followed with the same POST,
     * body and X-API-KEY, but only to the SAME host and never from https to http. When the website answers with something
     * that is not its JSON (an HTML 301/404 page), /index, /index.php and / are tried too. The working address is remembered.
     */
    private function api(string $action, array $body, int $timeout = 8): ?array {
        $json = (string)json_encode($body, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        [$code, $res, $err, $base] = $this->call($this->api, $action, $json, $timeout);
        $d = is_string($res) ? json_decode($res, true) : null;
        if (!self::answered($code, $d) && !is_array($d) && time() >= $this->nextProbe) {
            $this->nextProbe = time() + 300;   // at most one search every 5 minutes
            $tried = [$this->api => true, $base => true];
            foreach (array_merge(self::alternatives($this->api), self::alternatives($this->apiConfigured)) as $alt) {
                if (isset($tried[$alt])) continue;
                $tried[$alt] = true;
                [$c2, $r2, $e2, $b2] = $this->call($alt, $action, $json, $timeout);
                $d2 = is_string($r2) ? json_decode($r2, true) : null;
                if (self::answered($c2, $d2) || is_array($d2)) { [$code, $res, $err, $base, $d] = [$c2, $r2, $e2, $b2, $d2]; break; }
            }
        }
        $this->lastCode = $code;
        if (is_array($d)) $this->adoptApi($base);   // the website itself answered here (even 403 = wrong key proves the address)
        if ($this->debug) $this->log("API $action → $base HTTP $code " . substr((string)$res, 0, 300));
        if (!self::answered($code, $d)) {
            $this->stats['api_errors']++;
            $why = $err ?: (is_array($d) && isset($d['error']) ? $d['error'] : substr(trim(preg_replace('/\s+/', ' ', strip_tags((string)$res))), 0, 160));
            $this->lastErr = "HTTP $code $why";
            $this->log("API $action failed: HTTP $code $why", 'api' . $action . $code);
            return null;
        }
        $this->lastErr = '';
        return $d;
    }

    private static function answered(int $code, $d): bool { return $code >= 200 && $code < 300 && is_array($d); }

    /** POST to $base?radius=$action, following up to 5 same-host redirects. Returns [code, body, error, final base]. */
    private function call(string $base, string $action, string $json, int $timeout): array {
        $code = 0; $res = ''; $err = '';
        for ($hop = 0; $hop < 5; $hop++) {
            [$code, $res, $err, $loc] = $this->post(self::withAction($base, $action), $json, $timeout);
            if ($code < 300 || $code >= 400 || $loc === '') break;
            $next = self::redirectBase($base, $loc);
            if ($next === null) { $err = "redirect to $loc refused (other host or https → http) — set RADIUS_API_URL to the final website address"; break; }
            if ($next === $base) { $err = "redirect loop at $loc"; break; }
            $this->log("API $base redirects (HTTP $code) to $next — following it", 'redir' . $base . $next);
            $base = $next;
        }
        return [$code, $res, $err, $base];
    }

    /** One POST without automatic redirects. Returns [code, body, error, Location header]. */
    private function post(string $url, string $json, int $timeout): array {
        $hdr = ['Content-Type: application/json', 'Accept: application/json', 'X-API-KEY: ' . $this->key];
        $res = false; $code = 0; $err = ''; $loc = '';
        if (function_exists('curl_init')) {
            if (!$this->curl) $this->curl = curl_init();
            curl_setopt_array($this->curl, [CURLOPT_URL => $url, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $json, CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_HTTPHEADER => $hdr, CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_USERAGENT => 'SkyTanzaRadius/' . self::VERSION]);
            $res = curl_exec($this->curl);
            $code = (int)curl_getinfo($this->curl, CURLINFO_HTTP_CODE);
            $err = curl_error($this->curl);
            $loc = (string)curl_getinfo($this->curl, CURLINFO_REDIRECT_URL);
        } else {
            $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => implode("\r\n", $hdr) . "\r\nUser-Agent: SkyTanzaRadius/" . self::VERSION,
                'content' => $json, 'timeout' => $timeout, 'ignore_errors' => true, 'follow_location' => 0, 'max_redirects' => 1]]);
            $res = @file_get_contents($url, false, $ctx);
            $h = function_exists('http_get_last_response_headers') ? (http_get_last_response_headers() ?? []) : ($http_response_header ?? []);
            foreach ((array)$h as $line) {
                if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) { $code = (int)$m[1]; $loc = ''; }
                elseif (stripos($line, 'Location:') === 0) $loc = trim(substr($line, 9));
            }
            if ($res === false && $code === 0) $err = 'connection failed';
        }
        return [$code, is_string($res) ? $res : '', $err, $loc];
    }

    /** $base + "?radius=action" (or "&radius=action"). */
    public static function withAction(string $base, string $action): string {
        return $base . (strpos($base, '?') === false ? '?' : '&') . 'radius=' . rawurlencode($action);
    }

    /**
     * Where to send the next API call after a redirect: the Location without our "radius=" parameter.
     * null when it leaves the host (www. is ignored) or goes from https to http — the API key is never sent elsewhere.
     */
    public static function redirectBase(string $base, string $loc): ?string {
        $b = parse_url($base);
        $loc = trim($loc);
        if (!$b || empty($b['host']) || $loc === '') return null;
        $bs = strtolower((string)($b['scheme'] ?? 'https'));
        if (strpos($loc, '//') === 0) $loc = $bs . ':' . $loc;
        elseif (!preg_match('#^https?://#i', $loc)) {
            $dir = rtrim(str_replace('\\', '/', dirname((string)($b['path'] ?? '/') . 'x')), '/');
            $loc = $bs . '://' . $b['host'] . (isset($b['port']) ? ':' . (int)$b['port'] : '') . ($loc[0] === '/' ? $loc : $dir . '/' . $loc);
        }
        $l = parse_url($loc);
        if (!$l || empty($l['host'])) return null;
        $norm = fn($h) => (string)preg_replace('/^www\./', '', strtolower((string)$h));
        if ($norm($b['host']) !== $norm($l['host'])) return null;
        $ls = strtolower((string)($l['scheme'] ?? 'https'));
        if (!in_array($ls, ['http', 'https'], true) || ($bs === 'https' && $ls !== 'https')) return null;
        $q = [];
        parse_str((string)($l['query'] ?? ''), $q);
        unset($q['radius']);
        return $ls . '://' . strtolower((string)$l['host']) . (isset($l['port']) ? ':' . (int)$l['port'] : '') . ((string)($l['path'] ?? '') !== '' ? $l['path'] : '/')
            . ($q ? '?' . http_build_query($q) : '');
    }

    /** Other addresses of the same index.php: /index ↔ /index.php and the folder itself (/). */
    private static function alternatives(string $base): array {
        $p = parse_url($base);
        if (!$p || empty($p['host'])) return [];
        $origin = strtolower((string)($p['scheme'] ?? 'https')) . '://' . $p['host'] . (isset($p['port']) ? ':' . (int)$p['port'] : '');
        $path = (string)($p['path'] ?? '/');
        if ($path === '') $path = '/';
        $out = [];
        if (substr($path, -1) === '/') { $out[] = $origin . $path . 'index.php'; $out[] = $origin . $path . 'index'; }
        else {
            if (preg_match('#^(.*)\.php$#i', $path, $m)) $out[] = $origin . $m[1];
            else $out[] = $origin . $path . '.php';
            $out[] = $origin . rtrim(str_replace('\\', '/', dirname($path)), '/') . '/';
        }
        return array_values(array_unique(array_filter($out, fn($u) => $u !== $base)));
    }

    /** Remember the address that answered (survives restarts; reset automatically when RADIUS_API_URL changes). */
    private function adoptApi(string $url): void {
        if ($url === $this->api) return;
        $this->api = $url;
        $this->log("Website API now used: $url (RADIUS_API_URL is {$this->apiConfigured}) — saved; put define('RADIUS_API_URL', '$url'); in config.local.php to make it permanent");
        @file_put_contents($this->apiFile, (string)json_encode(['from' => $this->apiConfigured, 'to' => $url, 'at' => date('c')], JSON_UNESCAPED_SLASHES), LOCK_EX);
    }

    // ---------------------------------------------------------------- v5.9 Omada relay
    /**
     * The website (often on shared hosting) cannot open connections to a self-hosted Omada controller (port 8043 / 29814).
     * The relay runs in a child process of the RADIUS server: it long-polls ?radius=omada_jobs, performs each HTTP / TCP
     * request against the controller from THIS box and posts the answer to ?radius=omada_result. Only outgoing HTTPS from
     * this box is used — no extra port is opened.
     */
    private function startRelay(): void {
        if ((string)OMADA_RELAY === '0') { $this->log('Omada relay: switched off (OMADA_RELAY=0)'); return; }
        if (!function_exists('pcntl_fork')) {
            $this->log('Omada relay: PHP pcntl is not available — run "php index.php omada-relay" as a second service (see Admin → RADIUS Setup)', 'relaynopcntl');
            return;
        }
        $pid = @pcntl_fork();
        if ($pid === -1) { $this->log('Omada relay: fork failed — retrying in 30 s'); $this->relayNext = time() + 30; return; }
        if ($pid === 0) {
            // child: give the UDP sockets back to the parent, never touch the accounting spool
            foreach ([$this->authSock, $this->acctSock, $this->daeSock] as $sk) if (is_resource($sk)) @fclose($sk);
            $this->authSock = $this->acctSock = $this->daeSock = null;
            $this->curl = null; $this->queue = []; $this->isRelay = true;
            $this->relayLoop();
            exit(0);
        }
        $this->relayPid = $pid;
        $this->relayStarted = time();
    }

    /** Parent: restart the relay when it died (10 s pause, so a broken setup does not spin). */
    private function watchRelay(): void {
        if ($this->isRelay) return;
        if ($this->relayPid && function_exists('pcntl_waitpid')) {
            $st = 0;
            $r = pcntl_waitpid($this->relayPid, $st, WNOHANG);
            if ($r === $this->relayPid || $r === -1) {
                $this->log('Omada relay stopped (pid ' . $this->relayPid . ') — restarting in 10 s');
                $this->relayPid = 0;
                $this->relayNext = time() + 10;
            }
        }
        if (!$this->relayPid && $this->relayNext && time() >= $this->relayNext) { $this->relayNext = 0; $this->startRelay(); }
    }

    private function stopRelay(): void {
        if (!$this->relayPid) return;
        if (function_exists('posix_kill')) @posix_kill($this->relayPid, defined('SIGTERM') ? SIGTERM : 15);
        if (function_exists('pcntl_waitpid')) { $st = 0; for ($i = 0; $i < 20; $i++) { if (pcntl_waitpid($this->relayPid, $st, WNOHANG) !== 0) break; pauseMs(100); } }
        $this->relayPid = 0;
    }

    /** "php index.php omada-relay": the relay alone (for boxes without pcntl, or to run it on another machine). */
    private function runRelayOnly(): void {
        extendTimeLimit(0);
        if ($this->keyWeak()) { $this->log('FATAL: RADIUS_API_KEY is not set. Put the same key as the website in config.local.php next to index.php.'); exit(1); }
        if (function_exists('pcntl_async_signals')) {
            pcntl_async_signals(true);
            foreach ([SIGTERM, SIGINT] as $sig) pcntl_signal($sig, function () { $this->stop = true; });
        }
        $this->isRelay = true;
        $this->standalone = true;
        $this->relayLoop();
    }

    private function relayLoop(): void {
        $wait = max(0, min(25, (int)OMADA_RELAY_WAIT));
        $this->log('Omada relay ' . self::VERSION . ' started (pid ' . getmypid() . ') — website ' . $this->api . ' • long-poll ' . $wait . ' s');
        $backoff = 2;
        $started = time();
        while (!$this->stop) {
            $d = $this->api('omada_jobs', ['wait' => $wait, 'relay' => ['version' => self::VERSION, 'host' => (string)gethostname(), 'pid' => getmypid(),
                'uptime' => time() - $started, 'stats' => $this->relayStats, 'pcntl' => function_exists('pcntl_fork'),
                'standalone' => $this->standalone, 'os' => PHP_OS_FAMILY]], $wait + 20);
            if ($this->stop) break;
            if (!is_array($d) || empty($d['ok'])) {
                // website older than 5.9, wrong key, or offline — wait and try again
                $this->log('Omada relay: website did not answer omada_jobs (' . ($this->lastErr ?: 'update the website index.php to v5.9') . ') — retry in ' . $backoff . ' s', 'relayfail');
                for ($i = 0; $i < $backoff * 10 && !$this->stop; $i++) pauseMs(100);
                $backoff = min(60, $backoff * 2);
                continue;
            }
            $backoff = 2;
            foreach (array_slice((array)($d['jobs'] ?? []), 0, 20) as $job) {
                if (!is_array($job) || $this->stop) continue;
                $res = $this->relayExec($job);
                $this->api('omada_result', $res, 25);
            }
            if ($wait === 0 && empty($d['jobs'])) for ($i = 0; $i < 20 && !$this->stop; $i++) pauseMs(100);   // short-poll mode: every 2 s
            elseif (!empty($d['sleep'])) for ($i = 0; $i < min(600, (int)$d['sleep'] * 10) && !$this->stop; $i++) pauseMs(100);
        }
        $this->log('Omada relay stopped.');
    }

    /** True when the relay may connect to this host (never link-local / "this network"; loopback only when allowed). */
    private static function relayHostOk(string $host, ?string &$why = null): bool {
        $host = trim($host, '[]');
        if ($host === '' || !preg_match('/^[A-Za-z0-9.\-:]+$/', $host)) { $why = 'invalid host'; return false; }
        $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : (string)gethostbyname($host);
        if (!filter_var($ip, FILTER_VALIDATE_IP)) { $why = "cannot resolve $host on the RADIUS box"; return false; }
        if (preg_match('/^(0\.|169\.254\.)/', $ip) || $ip === '::' ) { $why = "address $ip is not allowed"; return false; }
        if ((preg_match('/^127\./', $ip) || $ip === '::1') && (string)OMADA_RELAY_ALLOW_LOCAL !== '1') {
            $why = "address $ip (this box) is blocked — use the controller's public IP, or set define('OMADA_RELAY_ALLOW_LOCAL', '1')"; return false;
        }
        return true;
    }

    /** Run one job from the website: kind http (method/url/headers/body) or tcp (host/port). */
    private function relayExec(array $j): array {
        $id = (int)($j['id'] ?? 0);
        $t0 = microtime(true);
        $timeout = max(2, min(60, (int)($j['timeout'] ?? 10)));
        $out = ['id' => $id, 'code' => 0, 'body' => '', 'error' => '', 'ms' => 0];
        try {
            if (($j['kind'] ?? 'http') === 'tcp') {
                $host = (string)($j['host'] ?? ''); $port = (int)($j['port'] ?? 0); $why = '';
                if ($port < 1 || $port > 65535 || !self::relayHostOk($host, $why)) $out['error'] = $why ?: 'invalid port';
                else {
                    $en = 0; $es = '';
                    $f = @stream_socket_client('tcp://' . (strpos($host, ':') !== false && strpos($host, '[') !== 0 ? '[' . $host . ']' : $host) . ':' . $port, $en, $es, min(10, $timeout));
                    if ($f) { fclose($f); $out['code'] = 1; } else $out['error'] = trim($es) !== '' ? trim($es) : 'connection failed';
                }
            } else {
                $url = (string)($j['url'] ?? '');
                $p = parse_url($url);
                $why = '';
                if (!$p || !in_array(strtolower((string)($p['scheme'] ?? '')), ['http', 'https'], true) || empty($p['host'])) $out['error'] = 'invalid URL';
                elseif (!self::relayHostOk((string)$p['host'], $why)) $out['error'] = $why;
                elseif (!function_exists('curl_init')) $out['error'] = 'php-curl is not installed on the RADIUS box (apt install php-curl)';
                else {
                    $method = strtoupper(preg_replace('/[^A-Za-z]/', '', (string)($j['method'] ?? 'GET'))) ?: 'GET';
                    $hdr = [];
                    foreach ((array)($j['headers'] ?? []) as $h) if (is_string($h) && $h !== '' && strpbrk($h, "\r\n") === false) $hdr[] = $h;
                    $verify = !empty($j['verify_ssl']);
                    $ch = curl_init($url);
                    $o = [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => $timeout,
                        CURLOPT_CONNECTTIMEOUT => min(8, $timeout), CURLOPT_HTTPHEADER => $hdr, CURLOPT_USERAGENT => 'SkyTanzaRelay/' . self::VERSION,
                        CURLOPT_SSL_VERIFYPEER => $verify, CURLOPT_SSL_VERIFYHOST => $verify ? 2 : 0];
                    if (defined('CURLOPT_PROTOCOLS')) $o[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
                    if (isset($j['body']) && is_string($j['body'])) $o[CURLOPT_POSTFIELDS] = $j['body'];
                    curl_setopt_array($ch, $o);
                    $raw = curl_exec($ch);
                    $out['code'] = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $out['error'] = (string)curl_error($ch);
                    curl_close($ch);
                    $raw = is_string($raw) ? $raw : '';
                    if (strlen($raw) > 8388608) { $raw = ''; $out['error'] = 'answer larger than 8 MB'; }
                    $out['body'] = base64_encode($raw);   // binary-safe through JSON
                    $out['b64'] = 1;
                }
            }
        } catch (Throwable $e) { $out['error'] = 'relay: ' . $e->getMessage(); }
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $ok = $out['error'] === '';
        $this->relayStats['jobs']++;
        $this->relayStats[$ok ? 'ok' : 'fail']++;
        $this->relayStats['last_ms'] = $out['ms'];
        $this->relayStats['last_at'] = date('c');
        if (!$ok) $this->relayStats['last_error'] = substr($out['error'], 0, 200);
        if ($this->debug || !$ok) $this->log('RELAY ' . (($j['kind'] ?? 'http') === 'tcp' ? 'TCP ' . ($j['host'] ?? '') . ':' . ($j['port'] ?? '')
            : ($j['method'] ?? 'GET') . ' ' . preg_replace('/[?].*$/', '', (string)($j['url'] ?? ''))) . ' → ' . ($ok ? 'HTTP ' . $out['code'] : 'ERROR ' . $out['error']) . ' (' . $out['ms'] . ' ms)', $ok ? '' : 'relayerr' . md5($out['error']));
        return $out;
    }

    /** --test: can this box reach every Omada controller the website knows? */
    private function relaySelfTest(): void {
        $d = $this->api('omada_targets', []);
        if (!is_array($d) || !isset($d['targets'])) { $this->log('INFO: Omada relay check skipped — the website is older than v5.9 (upload the new index.php to cPanel too)'); return; }
        if ($this->standalone) $this->log('OK  : Omada relay running as its own service (php index.php omada-relay)');
        else $this->log('OK  : Omada relay ' . ((string)OMADA_RELAY === '0' ? 'is switched off (OMADA_RELAY=0)' : (function_exists('pcntl_fork') ? 'starts with the radius-server service' : 'needs its own service: php index.php omada-relay (no pcntl)')));
        foreach (array_slice((array)$d['targets'], 0, 20) as $t) {
            if (!is_array($t)) continue;
            $host = (string)($t['host'] ?? '');
            $r = $this->relayExec(['kind' => 'tcp', 'host' => $host, 'port' => (int)($t['port'] ?? 0), 'timeout' => 6]);
            $this->log(($r['error'] === '' ? 'OK  : ' : 'FAIL: ') . ($t['label'] ?? '') . ' ' . $host . ':' . ($t['port'] ?? '')
                . ($r['error'] === '' ? ' reachable (' . $r['ms'] . ' ms)' : ' — ' . $r['error'] . (($t['hint'] ?? '') !== '' ? "\n      HINT: " . $t['hint'] : '')));
        }
        if (!$d['targets']) $this->log('INFO: no Omada controller is linked on the website yet');
    }

    private function selfTest(): bool {
        $this->log('Website API : ' . $this->apiConfigured . ($this->api !== $this->apiConfigured ? '  (last working address: ' . $this->api . ')' : ''));
        if ($this->keyWeak()) { $this->log('FAIL: RADIUS_API_KEY missing — copy config.local.php from the website RADIUS Setup page'); return false; }
        $this->nextProbe = 0;
        $p = $this->api('ping', []);
        if (!$p || empty($p['ok'])) {
            $this->log('FAIL: website API not reachable or key rejected (' . ($this->lastErr ?: 'see message above') . ')');
            if ($this->lastCode === 403) $this->log('HINT: HTTP 403 = RADIUS_API_KEY differs from the website, or this IP is not in "Only accept API calls from these IPs".');
            elseif ($this->lastCode >= 300 && $this->lastCode < 400) $this->log('HINT: the host keeps redirecting. Open the final address in a browser, then set RADIUS_API_URL to it, or add the .htaccess lines from Admin → RADIUS Setup.');
            elseif ($this->lastCode === 0) $this->log('HINT: no connection — check DNS / firewall / HTTPS on this box: curl -sv ' . $this->api);
            else $this->log('HINT: the address does not run this index.php. Check RADIUS_API_URL (e.g. https://your-domain/index.php or https://your-domain/).');
            return false;
        }
        $this->log('OK  : website reachable at ' . $this->api . ', app version ' . ($p['version'] ?? '?'));
        if ($this->api !== $this->apiConfigured)
            $this->log("TIP : the website redirects. It works already (address saved), but to skip the redirect put this in /opt/skyradius/config.local.php:\n      define('RADIUS_API_URL', '{$this->api}');");
        if ($this->standalone) { $this->relaySelfTest(); return true; }   // the relay-only service is no RADIUS server — skip hotspots / UDP ports
        $this->refreshClients(false);
        $list = [];
        foreach (array_slice($this->clients, 0, 15, true) as $k => $c) $list[] = $k . ' (NAS ID ' . ((string)($c['nas'] ?? '') !== '' ? $c['nas'] : 'not received yet') . ')';
        $this->log('OK  : ' . count($this->clients) . ' hotspot(s): ' . (implode(', ', $list) ?: 'none yet — add an EAP225 on the website'));
        foreach ([RADIUS_AUTH_PORT, RADIUS_ACCT_PORT] as $port) {
            $s = @stream_socket_server('udp://' . RADIUS_BIND_IP . ':' . $port, $en, $es, STREAM_SERVER_BIND);
            if ($s) { fclose($s); $this->log("OK  : UDP $port is free"); }
            else $this->log("INFO: UDP $port is in use ($es) — normal if the skyradius service is already running");
        }
        $this->relaySelfTest();
        return true;
    }

    // ---------------------------------------------------------------- packet helpers
    private function keyWeak(): bool { return strlen($this->key) < 24 || $this->key === 'change-radius-api-key-to-a-long-random-string'; }

    private function bind(int $port) {
        $s = @stream_socket_server('udp://' . RADIUS_BIND_IP . ':' . $port, $errno, $errstr, STREAM_SERVER_BIND);
        if (!$s) { $this->log("FATAL: cannot open UDP port $port: $errstr (already running? check: systemctl status skyradius)"); exit(1); }
        stream_set_blocking($s, false);
        return $s;
    }

    private function send($sock, string $pkt, string $peer): void { @stream_socket_sendto($sock, $pkt, 0, $peer); }

    private function log(string $m, string $once = ''): void {
        if ($once !== '') { if (($this->logged[$once] ?? 0) > time() - 300) return; $this->logged[$once] = time(); }
        fwrite(STDOUT, '[' . date('Y-m-d H:i:s') . '] ' . $m . PHP_EOL);
    }

    private function loadSpool(): void {
        if (!is_file($this->spool)) return;
        $d = json_decode((string)@file_get_contents($this->spool), true);
        if (is_array($d) && $d) { $this->queue = array_merge($d, $this->queue); $this->log('Loaded ' . count($d) . ' saved accounting record(s)'); }
    }

    private function saveSpool(): void {
        if ($this->queue) @file_put_contents($this->spool, json_encode($this->queue, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE), LOCK_EX);
        elseif (is_file($this->spool)) @unlink($this->spool);
    }

    private static function ip(string $peer): string { $i = strrpos($peer, ':'); return trim($i === false ? $peer : substr($peer, 0, $i), '[]'); }

    private static function parse(string $buf): ?array {
        if (strlen($buf) < 20) return null;
        $len = unpack('n', substr($buf, 2, 2))[1];
        if ($len < 20 || $len > 4096 || $len > strlen($buf)) return null;
        $buf = substr($buf, 0, $len);
        $raw = []; $pos = 20;
        while ($pos < $len) {
            if ($pos + 2 > $len) return null;
            $t = ord($buf[$pos]); $l = ord($buf[$pos + 1]);
            if ($l < 2 || $pos + $l > $len) return null;
            $raw[] = [$t, (string)substr($buf, $pos + 2, $l - 2), $pos];
            $pos += $l;
        }
        return ['code' => ord($buf[0]), 'id' => ord($buf[1]), 'auth' => substr($buf, 4, 16), 'raw' => $raw, 'buf' => $buf];
    }

    private static function rawAttr(array $p, int $type): ?string { foreach ($p['raw'] as $a) if ($a[0] === $type) return $a[1]; return null; }

    private static function decode(array $p): array {
        $o = [];
        foreach ($p['raw'] as $a) {
            [$t, $v] = $a;
            if (!isset(self::DICT[$t]) || isset($o[self::DICT[$t][0]])) continue;
            [$name, $type] = self::DICT[$t];
            if ($type === 'integer') {
                if (strlen($v) !== 4) continue;
                $v = unpack('N', $v)[1];
                if ($t === 40) $v = self::STATUS[$v] ?? $v;
                if ($t === 49) $v = self::CAUSE[$v] ?? $v;
            } elseif ($type === 'ipaddr') {
                if (strlen($v) !== 4) continue;
                $v = inet_ntop($v);
            } else $v = rtrim($v, "\0");
            $o[$name] = (string)$v;
        }
        return $o;
    }

    /** Message-Authenticator (RFC 3579) of a request: HMAC-MD5 over the packet with the attribute zeroed. */
    private static function checkMA(array $p, string $secret): bool {
        foreach ($p['raw'] as $a) {
            if ($a[0] !== 80) continue;
            if (strlen($a[1]) !== 16) return false;
            $b = substr_replace($p['buf'], str_repeat("\0", 16), $a[2] + 2, 16);
            return hash_equals(hash_hmac('md5', $b, $secret, true), $a[1]);
        }
        return true;
    }

    private static function papDecrypt(string $enc, string $secret, string $ra): string {
        $n = strlen($enc);
        if ($n === 0 || $n % 16 !== 0 || $n > 128) return '';
        $out = ''; $prev = $ra;
        for ($i = 0; $i < $n; $i += 16) { $c = substr($enc, $i, 16); $out .= $c ^ md5($secret . $prev, true); $prev = $c; }
        return rtrim($out, "\0");
    }

    private static function enc(string $name, $value): string {
        if (!isset(self::ENC[$name]) || $value === null || $value === '') return '';
        [$t, $vendor, $vt, $type] = self::ENC[$name];
        if ($type === 'integer') $v = pack('N', max(0, min(4294967295, (int)$value)));
        elseif ($type === 'ipaddr') { $v = @inet_pton((string)$value); if ($v === false || strlen($v) !== 4) return ''; }
        else $v = substr((string)$value, 0, 240);
        if ($vendor) $v = pack('N', $vendor) . chr($vt) . chr(strlen($v) + 2) . $v;
        return chr($t) . chr(strlen($v) + 2) . $v;
    }

    /** Access-Accept/Reject/Accounting-Response. Message-Authenticator first (BlastRADIUS-safe), then Response Authenticator. */
    private static function reply(int $code, int $id, string $reqAuth, string $attrs, string $secret, bool $withMA): string {
        if ($withMA) {
            $attrs = chr(80) . chr(18) . str_repeat("\0", 16) . $attrs;
            $hdr = chr($code) . chr($id) . pack('n', 20 + strlen($attrs));
            $attrs = chr(80) . chr(18) . hash_hmac('md5', $hdr . $reqAuth . $attrs, $secret, true) . substr($attrs, 18);
        }
        $hdr = chr($code) . chr($id) . pack('n', 20 + strlen($attrs));
        return $hdr . md5($hdr . $reqAuth . $attrs . $secret, true) . $attrs;
    }

    /** Disconnect-Request / CoA-Request (RFC 5176 §2.3 + §3.5). */
    private static function request(int $code, int $id, string $attrs, string $secret): string {
        $zero = str_repeat("\0", 16);
        $attrs .= chr(80) . chr(18) . $zero;
        $hdr = chr($code) . chr($id) . pack('n', 20 + strlen($attrs));
        $attrs = substr($attrs, 0, -16) . hash_hmac('md5', $hdr . $zero . $attrs, $secret, true);
        return $hdr . md5($hdr . $zero . $attrs . $secret, true) . $attrs;
    }
}

// The RADIUS box starts here and never touches the database.
if (PHP_SAPI === 'cli' && in_array($argv[1] ?? '', ['radius-server', 'radius', 'omada-relay'], true)) { RadiusServer::main($argv); exit(0); }
if (PHP_SAPI === 'cli' && in_array($argv[1] ?? '', ['help', '-h', '--help'], true)) {
    echo "SkyTanza WiFi " . APP_VERSION . "\n"
       . "  php index.php radius-server          run the external RADIUS server (UDP " . RADIUS_AUTH_PORT . "/" . RADIUS_ACCT_PORT . ")\n"
       . "  php index.php radius-server --test   check the website API, the key and the ports, then exit\n"
       . "  php index.php radius-server --debug  log every packet and API call\n"
       . "  php index.php omada-relay            run only the Omada relay (website → this box → Omada controller)\n"
       . "  php index.php omada-relay --test     relay only: check the website and test every Omada controller\n"
       . "  php index.php                        run housekeeping once (website server only)\n";
    exit(0);
}

// ============================================================
// DATABASE
// ============================================================
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+03:00'");
} catch (Throwable $e) {
    error_log('DB connect failed: ' . $e->getMessage());
    http_response_code(500);
    if (isset($_GET['radius'])) { header('Content-Type: application/json'); echo '{"error":"db"}'; exit; }
    if (PHP_SAPI === 'cli') { fwrite(STDERR, "Database connection failed: " . $e->getMessage() . "\n"); exit(1); }
    header('Content-Type: text/html; charset=utf-8');
    $noCfg = !is_file(__DIR__ . '/config.local.php');
    echo '<!DOCTYPE html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup</title>'
       . '<div style="font-family:system-ui,Arial,sans-serif;max-width:620px;margin:40px auto;padding:24px;border:1px solid #ccc;border-radius:14px;line-height:1.5">'
       . '<h2 style="margin-top:0">Database connection error</h2>'
       . ($noCfg || DB_PASS === ''
            ? '<p>The database password is not set. Since v5.7.1 passwords are no longer inside index.php.</p>'
              . '<p>Create <b>config.local.php</b> in the same folder as index.php (cPanel → File Manager) with:</p>'
              . '<pre style="background:#f4f4f4;padding:12px;border-radius:8px;overflow:auto">&lt;?php\ndefine(\'DB_USER\', \'your_db_user\');\ndefine(\'DB_PASS\', \'your_db_password\');\ndefine(\'DB_NAME\', \'your_db_name\');</pre>'
            : '<p>Check DB_HOST, DB_USER, DB_PASS and DB_NAME in config.local.php.</p>')
       . '</div>';
    exit;
}
function db(): mysqli { global $conn; return $conn; }
function q(string $sql, string $types = '', ...$params): mysqli_stmt {
    $st = db()->prepare($sql);
    if ($types !== '') $st->bind_param($types, ...$params);
    $st->execute();
    return $st;
}
function rows(string $sql, string $types = '', ...$p): array { $r = q($sql, $types, ...$p)->get_result(); return $r ? $r->fetch_all(MYSQLI_ASSOC) : []; }
function row(string $sql, string $types = '', ...$p): ?array { $r = q($sql, $types, ...$p)->get_result(); return $r ? ($r->fetch_assoc() ?: null) : null; }
function val(string $sql, string $types = '', ...$p) { $r = row($sql, $types, ...$p); return $r ? reset($r) : null; }
function run(string $sql, string $types = '', ...$p): int { return q($sql, $types, ...$p)->affected_rows; }

// ============================================================
// SESSION (not started for machine endpoints: RADIUS / cron / webhook / pwa)
// ============================================================
$isMachine = PHP_SAPI === 'cli' || isset($_GET['radius']) || isset($_GET['cron']) || isset($_GET['webhook']) || isset($_GET['pwa']);
if (!$isMachine && session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_name('SKYWIFI');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
// v5.3 FIX: Omada appends "?clientMac=...&apMac=..." to the External Web Portal URL. If an old portal URL already
// contained "?page=portal", PHP sees page="portal?clientMac=..." — recover the real parameters here.
$rawPage = (string)($_GET['page'] ?? '');
if (strpos($rawPage, '?') !== false) {
    [$rawPage, $extraQs] = explode('?', $rawPage, 2);
    parse_str($extraQs, $extraParams);
    foreach ($extraParams as $k => $v) if (!isset($_GET[$k])) $_GET[$k] = $v;
}
$page = preg_replace('/[^a-z_]/', '', $rawPage);
if ($page === 'devices') $page = 'routers';   // v5.5: the old "devices" page is now Routers (old links keep working)
// Clean portal URL (index.php without query): Omada redirects phones here with clientMac/apMac → captive portal.
if ($page === '' && (isset($_GET['clientMac']) || isset($_GET['apMac']))) $page = 'portal';

// ============================================================
// LANGUAGE — v6.2: the whole system runs in English only (Swahili translation removed)
// ============================================================
$currentLang = 'en';

$T = [
'en' => [
 'app_title'=>'WiFi Seller Platform','login'=>'Login','register'=>'Register','logout'=>'Logout','dashboard'=>'Dashboard',
 'devices'=>'Routers','packages'=>'Packages','vouchers'=>'Vouchers','sessions'=>'Live Sessions','orders'=>'Orders',
 'adjustments'=>'Time Adjustments','transactions'=>'Transactions','withdraw'=>'Withdraw','profile'=>'Profile','settings'=>'Settings',
 'notifications'=>'Notifications','admin_panel'=>'Admin Panel','radius_setup'=>'RADIUS Setup','main_menu'=>'Main','hotspot_menu'=>'Hotspot',
 'money_menu'=>'Money','account_menu'=>'Account','admin_menu'=>'Administration',
 'username_email_phone'=>'Username / Email / Phone','password'=>'Password','invalid_credentials'=>'Invalid username or password',
 'session_expired'=>'Session expired. Please login again.','no_account'=>"Don't have an account?",'create_account'=>'Create Seller Account',
 'full_name'=>'Full Name','username'=>'Username','email'=>'Email','phone'=>'Phone','all_fields_required'=>'All fields are required',
 'password_min'=>'Password must be at least 6 characters','already_account'=>'Already have an account?','welcome_back'=>'Welcome back',
 'today_revenue'=>"Today's Online Sales",'month_revenue'=>'This Month','total_revenue'=>'All-time Online Sales','active_sessions'=>'Active Sessions',
 'available_vouchers'=>'Unused Vouchers','active_vouchers'=>'Vouchers In Use','used_today'=>'Vouchers Started Today','pending_orders'=>'Pending Payments',
 'devices_online'=>'APs Online','balance'=>'Balance','recent_orders'=>'Recent Orders','no_data'=>'Nothing here yet.','view_all'=>'View all',
 'add_device'=>'Add router','edit_device'=>'Edit router','device_name'=>'Device Name','ap_mac'=>'AP MAC Address','ssid'=>'SSID (WiFi name)',
 'site_name'=>'Omada Site','controller_url'=>'Controller Portal URL (optional)',
 'controller_url_help'=>'Leave empty to auto-detect from Omada redirect. Example: http://192.168.0.10:8088 or your Cloud controller URL.',
 'lipa_info'=>'Lipa Namba / Payment instructions','lipa_info_help'=>'Shown on the portal when automatic mobile-money is off, e.g. "M-Pesa Lipa 123456 — SKY TANZANIA".',
 'location'=>'Location','save'=>'Save','edit'=>'Edit','delete'=>'Delete','confirm_delete'=>'Delete this item?','online'=>'Online','offline'=>'Offline',
 'last_seen'=>'Last RADIUS contact','never'=>'Never','saved'=>'Saved successfully.','deleted'=>'Deleted.','cancel'=>'Cancel',
 'create_package'=>'Create Package','edit_package'=>'Edit Package','package'=>'Package','package_name'=>'Package Name','description'=>'Description','price'=>'Price',
 'duration'=>'Duration','duration_minutes'=>'Duration (minutes)','time_mode'=>'Time counting','continuous'=>'Continuous (clock starts at first login)',
 'online_time'=>'Online time only (pauses when offline)','data_limit_mb'=>'Data limit MB (0 = unlimited)','speed_down'=>'Download Mbps (0 = no limit)',
 'speed_up'=>'Upload Mbps (0 = no limit)','max_devices'=>'Devices per voucher','validity_days'=>'Must be used within (days, 0 = never expires)',
 'show_on_portal'=>'Sell on portal','active'=>'Active','inactive'=>'Inactive','all_my_aps'=>'All my EAP225 devices','minutes'=>'minutes','unlimited'=>'Unlimited',
 'generate'=>'Generate','generate_vouchers'=>'Generate Vouchers','quantity'=>'Quantity','batch'=>'Batch','code'=>'Code','status'=>'Status','print'=>'Print',
 'export_csv'=>'Export CSV','block'=>'Block','unblock'=>'Unblock','expires'=>'Expires','remaining'=>'Remaining','data_used'=>'Data used','filter'=>'Filter',
 'all'=>'All','search'=>'Search','mac'=>'MAC','ip'=>'IP','started'=>'Started','disconnect'=>'Disconnect','block_device'=>'Block device',
 'adjust_time'=>'Adjust time','reason'=>'Reason','apply_to_selected'=>'Apply to selected','adjustment_success'=>'Voucher time adjusted.',
 'adjustment_failed'=>'Could not adjust time.','disconnect_queued'=>'Disconnect requested. It runs within ~15 seconds if the DAE worker is enabled; otherwise the session ends at its timeout.',
 'device_blocked_ok'=>'Device blocked. It cannot log in again.','device_unblocked_ok'=>'Device unblocked.','blocked_devices'=>'Blocked devices',
 'order_ref'=>'Order Ref','amount'=>'Amount','mark_paid'=>'Confirm paid','order_paid'=>'Order confirmed and voucher issued.','date'=>'Date','type'=>'Type',
 'method'=>'Method','reference'=>'Reference','your_balance'=>'Your Balance','minimum_withdrawal'=>'Minimum withdrawal','platform_fee'=>'Platform fee',
 'sonic_pesa_fee'=>'Sonic Pesa fee','request_withdrawal'=>'Request Withdrawal','withdrawal_history'=>'Withdrawal History','account_number'=>'Account / Phone Number',
 'account_name'=>'Account Name','submit_request'=>'Submit Request','insufficient_balance'=>'Insufficient balance','below_minimum'=>'Amount is below minimum withdrawal',
 'invalid_method'=>'Invalid withdrawal method','withdrawal_failed'=>'Withdrawal failed. Please try again.','withdrawal_pending'=>'Your withdrawal is processing',
 'withdrawal_pending_desc'=>'The request was received and sent to Sonic Pesa.','sonic_pesa_minimum'=>'Sonic Pesa requires a minimum payout of TZS 30,000.',
 'fee'=>'Fee','net_amount'=>'Net','you_receive'=>'You receive','change_password'=>'Change Password','current_password'=>'Current password',
 'new_password'=>'New password','password_changed'=>'Password changed.','wrong_password'=>'Current password is wrong.','language'=>'Language','update'=>'Update',
 'invalid_csrf'=>'Security token expired. Please try again.','rate_limited'=>'Too many attempts. Try again in a few minutes.','mark_all_read'=>'Mark all read',
 'no_notifications'=>'No notifications','invalid_voucher'=>'Invalid voucher code','voucher_blocked'=>'This voucher has been blocked',
 'voucher_expired'=>'This voucher has expired','voucher_exhausted'=>'Data bundle for this voucher is finished','voucher_wrong_hotspot'=>'This voucher belongs to a different hotspot',
 'unknown_ap'=>'This access point is not registered','device_blocked'=>'This device is blocked on this hotspot','voucher_in_use_other'=>'Voucher is already in use on another device',
 'welcome_online'=>'Welcome! Time left','day'=>'day','days'=>'days','hour'=>'hour','hours'=>'hours','min_short'=>'min','cancelled'=>'Cancelled',
 'p_title'=>'Connect to the Internet','p_have_voucher'=>'I have a voucher','p_buy'=>'Buy a package','p_enter_code'=>'Enter voucher code','p_connect'=>'Connect',
 'p_remember'=>'Remember on this phone','p_continue'=>'Continue browsing','p_time_left'=>'Time left','p_choose_pkg'=>'Choose a package','p_phone'=>'Mobile money number',
 'p_pay'=>'Pay now','p_waiting'=>'Waiting for payment confirmation…','p_push_sent'=>'Check your phone and enter your PIN to approve the payment.',
 'p_pay_instructions'=>'Pay using the details below, then wait here. Your voucher appears automatically once the seller confirms.',
 'p_paid_code'=>'Payment received! Your voucher','p_connecting'=>'Connecting…','p_connected'=>'You are connected!','p_no_ctx'=>'Please connect to the WiFi network first, then open any website.',
 'p_help'=>'Help','p_no_controller'=>'Portal is not linked to the controller. Ask the seller to set the Controller Portal URL.','p_order_failed'=>'Payment failed or was cancelled.',
 'p_order_expired'=>'Payment time expired. Please try again.','p_back'=>'Back','p_data'=>'Data','p_devices'=>'device(s)','p_speed'=>'Speed','p_invalid_phone'=>'Enter a valid number e.g. 0712345678',
 'p_resume'=>'Saved voucher found','p_forget'=>'Forget','p_open_internet'=>'Open Internet',
 'omada_setup'=>'Omada RADIUS Settings','radius_settings_btn'=>'RADIUS settings','radius_server_ip'=>'RADIUS Server IP','auth_port'=>'Authentication Port',
 'auth_password'=>'Authentication Password (RADIUS password)','acct_server_ip'=>'Accounting Server IP','acct_port'=>'Accounting Port',
 'acct_password'=>'Accounting Password','nas_id'=>'NAS ID','fixed_port'=>'Fixed — do not change','not_set'=>'Not set yet','copy'=>'Copy',
 'copy_all'=>'Copy all settings','print_sheet'=>'Print','step'=>'Step','radius_server'=>'RADIUS server','radius_activity'=>'Recent RADIUS activity',
 'radius_ip_missing'=>'The RADIUS server IP has not been set yet. The administrator must enter it under RADIUS Setup before this hotspot can work.',
 'omada_intro'=>'The system generated these RADIUS passwords for this EAP225 only. Type them exactly into your Omada Controller. Ports are fixed: 1812 (authentication) and 1813 (accounting). The NAS ID is the one Omada sends — it is read automatically.',
 'step_profile'=>'Create the RADIUS Profile','step_portal'=>'Create the Portal (External RADIUS Server)','step_preauth'=>'Let phones open the portal before login',
 'step_test'=>'Test the hotspot','regen_secrets'=>'Generate new passwords',
 'regen_help'=>'Use this only if the passwords leaked. The hotspot stops working until you paste the new passwords into Omada.',
 'regen_confirm'=>'Generate new RADIUS passwords? You must update them in Omada immediately.','secrets_regenerated'=>'New RADIUS passwords generated. Paste them into Omada now.',
 'waiting_contact'=>'Waiting for the first RADIUS request from this hotspot…','contact_from'=>'from','dae_target'=>'Disconnect target IP (optional)',
 'dae_target_help'=>'Where kick requests are sent (UDP 3799). Empty = the public IP the RADIUS server sees. Needs a port-forward when the RADIUS server is in the cloud.',
 'unknown_nas'=>'This hotspot is not registered (no matching RADIUS password)','hotspot_disabled'=>'This hotspot is disabled',
 'no_radius_traffic'=>'No RADIUS traffic from your EAP225 in the last 10 minutes. Check that the Omada RADIUS profile and portal use the values in RADIUS settings.',
 'how_it_works'=>'How it works','hiw_1'=>'Routers → Add router → choose Omada EAP225 and enter its data. The system creates its RADIUS passwords automatically and reads the NAS ID that Omada sends.',
 'hiw_2'=>'Hotspot → choose the router → set the Inform URL on the EAP225, adopt it in Omada Central, copy the RADIUS profile and portal settings, then press “Provision & connect”.','hiw_3'=>'Phones join the SSID, the portal opens, and every login and every MB goes through the RADIUS server.',
 'troubleshoot'=>'Troubleshooting','server_online'=>'Online','server_offline'=>'Not running',
 'omada_nas_id'=>'NAS ID sent by Omada (optional)','omada_nas_help'=>'Leave empty — the RADIUS server reads the NAS ID from the first request Omada sends and saves it here. Or type exactly the NAS ID shown in your Omada portal.',
 'nas_auto'=>'Any value — read automatically','nas_auto_hint'=>'Keep the NAS ID Omada shows (or type any name). The RADIUS server recognises this hotspot by its passwords and saves the NAS ID Omada sends.',
 'nas_learned'=>'Received from Omada','nas_waiting'=>'Waiting for Omada','nas_keep_hint'=>'Keep this value in the Omada portal',
 'nas_invalid'=>'NAS ID may only contain normal characters (max 64).',
 'omada_controller'=>'Omada Cloud','ctrl_add'=>'Link Omada Cloud','ctrl_edit'=>'Edit Omada Cloud','ctrl_name'=>'Name','ctrl_type'=>'Controller type',
 'ctrl_type_local'=>'Software / OC200 / OC300','ctrl_type_cloud'=>'Cloud-Based Controller','ctrl_base'=>'Controller URL / Interface Access Address',
 'ctrl_base_help'=>'Filled automatically from the Inform URL. Only needed for a local controller: https://PUBLIC-IP-or-DDNS:8043.','ctrl_omadac'=>'Omada ID (omadacId)',
 'ctrl_omadac_ph'=>'Empty = read from the Inform URL (or /api/info)','ctrl_secret_keep'=>'Leave empty to keep the saved secret',
 'ctrl_inform_help'=>'Local controller: its host name or IP (empty = controller host).',
 'ctrl_verify_ssl'=>'Verify SSL certificate (turn off for self-signed controller certificates)','ctrl_save_test'=>'Save & test connection',
 'ctrl_howto'=>'How to connect','ctrl_last_ok'=>'Last OK','ctrl_open'=>'Access points','ctrl_test'=>'Test connection','ctrl_aps'=>'Access points (live from controller)',
 'ctrl_import'=>'Add as hotspot','ctrl_link_hotspot'=>'Link to this controller','ctrl_no_aps'=>'No access points in this site yet. Set the Inform URL on the EAP225 so it appears here as PENDING.',
 'ctrl_claim'=>'Claim a device by serial number','ctrl_claim_help'=>'Cloud-Based Controller: adds the device to this site with its S/N (and device key if your controller asks). Then press Adopt when it shows PENDING.',
 'ctrl_claim_btn'=>'Claim','ctrl_adopt'=>'Adopt','ctrl_check_now'=>'Check now','ctrl_cmd_sent'=>'Command accepted by the Omada Controller.',
 'ctrl_imported'=>'Hotspot added from the Omada Controller. Now copy these RADIUS settings into Omada.','ctrl_pick_site'=>'Choose a site first.',
 'ctrl_url_invalid'=>'Enter the controller address, e.g. https://omada.example.co.tz:8043','omada_synced'=>'Omada status updated',
 'ctrl_connect_first'=>'Link your Omada Cloud with its Inform URL (menu Omada Cloud) so every router shows the right Inform URL.',
 'ctrl_link'=>'Omada Controller / site','ctrl_not_linked_opt'=>'— not linked —','ctrl_auto_site'=>'find site automatically',
 'ctrl_link_help'=>'Links this hotspot to the controller so its live status (CONNECTED / PENDING / OFFLINE) shows here.',
 'ctrl_not_linked'=>'This hotspot is not linked to an Omada Controller yet.',
 'ctrl_intro'=>'Link your Omada Cloud (Omada Central) or local controller with the device Inform URL. Add the Open API Client ID + Client Secret to let the system create the site, SSID, RADIUS profile, portal and vouchers, adopt every EAP225 and manage clients by itself. Without the keys you copy the settings sheet into Omada by hand. Every customer login goes through your RADIUS server.',
 'step_adopt'=>'Adopt the EAP225 into the Omada Controller','dev_user'=>'Device username','dev_pass'=>'Device password',
 'dev_default_hint'=>'Factory default of a new / reset EAP225','inform_url'=>'Controller Inform URL',
 'inform_hint'=>'Type this on the EAP225 (or in Omada Discovery Utility)','inform_ports'=>'Ports open to the controller',
 'inform_ports_hint'=>'Needed when the EAP225 is on another network than the controller',
 'inform_path'=>'EAP225 web page (standalone, default 192.168.0.254, admin/admin) → Controller Settings → Controller Inform URL → Save. Or: Omada Discovery Utility → Batch Setting → Center IP / Inform URL → Apply.',
 // v5.4 — Omada Cloud auto-setup
 'prov_title'=>'Omada auto-setup','prov_run_now'=>'Set up now','prov_save_setup'=>'Save & set up Omada','prov_busy'=>'Creating the site, SSID, RADIUS profile, portal and vouchers in Omada… (up to a minute)',
 'prov_need_keys'=>'No Open API keys on this Omada link, so the SSID, RADIUS profile and portal are entered in Omada by hand from the settings sheet. Add the Client ID + Client Secret (menu Omada Cloud → Edit) to let the system set up everything automatically.',
 'ctrl_essentials_hint'=>'Omada Central gives no API keys: the Inform URL connects the EAP225 to Omada Cloud, and the RADIUS profile + portal are copied from the settings sheet.',
 'ctrl_inform_paste'=>'Omada Inform URL','ctrl_inform_paste_help'=>'Omada Central → Devices → Add Device → Inform URL (starts with omada://). The Omada ID and the API address are read from it.',
 'ctrl_inform_invalid'=>'That does not look like an Omada Inform URL (omada://...-device.tplinkcloud.com?...&omadacId=...).',
 'ctrl_inform_only'=>'Omada Cloud linked with its Inform URL.','ctrl_inform_only_badge'=>'Omada Cloud · Inform URL',
 'ctrl_keys_optional'=>'Only the Inform URL is needed. Client ID + Client Secret are optional and turn on the full automatic setup.',
 'ctrl_keys_title'=>'Open API keys (optional — full automatic setup)','ctrl_client_id'=>'Client ID','ctrl_client_secret'=>'Client Secret',
 'ctrl_keys_help'=>'Omada → Global View → Settings → Platform Integration → Open API → Add New App → Mode “Client” → role with Site + Device management → copy the Client ID and Client Secret. Local controller: also the Interface Access Address (Advanced).',
 'ctrl_remove_keys'=>'Remove the saved API keys','ctrl_api_check'=>'Check all Open API features','ctrl_api_report'=>'Open API feature check',
 'ctrl_api_mode'=>'Open API','ctrl_site_create'=>'Create an Omada site','ctrl_site_created'=>'Site created in Omada',
 'omada_clients'=>'Clients (live from Omada)','omada_ap_clients'=>'Clients on this EAP225 (live from Omada)','omada_no_clients'=>'No clients connected right now.',
 'omada_block'=>'Block','omada_unblock'=>'Unblock','omada_reconnect'=>'Reconnect','omada_also'=>'Also applied in Omada',
 'omada_client'=>'Client','omada_ap'=>'Access point','omada_traffic'=>'Traffic','omada_uptime'=>'Uptime','omada_auth'=>'Portal',
 'ctrl_new_inline'=>'+ Connect Omada Cloud (paste Inform URL)','omada_site_new'=>'new site','omada_site_keep'=>'keep site','omada_site_name'=>'New site name (default: device name)',
 'omada_sn'=>'Serial number (S/N) — optional','prov_creds'=>'EAP225 login','ap_mac_where'=>'on the EAP225 label','ssid_auto_hint'=>'created in Omada automatically',
 'voucher_mode'=>'Voucher system','vm_radius'=>'SkyTanza vouchers (RADIUS: mobile money, live sessions, sales)','vm_omada'=>'Omada Hotspot vouchers (generated inside Omada)',
 'prov_pkg'=>'Vouchers to create now','prov_pkg_none'=>'None','prov_pkg_starter'=>'Starter packages (1 hour · 1 day · 1 week)','prov_qty'=>'Quantity','advanced'=>'Advanced',
 'prov_api_ok'=>'Open API connected','prov_site_created'=>'Site created','prov_site_reused'=>'Site already exists — reused','prov_site_existing'=>'Using site',
 'prov_dev_in_site'=>'EAP225 is already in this site','prov_dev_added'=>'EAP225 added to the site',
 'prov_no_sn'=>'No serial number — the EAP225 appears as PENDING after you set the Inform URL on it; Provision & connect then adopts it.',
 'prov_created'=>'created','prov_updated'=>'updated','prov_radius_ok'=>'RADIUS profile ready','prov_ssid_ok'=>'SSID ready','prov_portal_ok'=>'Portal ready','prov_preauth_ok'=>'Pre-Authentication Access ready',
 'prov_portal_waits'=>'Portal not created — it needs the SSID and the RADIUS profile first.','prov_no_vouchers'=>'No vouchers requested','prov_omada_vouchers'=>'%d Omada vouchers created (%s)',
 'prov_omada_vouchers_nocodes'=>'The voucher group was created in Omada but no codes could be read back','prov_secrets_pushed'=>'The new passwords were sent to the Omada RADIUS profile.',
 'prov_state_new'=>'Not set up yet','prov_state_ready'=>'Configured — waiting for the EAP225','prov_state_partial'=>'Partly configured — see the log','prov_state_manual'=>'Ready — copy the settings into Omada',
 'prov_state_provisioning'=>'Provisioning…','prov_state_done'=>'Online','prov_state_failed'=>'Failed','prov_log'=>'Setup log','prov_never'=>'The automatic setup has not run for this EAP225 yet.','prov_run_again'=>'Run setup again',
 'pstep_controller'=>'Omada controller','pstep_site'=>'Site','pstep_device'=>'EAP225','pstep_radius'=>'RADIUS profile','pstep_ssid'=>'SSID','pstep_portal'=>'Portal','pstep_preauth'=>'Pre-Authentication Access','pstep_vouchers'=>'Vouchers',
 'prov_start'=>'Provision & connect','prov_stop'=>'Stop','prov_stopped'=>'Stopped. Press Provision & connect to continue.','prov_net_retry'=>'Network problem — retrying…',
 'prov_step_power'=>'Connect the EAP225 to power and to a network with internet (DHCP).','prov_step_inform'=>'Open the EAP225 page and save this Inform URL in Controller Settings.','prov_step_press'=>'Press Provision & connect and keep this page open until it shows Connected.',
 'prov_start_help'=>'Set the Inform URL on the EAP225, adopt it in Omada Central and save the settings below there, then press Provision & connect.','pph_waiting'=>'Waiting','pph_adopting'=>'Adopting','pph_provisioning'=>'Provisioning','pph_connected'=>'Connected',
 'prov_wait_inform'=>'Waiting for the EAP225 to reach Omada… Check that the Inform URL is saved on the EAP225 and that it has internet.',
 'prov_adopting'=>'Adopting the EAP225…','prov_provisioning'=>'Omada is sending the configuration (SSID, portal, RADIUS) to the EAP225…','prov_done'=>'The EAP225 is CONNECTED and the hotspot is live.',
 'prov_done_radius'=>'The EAP225 is sending RADIUS requests — the hotspot is live.','prov_no_site'=>'This hotspot has no Omada site yet — run the setup first.',
 'prov_bad_dev_pass'=>'Adoption failed: wrong EAP225 username/password. Type its login (factory default admin/admin) and press Provision & connect again.',
 'prov_managed_others'=>'This EAP225 is managed by another controller. Forget it there or reset it (hold Reset ~10 s), then try again.','prov_offline'=>'Omada reports the EAP225 as %s. Check its power and internet.',
 'prov_manual_tick'=>'Waiting for the first RADIUS request from this EAP225… Make sure it is adopted in Omada Central and that the RADIUS profile and portal below are saved there.',
 'omada_intro_auto'=>'These settings were created in Omada automatically through the Open API — the sheet below is for checking only. The NAS ID is set by this system.',
 'omada_vouchers_gen'=>'Generate Omada vouchers','voucher_omada_only'=>'This voucher works only on the Omada hotspot it was made for',
 'pstep_server'=>'Server','prov_time_up'=>'Stopped before the hosting time limit — everything done so far is saved. Press "Run setup again" to finish the remaining steps.',
 'server_errors'=>'Recent server errors','server_errors_none'=>'No server errors recorded.',
 'routers'=>'Routers',
 'hotspot'=>'Hotspot',
 'network_menu'=>'Network',
 'wifi_menu'=>'WiFi sales',
 'add_router'=>'Add router',
 'edit_router'=>'Edit router',
 'choose_model'=>'Choose the router model',
 'choose_model_help'=>'Select the device you are installing — its data form opens next.',
 'coming_soon'=>'Coming soon',
 'select'=>'Select',
 'router_model'=>'Router model',
 'change_model'=>'Change model',
 'router_details'=>'Router details',
 'wifi_details'=>'WiFi & payments',
 'cloud_link'=>'Omada Cloud',
 'vouchers_section'=>'Vouchers to print now',
 'routers_intro'=>'Every router (access point) you install is listed here. Add a router first, then open Hotspot to provision and connect it.',
 'router_saved'=>'Router saved. Now provision and connect it.',
 'rerun_setup'=>'Run setup again after saving',
 'hs_intro'=>'Choose a router to provision and connect: set the Inform URL on the EAP225 → adopt it in Omada Central → copy the RADIUS profile and portal → Provision & connect.',
 'hs_no_routers'=>'No routers yet. Add one under Routers first.',
 'hs_live'=>'Live',
 'hs_waiting'=>'Not connected yet',
 'prov_history'=>'Provisioning history',
 'prov_step_copy'=>'Copy the RADIUS profile, portal and pre-authentication settings (steps 1–3 below) into Omada Central.',
 'cloud_check'=>'Check Omada Cloud',
 'cloud_ok'=>'Omada Cloud device gateway is reachable',
 'cloud_fail'=>'Omada Cloud device gateway is not reachable from this server',
 'cloud_not_checked'=>'Reachability could not be checked on this host',
 'site_name_help'=>'The site in Omada Central where this EAP225 is adopted.',
 'serial_help'=>'On the EAP225 label (S/N).',
 'pa_added'=>'Router added',
 'pa_updated'=>'Router updated',
 'pa_setup'=>'Setup',
 'pa_connect'=>'Provision & connect',
 'pa_secrets'=>'New RADIUS passwords',
 'pa_cloud'=>'Omada Cloud check',
 'routers_linked'=>'Routers using this Omada Cloud',
 'new_cloud_hint'=>'Paste the Inform URL from Omada Central → Devices → Add Device. Add the Open API Client ID + Client Secret below for the full automatic setup (optional).',
 'prov_step_adopt'=>'In Omada Central → Devices, adopt the EAP225 when it shows Pending (factory login admin / admin).',
 // v5.7 — Omada link engine
 'hl_title'=>'Connection health — Router ↔ Omada ↔ RADIUS','hl_check'=>'Check now','hl_fix'=>'Fix automatically','hl_checked'=>'Checked','hl_never'=>'Not checked yet — press Check now.',
 'hl_all_ok'=>'Everything communicates correctly — the hotspot is ready.','hl_problems'=>'%d problem(s) found — open the router to see what to fix.',
 'hl_http_warn'=>'the website is not HTTPS — some phones show a security warning on the portal','hl_key_weak'=>'RADIUS_API_KEY is still the default — the RADIUS server cannot talk to the website',
 'hl_box_down'=>'The RADIUS server is not reporting to the website','hl_ip_mismatch'=>'The RADIUS server reaches the website from %s but the RADIUS Server IP is %s — make sure Omada can reach that IP on UDP 1812/1813',
 'hl_badpw'=>'Omada is sending a wrong %s for this router — press Fix automatically or copy the passwords again','hl_secrets_ok'=>'Passwords ready • NAS ID %s',
 'hl_site_missing'=>'The Omada site saved for this router no longer exists','hl_dev_missing'=>'The EAP225 is not in this Omada site yet','hl_ssid_missing'=>'SSID "%s" was not found in Omada',
 'hl_ssid_secured'=>'SSID "%s" has a WiFi password — a hotspot SSID must be open (the portal does the login)','hl_profile_missing'=>'The RADIUS profile is missing in Omada',
 'hl_profile_wrong'=>'The RADIUS profile points to %s — it must be %s','hl_portal_missing'=>'The portal is missing in Omada','hl_portal_nas'=>'Portal NAS ID is %s — it must be %s',
 'hl_portal_ssid'=>'The portal is not applied to the hotspot SSID','hl_portal_off'=>'The portal is disabled in Omada','hl_preauth_missing'=>'The website is not in Pre-Authentication Access — phones cannot open the portal',
 'hl_portal_reach_ok'=>'A phone reached the portal %s (Omada portal service: %s)','hl_portal_reach_none'=>'No phone has opened the portal from this EAP225 yet — join the SSID with a phone to test',
 'hl_traffic_ok'=>'RADIUS requests arrive from %s (last %s)','hl_traffic_none'=>'No RADIUS request from this EAP225 in the last 10 minutes',
 'hl_manual'=>'Without Open API keys this is checked in Omada by hand — use the settings sheet below','hl_details_hidden'=>'details not returned by Omada',
 'hl_phone'=>'Phone','hl_eap'=>'EAP225','hl_omada'=>'Omada','hl_radius'=>'RADIUS','hl_web'=>'Website','hs_health'=>'Health',
 'hc_website'=>'Website / portal URL','hc_radius_ip'=>'RADIUS Server IP','hc_radius_box'=>'RADIUS server ↔ website','hc_router'=>'Router RADIUS passwords','hc_cloud'=>'Omada Cloud link',
 'hc_api'=>'Omada Open API','hc_site'=>'Omada site','hc_device'=>'EAP225 in Omada','hc_ssid'=>'Hotspot SSID','hc_radius_profile'=>'RADIUS profile in Omada','hc_portal'=>'Portal in Omada',
 'hc_preauth'=>'Pre-Authentication Access','hc_portal_reach'=>'Phones reach the portal','hc_radius_traffic'=>'EAP225 → RADIUS traffic',
 'sync_all'=>'Sync all my routers with Omada','sync_all_done'=>'%d router(s) synced with Omada','sync_all_more'=>'%d router(s) still to sync — press the button again',
 'push_needed'=>'The RADIUS server settings changed. Push them to every Omada router.','push_all'=>'Push to all Omada routers','push_done'=>'Pushed to %d router(s)',
 'push_manual_notified'=>'%d seller(s) without Open API keys were notified to update Omada by hand.','radius_changed_title'=>'RADIUS server changed',
 'radius_changed_msg'=>'The RADIUS Server IP is now %s. Update the RADIUS profile in Omada for: %s',
 'ssid_manage'=>'SSIDs in this site','ssid_new'=>'Create SSID','ssid_type'=>'Type','ssid_type_hotspot'=>'Hotspot (open, portal login)','ssid_type_private'=>'Private (WPA2 password)',
 'ssid_pass'=>'WiFi password','ssid_band'=>'Band','ssid_created'=>'SSID created in Omada','ssid_deleted'=>'SSID deleted in Omada','ssid_pass_bad'=>'The WiFi password must be 8–63 normal characters',
 'ssid_none'=>'No SSIDs in this site yet.','ssid_used_by'=>'Used by','ssid_open'=>'Open','ssid_wpa'=>'WPA2','ssid_guest'=>'Guest',
 // v5.8 — one Omada Inform URL for every router
 'default_inform'=>'Omada Inform URL (all routers)','default_inform_admin'=>'Default Omada Inform URL (used for every added router)',
 'default_inform_help'=>'Every router you add is linked to this Omada controller automatically. Set it on each EAP225: Controller Settings → Controller Inform URL (or Omada Discovery Utility).',
 // v5.9 — Omada relay through the RADIUS server
 'route_label'=>'Connection route (website → Omada controller)','route_auto'=>'Automatic (self-hosted controller via the RADIUS server, TP-Link cloud direct)',
 'route_relay'=>'Via RADIUS server','route_direct'=>'Direct from the website',
 'route_help'=>'Shared hosting cannot open connections to a self-hosted controller (port 8043 / 29814). "Via RADIUS server" sends every Omada call through your external RADIUS box, which can reach it.',
 'relay_title'=>'Omada relay (RADIUS server)','relay_down'=>'the Omada relay on the RADIUS server is not running (needs RADIUS box v5.9)',
 'relay_not_taken'=>'the RADIUS server did not pick up the request — is "skyradius" v5.9 running?','relay_timeout'=>'the RADIUS server did not answer in time (the controller may be slow or unreachable from the RADIUS box)',
 'relay_hint_direct'=>'this hosting blocks the connection; the Omada relay on the RADIUS server will be used','relay_hint_start'=>'shared hosting usually blocks this port — update the RADIUS box to v5.9 so the Omada relay reaches the controller for you',
 'relay_off_help'=>'Copy this index.php (v5.9) to the RADIUS box (/opt/skyradius/index.php), run "php index.php radius-server --test", then "sudo systemctl restart skyradius". The relay starts with it and appears here within a minute.',
 'relay_needs_service'=>'This RADIUS box has no PHP pcntl: also install skyradius-relay.service (step 3b).',
 'relay_explain'=>'The website queues each Omada Open API call, the RADIUS box performs it against the controller and sends the answer back over HTTPS — no extra port is opened.',
 'relay_unit_title'=>'Optional: Omada relay as its own service','relay_unit_help'=>'Only needed when "php -m" shows no pcntl on the RADIUS box (otherwise the relay already runs inside skyradius).',
 'ctrl_api_port_ok'=>'Omada Open API port reachable','ctrl_api_port_fail'=>'Omada Open API port not reachable','ctrl_api_port_hint'=>'Open TCP 8043 on the controller firewall for the RADIUS box and check that the Omada controller is running.',
 'ctrl_dev_port_ok'=>'Omada device port reachable (EAP225 → controller)','ctrl_dev_port_fail'=>'Omada device port not reachable',
 'ctrl_dev_port_hint'=>'On the controller VPS open UDP 29810 and TCP 29811-29817 (ufw allow 29810/udp ; ufw allow 29811:29817/tcp) and check the Omada service is running.',
 'ctrl_reach_ok'=>'Controller reachable','ctrl_local_keys_hint'=>'Self-hosted controller: add the Open API Client ID + Client Secret to provision every EAP225 automatically.',
 'ctrl_local_keys_steps'=>'For automatic provisioning open %s → Global View → Settings → Platform Integration → Open API → Add New App (mode Client, role Administrator / site + device management) and paste the Client ID + Client Secret here (Edit). Until then the RADIUS profile and portal are copied into the controller by hand.',
 'ctrl_shared_sites'=>'Shared Open API keys — your Omada sites appear after your first router is set up (Routers → Add router).',
 'ctrl_site_not_yours'=>'That Omada site does not belong to one of your routers.','ctrl_shared_keys_note'=>'This controller uses the platform Open API keys set by the administrator. Type your own keys only if you want to replace them.',
 'ctrl_shared_badge'=>'platform keys','ctrl_no_keys_badge'=>'Inform URL · no Open API keys',
 'default_keys_title'=>'Open API keys of the default controller (shared with every seller)',
 'default_keys_help'=>'Omada controller → Global View → Settings → Platform Integration → Open API → Add New App (Client mode). Every seller linked to the default Inform URL gets these keys, so Add router provisions everything automatically; each seller only sees the Omada sites of his own routers.',
 'site_region'=>'Region for new Omada sites','site_timezone'=>'Time zone for new Omada sites','hc_relay'=>'Website → RADIUS server → Omada',
],
];
// v6.0 — Omada Manager texts (added to the tables above; existing keys are never replaced)
$T['en'] += [
 'omada_manager'=>'Omada Manager','om_intro'=>'Everything here goes through the Omada Open API of your controller (VPS, OC200 or Omada Cloud): sites, EAP225 devices, Omada Hotspot vouchers and clients.',
 'om_no_api'=>'Omada Manager needs a controller with Open API keys (Client ID + Client Secret).','om_site'=>'Site','om_sites'=>'Omada sites',
 'om_site_new'=>'Create a site','om_site_delete'=>'Delete site','om_site_delete_confirm'=>'Type the site name to confirm','om_site_deleted'=>'Site deleted in Omada',
 'om_site_name_mismatch'=>'The name you typed does not match the site name — nothing was deleted.',
 'om_tab_overview'=>'Overview','om_tab_devices'=>'Devices','om_tab_vouchers'=>'Vouchers','om_tab_clients'=>'Clients',
 'om_stat_devices'=>'EAP connected','om_stat_pending'=>'Waiting / pending','om_stat_clients'=>'Clients online','om_stat_vouchers'=>'Unused Omada vouchers',
 'om_local_routers'=>'Hotspots on this site','om_none_local'=>'No hotspot of yours is linked to this site yet.',
 'om_dev_add'=>'Add EAP225','om_dev_add_help'=>'Serial number (S/N) adds the EAP225 to this site through the Open API (Omada adopts it when it comes online with the Inform URL). Add the MAC too to make it a hotspot on this website.',
 'om_as_hotspot'=>'Turn into a hotspot on this website (needs the MAC)','om_run_setup'=>'Run the full setup now (SSID, RADIUS profile, portal, pre-authentication)',
 'om_dev_rename'=>'Rename in Omada','om_renamed'=>'Renamed in Omada','om_dev_forget'=>'Forget (remove from Omada)','om_dev_forget_confirm'=>'Remove this device from Omada?',
 'om_dev_forgotten'=>'Device removed from Omada','om_dev_need'=>'Enter the serial number (S/N) or the MAC of the EAP225.','om_dev_need_mac'=>'No hotspot made — add the MAC to turn it into a hotspot.',
 'om_vg_hint'=>'Omada vouchers are checked by Omada itself: the SSID must use a portal with Hotspot → Voucher login (choose "Omada Hotspot vouchers" on the router). SkyTanza RADIUS vouchers are made under Vouchers.',
 'om_vg_codes'=>'Codes','om_vg_back'=>'All groups','om_v_unused'=>'Unused','om_v_inuse'=>'In use','om_v_expired'=>'Expired','om_v_delete'=>'Delete voucher','om_v_deleted'=>'Voucher deleted in Omada',
 'om_vg_create'=>'Create Omada vouchers','om_vg_groups'=>'Voucher groups in Omada','om_total'=>'Total','om_duration'=>'Duration','om_created'=>'Created',
 'om_vg_import'=>'Import codes for printing','om_vg_imported'=>'%d new code(s) imported (%d in the group)','om_vg_delete'=>'Delete group',
 'om_vg_delete_confirm'=>'Delete this voucher group in Omada? Its unused codes stop working.','om_vg_deleted'=>'Voucher group deleted in Omada','om_vg_none'=>'No voucher groups on this site yet.',
 'om_vsync'=>'Sync voucher status','om_vsync_done'=>'%d Omada voucher group(s) checked • %d code(s) updated',
 'om_vps_title'=>'VPS setup: Omada Software Controller + RADIUS server','om_vps_help'=>'Run the Omada controller on the same Ubuntu VPS as the SkyTanza RADIUS server. Copy the blocks below.',
 'om_vps_controller'=>'1. Install the Omada controller (commands)','om_vps_steps'=>'2. Connect it to this website',
];

// v6.1 — Omada Controller only (Open API keys required). These texts replace the older Omada Cloud wording.
$T['en'] = array_merge($T['en'], [
 'omada_controller'=>'Omada Controller','cloud_link'=>'Omada Controller','ctrl_add'=>'Connect Omada Controller','ctrl_edit'=>'Edit Omada Controller',
 'ctrl_base'=>'Controller URL (Interface Access Address) *','ctrl_base_help'=>'Your own controller with its port, e.g. https://169.58.93.38:8043 (Software Controller, OC200 or OC300). Omada Cloud is not supported.',
 'ctrl_omadac'=>'Omada ID (omadacId) *','ctrl_omadac_ph'=>'e.g. 6acf85545651212b5ca146e6',
 'ctrl_get_omadac'=>'Omada ID: open https://YOUR-CONTROLLER:8043/api/info in a browser and copy "omadacId" (also shown on the Open API page).',
 'ctrl_keys_title'=>'Open API keys — Platform Integration (required)','ctrl_keys_optional'=>'Controller URL, Omada ID, Client ID and Client Secret are all required.',
 'ctrl_keys_help'=>'Omada → Global View → Settings → Platform Integration → Open API → Add New App → Mode “Client” (Client Credentials) → role Administrator (or Site + Device + Hotspot management) → Apply → copy the Client ID and Client Secret.',
 'ctrl_required'=>'Controller URL, Omada ID, Client ID and Client Secret are all required.','ctrl_omadac_required'=>'Omada ID is required (https://YOUR-CONTROLLER:8043/api/info → omadacId).',
 'ctrl_cloud_unsupported'=>'Omada Cloud (tplinkcloud.com) is not supported any more — use your own Omada Controller (https://IP:8043) with Platform Integration keys.',
 'ctrl_need_api_router'=>'Choose an Omada Controller that has its Omada ID, Client ID and Client Secret (menu Omada Controller → Edit), or connect a new one.',
 'ctrl_intro'=>'Connect your own Omada Controller (Software Controller on your VPS, OC200 or OC300) with Platform Integration (Open API). With it the website creates the site, SSID, RADIUS profile, External RADIUS portal, Pre-Authentication Access and vouchers, adopts every EAP225 and manages clients automatically. On shared hosting all calls go through your RADIUS server (Omada relay).',
 'ctrl_connect_first'=>'Connect your Omada Controller (URL, Omada ID, Client ID, Client Secret) under menu Omada Controller first.',
 'ctrl_inform_paste'=>'Controller Inform URL / IP (optional)','ctrl_inform_paste_help'=>'What the EAP225 reports to. Empty = the controller host from the URL above.',
 'ctrl_inform_invalid'=>'That does not look like a controller Inform URL or IP (e.g. 169.58.93.38 or omada://169.58.93.38?dPort=29810&mPort=29814).',
 'ctrl_inform_only'=>'This controller has no Open API keys — edit it and add Client ID + Client Secret.','ctrl_inform_only_badge'=>'no Open API keys','ctrl_essentials_hint'=>'',
 'ctrl_no_keys_badge'=>'no Open API keys','ctrl_new_inline'=>'+ Connect a new Omada Controller','new_cloud_hint'=>'Controller URL, Omada ID, Client ID and Client Secret are required.',
 'ctrl_link_help'=>'Every router is created and provisioned in this controller automatically through the Open API.','ctrl_not_linked'=>'This router is not linked to an Omada Controller with Open API keys.',
 'prov_need_keys'=>'This router needs an Omada Controller with Omada ID + Client ID + Client Secret (Platform Integration). Edit the controller under menu Omada Controller.',
 'cloud_check'=>'Check controller','cloud_ok'=>'Omada Controller port is reachable','cloud_fail'=>'Omada Controller port is not reachable','pa_cloud'=>'Controller check',
 'routers_linked'=>'Routers using this controller','hc_cloud'=>'Omada Controller link',
 'hiw_1'=>'Routers → Add router → choose Omada EAP225, enter its data and pick your Omada Controller. The website creates the site, SSID, RADIUS profile, portal and vouchers in Omada automatically.',
 'hiw_2'=>'On the EAP225 set the Controller Inform URL to your controller IP. “Provision & connect” starts automatically and adopts it as soon as it shows PENDING.',
 'hs_intro'=>'Choose a router: the website provisions it in your Omada Controller (Open API) and adopts the EAP225 automatically once its Inform URL points to the controller.',
 'prov_start_help'=>'Set the controller IP as Inform URL on the EAP225, then press Provision & connect — adoption and provisioning run automatically.',
 'prov_step_inform'=>'Open the EAP225 page (192.168.0.254, admin/admin) → Controller Settings → Controller Inform URL = your controller IP → Save.',
 'prov_step_press'=>'Press Provision & connect: the website adopts the EAP225 in your controller and pushes SSID, RADIUS and portal. Keep the page open until Connected.',
 'prov_step_adopt'=>'Adoption is automatic through the Open API (EAP225 login: admin / admin unless changed).',
 'prov_no_sn'=>'The EAP225 is adopted automatically when it reports PENDING to your controller (Inform URL = controller IP).',
 'prov_wait_inform'=>'Waiting for the EAP225 to report to your Omada Controller… Check that its Controller Inform URL is the controller IP and that UDP 29810 / TCP 29811-29817 are open on the controller.',
 'default_inform'=>'Controller Inform URL (all routers)','default_inform_admin'=>'Default Omada Controller Inform URL (self-hosted controller used for every seller)',
 'default_inform_help'=>'Your own controller, e.g. omada://169.58.93.38?dPort=29810&mPort=29814  Sellers are linked to it automatically only when the Open API keys below are set.',
 'default_keys_title'=>'Open API keys of the default controller (required for automatic seller linking)',
 'ctrl_local_keys_hint'=>'Add the Omada ID + Client ID + Client Secret to this controller — they are required.',
 'route_help'=>'Shared hosting cannot reach your controller on port 8043, so "Automatic" and "Via RADIUS server" send every Omada call through your external RADIUS server (Omada relay).',
 'prov_api_alert'=>'Automatic provisioning needs the Omada ID, Client ID and Client Secret of your Omada Controller.',
]);

// v6.1.2 — public Omada Controller on the VPS (https://169.58.93.38:8043)
$T['en'] = array_merge($T['en'], [
 'ctrl_base_help'=>'Your Omada Controller on the VPS with its HTTPS port, e.g. https://169.58.93.38:8043 — the Open API is HTTPS only (http:// or port 8088 is changed to https://…:8043 automatically).',
 'ctrl_omadac'=>'Omada ID (omadacId)','ctrl_omadac_ph'=>'empty = read automatically from https://IP:8043/api/info',
 'ctrl_get_omadac'=>'Omada ID: left empty, it is read from https://169.58.93.38:8043/api/info ("omadacId"). If you type it, copy it from the Open API page of THIS controller.',
 'ctrl_required'=>'Controller URL, Client ID and Client Secret are required.',
 'ctrl_inform_paste'=>'Controller Inform URL / IP (optional)','ctrl_inform_paste_help'=>'What the EAP225 reports to. Empty = the controller IP from the URL above (169.58.93.38).',
 'ctrl_inform_invalid'=>'That does not look like a controller Inform URL or IP (e.g. 169.58.93.38).',
 'default_inform_help'=>'Your Omada Controller on the VPS, e.g. omada://169.58.93.38?dPort=29810&mPort=29814 (Omada ID optional). Every EAP225 gets the controller IP as its Inform URL. Sellers are linked automatically only when the Open API keys below are set.',
 'inform_hint'=>'Type this controller IP on the EAP225 (Controller Settings → Controller Inform URL) or in Omada Discovery Utility',
 'inform_ports_hint'=>'Open on the VPS firewall so the EAP225 can reach the controller (ufw allow 29810/udp ; ufw allow 29811:29817/tcp)',
 'tok_http'=>'The Omada Open API answers only on HTTPS — the controller URL was changed to %s. Press Test connection again.',
 'tok_ssl'=>'SSL check failed — keep "Verify SSL certificate" OFF for a controller reached by IP (self-signed certificate).',
 'tok_omadac'=>'The saved Omada ID was wrong — the Omada ID of this controller (%s) was read from /api/info and saved.',
 'tok_keys'=>'Check the Client ID / Client Secret (Platform Integration → Open API app in mode "Client") of THIS controller.',
]);

// v6.2 — admin-managed Omada + new features
$T['en'] = array_merge($T['en'], [
 'admin_only'=>'Only the administrator can do this. Sellers add routers, provision them and start the hotspot.',
 'ctrl_managed_by_admin'=>'The Omada Controller and RADIUS server are managed by the administrator. Your router is linked to it automatically.',
 'ctrl_admin_pending'=>'The administrator has not finished the Omada Controller setup yet. Your router is saved and will be linked and provisioned automatically as soon as it is ready.',
 'ctrl_linked_auto'=>'Linked automatically','all_routers'=>'All Routers','seller'=>'Seller','owner_view'=>'You are managing a router of seller %s.',
 'quick_start'=>'Quick start','qs_router'=>'Add your router (Omada EAP225)','qs_provision'=>'Provision & connect it','qs_package'=>'Create a package',
 'qs_vouchers'=>'Generate vouchers','qs_live'=>'Hotspot is live (RADIUS traffic)','qs_done'=>'All done — your hotspot is selling WiFi.',
 'hotspot_start'=>'Start hotspot','hotspot_stop'=>'Stop hotspot','hotspot_started'=>'Hotspot started — customers can log in again.',
 'hotspot_stopped'=>'Hotspot stopped — new logins are refused and connected users are disconnected.','hotspot_stop_confirm'=>'Stop this hotspot? Connected users will be disconnected.',
 'broadcast'=>'Message all sellers','broadcast_title'=>'Title','broadcast_msg'=>'Message','broadcast_sent'=>'Notification sent to %d seller(s).',
 'allow_registration'=>'Allow new sellers to register','registration_closed'=>'Registration of new seller accounts is closed. Please contact the administrator.',
 'link_unlinked'=>'Link unlinked routers to the default controller','linked_n'=>'%d router(s) linked to the default Omada Controller.',
 'ar_intro'=>'Every router of every seller. Open a router to see its Hotspot page exactly as the seller does, run the Omada setup, check or fix its connection health.',
 'ar_total'=>'Routers','ar_online'=>'Online','ar_provisioned'=>'Provisioned','ar_unlinked'=>'Not linked','run_setup'=>'Run setup','check_health'=>'Check health',
 'ar_setup_done'=>'Setup for %s: %s','open'=>'Open',
]);

// v6.3 — mobile-money-first captive portal, seller SSIDs, one withdrawal fee
$T['en'] = array_merge($T['en'], [
 'p_lipia'=>'LIPIA','p_pay_title'=>'Lipia kifurushi','p_pay_now'=>'Lipa sasa','p_choose_pkg_sw'=>'Chagua kifurushi',
 'p_mm_hint'=>'M-Pesa • Mixx by Yas • Airtel Money • HaloPesa','p_phone_sw'=>'Namba ya simu ya kulipia',
 'p_push_sw'=>'Angalia simu yako, weka PIN kuthibitisha malipo. Utaunganishwa moja kwa moja.',
 'p_or_voucher'=>'Una vocha? Ingiza hapa','p_customer_care'=>'Huduma kwa wateja','p_want_system'=>'JE UNATAKA MFUMO HUU?',
 'p_want_system_desc'=>'Pata mfumo wa WiFi billing kwa biashara yako: vocha, malipo ya simu, hotspot na ripoti. Wasiliana nasi:',
 'p_call'=>'Piga simu','p_whatsapp'=>'WhatsApp','p_close'=>'Funga','p_ipaid'=>'Nimekwisha lipa',
 'p_ipaid_wait'=>'Bado hatujapokea uthibitisho. Subiri kidogo — muuzaji amejulishwa.','p_ipaid_notify'=>'Customer says payment was made',
 'p_payment_success'=>'Malipo yamefanikiwa! Tunakuunganisha sasa…','p_auto_connect'=>'Inaunganisha kiotomatiki…',
 'p_waiting_sw'=>'Tunasubiri uthibitisho wa malipo…','p_paid_sw'=>'Malipo yamepokelewa! Vocha yako','p_back_sw'=>'Rudi',
 'p_no_pkgs'=>'Hakuna vifurushi kwa sasa. Tumia vocha.',
 'withdraw_fee'=>'Withdrawal fee','withdraw_fee_note'=>'One fee covers everything deducted (platform + mobile-money transfer).',
 'my_ssids'=>'WiFi names (SSIDs) on this router','ssid_add_help'=>'Add more WiFi names to this router. "Hotspot" names open the payment / voucher portal; "Private" names use a WiFi password (staff, home).',
 'ssid_main'=>'Main','ssid_extra'=>'Extra','ssid_need_setup'=>'Run the Omada setup for this router first (Provision & connect) — SSIDs are created in its Omada site.',
 'ssid_main_keep'=>'The main hotspot SSID cannot be deleted here — rename it under Edit router.','ssid_not_found'=>'SSID not found in Omada.',
 'ssid_limit'=>'Maximum %d extra SSIDs per router.','ssid_exists'=>'An SSID with this name already exists.','ssid_portal_added'=>'Added to the hotspot portal.',
 'sales_contact'=>'Portal "JE UNATAKA MFUMO HUU?" contact phone','sonic_collect'=>'Sonic Pesa collection endpoint',
 'sonic_collect_help'=>'Relative to %s. Empty = /payment/create_order (official Sonic Pesa API). Callback URL: %s',
]);

// v6.4 — earnings (mobile money + vouchers) and payment recovery
$T['en'] = array_merge($T['en'], [
 'today_revenue'=>"Today's Earnings",'month_revenue'=>'This Month','total_revenue'=>'Total Earnings',
 'p_on_ssid'=>'Mtandao','p_not_confirmed'=>'Malipo bado hayajathibitishwa na Sonic Pesa. Kama umeshalipa, subiri hapa — utaunganishwa moja kwa moja.',
 'p_resumed'=>'Malipo yako ya awali yamepatikana.',
 'earn_mobile'=>'Earnings from Mobile Money','earn_vouchers'=>'Earnings from Vouchers','earn_total'=>'Total Earnings','earn_withdrawn'=>'Withdrawn',
 'earn_available'=>'Available Balance','earn_commission'=>'Platform commission','earn_today'=>'Today',
 'earn_note'=>'Total earnings = mobile money + vouchers used by customers (minus platform commission). Withdrawals are deducted from total earnings; what remains is the available balance.',
 'earn_all_sellers'=>'All sellers',
 'payments'=>'Payments','ledger'=>'Ledger','pay_attention'=>'Needs attention',
 'pay_intro'=>'Every payment made on the captive portal. If a customer paid but the payment shows pending, failed or expired, confirm it here: a voucher is issued, the balance is credited and the customer is connected to the internet automatically.',
 'pay_confirm'=>'Confirm paid','pay_confirm_btn'=>'Confirm & connect customer','pay_gw_ref'=>'Mobile money transaction ID (optional)','pay_note'=>'Note (optional)',
 'pay_confirm_q'=>'Confirm this payment as received? A voucher is issued and the customer is connected.',
 'pay_recheck'=>'Check again with Sonic Pesa','pay_mark_failed'=>'Mark failed','pay_cancel'=>'Cancel payment','pay_reconnect'=>'Connect customer',
 'pay_confirmed'=>'%s confirmed — voucher %s issued. The customer is connected automatically (the WiFi login page reopens; routers with the Omada Open API reconnect the phone within about a minute).',
 'pay_already_paid'=>'This payment is already confirmed.','pay_confirm_failed'=>'Could not confirm the payment (the voucher could not be issued).',
 'pay_no_gateway'=>'This payment has no Sonic Pesa order to check — confirm it by hand if you received the money.',
 'pay_recheck_paid'=>'Sonic Pesa confirms the payment — voucher issued and the customer will be connected.','pay_recheck_failed'=>'Sonic Pesa reports this payment as failed.',
 'pay_recheck_pending'=>'Sonic Pesa has not confirmed this payment yet.','pay_marked_failed'=>'Payment marked as failed.','pay_cancelled'=>'Payment cancelled.',
 'pay_reconnect_sent'=>'The phone was asked to reconnect (%d Omada site) — its WiFi login page opens and connects it with the voucher.',
 'pay_reconnect_none'=>'This router has no Omada Open API link, so the phone cannot be reconnected remotely. The customer is connected as soon as they open the WiFi login page again.',
 'pay_no_mac'=>'No phone MAC is saved for this payment.','pay_confirmed_by'=>'Confirmed by','pay_gateway'=>'Gateway','pay_customer'=>'Customer',
 'pay_voucher_used'=>'used','pay_voucher_waiting'=>'not used yet','pay_admin_confirmed_title'=>'Payment confirmed by the administrator',
 'pay_note_saved'=>'Note saved.','pay_late_title'=>'Late payment confirmed',
 'pay_set_status'=>'Update status','pay_status_set'=>'%s: status changed to %s.','pay_paid_locked'=>'This payment is already paid — its voucher was issued and cannot be taken back here.',
 'pay_no_package'=>'the package of this payment no longer exists; create a package with the same price first.',
 'pay_set_status_help'=>'Choosing "paid" creates the voucher for this package automatically and connects the customer.',
]);

// v6.7.1 — USSD push errors on the portal
$T['en'] = array_merge($T['en'], [
 'p_push_failed'=>'Imeshindikana kutuma ombi la malipo kwenye simu yako. Hakikisha namba ni sahihi kisha jaribu tena.',
 'sp_push_failed_title'=>'USSD push failed',
 'p_sp_answer'=>'Jibu la Sonic Pesa','p_sp_no_key'=>'Sonic Pesa API key haijawekwa kwenye mfumo.',
]);

// v6.6 — Sonic Pesa status tracking
$T['en'] = array_merge($T['en'], [
 'pay_confirm_failed'=>'Could not confirm the payment',
 'pay_recheck_all'=>'Check all with Sonic Pesa now','pay_recheck_all_done'=>'%d payment(s) checked with Sonic Pesa • %d confirmed as paid.',
 'pay_sp_status'=>'Sonic Pesa','pay_log'=>'Log','pay_error'=>'Last error','pay_no_events'=>'No events recorded yet.',
 'pay_no_package'=>'the package of this payment no longer exists and the order has no copy of it; create a package with the same price first.',
]);

function t(string $k): string {
    global $T, $currentLang;
    return $T[$currentLang][$k] ?? $T['en'][$k] ?? ucfirst(str_replace('_', ' ', $k));
}

// ============================================================
// CSRF / FLASH
// ============================================================
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function csrf_check($token): bool { return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
function flash(string $type, string $msg): void { $_SESSION['flash'][] = [$type, $msg]; }
function back(string $url, string $type = '', string $msg = ''): void { if ($msg !== '') flash($type, $msg); redirectTo(safeReturn($url)); }
/** Only allow same-site relative return targets (prevents open redirects). */
function safeReturn(?string $url, string $fallback = '?page=dashboard'): string {
    $url = (string)$url;
    if (preg_match('#^https?://#i', $url)) {
        $host = parse_url($url, PHP_URL_HOST);
        if ($host && $host === ($_SERVER['HTTP_HOST'] ?? '')) { $p = parse_url($url); return ($p['path'] ?? '/') . (isset($p['query']) ? '?' . $p['query'] : ''); }
        return $fallback;
    }
    return preg_match('#^(\?|/[^/])#', $url) ? $url : $fallback;
}

// ============================================================
// SCHEMA
// ============================================================
function initializeDatabase(): void {
    $s = [];
    $s[] = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL, email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(20) UNIQUE NOT NULL, password VARCHAR(255) NOT NULL, full_name VARCHAR(100) NOT NULL,
        user_type ENUM('admin','seller','customer') DEFAULT 'seller', balance DECIMAL(15,2) DEFAULT 0.00,
        status ENUM('active','inactive','suspended') DEFAULT 'active', email_verified TINYINT(1) DEFAULT 0, phone_verified TINYINT(1) DEFAULT 0,
        verification_token VARCHAR(100), last_login DATETIME, referral_code VARCHAR(50) UNIQUE, sms_enabled TINYINT(1) DEFAULT 1,
        email_enabled TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_user_type (user_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(100) UNIQUE NOT NULL, setting_value TEXT,
        setting_group VARCHAR(50) DEFAULT 'general', setting_type VARCHAR(20) DEFAULT 'text',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, seller_id INT, voucher_id INT, transaction_ref VARCHAR(100) UNIQUE NOT NULL,
        amount DECIMAL(15,2) NOT NULL, currency VARCHAR(10) DEFAULT 'TZS', payment_method VARCHAR(30) NOT NULL, payment_phone VARCHAR(20),
        type ENUM('purchase','deposit','withdrawal','commission','refund','adjustment') NOT NULL,
        status ENUM('pending','completed','failed','cancelled','refunded') DEFAULT 'pending', notes TEXT, completed_at DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_status (status), INDEX idx_user (user_id), INDEX idx_seller (seller_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS withdrawals (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, amount DECIMAL(15,2) NOT NULL, fee DECIMAL(10,2) DEFAULT 0.00,
        net_amount DECIMAL(15,2) NOT NULL, method VARCHAR(30) NOT NULL, account_number VARCHAR(50) NOT NULL, account_name VARCHAR(100),
        status ENUM('pending','processing','completed','rejected') DEFAULT 'pending', sonic_pesa_withdrawal_id VARCHAR(64),
        sonic_pesa_fee DECIMAL(10,2) DEFAULT 0.00, sonic_pesa_net_amount DECIMAL(15,2) DEFAULT 0.00, sonic_pesa_response TEXT,
        admin_notes TEXT, processed_by INT, processed_at DATETIME, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id), INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, action VARCHAR(100) NOT NULL, description TEXT, ip_address VARCHAR(45),
        user_agent TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, title VARCHAR(200) NOT NULL, message TEXT NOT NULL,
        type ENUM('info','success','warning','error','payment') DEFAULT 'info', is_read TINYINT(1) DEFAULT 0, read_at DATETIME,
        link VARCHAR(500), icon VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_user (user_id), INDEX idx_read (is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS rate_limits (
        id INT AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(100) NOT NULL, action VARCHAR(50) NOT NULL, attempts INT DEFAULT 1,
        window_start DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_id_action (identifier, action)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    // ---- Hotspot (Omada + RADIUS) tables ----
    // nas_id        = internal hotspot key (auto-generated, unique)
    // omada_nas_id  = NAS-Identifier exactly as TP-Link Omada sends it (learned automatically, or typed by the seller)
    $s[] = "CREATE TABLE IF NOT EXISTS hs_devices (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, device_name VARCHAR(100) NOT NULL, model VARCHAR(50) DEFAULT 'EAP225',
        ap_mac VARCHAR(17) NOT NULL, ssid VARCHAR(64), site_name VARCHAR(100) DEFAULT 'Default', controller_url VARCHAR(255),
        lipa_info VARCHAR(255), nas_ip VARCHAR(45), location VARCHAR(255), last_seen DATETIME NULL, is_active TINYINT(1) DEFAULT 1,
        nas_id VARCHAR(32) NULL, radius_secret VARCHAR(64) NULL, acct_secret VARCHAR(64) NULL, radius_src_ip VARCHAR(45) NULL,
        radius_last_auth DATETIME NULL, dae_target VARCHAR(64) NULL, secrets_rotated_at DATETIME NULL,
        omada_nas_id VARCHAR(64) NULL, nas_learned_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_ap (ap_mac), UNIQUE KEY uniq_nas (nas_id), INDEX idx_user (user_id),
        INDEX idx_omada_nas (omada_nas_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_packages (
        id INT AUTO_INCREMENT PRIMARY KEY, seller_id INT NOT NULL, device_id INT NULL, name VARCHAR(100) NOT NULL, description VARCHAR(255),
        price DECIMAL(12,2) NOT NULL DEFAULT 0, duration_minutes INT NOT NULL, time_mode ENUM('continuous','online') DEFAULT 'continuous',
        data_limit_mb INT DEFAULT 0, speed_down_mbps DECIMAL(7,2) DEFAULT 5, speed_up_mbps DECIMAL(7,2) DEFAULT 2, max_devices INT DEFAULT 1,
        validity_days INT DEFAULT 30, show_on_portal TINYINT(1) DEFAULT 1, is_active TINYINT(1) DEFAULT 1, sort_order INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_seller (seller_id),
        FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (device_id) REFERENCES hs_devices(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_vouchers (
        id INT AUTO_INCREMENT PRIMARY KEY, package_id INT NULL, seller_id INT NOT NULL, device_id INT NULL, code VARCHAR(20) NOT NULL,
        batch VARCHAR(20), price DECIMAL(12,2) DEFAULT 0, duration_minutes INT NOT NULL, time_mode ENUM('continuous','online') DEFAULT 'continuous',
        data_limit_mb INT DEFAULT 0, speed_down_mbps DECIMAL(7,2) DEFAULT 0, speed_up_mbps DECIMAL(7,2) DEFAULT 0, max_devices INT DEFAULT 1,
        status ENUM('available','sold','active','expired','exhausted','blocked','cancelled') DEFAULT 'available',
        source ENUM('batch','online','manual') DEFAULT 'batch', sold_to_phone VARCHAR(20), sold_at DATETIME, first_used_at DATETIME NULL,
        expires_at DATETIME NULL, valid_until DATETIME NULL, data_used_bytes BIGINT UNSIGNED DEFAULT 0, seconds_used INT DEFAULT 0,
        last_mac VARCHAR(17), last_seen DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_code (code), INDEX idx_status (status), INDEX idx_seller (seller_id), INDEX idx_batch (batch),
        FOREIGN KEY (package_id) REFERENCES hs_packages(id) ON DELETE SET NULL,
        FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_voucher_macs (
        id INT AUTO_INCREMENT PRIMARY KEY, voucher_id INT NOT NULL, mac VARCHAR(17) NOT NULL, first_seen DATETIME, last_seen DATETIME,
        UNIQUE KEY uniq_vm (voucher_id, mac), FOREIGN KEY (voucher_id) REFERENCES hs_vouchers(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_sessions (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, voucher_id INT NULL, seller_id INT NULL, device_id INT NULL, username VARCHAR(64),
        unique_id VARCHAR(64) NOT NULL, acct_session_id VARCHAR(64), mac VARCHAR(17), ip VARCHAR(45), nas_ip VARCHAR(45), nas_id VARCHAR(32), ap_mac VARCHAR(17),
        started_at DATETIME, updated_at DATETIME, stopped_at DATETIME NULL, session_time INT DEFAULT 0,
        bytes_in BIGINT UNSIGNED DEFAULT 0, bytes_out BIGINT UNSIGNED DEFAULT 0, status ENUM('active','closed','stale') DEFAULT 'active',
        terminate_cause VARCHAR(64), UNIQUE KEY uniq_unique (unique_id), INDEX idx_voucher (voucher_id), INDEX idx_status (status),
        INDEX idx_seller (seller_id), INDEX idx_mac (mac), INDEX idx_nas (nas_id),
        FOREIGN KEY (voucher_id) REFERENCES hs_vouchers(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_adjustments (
        id INT AUTO_INCREMENT PRIMARY KEY, voucher_id INT NOT NULL, seller_id INT NOT NULL, minutes INT NOT NULL,
        old_value VARCHAR(40), new_value VARCHAR(40), reason VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_seller (seller_id), FOREIGN KEY (voucher_id) REFERENCES hs_vouchers(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_blocked_macs (
        id INT AUTO_INCREMENT PRIMARY KEY, seller_id INT NOT NULL, mac VARCHAR(17) NOT NULL, reason VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_sm (seller_id, mac)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_dae_queue (
        id INT AUTO_INCREMENT PRIMARY KEY, voucher_id INT NULL, session_id BIGINT NULL, username VARCHAR(64), mac VARCHAR(17),
        acct_session_id VARCHAR(64), nas_ip VARCHAR(45), framed_ip VARCHAR(45), reason VARCHAR(100),
        status ENUM('pending','sent','done','failed') DEFAULT 'pending', attempts INT DEFAULT 0, last_result VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_radius_log (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(16), username VARCHAR(64), mac VARCHAR(17), ap_mac VARCHAR(17), nas_ip VARCHAR(45),
        nas_id VARCHAR(32), src_ip VARCHAR(45), result VARCHAR(16), message VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_created (created_at), INDEX idx_nas (nas_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $s[] = "CREATE TABLE IF NOT EXISTS hs_orders (
        id INT AUTO_INCREMENT PRIMARY KEY, order_ref VARCHAR(40) NOT NULL, seller_id INT NOT NULL, package_id INT NULL, device_id INT NULL,
        phone VARCHAR(20), amount DECIMAL(12,2) NOT NULL, client_mac VARCHAR(17),
        status ENUM('pending','paid','failed','expired','cancelled') DEFAULT 'pending', voucher_id INT NULL, gateway_ref VARCHAR(100),
        gateway_response TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, paid_at DATETIME NULL,
        UNIQUE KEY uniq_ref (order_ref), INDEX idx_status (status), INDEX idx_seller (seller_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    foreach ($s as $sql) { try { db()->query($sql); } catch (Throwable $e) { error_log('Schema: ' . $e->getMessage()); } }

    $defaults = [
        ['site_name', SITE_NAME, 'general'], ['min_withdrawal', '5000', 'payment'], ['platform_commission_percent', '0', 'payment'],
        ['radius_server_ip', '', 'radius'], ['acct_server_ip', '', 'radius'], ['dae_enabled', '1', 'radius'],
        ['radius_idle_timeout', '900', 'radius'], ['radius_allowed_ips', '', 'radius'],
        ['radius_reply_lang', 'en', 'radius'], ['voucher_length', '8', 'general'], ['controller_url', '', 'radius'],
        ['radius_server_seen', '0', 'system'], ['radius_server_info', '', 'system'],
        ['hk_last_run', '0', 'system'], ['hk_last_result', '', 'system'], ['schema_version', '6', 'system'],
    ];
    foreach ($defaults as $d) q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,?)", 'sss', $d[0], $d[1], $d[2]);
    $adminPass = password_hash('Admin@123', PASSWORD_DEFAULT);
    q("INSERT IGNORE INTO users (username,email,phone,password,full_name,user_type,status,email_verified,phone_verified,referral_code)
       VALUES ('admin','admin@skytanza.com','0700000000',?,'System Administrator','admin','active',1,1,'ADMIN001')", 's', $adminPass);
}
try {
    if (db()->query("SHOW TABLES LIKE 'hs_orders'")->num_rows === 0 || db()->query("SHOW TABLES LIKE 'users'")->num_rows === 0) initializeDatabase();
} catch (Throwable $e) { error_log('Init: ' . $e->getMessage()); }

function getSetting(string $key, string $default = ''): string {
    $v = val("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1", 's', $key);
    return $v === null ? $default : (string)$v;
}
function setSetting(string $key, string $value): void {
    q("INSERT INTO settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)", 'ss', $key, $value);
}
/** v4 → v5: per-router RADIUS credentials. v5 → v6: NAS ID as sent by Omada. Safe to run more than once; MySQL 5.7 and MariaDB. */
function migrateDatabase(): void {
    $hasCol = fn(string $t, string $c): bool => db()->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->num_rows > 0;
    $hasIdx = fn(string $t, string $i): bool => db()->query("SHOW INDEX FROM `$t` WHERE Key_name='$i'")->num_rows > 0;
    $add = [
        'hs_devices' => ['nas_id' => 'VARCHAR(32) NULL', 'radius_secret' => 'VARCHAR(64) NULL', 'acct_secret' => 'VARCHAR(64) NULL',
            'radius_src_ip' => 'VARCHAR(45) NULL', 'radius_last_auth' => 'DATETIME NULL', 'dae_target' => 'VARCHAR(64) NULL', 'secrets_rotated_at' => 'DATETIME NULL',
            'omada_nas_id' => 'VARCHAR(64) NULL', 'nas_learned_at' => 'DATETIME NULL'],
        'hs_sessions' => ['nas_id' => 'VARCHAR(32) NULL'],
        'hs_radius_log' => ['nas_id' => 'VARCHAR(32) NULL', 'src_ip' => 'VARCHAR(45) NULL'],
    ];
    foreach ($add as $t => $cols) foreach ($cols as $c => $ddl) if (!$hasCol($t, $c)) db()->query("ALTER TABLE `$t` ADD COLUMN `$c` $ddl");
    if (!$hasIdx('hs_devices', 'uniq_nas')) db()->query("ALTER TABLE hs_devices ADD UNIQUE KEY uniq_nas (nas_id)");
    if (!$hasIdx('hs_devices', 'idx_omada_nas')) db()->query("ALTER TABLE hs_devices ADD INDEX idx_omada_nas (omada_nas_id)");
    if (!$hasIdx('hs_sessions', 'idx_nas')) db()->query("ALTER TABLE hs_sessions ADD INDEX idx_nas (nas_id)");
    if (!$hasIdx('hs_radius_log', 'idx_nas')) db()->query("ALTER TABLE hs_radius_log ADD INDEX idx_nas (nas_id)");
    foreach ([['radius_server_ip', ''], ['acct_server_ip', ''], ['dae_enabled', '1'], ['radius_server_seen', '0'], ['radius_server_info', '']] as [$k, $v])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,'radius')", 'ss', $k, $v);
    foreach (rows("SELECT id FROM hs_devices WHERE nas_id IS NULL OR radius_secret IS NULL OR acct_secret IS NULL") as $d) Device::ensureCredentials((int)$d['id']);
    setSetting('schema_version', '6');
}
/** v6 → v7: Omada Controller (Open API) connections + live AP status on every hotspot. */
function migrateDatabaseV7(): void {
    db()->query("CREATE TABLE IF NOT EXISTS hs_controllers (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, name VARCHAR(100) NOT NULL,
        ctype ENUM('local','cloud') DEFAULT 'local', base_url VARCHAR(255) NOT NULL, omadac_id VARCHAR(64) NULL,
        client_id VARCHAR(128) NULL, client_secret VARCHAR(255) NULL, verify_ssl TINYINT(1) DEFAULT 0,
        inform_url VARCHAR(255) NULL, controller_ver VARCHAR(40) NULL, api_ver VARCHAR(20) NULL,
        access_token TEXT NULL, refresh_token TEXT NULL, token_expires DATETIME NULL,
        last_ok DATETIME NULL, last_error VARCHAR(255) NULL, last_sync DATETIME NULL, sites_json MEDIUMTEXT NULL, paths_json TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_user (user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $hasCol = fn(string $t, string $c): bool => db()->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->num_rows > 0;
    $cols = ['controller_id' => 'INT NULL', 'omada_site_id' => 'VARCHAR(64) NULL', 'omada_status' => 'VARCHAR(32) NULL',
        'omada_status_at' => 'DATETIME NULL', 'omada_online_at' => 'DATETIME NULL', 'omada_clients' => 'INT DEFAULT 0',
        'omada_model' => 'VARCHAR(64) NULL', 'omada_ip' => 'VARCHAR(45) NULL', 'omada_fw' => 'VARCHAR(80) NULL', 'omada_uptime' => 'VARCHAR(64) NULL'];
    foreach ($cols as $c => $ddl) if (!$hasCol('hs_devices', $c)) db()->query("ALTER TABLE hs_devices ADD COLUMN `$c` $ddl");
    if (db()->query("SHOW INDEX FROM hs_devices WHERE Key_name='idx_ctrl'")->num_rows === 0) db()->query("ALTER TABLE hs_devices ADD INDEX idx_ctrl (controller_id)");
    foreach ([['site_url', '', 'general'], ['omada_last_sync', '0', 'system']] as [$k, $v, $g])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,?)", 'sss', $k, $v, $g);
    setSetting('schema_version', '7');
}
/**
 * Public base URL of the website (no trailing slash). Order: SITE_URL in config.local.php → admin setting "site_url"
 * (saved automatically the first time an admin opens the site) → detected from the current request.
 */
function appUrl(): string {
    static $u = null;
    if ($u !== null) return $u;
    if (SITE_URL !== '') return $u = rtrim(SITE_URL, '/');
    $s = '';
    try { $s = getSetting('site_url'); } catch (Throwable $e) {}
    if ($s !== '') return $u = rtrim($s, '/');
    $d = detectedBaseUrl();
    return $u = ($d !== '' ? $d : 'https://wifi.skytanzania.co.tz');
}
/**
 * v5.7.2 — the address machines must call (RADIUS box, payment gateway, Omada External Web Portal): appUrl()/index.php,
 * or the address the host redirects it to (found by Admin → RADIUS Setup → Website API endpoint). Always the same host.
 */
function machineUrl(): string {
    $base = appUrl() . '/index.php';
    $e = '';
    try { $e = getSetting('api_endpoint'); } catch (Throwable $t) {}
    if ($e !== '') { $ok = RadiusServer::redirectBase($base, $e); if ($ok !== null) return $ok; }
    return $base;
}
/**
 * v5.7.2 — POST this website's own API address (no key) and follow the host's redirects the way the RADIUS box does.
 * Any JSON reply (403 / 503 included) proves index.php was reached. Cached 15 minutes.
 */
function probeApiEndpoint(bool $force = false): array {
    $cached = json_decode(getSetting('api_probe'), true) ?: [];
    if (!$force && ($cached['base'] ?? '') === appUrl() && (int)($cached['at'] ?? 0) > time() - 900) return $cached;
    $url = appUrl() . '/index.php';
    $r = ['base' => appUrl(), 'start' => $url, 'url' => $url, 'redirects' => [], 'ok' => null, 'code' => 0, 'msg' => '', 'at' => time()];
    if (!function_exists('curl_init')) { $r['msg'] = 'PHP cURL is not installed on this host — check skipped'; return $r; }
    for ($hop = 0; $hop < 5; $hop++) {
        $ch = curl_init(RadiusServer::withAction($url, 'ping'));
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '{}', CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 7,
            CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_FOLLOWLOCATION => false, CURLOPT_USERAGENT => 'SkyTanzaProbe/' . APP_VERSION,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json']]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $loc = (string)curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        $err = curl_error($ch);
        curl_close($ch);
        $r['code'] = $code;
        if ($err !== '') { $r['msg'] = 'The website cannot call itself (' . $err . ') — the check is skipped; the RADIUS box still follows redirects on its own.'; break; }
        if ($code >= 300 && $code < 400 && $loc !== '') {
            $r['redirects'][] = $code . ' → ' . $loc;
            $next = RadiusServer::redirectBase($url, $loc);
            if ($next === null || $next === $url) { $r['ok'] = false; $r['msg'] = 'Redirect to ' . $loc . ' leaves this host or loops.'; break; }
            $url = $next;
            continue;
        }
        $r['ok'] = is_array(json_decode((string)$body, true));
        $r['url'] = $url;
        if (!$r['ok']) $r['msg'] = 'HTTP ' . $code . ' — this address does not run index.php.';
        break;
    }
    setSetting('api_probe', (string)json_encode($r, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    if ($r['ok'] === true) setSetting('api_endpoint', $r['url'] !== $r['start'] ? $r['url'] : '');
    return $r;
}
/** The External Web Portal URL to put in Omada — a clean URL with NO "?" (Omada appends ?clientMac=... itself). */
function portalUrl(): string { return (string)preg_replace('/\?.*$/', '', machineUrl()); }
/**
 * v6.6.1 — clean a browserauth address: always https, no :443, "/portal/radius/browserauth" added when only the domain
 * (or ".../portal") is given. Returns '' when it is not a usable address.
 */
function normalizeBrowserAuthUrl(string $u): string {
    $u = trim($u);
    if ($u === '') return '';
    if (!preg_match('#^[a-z][a-z0-9+.\-]*://#i', $u)) $u = 'https://' . ltrim($u, '/');
    $p = @parse_url($u);
    if (!is_array($p)) return '';
    $host = strtolower((string)($p['host'] ?? ''));
    if ($host === '' || !preg_match('/^[a-z0-9.\-]+$/', $host)) return '';
    $port = isset($p['port']) ? (int)$p['port'] : 0;
    $path = rtrim(preg_replace('#/+#', '/', (string)($p['path'] ?? '')), '/');
    if (!preg_match('#/browserauth$#i', $path)) $path .= preg_match('#/portal$#i', $path) ? '/radius/browserauth' : '/portal/radius/browserauth';
    return 'https://' . $host . ($port && $port !== 443 ? ':' . $port : '') . $path;
}
/** v6.6.1 — the fixed HTTPS browserauth URL (admin setting "omada_portal_auth_url", else OMADA_PORTAL_AUTH_URL). */
function omadaPortalAuthUrl(): string {
    $u = '';
    try { $u = trim(getSetting('omada_portal_auth_url')); } catch (Throwable $e) {}
    if ($u === '') $u = trim((string)OMADA_PORTAL_AUTH_URL);
    return normalizeBrowserAuthUrl($u);
}
/** v6.6.1 — why a browserauth URL would give phones a certificate error ('' = looks fine). */
function browserAuthUrlWarning(string $u): string {
    if ($u === '') return 'Not set — paid customers cannot be connected automatically.';
    $host = (string)parse_url($u, PHP_URL_HOST);
    $port = (int)parse_url($u, PHP_URL_PORT);
    if (filter_var($host, FILTER_VALIDATE_IP)) return 'This is an IP address — it has no valid SSL certificate, phones will show a certificate error. Use your domain, e.g. https://omada.skytanzania.co.tz/portal/radius/browserauth';
    if (in_array($port, [8043, 8843, 8088], true)) return 'Port ' . $port . ' is the Omada self-signed port — phones will show a certificate error. Use the nginx domain on port 443 (no port in the URL).';
    return '';
}
/**
 * v6.6.1 — test from this website that the browserauth address answers over HTTPS with a VALID certificate.
 * Any HTTP answer (200/302/400/404/405…) with a trusted certificate is OK; an SSL error is what phones would see.
 */
function testBrowserAuthUrl(string $u): array {
    if ($u === '') return ['ok' => false, 'msg' => 'No browserauth URL set.'];
    if (!function_exists('curl_init')) return ['ok' => false, 'msg' => 'cURL is not available on this hosting.'];
    $ch = curl_init($u);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_NOBODY => false, CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_USERAGENT => 'SkyTanzaWiFi/' . APP_VERSION]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errno = curl_errno($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($errno === 0 && $code > 0)
        return ['ok' => true, 'msg' => 'SSL certificate valid — ' . parse_url($u, PHP_URL_HOST) . ' answered HTTP ' . $code . '. Phones will not see a certificate error.'];
    if ($errno !== 0 && preg_match('/reset|timed? ?out|refused|resolve|tunnel/i', $err))
        return ['ok' => false, 'msg' => 'Not reachable from the website: ' . $err . ' — check DNS (A record → VPS IP), nginx and ports 80/443.'];
    if (in_array($errno, [35, 51, 53, 54, 58, 59, 60, 64, 66, 77, 80, 82, 83, 90, 91], true))
        return ['ok' => false, 'msg' => 'SSL certificate problem: ' . $err . ' — install a Let\'s Encrypt certificate for this domain on the VPS (certbot --nginx).'];
    return ['ok' => false, 'msg' => 'Not reachable from the website: ' . ($err ?: 'no answer') . ' — check DNS (A record → VPS IP), nginx and ports 80/443.'];
}
/**
 * v6.1.2 — the Omada Open API address of a self-hosted controller: always https, port 8043 when the port is missing
 * (IP address), 80 or 8088 (the HTTP portal port). "http://169.58.93.38:8043" → "https://169.58.93.38:8043".
 */
function omadaControllerBase(string $u): string {
    $o = Device::normalizeOrigin($u, 'https');
    if ($o === '') return '';
    $p = parse_url($o);
    $host = strtolower((string)($p['host'] ?? ''));
    if ($host === '') return '';
    $port = isset($p['port']) ? (int)$p['port'] : 0;
    if (in_array($port, [80, 8088], true) || ($port === 0 && filter_var($host, FILTER_VALIDATE_IP))) $port = 8043;
    return 'https://' . $host . ($port ? ':' . $port : '');
}
/**
 * Controller Inform URL the EAP225 must report to. v6.1.2: for your own controller this is simply the controller IP / host
 * of its Controller URL (e.g. 169.58.93.38) — a stale Inform URL that points to another host is never shown any more.
 */
function informUrlOf(?array $ctl): string {
    if (!$ctl) return '';
    $baseHost = strtolower((string)parse_url((string)($ctl['base_url'] ?? ''), PHP_URL_HOST));
    $inf = parseInformUrl(trim((string)($ctl['inform_url'] ?? '')));
    if ($inf && $inf['cloud']) return $inf['raw'];
    if ($baseHost !== '' && !OmadaRelay::isCloudHost($baseHost)) return $baseHost;
    return $inf ? $inf['host'] : '';
}
/** v6.1.2 — what to type on the EAP225 for an Inform URL string ("omada://169.58.93.38?..." → "169.58.93.38"). */
function informDeviceAddr(string $raw): string {
    $inf = $raw !== '' ? parseInformUrl($raw) : null;
    if (!$inf) return '';
    return $inf['cloud'] ? $inf['raw'] : $inf['host'];
}
/** v5.8 — the Omada Inform URL every added router uses: admin setting "omada_default_inform", else OMADA_DEFAULT_INFORM_URL. */
function defaultInformUrl(): string {
    $s = '';
    try { $s = trim(getSetting('omada_default_inform')); } catch (Throwable $e) {}
    if ($s === '') $s = trim((string)OMADA_DEFAULT_INFORM_URL);
    $inf = $s !== '' ? parseInformUrl($s) : null;
    return $inf ? $inf['raw'] : '';
}
/** Open API / interface address for an Inform URL: the regional cloud address, else https://<controller host>:8043. */
function informApiBase(array $inf): string {
    return 'https://' . $inf['host'] . ':8043';   // v6.1: own Omada Controller only (Interface Access Address, port 8043)
}
/**
 * v5.8 — this seller's Omada controller link for the default Inform URL (created the first time, Omada ID read from the URL).
 * Every router of the seller that is not linked to any controller yet is linked to it. Returns the controller id (0 = none).
 */
/** v5.9 — platform Open API keys for the default Inform URL controller: [client_id, client_secret] ('' when not set). */
function defaultOmadaKeys(): array {
    $id = ''; $sec = '';
    try { $id = trim(getSetting('omada_default_client_id')); $sec = openSecret(getSetting('omada_default_client_secret')); } catch (Throwable $e) {}
    if ($id === '' && (string)OMADA_DEFAULT_CLIENT_ID !== '') { $id = (string)OMADA_DEFAULT_CLIENT_ID; $sec = (string)OMADA_DEFAULT_CLIENT_SECRET; }
    return ($id !== '' && $sec !== '') ? [$id, $sec] : ['', ''];
}
/**
 * v5.9 — give every seller's link to the default Inform URL controller the platform keys (shared_keys=1), or take them
 * away again when the admin removes them. Rows where a seller typed his own keys are never touched. $uid 0 = everyone.
 */
function applyDefaultOmadaKeys(int $uid = 0): void {
    $raw = defaultInformUrl();
    if ($raw === '') return;
    [$cid, $sec] = defaultOmadaKeys();
    $w = $uid ? ' AND user_id=' . (int)$uid : '';
    try {
        if ($cid !== '') {
            run("UPDATE hs_controllers SET client_id=?, client_secret=?, shared_keys=1, access_token=NULL, token_expires=NULL, last_sync=NULL
                 WHERE inform_url=? AND (shared_keys=1 OR client_id IS NULL OR client_id='')$w AND NOT (shared_keys=1 AND client_id=? AND client_secret=?)",
                'sssss', $cid, $sec, $raw, $cid, $sec);
        } else {
            run("UPDATE hs_controllers SET client_id='', client_secret='', shared_keys=0, access_token=NULL, token_expires=NULL WHERE shared_keys=1$w");
        }
    } catch (Throwable $e) { error_log('applyDefaultOmadaKeys: ' . $e->getMessage()); }
}
function ensureDefaultController(int $uid): int {
    static $done = [];
    if ($uid <= 0) return 0;
    if (isset($done[$uid])) return $done[$uid];
    $raw = defaultInformUrl();
    $inf = $raw !== '' ? parseInformUrl($raw) : null;
    if (!$inf || $inf['cloud']) return $done[$uid] = 0;                               // v6.1: own controller only (v6.1.2: Omada ID may come from /api/info)
    [$defKey] = defaultOmadaKeys();
    if ($defKey === '') return $done[$uid] = 0;                                         // v6.1: Open API keys are required
    try {
        $id = (int)val("SELECT id FROM hs_controllers WHERE user_id=? AND inform_url=? ORDER BY id LIMIT 1", 'is', $uid, $inf['raw']);
        if (!$id) {   // v6.1.2: the seller already has this controller (same host) → reuse it instead of a duplicate
            $id = (int)val("SELECT id FROM hs_controllers WHERE user_id=? AND (base_url=? OR base_url LIKE ?) ORDER BY id LIMIT 1", 'iss',
                $uid, informApiBase($inf), 'https://' . $inf['host'] . ':%');
            if ($id) run("UPDATE hs_controllers SET inform_url=? WHERE id=?", 'si', $inf['raw'], $id);
        }
        if (!$id) {
            $type = $inf['cloud'] ? 'cloud' : 'local';
            $name = ($inf['cloud'] ? 'Omada Cloud' : 'Omada Controller') . ' ' . $inf['host'];
            q("INSERT INTO hs_controllers (user_id,name,ctype,base_url,omadac_id,client_id,client_secret,inform_url,verify_ssl,region) VALUES (?,?,?,?,?,'','',?,?,?)",
                'isssssis', $uid, substr($name, 0, 100), $type, informApiBase($inf), $inf['omadac_id'] !== '' ? $inf['omadac_id'] : null, $inf['raw'],
                $inf['cloud'] ? 1 : 0, $inf['region'] !== '' ? $inf['region'] : null);
            $id = (int)db()->insert_id;
            logActivity($uid, 'omada_default_inform', 'Linked Omada Inform URL ' . $inf['raw']);
        }
        if ($id) run("UPDATE hs_devices SET controller_id=? WHERE user_id=? AND controller_id IS NULL", 'ii', $id, $uid);
        applyDefaultOmadaKeys($uid);   // v5.9: platform Open API keys → automatic provisioning for every seller
        return $done[$uid] = $id;
    } catch (Throwable $e) {
        error_log('ensureDefaultController: ' . $e->getMessage());
        return $done[$uid] = 0;
    }
}
/** v7 → v8: Omada Cloud auto-setup (Inform URL, site / SSID / RADIUS profile / portal / voucher-group IDs, provisioning state). */
function migrateDatabaseV8(): void {
    $hasCol = fn(string $t, string $c): bool => db()->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->num_rows > 0;
    $add = [
        'hs_devices' => ['omada_sn' => 'VARCHAR(32) NULL', 'omada_wlan_id' => 'VARCHAR(64) NULL', 'omada_ssid_id' => 'VARCHAR(64) NULL',
            'omada_radius_id' => 'VARCHAR(64) NULL', 'omada_portal_id' => 'VARCHAR(64) NULL', 'omada_vgroup_id' => 'VARCHAR(64) NULL',
            'voucher_mode' => "VARCHAR(10) NOT NULL DEFAULT 'radius'", 'prov_state' => 'VARCHAR(24) NULL', 'prov_log' => 'MEDIUMTEXT NULL',
            'prov_at' => 'DATETIME NULL', 'prov_opts' => 'TEXT NULL', 'prov_user' => 'VARCHAR(64) NULL', 'prov_pass' => 'VARCHAR(255) NULL',
            'prov_adopt_at' => 'DATETIME NULL'],
        'hs_controllers' => ['site_dev_user' => 'VARCHAR(64) NULL', 'site_dev_pass' => 'VARCHAR(255) NULL', 'region' => 'VARCHAR(16) NULL'],
        'hs_vouchers' => ['ext_ref' => 'VARCHAR(64) NULL'],
    ];
    $sqls = [];
    foreach ($add as $t => $cols) foreach ($cols as $c => $ddl) if (!$hasCol($t, $c)) $sqls[] = "ALTER TABLE `$t` ADD COLUMN `$c` $ddl";
    $sqls[] = "ALTER TABLE hs_vouchers MODIFY source ENUM('batch','online','manual','omada') DEFAULT 'batch'";
    $sqls[] = "ALTER TABLE hs_controllers MODIFY inform_url VARCHAR(512) NULL";
    $failed = [];
    foreach ($sqls as $sql) { try { db()->query($sql); } catch (Throwable $e) { $failed[] = $e->getMessage(); error_log('Migration v8: ' . $sql . ' → ' . $e->getMessage()); } }
    foreach ([['omada_site_region', 'Tanzania'], ['omada_site_timezone', 'Africa/Nairobi']] as [$k, $v])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,'omada')", 'ss', $k, $v);
    if ($failed) throw new RuntimeException('Database upgrade v8 incomplete: ' . implode(' | ', $failed));   // retried on the next request
    setSetting('schema_version', '8');
}
/**
 * v8 → v9: "Routers" + "Hotspot" menus. New tables:
 *   hs_router_models   — the router models a seller can choose under Routers → Add router (Omada EAP225 first)
 *   hs_provision_runs  — history of every add / setup / provision-and-connect step per router (shown on Hotspot)
 * and hs_devices.router_model_id (which model each router is).
 */
function migrateDatabaseV9(): void {
    db()->query("CREATE TABLE IF NOT EXISTS hs_router_models (
        id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(40) NOT NULL, brand VARCHAR(50) NOT NULL, model VARCHAR(60) NOT NULL,
        kind VARCHAR(30) DEFAULT 'access_point', description VARCHAR(255) NULL, icon VARCHAR(40) DEFAULT 'wifi',
        is_active TINYINT(1) DEFAULT 1, sort_order INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_code (code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->query("CREATE TABLE IF NOT EXISTS hs_provision_runs (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, device_id INT NOT NULL, user_id INT NOT NULL, action VARCHAR(30) NOT NULL,
        phase VARCHAR(30) NULL, message VARCHAR(500) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_dev (device_id), INDEX idx_user (user_id),
        FOREIGN KEY (device_id) REFERENCES hs_devices(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    foreach ([
        ['omada-eap225', 'TP-Link Omada', 'EAP225', 'access_point', 'AC1350 ceiling-mount Wi-Fi access point • External RADIUS portal • Omada Cloud / OC200', 'wifi', 1, 1],
        ['omada-eap245', 'TP-Link Omada', 'EAP245', 'access_point', 'AC1750 ceiling-mount access point', 'wifi', 0, 2],
        ['omada-eap110-outdoor', 'TP-Link Omada', 'EAP110-Outdoor', 'access_point', '300 Mbps outdoor access point', 'tower-broadcast', 0, 3],
    ] as $m) q("INSERT IGNORE INTO hs_router_models (code,brand,model,kind,description,icon,is_active,sort_order) VALUES (?,?,?,?,?,?,?,?)", 'ssssssii', ...$m);
    if (db()->query("SHOW COLUMNS FROM hs_devices LIKE 'router_model_id'")->num_rows === 0) db()->query("ALTER TABLE hs_devices ADD COLUMN router_model_id INT NULL");
    run("UPDATE hs_devices SET router_model_id=(SELECT id FROM hs_router_models WHERE code='omada-eap225') WHERE router_model_id IS NULL");
    setSetting('schema_version', '9');
}
/** v9 → v10: Omada link engine (health checks, portal reach, RADIUS push after a server change). */
function migrateDatabaseV10(): void {
    $hasCol = fn(string $t, string $c): bool => db()->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->num_rows > 0;
    foreach (['health_json' => 'MEDIUMTEXT NULL', 'health_at' => 'DATETIME NULL', 'portal_seen_at' => 'DATETIME NULL', 'portal_target' => 'VARCHAR(160) NULL'] as $c => $ddl)
        if (!$hasCol('hs_devices', $c)) db()->query("ALTER TABLE hs_devices ADD COLUMN `$c` $ddl");
    foreach ([['omada_push_since', '0'], ['omada_push_needed', '0']] as [$k, $v])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,'omada')", 'ss', $k, $v);
    setSetting('schema_version', '10');
}
/** v10 → v11: Omada relay through the RADIUS box (job queue) + connection route / shared Open API keys per controller. */
function migrateDatabaseV11(): void {
    db()->query("CREATE TABLE IF NOT EXISTS hs_omada_jobs (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, ctrl_id INT NULL, kind VARCHAR(8) NOT NULL DEFAULT 'http', method VARCHAR(8) NOT NULL DEFAULT 'GET',
        url VARCHAR(1024) NOT NULL DEFAULT '', host VARCHAR(255) NULL, port INT NULL, headers MEDIUMTEXT NULL, body MEDIUMTEXT NULL,
        timeout_s INT NOT NULL DEFAULT 10, verify_ssl TINYINT(1) NOT NULL DEFAULT 0,
        status ENUM('pending','taken','done','expired') NOT NULL DEFAULT 'pending', claim VARCHAR(32) NULL,
        res_code INT NULL, res_body MEDIUMTEXT NULL, res_error VARCHAR(500) NULL, res_ms INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, taken_at DATETIME NULL, done_at DATETIME NULL,
        INDEX idx_status (status), INDEX idx_claim (claim)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $hasCol = fn(string $t, string $c): bool => db()->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->num_rows > 0;
    foreach (['conn_mode' => "VARCHAR(10) NOT NULL DEFAULT 'auto'", 'direct_fail_at' => 'DATETIME NULL', 'last_via' => 'VARCHAR(10) NULL',
              'shared_keys' => 'TINYINT(1) NOT NULL DEFAULT 0'] as $c => $ddl)
        if (!$hasCol('hs_controllers', $c)) db()->query("ALTER TABLE hs_controllers ADD COLUMN `$c` $ddl");
    foreach ([['omada_relay_seen', '0'], ['omada_relay_info', ''], ['omada_default_client_id', ''], ['omada_default_client_secret', '']] as [$k, $v])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,'omada')", 'ss', $k, $v);
    setSetting('schema_version', '11');
}

/** v11 → v12 (v6.0 Omada Manager): sites a seller created, Omada voucher groups made / imported here, Omada voucher id per code. */
function migrateDatabaseV12(): void {
    db()->query("CREATE TABLE IF NOT EXISTS hs_omada_sites (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, ctrl_id INT NULL, site_id VARCHAR(64) NOT NULL, name VARCHAR(100) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_us (user_id, site_id), INDEX idx_site (site_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->query("CREATE TABLE IF NOT EXISTS hs_omada_vgroups (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, ctrl_id INT NULL, site_id VARCHAR(64) NOT NULL, group_id VARCHAR(64) NOT NULL,
        name VARCHAR(100) NULL, package_id INT NULL, batch VARCHAR(20) NULL, amount INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_ug (user_id, group_id), INDEX idx_site (site_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (db()->query("SHOW COLUMNS FROM hs_vouchers LIKE 'ext_vid'")->num_rows === 0) db()->query("ALTER TABLE hs_vouchers ADD COLUMN ext_vid VARCHAR(64) NULL");
    setSetting('schema_version', '12');
}
/**
 * v12 → v13 (v6.1.2): the controller is public on the VPS. Every self-hosted controller row gets an https Open API address
 * (http://IP:8043 caused "Token refused (HTTP 400)"), its Inform URL points to its own host, cached tokens are dropped, and the
 * default Inform URL that still points to another host (e.g. 65.109.35.14) is moved to the public controller.
 */
function migrateDatabaseV13(): void {
    $pub = omadaControllerBase((string)OMADA_CONTROLLER_URL);
    $pubHost = strtolower((string)parse_url($pub, PHP_URL_HOST));
    foreach (rows("SELECT id, base_url, inform_url, omadac_id FROM hs_controllers") as $c) {
        if (OmadaRelay::isCloudHost((string)parse_url((string)$c['base_url'], PHP_URL_HOST))) continue;
        $base = omadaControllerBase((string)$c['base_url']);
        if ($base === '') continue;
        $host = strtolower((string)parse_url($base, PHP_URL_HOST));
        $inf = parseInformUrl((string)$c['inform_url']);
        $inform = (string)$c['inform_url'];
        if (!$inf || $inf['host'] !== $host)
            $inform = 'omada://' . $host . '?dPort=29810&mPort=29814' . ((string)$c['omadac_id'] !== '' ? '&omadacId=' . $c['omadac_id'] : '');
        if ($base !== (string)$c['base_url'] || $inform !== (string)$c['inform_url'])
            run("UPDATE hs_controllers SET base_url=?, inform_url=?, access_token=NULL, token_expires=NULL, paths_json=NULL, last_error=NULL, direct_fail_at=NULL WHERE id=?",
                'ssi', $base, $inform, (int)$c['id']);
    }
    if ($pubHost !== '') {
        $cur = parseInformUrl(getSetting('omada_default_inform'));
        if (!$cur || $cur['host'] !== $pubHost) {
            $oid = (string)val("SELECT omadac_id FROM hs_controllers WHERE base_url LIKE ? AND omadac_id IS NOT NULL AND omadac_id<>'' ORDER BY id LIMIT 1", 's', 'https://' . $pubHost . ':%');
            $raw = 'omada://' . $pubHost . '?dPort=29810&mPort=29814' . ($oid !== '' ? '&omadacId=' . $oid : '');
            setSetting('omada_default_inform', $raw);
            run("UPDATE hs_controllers SET inform_url=? WHERE base_url LIKE ?", 'ss', $raw, 'https://' . $pubHost . ':%');   // keeps the default controller match
        }
    }
    try { run("DELETE FROM settings WHERE setting_key LIKE 'omada_relay:%'"); } catch (Throwable $e) {}   // v6.1.1 LAN relay list (removed)
    setSetting('schema_version', '13');
}
/**
 * v5.9 — OMADA RELAY (website side). Shared hosting usually cannot open connections to a self-hosted controller
 * (https://IP:8043, device port 29814). The request is written to hs_omada_jobs, the RADIUS box picks it up with a
 * long-poll (?radius=omada_jobs), calls the controller and posts the answer (?radius=omada_result). Header and body of
 * every job are sealed with APP_SECRET while they wait in the database; finished jobs are deleted at once.
 */
final class OmadaRelay
{
    /** The relay counts as running when it polled the website in the last 75 s. */
    static function alive(): bool {
        try { return (int)getSetting('omada_relay_seen', '0') > time() - 75; } catch (Throwable $e) { return false; }
    }
    static function info(): array {
        try { return json_decode(getSetting('omada_relay_info'), true) ?: []; } catch (Throwable $e) { return []; }
    }
    static function isCloudHost(string $host): bool { return (bool)preg_match('/(^|\.)tplinkcloud\.com$/i', $host); }
    /** Short "via RADIUS server (host)" label for messages. */
    static function label(): string {
        $i = self::info();
        return t('route_relay') . (($i['host'] ?? '') !== '' ? ' (' . $i['host'] . ')' : '');
    }
    /**
     * 'relay' or 'direct' for one controller row and URL.
     * auto: self-hosted controllers (an IP / own domain) always go through the RADIUS box when it is running; the TP-Link
     *       cloud goes direct, and through the relay for 30 minutes after a direct connection error.
     */
    static function routeFor(array $ctl, string $url): string {
        $mode = (string)($ctl['conn_mode'] ?? 'auto');
        if ($mode === 'direct') return 'direct';
        if ($mode === 'relay') return 'relay';
        if (!self::alive()) return 'direct';
        $host = (string)parse_url($url, PHP_URL_HOST);
        if (!self::isCloudHost($host)) return 'relay';
        if (!empty($ctl['direct_fail_at']) && strtotime((string)$ctl['direct_fail_at']) > time() - 1800) return 'relay';
        return 'direct';
    }
    /** The route a controller uses for its API address (for badges and messages). */
    static function routeOf(array $ctl): string { return self::routeFor($ctl, (string)($ctl['base_url'] ?? '')); }

    /** "via RADIUS server (host)" — kept for the messages that name the relay. */
    static function labelFor(string $host): string { return self::label(); }

    /** Sleep without usleep() on hosts that disable it: MySQL DO SLEEP() always works. */
    private static function nap(int $ms): void {
        if (canCall('usleep')) { usleep($ms * 1000); return; }
        try { db()->query('DO SLEEP(' . number_format($ms / 1000, 3, '.', '') . ')'); } catch (Throwable $e) {}
    }

    /** Queue a job and wait for the RADIUS box. Returns the finished row (decrypted body) or ['error' => ...]. */
    private static function submit(array $job, int $timeout, int $ctlId = 0): array {
        if (!self::alive()) return ['res_code' => 0, 'res_body' => '', 'res_error' => t('relay_down')];
        $wait = $timeout + 8;
        if (OmadaApi::$deadline !== null) $wait = min($wait, (int)floor(OmadaApi::$deadline - microtime(true)));
        if ($wait < 3) return ['res_code' => 0, 'res_body' => '', 'res_error' => 'time limit of this request reached'];
        extendTimeLimit($wait + 15);
        q("INSERT INTO hs_omada_jobs (ctrl_id,kind,method,url,host,port,headers,body,timeout_s,verify_ssl) VALUES (?,?,?,?,?,?,?,?,?,?)", 'issssissii',
            $ctlId ?: null, $job['kind'], $job['method'] ?? 'GET', substr((string)($job['url'] ?? ''), 0, 1024), $job['host'] ?? null, $job['port'] ?? null,
            sealSecret((string)json_encode($job['headers'] ?? [], JSON_UNESCAPED_SLASHES)), isset($job['body']) ? sealSecret((string)$job['body']) : null,
            $timeout, !empty($job['verify_ssl']) ? 1 : 0);
        $id = (int)db()->insert_id;
        $end = microtime(true) + $wait;
        $n = 0;
        while (microtime(true) < $end) {
            self::nap($n++ < 10 ? 100 : 200);
            $r = row("SELECT status, res_code, res_body, res_error, res_ms FROM hs_omada_jobs WHERE id=?", 'i', $id);
            if (!$r) break;
            if ($r['status'] === 'done') {
                run("DELETE FROM hs_omada_jobs WHERE id=?", 'i', $id);
                $r['res_body'] = $r['res_body'] !== null ? openSecret($r['res_body']) : '';
                return $r;
            }
        }
        $st = (string)val("SELECT status FROM hs_omada_jobs WHERE id=?", 'i', $id);
        run("DELETE FROM hs_omada_jobs WHERE id=?", 'i', $id);
        return ['res_code' => 0, 'res_body' => '', 'res_error' => $st === 'pending' ? t('relay_not_taken') : t('relay_timeout')];
    }

    /** HTTP request through the RADIUS box. Same return shape as OmadaApi::http(): [code, json|null, error, raw]. */
    static function http(string $method, string $url, array $headers, ?string $body, int $timeout, bool $verify, int $ctlId = 0): array {
        $r = self::submit(['kind' => 'http', 'method' => $method, 'url' => $url, 'headers' => $headers, 'body' => $body, 'verify_ssl' => $verify], $timeout, $ctlId);
        $raw = (string)($r['res_body'] ?? '');
        $err = (string)($r['res_error'] ?? '');
        $json = $raw !== '' ? json_decode($raw, true) : null;
        if ($err !== '') {
            $err = '[' . t('route_relay') . '] ' . $err;
        }
        return [(int)($r['res_code'] ?? 0), is_array($json) ? $json : null, $err, $raw];
    }

    /** TCP connect test from the RADIUS box. ['ok' => bool|null, 'msg' => error text, 'ms' => int]. */
    static function tcp(string $host, int $port, int $timeout = 6): array {
        $r = self::submit(['kind' => 'tcp', 'host' => $host, 'port' => $port], $timeout);
        $err = (string)($r['res_error'] ?? '');
        if ($err === t('relay_down')) return ['ok' => null, 'msg' => $err, 'ms' => 0];
        return ['ok' => $err === '' && (int)($r['res_code'] ?? 0) === 1, 'msg' => $err, 'ms' => (int)($r['res_ms'] ?? 0)];
    }

    // ---------------------------------------------------------------- endpoints for the RADIUS box (Radius::handle)
    /** Long-poll: hand out pending jobs (or wait up to "wait" seconds for one). */
    static function jobs(array $b): void {
        setSetting('omada_relay_seen', (string)time());
        $rel = is_array($b['relay'] ?? null) ? $b['relay'] : [];
        if ($rel) setSetting('omada_relay_info', (string)json_encode($rel + ['ip' => clientIp(), 'at' => date('c')], JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
        $wait = max(0, min(25, (int)($b['wait'] ?? 0)));
        extendTimeLimit($wait + 20);
        if (function_exists('ignore_user_abort')) @ignore_user_abort(false);
        // a job nobody answered within 2 minutes is dead (its waiter gave up) — never execute it late
        run("UPDATE hs_omada_jobs SET status='expired' WHERE status='pending' AND created_at < DATE_SUB(NOW(), INTERVAL 2 MINUTE)");
        $end = microtime(true) + $wait;
        $beat = time();
        do {
            $cands = rows("SELECT id FROM hs_omada_jobs WHERE status='pending' ORDER BY id LIMIT 10");
            if ($cands) {
                $claim = bin2hex(random_bytes(12));
                $taken = 0;
                foreach ($cands as $c) {
                    $taken += run("UPDATE hs_omada_jobs SET status='taken', claim=?, taken_at=NOW() WHERE id=? AND status='pending'", 'si', $claim, (int)$c['id']);
                }
                if ($taken > 0) {
                    $out = [];
                    foreach (rows("SELECT * FROM hs_omada_jobs WHERE claim=? ORDER BY id", 's', $claim) as $j) {
                        $hdr = json_decode(openSecret($j['headers']), true);
                        $out[] = ['id' => (int)$j['id'], 'kind' => $j['kind'], 'method' => $j['method'], 'url' => $j['url'], 'host' => (string)$j['host'],
                            'port' => (int)$j['port'], 'headers' => is_array($hdr) ? array_values($hdr) : [], 'body' => $j['body'] !== null ? openSecret($j['body']) : null,
                            'timeout' => (int)$j['timeout_s'], 'verify_ssl' => (int)$j['verify_ssl']];
                    }
                    jsonOut(['ok' => true, 'jobs' => $out]);
                }
            }
            if (time() - $beat >= 10) { setSetting('omada_relay_seen', (string)time()); $beat = time(); }
            if (microtime(true) >= $end) break;
            self::nap(250);
        } while (connection_status() === CONNECTION_NORMAL);
        jsonOut(['ok' => true, 'jobs' => []]);
    }

    /** Answer of one job from the RADIUS box. */
    static function result(array $b): void {
        $id = (int)($b['id'] ?? 0);
        $body = (string)($b['body'] ?? '');
        if (!empty($b['b64'])) $body = (string)base64_decode($body);
        run("UPDATE hs_omada_jobs SET status='done', done_at=NOW(), res_code=?, res_body=?, res_error=?, res_ms=?, headers=NULL, body=NULL WHERE id=? AND status='taken'", 'issii',
            (int)($b['code'] ?? 0), sealSecret($body), substr((string)($b['error'] ?? ''), 0, 500), (int)($b['ms'] ?? 0), $id);
        setSetting('omada_relay_seen', (string)time());
        jsonOut(['ok' => true]);
    }

    /** Hosts / ports the RADIUS box --test checks (no secrets). */
    static function targets(): void {
        $out = []; $seen = [];
        foreach (rows("SELECT name, base_url, inform_url, ctype FROM hs_controllers ORDER BY id LIMIT 200") as $c) {
            $b = parse_url((string)$c['base_url']);
            if ($b && !empty($b['host'])) {
                $port = (int)($b['port'] ?? (strtolower((string)($b['scheme'] ?? 'https')) === 'https' ? 443 : 80));
                $k = strtolower($b['host']) . ':' . $port;
                if (!isset($seen[$k])) { $seen[$k] = 1; $out[] = ['label' => 'Omada Open API (' . $c['name'] . ')', 'host' => $b['host'], 'port' => $port,
                    'hint' => 'open TCP ' . $port . ' on the controller VPS firewall (ufw allow ' . $port . '/tcp) and check the Omada service is running'];}
            }
            $inf = parseInformUrl((string)$c['inform_url']);
            if ($inf && $inf['m_port'] > 0) {
                $k = $inf['host'] . ':' . $inf['m_port'];
                if (!isset($seen[$k])) { $seen[$k] = 1; $out[] = ['label' => 'Omada device port (EAP225 → controller)', 'host' => $inf['host'], 'port' => $inf['m_port'],
                    'hint' => 'the EAP225 must reach TCP 29811-29817 + UDP 29810 on the controller (open them in the VPS firewall: ufw allow 29810:29817/tcp ; ufw allow 29810/udp)']; }
            }
        }
        jsonOut(['ok' => true, 'targets' => array_slice($out, 0, 20)]);
    }
}
/** Router models offered under Routers → Add router. */
final class RouterModels {
    const DEFAULT_CODE = 'omada-eap225';
    static function all(): array {
        try { return rows("SELECT * FROM hs_router_models ORDER BY sort_order, id"); } catch (Throwable $e) { return []; }
    }
    static function byCode(string $code): ?array {
        if ($code === '') return null;
        try { return row("SELECT * FROM hs_router_models WHERE code=? AND is_active=1", 's', $code); } catch (Throwable $e) { return null; }
    }
    static function byId(int $id): ?array {
        if ($id <= 0) return null;
        try { return row("SELECT * FROM hs_router_models WHERE id=?", 'i', $id); } catch (Throwable $e) { return null; }
    }
    static function forDevice(array $d): array {
        return self::byId((int)($d['router_model_id'] ?? 0)) ?: self::byCode(self::DEFAULT_CODE)
            ?: ['id' => 0, 'code' => self::DEFAULT_CODE, 'brand' => 'TP-Link Omada', 'model' => 'EAP225', 'description' => '', 'icon' => 'wifi', 'is_active' => 1];
    }
    static function label(array $m): string { return trim($m['brand'] . ' ' . $m['model']); }
    /** Remember which model a router is (needs the v9 column; ignored if the upgrade has not run yet). */
    static function assign(int $deviceId, array $m): void {
        try { run("UPDATE hs_devices SET router_model_id=?, model=? WHERE id=?", 'isi', (int)$m['id'] ?: null, substr((string)$m['model'], 0, 50), $deviceId); }
        catch (Throwable $e) { error_log('RouterModels::assign: ' . $e->getMessage()); }
    }
}
/** History of provisioning / connection steps per router (Hotspot menu). */
final class ProvisionLog {
    /** $dedupe: skip when the last entry of this action for the router already had the same phase (in the last 30 min). */
    static function add(int $deviceId, int $uid, string $action, string $phase = '', string $msg = '', bool $dedupe = false): void {
        try {
            if ($dedupe) {
                $last = row("SELECT phase, created_at FROM hs_provision_runs WHERE device_id=? AND action=? ORDER BY id DESC LIMIT 1", 'is', $deviceId, $action);
                if ($last && (string)$last['phase'] === $phase && strtotime($last['created_at']) > time() - 1800) return;
            }
            q("INSERT INTO hs_provision_runs (device_id,user_id,action,phase,message) VALUES (?,?,?,?,?)", 'iisss',
                $deviceId, $uid, substr($action, 0, 30), substr($phase, 0, 30), substr($msg, 0, 500));
        } catch (Throwable $e) { error_log('ProvisionLog: ' . $e->getMessage()); }
    }
    static function forDevice(int $deviceId, int $limit = 12): array {
        try { return rows("SELECT * FROM hs_provision_runs WHERE device_id=? ORDER BY id DESC LIMIT ?", 'ii', $deviceId, $limit); } catch (Throwable $e) { return []; }
    }
    static function forUser(int $uid, int $limit = 15): array {
        try { return rows("SELECT r.*, d.device_name FROM hs_provision_runs r JOIN hs_devices d ON d.id=r.device_id WHERE r.user_id=? ORDER BY r.id DESC LIMIT ?", 'ii', $uid, $limit); }
        catch (Throwable $e) { return []; }
    }
}
/**
 * Can the Omada device port named in an Inform URL be reached? (TCP connect, a few seconds.)
 * v5.9: for a self-hosted controller (or when $ctl routes through the relay) the test runs FROM THE RADIUS SERVER,
 * because shared hosting blocks outgoing connections to ports like 29814 — that block is not a controller problem.
 * Returns ['ok' => true|false|null, 'msg' => text, 'via' => 'relay'|'direct'|'']; null = not checked.
 */
function omadaCloudReach(string $inform, ?array $ctl = null): array {
    $inf = parseInformUrl($inform);
    if (!$inf) return ['ok' => null, 'msg' => t('cloud_not_checked'), 'via' => ''];
    $port = $inf['m_port'] > 0 && $inf['m_port'] < 65536 ? $inf['m_port'] : 443;
    return omadaPortReach($inf['host'], $port, $ctl, $inf['cloud'] ? 'cloud' : 'device');
}
/** TCP reachability of host:port — through the RADIUS box (relay) or from this website. $what: cloud | device | api. */
function omadaPortReach(string $host, int $port, ?array $ctl, string $what = 'device'): array {
    $target = $host . ':' . $port;
    $useRelay = OmadaRelay::alive() && ($ctl ? OmadaRelay::routeFor($ctl, 'https://' . $target) === 'relay' : !OmadaRelay::isCloudHost($host));
    $okKey = $what === 'cloud' ? 'cloud_ok' : ($what === 'api' ? 'ctrl_api_port_ok' : 'ctrl_dev_port_ok');
    $failKey = $what === 'cloud' ? 'cloud_fail' : ($what === 'api' ? 'ctrl_api_port_fail' : 'ctrl_dev_port_fail');
    if ($useRelay) {
        $r = OmadaRelay::tcp($host, $port, 6);
        if ($r['ok'] === true) return ['ok' => true, 'msg' => t($okKey) . ' (' . $target . ') — ' . OmadaRelay::labelFor($host) . ', ' . $r['ms'] . ' ms', 'via' => 'relay'];
        if ($r['ok'] === false) return ['ok' => false, 'msg' => t($failKey) . ' (' . $target . ': ' . $r['msg'] . ') — ' . OmadaRelay::labelFor($host)
            . ($what === 'device' ? '. ' . t('ctrl_dev_port_hint') : ($what === 'api' ? '. ' . t('ctrl_api_port_hint') : '')), 'via' => 'relay'];
        // relay could not run the test → fall through to a direct test
    }
    $f = null; $en = 0; $es = '';
    if (canCall('fsockopen')) $f = @fsockopen($host, $port, $en, $es, 5);
    elseif (canCall('stream_socket_client')) $f = @stream_socket_client('tcp://' . $target, $en, $es, 5);
    else return ['ok' => null, 'msg' => t('cloud_not_checked'), 'via' => ''];
    if ($f) { fclose($f); return ['ok' => true, 'msg' => t($okKey) . ' (' . $target . ') — ' . t('route_direct'), 'via' => 'direct']; }
    $msg = t($failKey) . ' (' . $target . ($es !== '' ? ': ' . $es : '') . ') — ' . t('route_direct');
    if (!OmadaRelay::isCloudHost($host)) {
        // from shared hosting this is usually the host's firewall, not the controller: say so and point to the relay
        return ['ok' => null, 'msg' => $msg . '. ' . (OmadaRelay::alive() ? t('relay_hint_direct') : t('relay_hint_start')), 'via' => 'direct'];
    }
    return ['ok' => false, 'msg' => $msg, 'via' => 'direct'];
}
/**
 * Omada Central / Cloud device "Inform URL", e.g.
 *   omada://euw1-omada-essential-device.tplinkcloud.com?dPort=29810&mPort=443&omadacId=ffff16ace7700dc406242365ce708
 * Returns its parts plus the regional Open API address ("Interface Access Address"), or null when nothing usable is in it.
 * Region prefix → Open API host: aps1 (Singapore) / euw1 (Europe) / use1 (US) → https://{region}-omada-northbound.tplinkcloud.com
 */
function parseInformUrl(string $u): ?array {
    $raw = trim($u);
    if ($raw === '' || strlen($raw) > 512 || preg_match('/[\s"<>]/', $raw)) return null;
    $full = preg_match('#^[a-z][a-z0-9+.\-]*://#i', $raw) ? $raw : 'omada://' . $raw;
    $p = parse_url($full);
    if (!$p || empty($p['host'])) return null;
    $host = strtolower((string)$p['host']);
    if (!preg_match('/^[a-z0-9.\-]+$/', $host)) return null;
    $qs = [];
    parse_str((string)($p['query'] ?? ''), $qs);
    $qs = array_change_key_case($qs, CASE_LOWER);
    $omadac = substr(preg_replace('/[^A-Za-z0-9]/', '', (string)($qs['omadacid'] ?? '')), 0, 64);
    $cloud = (bool)preg_match('/(^|\.)tplinkcloud\.com$/', $host);
    $region = preg_match('/^([a-z]{2,5}\d{1,2})-/', $host, $m) ? $m[1] : '';
    return ['raw' => $raw, 'scheme' => strtolower((string)($p['scheme'] ?? 'omada')), 'host' => $host,
        'd_port' => (int)($qs['dport'] ?? 29810), 'm_port' => (int)($qs['mport'] ?? ($cloud ? 443 : 29811)), 'omadac_id' => $omadac,
        'cloud' => $cloud, 'region' => $region, 'essentials' => strpos($host, 'essential') !== false,
        'api_base' => ($cloud && $region !== '') ? 'https://' . $region . '-omada-northbound.tplinkcloud.com' : ''];
}
/** Device / site passwords kept in the database are sealed with APP_SECRET (AES-256-GCM). */
function sealSecret(string $plain): string {
    if ($plain === '') return '';
    if (!function_exists('openssl_encrypt')) return 'p:' . base64_encode($plain);
    $iv = random_bytes(12); $tag = '';
    $c = openssl_encrypt($plain, 'aes-256-gcm', hash('sha256', 'seal|' . APP_SECRET, true), OPENSSL_RAW_DATA, $iv, $tag);
    return $c === false ? 'p:' . base64_encode($plain) : 'v1:' . base64_encode($iv . $tag . $c);
}
function openSecret(?string $s): string {
    $s = (string)$s;
    if ($s === '') return '';
    if (strncmp($s, 'p:', 2) === 0) return (string)base64_decode(substr($s, 2));
    if (strncmp($s, 'v1:', 3) !== 0 || !function_exists('openssl_decrypt')) return $s;
    $b = (string)base64_decode(substr($s, 3));
    if (strlen($b) < 29) return '';
    foreach (array_unique([APP_SECRET, APP_SECRET_LEGACY]) as $sec) {   // v5.7.1: a changed APP_SECRET still opens old values
        $p = openssl_decrypt(substr($b, 28), 'aes-256-gcm', hash('sha256', 'seal|' . $sec, true), OPENSSL_RAW_DATA, substr($b, 0, 12), substr($b, 12, 16));
        if ($p !== false) return $p;
    }
    return '';
}
/** Strong password accepted by Omada site device accounts (10-64 chars, upper + lower + digit + symbol, no repeated neighbours). */
function genDevicePassword(int $len = 14): string {
    $sets = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnpqrstuvwxyz', '23456789', '!#$%&*@^'];
    for ($try = 0; $try < 50; $try++) {
        $chars = [];
        foreach ($sets as $s) $chars[] = $s[random_int(0, strlen($s) - 1)];
        $all = implode('', $sets);
        while (count($chars) < $len) $chars[] = $all[random_int(0, strlen($all) - 1)];
        for ($i = count($chars) - 1; $i > 0; $i--) { $j = random_int(0, $i); [$chars[$i], $chars[$j]] = [$chars[$j], $chars[$i]]; }
        $p = implode('', $chars);
        if (!preg_match('/(.)\1/', $p)) return $p;
    }
    return 'Sky#' . bin2hex(random_bytes(5)) . 'Wz7';
}
/**
 * v5.7.1 — what is still insecure on this installation. Returns rows [level danger|warning|info, message, config line or ''].
 * Never prints a secret value.
 */
function securityIssues(): array {
    $out = [];
    $hasCfg = is_file(__DIR__ . '/config.local.php');
    if (!$hasCfg) $out[] = ['danger', 'config.local.php is missing next to index.php — every secret below is using its built-in default.', ''];
    $weak = [
        'APP_SECRET' => APP_SECRET === APP_SECRET_LEGACY || strlen((string)APP_SECRET) < 24,
        'RADIUS_API_KEY' => radiusApiKeyWeak(),
        'CRON_SECRET' => CRON_SECRET === 'cron-secret-change-me' || strlen((string)CRON_SECRET) < 16,
        'PAYMENT_WEBHOOK_SECRET' => PAYMENT_WEBHOOK_SECRET === 'webhook-secret-change-me' || strlen((string)PAYMENT_WEBHOOK_SECRET) < 16,
    ];
    $why = [
        'APP_SECRET' => 'protects saved EAP225 / Omada site logins (old ones keep working after you change it)',
        'RADIUS_API_KEY' => 'lets the RADIUS box talk to this website — use the SAME value on the VPS',
        'CRON_SECRET' => 'protects ?cron=run — update your cPanel cron URL after changing it',
        'PAYMENT_WEBHOOK_SECRET' => 'protects the mobile-money payment callback',
    ];
    foreach ($weak as $k => $bad) if ($bad)
        $out[] = [$k === 'RADIUS_API_KEY' || $k === 'APP_SECRET' ? 'danger' : 'warning', $k . ' is still the default / too short — it ' . $why[$k] . '.',
            "define('$k', '" . bin2hex(random_bytes(24)) . "');"];
    try {
        $hash = (string)val("SELECT password FROM users WHERE username='admin' AND user_type='admin' LIMIT 1");
        if ($hash !== '' && password_verify('Admin@123', $hash)) $out[] = ['danger', 'The "admin" account still uses the factory password Admin@123 — change it now under Profile → Change Password.', ''];
    } catch (Throwable $e) {}
    if (sonicApiKey() === '')
        $out[] = ['info', 'The Sonic Pesa API key is not set, so portal mobile-money push and seller withdrawals are switched off. Paste it under Admin → Platform settings, or add it to config.local.php.',
            "define('SONIC_PESA_API_KEY', 'sk_live_...');\ndefine('SONIC_PESA_API_SECRET', '...');"];
    if (stripos(appUrl(), 'https://') !== 0) $out[] = ['warning', 'The website is not served over HTTPS — logins, vouchers and the RADIUS API travel unencrypted.', ''];
    return $out;
}
/** Bootstrap-styled list of security issues (admin pages). */
function securityPanel(array $issues): string {
    if (!$issues) return '<div class="alert alert-success small mb-3"><i class="fa-solid fa-shield-halved me-2"></i>Security check: everything is configured.</div>';
    $lines = []; $o = '';
    foreach ($issues as [$lvl, $msg, $cfgLine]) {
        $o .= '<div class="d-flex gap-2 py-2 border-bottom border-secondary-subtle small"><i class="fa-solid fa-' . ($lvl === 'danger' ? 'circle-xmark text-danger' : ($lvl === 'warning' ? 'triangle-exclamation text-warning' : 'circle-info text-info'))
            . ' mt-1"></i><span>' . h($msg) . '</span></div>';
        if ($cfgLine !== '') $lines[] = $cfgLine;
    }
    $kit = $lines ? "<?php\n// Add these lines to config.local.php (same folder as index.php). Keep any lines you already have.\n" . implode("\n", $lines) . "\n" : '';
    return '<div class="card mb-3 border-danger-subtle"><div class="card-header"><i class="fa-solid fa-shield-halved me-2"></i>Security check (' . count($issues) . ')</div><div class="card-body">'
        . $o . ($kit !== '' ? '<div class="d-flex justify-content-between align-items-center mt-3 mb-1"><b class="small text-body-emphasis">Ready-to-paste lines (new random values on every page load)</b>'
        . '<button type="button" class="btn btn-sm btn-outline-primary" onclick="cp(\'secKit\',this)"><i class="fa-regular fa-copy"></i></button></div><pre class="kit" id="secKit">' . h($kit) . '</pre>' : '')
        . '</div></div>';
}
function rateLimitCheck(string $identifier, string $action, int $max = 5, int $window = 300): bool {
    $identifier = substr($identifier, 0, 100);
    $r = row("SELECT id, attempts, window_start FROM rate_limits WHERE identifier=? AND action=?", 'ss', $identifier, $action);
    if (!$r) { q("INSERT IGNORE INTO rate_limits (identifier, action, attempts, window_start) VALUES (?,?,1,NOW())", 'ss', $identifier, $action); return true; }
    if (time() - strtotime($r['window_start']) > $window) { run("UPDATE rate_limits SET attempts=1, window_start=NOW() WHERE id=?", 'i', $r['id']); return true; }
    if ((int)$r['attempts'] >= $max) return false;
    run("UPDATE rate_limits SET attempts=attempts+1 WHERE id=?", 'i', $r['id']);
    return true;
}

// ============================================================
// NOTIFICATIONS / ACTIVITY
// ============================================================
class Notify {
    static function add(int $uid, string $title, string $msg, string $type = 'info', ?string $link = null, ?string $icon = null): void {
        q("INSERT INTO notifications (user_id,title,message,type,link,icon) VALUES (?,?,?,?,?,?)", 'isssss', $uid, $title, $msg, $type, $link, $icon);
    }
    static function unread(int $uid): int { return (int)val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0", 'i', $uid); }
    static function list(int $uid, int $limit = 50): array { return rows("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT ?", 'ii', $uid, $limit); }
    static function readAll(int $uid): void { run("UPDATE notifications SET is_read=1, read_at=NOW() WHERE user_id=? AND is_read=0", 'i', $uid); }
}
function logActivity(?int $uid, string $action, string $desc): void {
    q("INSERT INTO activity_logs (user_id,action,description,ip_address,user_agent) VALUES (?,?,?,?,?)", 'issss',
        $uid, $action, $desc, clientIp(), substr($_SERVER['HTTP_USER_AGENT'] ?? 'cli', 0, 500));
}

// ============================================================
// AUTH
// ============================================================
class Auth {
    function login(string $username, string $password): bool {
        $u = row("SELECT * FROM users WHERE (username=? OR email=? OR phone=?) AND status='active' LIMIT 1", 'sss', $username, $username, $username);
        if (!$u || !password_verify($password, $u['password'])) return false;
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$u['id'];
        $_SESSION['username'] = $u['username'];
        $_SESSION['user_type'] = $u['user_type'];
        $_SESSION['full_name'] = $u['full_name'];
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();
        run("UPDATE users SET last_login=NOW() WHERE id=?", 'i', $u['id']);
        if (password_needs_rehash($u['password'], PASSWORD_DEFAULT)) run("UPDATE users SET password=? WHERE id=?", 'si', password_hash($password, PASSWORD_DEFAULT), $u['id']);
        logActivity((int)$u['id'], 'login', 'User logged in');
        return true;
    }
    function register(array $d): array {
        if (row("SELECT id FROM users WHERE username=? OR email=? OR phone=?", 'sss', $d['username'], $d['email'], $d['phone']))
            return ['success' => false, 'message' => 'Username, email or phone already exists'];
        $hash = password_hash($d['password'], PASSWORD_DEFAULT);
        $ref = strtoupper(bin2hex(random_bytes(4)));
        q("INSERT INTO users (username,email,phone,password,full_name,user_type,referral_code) VALUES (?,?,?,?,?,'seller',?)",
            'ssssss', $d['username'], $d['email'], $d['phone'], $hash, $d['full_name'], $ref);
        $uid = db()->insert_id;
        session_regenerate_id(true);
        $_SESSION['user_id'] = $uid; $_SESSION['username'] = $d['username']; $_SESSION['user_type'] = 'seller';
        $_SESSION['full_name'] = $d['full_name']; $_SESSION['logged_in'] = true; $_SESSION['login_time'] = time();
        logActivity($uid, 'register', 'Seller registered');
        Notify::add($uid, 'Welcome', 'Step 1: Routers → Add router (Omada EAP225). Step 2: Hotspot → Provision & connect. Step 3: create packages and vouchers.', 'success', '?page=routers&add=1', 'wifi');
        return ['success' => true];
    }
    function isLoggedIn(): bool { return !empty($_SESSION['logged_in']); }
    function requireLogin(): void {
        if (!$this->isLoggedIn()) redirectTo('?page=login');
        if (time() - ($_SESSION['login_time'] ?? 0) > SESSION_TIMEOUT) { $this->logout(); redirectTo('?page=login&timeout=1'); }
        $_SESSION['login_time'] = time();
    }
    function requireSeller(): void { $this->requireLogin(); if (!in_array($_SESSION['user_type'], ['seller', 'admin'], true)) redirectTo('?page=dashboard'); }
    function requireAdmin(): void { $this->requireLogin(); if ($_SESSION['user_type'] !== 'admin') redirectTo('?page=dashboard'); }
    function isAdmin(): bool { return ($_SESSION['user_type'] ?? '') === 'admin'; }
    function logout(): void {
        if (isset($_SESSION['user_id'])) logActivity((int)$_SESSION['user_id'], 'logout', 'User logged out');
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
    }
    function user(): ?array { return isset($_SESSION['user_id']) ? row("SELECT * FROM users WHERE id=?", 'i', $_SESSION['user_id']) : null; }
}

// ============================================================
// DEVICES (Omada EAP225 only) — each one owns its RADIUS passwords; its NAS ID is the one Omada sends
// ============================================================
class Device {
    static function forSeller(int $uid): array {
        return rows("SELECT d.*, (SELECT COUNT(*) FROM hs_sessions s WHERE s.device_id=d.id AND s.status='active') AS active_sessions
                     FROM hs_devices d WHERE d.user_id=? ORDER BY d.created_at DESC", 'i', $uid);
    }
    static function get(int $id, ?int $uid = null): ?array {
        return $uid ? row("SELECT * FROM hs_devices WHERE id=? AND user_id=?", 'ii', $id, $uid) : row("SELECT * FROM hs_devices WHERE id=?", 'i', $id);
    }
    static function byApMac(string $mac): ?array { return $mac === '' ? null : row("SELECT * FROM hs_devices WHERE ap_mac=? AND is_active=1", 's', $mac); }
    /** The router that owns an internal hotspot key (any status — the caller decides), with its seller's account status. */
    static function byNasId(string $nas): ?array {
        $nas = strtoupper(trim($nas));
        if ($nas === '' || strlen($nas) > 32) return null;
        return row("SELECT d.*, u.status AS seller_status FROM hs_devices d JOIN users u ON u.id=d.user_id WHERE d.nas_id=? LIMIT 1", 's', $nas);
    }
    /** The router whose saved Omada NAS ID equals what Omada sent (only when exactly one router uses it). */
    static function byOmadaNas(string $nas): ?array {
        $nas = trim($nas);
        if ($nas === '' || strlen($nas) > 64) return null;
        $r = rows("SELECT d.*, u.status AS seller_status FROM hs_devices d JOIN users u ON u.id=d.user_id WHERE UPPER(d.omada_nas_id)=UPPER(?) LIMIT 2", 's', $nas);
        return count($r) === 1 ? $r[0] : null;
    }
    /** RADIUS server sends our hotspot key (nas_id) + the NAS ID Omada sent. Older RADIUS boxes send only one of them. */
    static function find(string $key, string $omadaNas): ?array {
        return self::byNasId($key) ?: self::byNasId($omadaNas) ?: self::byOmadaNas($omadaNas) ?: self::byOmadaNas($key);
    }
    /** Save the NAS-Identifier exactly as Omada sends it (the RADIUS server already proved the router by its password). */
    static function learnNas(array $d, string $nas): void {
        $nas = asciiClean(trim($nas), 64);
        if ($nas === '' || $nas === (string)($d['omada_nas_id'] ?? '')) return;
        run("UPDATE hs_devices SET omada_nas_id=?, nas_learned_at=NOW() WHERE id=?", 'si', $nas, $d['id']);
        Notify::add((int)$d['user_id'], 'NAS ID received from Omada', $d['device_name'] . ': ' . $nas, 'info', '?page=hotspot&id=' . (int)$d['id'], 'tower-broadcast');
    }
    /** RADIUS arrives per Omada portal. If the phone sits on another registered EAP225 of the same seller, use that EAP. */
    static function resolve(array $nasDev, string $apMac): array {
        if ($apMac !== '' && ($d = self::byApMac($apMac)) && (int)$d['user_id'] === (int)$nasDev['user_id']) return $d;
        return $nasDev;
    }
    /** Online = RADIUS traffic in the last 10 min OR the Omada controller reported the AP CONNECTED in its last sync. */
    static function isOnline(?array $d): bool {
        if (!$d) return false;
        if (!empty($d['last_seen']) && (time() - strtotime($d['last_seen'])) < 600) return true;
        return self::omadaConnected($d);
    }
    static function omadaConnected(?array $d): bool {
        return $d && ($d['omada_status'] ?? '') === 'connected' && !empty($d['omada_status_at']) && (time() - strtotime($d['omada_status_at'])) < max(900, (int)OMADA_SYNC_EVERY * 4);
    }
    /** "http://192.168.0.10:8088/anything" or "192.168.0.10:8088" → "http://192.168.0.10:8088" ('' when not a URL). */
    static function normalizeOrigin(string $u, string $defaultScheme = 'http'): string {
        $u = trim($u);
        if ($u === '') return '';
        if (!preg_match('#^[a-z]+://#i', $u)) $u = $defaultScheme . '://' . $u;
        $p = parse_url($u);
        if (!$p || empty($p['host']) || !in_array(strtolower($p['scheme'] ?? ''), ['http', 'https'], true)) return '';
        if (!preg_match('/^[A-Za-z0-9.\-]+$/', $p['host'])) return '';
        return strtolower($p['scheme']) . '://' . strtolower($p['host']) . (isset($p['port']) ? ':' . (int)$p['port'] : '');
    }
    static function touch(int $id, string $nasIp = ''): void {
        run("UPDATE hs_devices SET last_seen=NOW(), nas_ip=IF(?<>'', ?, nas_ip) WHERE id=?", 'ssi', $nasIp, $nasIp, $id);
    }
    static function touchRadius(int $id, string $srcIp, string $nasIp, bool $isAuth): void {
        run("UPDATE hs_devices SET last_seen=NOW(), radius_src_ip=IF(?<>'', ?, radius_src_ip), nas_ip=IF(?<>'', ?, nas_ip)"
            . ($isAuth ? ', radius_last_auth=NOW()' : '') . " WHERE id=?", 'ssssi', $srcIp, $srcIp, $nasIp, $nasIp, $id);
    }
    static function newNasId(): string {
        for ($i = 0; $i < 20; $i++) { $id = 'SKY' . genCode(9); if (!val("SELECT 1 FROM hs_devices WHERE nas_id=?", 's', $id)) return $id; }
        return 'SKY' . strtoupper(bin2hex(random_bytes(6)));
    }
    /** Fill in any missing hotspot key / passwords (new devices and devices from v4). Never changes existing values. */
    static function ensureCredentials(int $id): void {
        $d = row("SELECT nas_id, radius_secret, acct_secret FROM hs_devices WHERE id=?", 'i', $id);
        if (!$d) return;
        run("UPDATE hs_devices SET nas_id=?, radius_secret=?, acct_secret=?, secrets_rotated_at=COALESCE(secrets_rotated_at, NOW()) WHERE id=?", 'sssi',
            $d['nas_id'] ?: self::newNasId(), $d['radius_secret'] ?: genSecret(), $d['acct_secret'] ?: genSecret(), $id);
    }
    /** New Authentication + Accounting passwords (hotspot key and Omada NAS ID stay the same). */
    static function rotateSecrets(int $id, int $uid): bool {
        return run("UPDATE hs_devices SET radius_secret=?, acct_secret=?, secrets_rotated_at=NOW() WHERE id=? AND user_id=?", 'ssii', genSecret(), genSecret(), $id, $uid) === 1;
    }
    static function save(array $in, int $uid, ?int $id = null): array {
        $mac = normMac($in['ap_mac'] ?? '');
        $name = trim($in['device_name'] ?? '');
        if ($name === '' || $mac === '') return ['success' => false, 'message' => 'Device name and a valid AP MAC (e.g. 50-C7-BF-11-22-33) are required'];
        // v5.3 FIX: accept "192.168.0.10:8088", full paths and trailing slashes — keep only scheme://host:port
        $ctrlIn = trim($in['controller_url'] ?? '');
        $ctrl = self::normalizeOrigin($ctrlIn);
        if ($ctrlIn !== '' && $ctrl === '') return ['success' => false, 'message' => 'Controller URL must look like http://192.168.0.10:8088'];
        $dae = trim($in['dae_target'] ?? '');
        if ($dae !== '' && !preg_match('/^\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?$/', $dae)) return ['success' => false, 'message' => 'Disconnect target must be an IP like 41.59.10.20 or 41.59.10.20:3799'];
        $omadaNas = trim((string)($in['omada_nas_id'] ?? ''));
        if ($omadaNas !== '' && (strlen($omadaNas) > 64 || preg_match('/[^\x20-\x7E]/', $omadaNas))) return ['success' => false, 'message' => t('nas_invalid')];
        $ctrlId = (int)($in['controller_id'] ?? 0);
        if ($ctrlId && !val("SELECT 1 FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $ctrlId, $uid)) $ctrlId = 0;
        $siteId = substr(preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($in['omada_site_id'] ?? '')), 0, 64);
        $f = [$name, $mac, trim($in['ssid'] ?? ''), trim($in['site_name'] ?? 'Default') ?: 'Default', $ctrl, trim($in['lipa_info'] ?? ''),
              trim($in['location'] ?? ''), $dae, $omadaNas !== '' ? $omadaNas : null, !empty($in['is_active']) ? 1 : 0,
              $ctrlId ?: null, $siteId !== '' ? $siteId : null];
        try {
            if ($id) {
                if (!val("SELECT 1 FROM hs_devices WHERE id=? AND user_id=?", 'ii', $id, $uid)) return ['success' => false, 'message' => 'Device not found'];
                run("UPDATE hs_devices SET device_name=?, ap_mac=?, ssid=?, site_name=?, controller_url=?, lipa_info=?, location=?, dae_target=?, omada_nas_id=?, is_active=?, controller_id=?, omada_site_id=? WHERE id=? AND user_id=?",
                    'sssssssssiisii', ...array_merge($f, [$id, $uid]));
            } else {
                q("INSERT INTO hs_devices (device_name, ap_mac, ssid, site_name, controller_url, lipa_info, location, dae_target, omada_nas_id, is_active, controller_id, omada_site_id, user_id, model) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'EAP225')",
                    'sssssssssiisi', ...array_merge($f, [$uid]));
                $id = (int)db()->insert_id;
            }
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) return ['success' => false, 'message' => 'This AP MAC is already registered.'];
            error_log('Device save: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Database error while saving the device: ' . $e->getMessage()];
        }
        self::ensureCredentials($id);
        return ['success' => true, 'id' => $id];
    }
    /** Everything the seller types into Omada for this EAP225 — passwords generated by the system, NAS ID as Omada sends it. */
    static function radiusConfig(array $d): array {
        $ip = getSetting('radius_server_ip');
        return [
            'server_ip' => $ip, 'auth_port' => (string)RADIUS_AUTH_PORT, 'auth_secret' => (string)$d['radius_secret'],
            'acct_ip' => getSetting('acct_server_ip') ?: $ip, 'acct_port' => (string)RADIUS_ACCT_PORT, 'acct_secret' => (string)$d['acct_secret'],
            'nas_id' => (string)($d['omada_nas_id'] ?? ''), 'key' => (string)$d['nas_id'], 'interim' => (string)(int)RADIUS_INTERIM, 'dae_port' => (string)RADIUS_DAE_PORT,
            'profile' => 'SkyRadius-' . (int)$d['id'], 'portal_name' => 'SkyPortal-' . (int)$d['id'],
            'portal_url' => portalUrl(),
        ];
    }
    /** Where the phone's browser must POST the voucher (Omada /portal/radius/browserauth). */
    static function authUrl(?array $dev, array $ctx): string {
        // v6.6.1 — ONE fixed HTTPS address with a valid certificate (https://omada.skytanzania.co.tz/portal/radius/browserauth).
        // The target / targetPort Omada sends (169.58.93.38:8843) and the controller IP are self-signed → "SSL certificate error"
        // on the phone, so they are only used when no fixed address is configured at all.
        $fixed = omadaPortalAuthUrl();
        if ($fixed !== '') return $fixed;
        $base = '';
        if ($dev && !empty($dev['controller_url'])) $base = self::normalizeOrigin((string)$dev['controller_url']);
        if ($base === '' && !empty($ctx['target']) && preg_match('/^[A-Za-z0-9.\-]+$/', $ctx['target'])) {
            // Omada tells the portal where its own portal service is (target / targetPort / scheme)
            $scheme = in_array($ctx['scheme'] ?? '', ['http', 'https'], true) ? $ctx['scheme'] : 'http';
            $port = (int)($ctx['targetPort'] ?? 0);
            $base = $scheme . '://' . $ctx['target'] . ($port ? ':' . $port : '');
        }
        if ($base === '' && $dev && !empty($dev['portal_target'])) $base = self::normalizeOrigin((string)$dev['portal_target']);   // v5.7: last target Omada sent
        if ($base === '' && getSetting('controller_url') !== '') $base = self::normalizeOrigin(getSetting('controller_url'));
        // v6.3 (from portal.php v6.5): browserauth lives on the Omada Controller PORTAL port — never on this website and never on
        // the management port 8043. Without these fallbacks a paid customer could not be connected automatically.
        if ($base !== '') {
            $bh = strtolower((string)parse_url($base, PHP_URL_HOST));
            $own = strtolower((string)parse_url(appUrl(), PHP_URL_HOST));
            if ($bh === '' || $bh === $own || $bh === strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')))) $base = '';
            elseif ((int)parse_url($base, PHP_URL_PORT) === 8043) $base = 'https://' . $bh . ':8843';
        }
        if ($base === '' && $dev && !empty($dev['controller_id'])) {
            $cb = (string)val("SELECT base_url FROM hs_controllers WHERE id=?", 'i', (int)$dev['controller_id']);
            $ch = strtolower((string)parse_url($cb, PHP_URL_HOST));
            if ($ch !== '' && !OmadaRelay::isCloudHost($ch)) $base = 'https://' . $ch . ':8843';
        }
        if ($base === '') {
            $ch = strtolower((string)parse_url((string)OMADA_CONTROLLER_URL, PHP_URL_HOST));
            if ($ch !== '') $base = 'https://' . $ch . ':8843';
        }
        return $base === '' ? '' : $base . '/portal/radius/browserauth';
    }
    /** Omada status → [label, bootstrap colour]. */
    static function omadaBadge(?string $s): array {
        return [
            'connected' => ['CONNECTED', 'success'], 'provisioning' => ['PROVISIONING', 'info'], 'pending' => ['PENDING', 'warning'],
            'adopting' => ['ADOPTING', 'info'], 'adopt_failed' => ['ADOPT FAILED', 'danger'], 'managed_by_others' => ['MANAGED BY OTHERS', 'danger'],
            'heartbeat_missed' => ['HEARTBEAT MISSED', 'warning'], 'isolated' => ['ISOLATED', 'warning'], 'disconnected' => ['DISCONNECTED', 'danger'],
            'not_found' => ['NOT IN CONTROLLER', 'secondary'],
        ][(string)$s] ?? ['—', 'secondary'];
    }
}

// ============================================================
// OMADA CONTROLLER — official Omada Open API (Client Credentials mode)
// Works with Omada Software Controller, OC200/OC300 hardware controllers and the Cloud-Based Controller.
// In Omada: Global View → Settings → Platform Integration → Open API → Add New App → Mode "Client",
// role with device management rights → copy Omada ID, Client ID, Client Secret and the Interface Access Address.
//   GET  {base}/api/info                                         → omadacId, controller version (no auth)
//   POST {base}/openapi/authorize/token?grant_type=client_credentials  {omadacId, client_id, client_secret}
//   Authorization: AccessToken=<token>   on every /openapi/v1/{omadacId}/... call
// Endpoint paths are checked against the controller's own OpenAPI spec ({base}/v3/api-docs/...) when it is reachable.
//
// v5.4 — OMADA CENTRAL / CLOUD: the device Inform URL (omada://<region>-omada-...-device.tplinkcloud.com?...&omadacId=...)
// gives the Omada ID and the region; the Open API lives at https://<region>-omada-northbound.tplinkcloud.com
// (aps1 = Singapore, euw1 = Europe, use1 = US). Paths used by the auto-setup (Omada Open API v1, cloud spec):
//   POST /sites                                         create site (name, region, timeZone, scenario, deviceAccountSetting)
//   GET  /scenarios                                     scenario names for a new site
//   POST /sites/{siteId}/multi-devices/sn-add           add EAP by serial number  → operateId
//   GET  /sites/{siteId}/multi-devices/add/{operateId}/status
//   POST /sites/{siteId}/devices/{mac}/start-adopt      adopt a PENDING EAP; GET .../adopt-result
//   GET/POST /sites/{siteId}/wireless-network/wlans[/{wlanId}/ssids]     WLAN group + SSID
//   GET/POST/PATCH /sites/{siteId}/profiles/radius[/{id}]                RADIUS profile (this server)
//   GET /sites/{siteId}/portals · POST /sites/{siteId}/portal · PATCH /sites/{siteId}/portal/{id}
//   GET/PATCH /sites/{siteId}/setting/access-control                    Pre-Authentication Access
//   POST /sites/{siteId}/hotspot/voucher-groups · GET .../voucher-groups/{groupId}/print-unused
// v5.6 — client management (seller ↔ controller):
//   GET  /sites/{siteId}/clients (v2: POST /v2/sites/{siteId}/clients)   live clients
//   POST /sites/{siteId}/clients/{clientMac}/block | unblock | reconnect
// ============================================================
final class OmadaApi
{
    /** action => [method, candidate paths relative to /openapi/{version}/{omadacId}, keyword regex for spec search] */
    const ACTIONS = [
        'sites'        => ['GET',  ['/v1/sites'], null],
        'devices'      => ['GET',  ['/v1/sites/{siteId}/devices'], null],
        'clients'      => ['GET',  ['/v1/sites/{siteId}/clients'], null],
        'adopt'        => ['POST', ['/v1/sites/{siteId}/devices/{deviceMac}/start-adopt', '/v1/sites/{siteId}/devices/{deviceMac}/adopt'], '#/devices/\{[^}]+\}/(start-)?adopt$#i'],
        'adopt_result' => ['GET',  ['/v1/sites/{siteId}/devices/{deviceMac}/adopt-result'], '#/devices/\{[^}]+\}/adopt-result$#i'],
        'reboot'       => ['POST', ['/v1/sites/{siteId}/devices/{deviceMac}/reboot', '/v1/sites/{siteId}/cmd/devices/reboot'], '#/devices?/(\{[^}]+\}/)?reboot$#i'],
        'locate'       => ['POST', ['/v1/sites/{siteId}/devices/{deviceMac}/locate'], '#/devices/\{[^}]+\}/locate$#i'],
        'add_by_sn'    => ['POST', ['/v1/sites/{siteId}/multi-devices/sn-add'], '#/sites/\{[^}]+\}/multi-devices/sn-add$#i'],
        'add_by_key'   => ['POST', ['/v1/sites/{siteId}/multi-devices/devicekey-add'], '#/sites/\{[^}]+\}/multi-devices/devicekey-add$#i'],
        'add_status'   => ['GET',  ['/v1/sites/{siteId}/multi-devices/add/{operateId}/status'], '#/multi-devices/add/\{[^}]+\}/status$#i'],
        // v5.6 — client management
        'client_block'     => ['POST', ['/v1/sites/{siteId}/clients/{clientMac}/block'], '#/clients/\{[^}]+\}/block$#i'],
        'client_unblock'   => ['POST', ['/v1/sites/{siteId}/clients/{clientMac}/unblock'], '#/clients/\{[^}]+\}/unblock$#i'],
        'client_reconnect' => ['POST', ['/v1/sites/{siteId}/clients/{clientMac}/reconnect'], '#/clients/\{[^}]+\}/reconnect$#i'],
    ];
    const SPEC_URLS = ['/v3/api-docs/00%20All', '/v3/api-docs', '/openapi/v3/api-docs'];

    private array $c;
    private ?array $paths = null;
    public string $error = '';
    /** microtime() by which slow work must finish (set by the auto-setup); every HTTP timeout is cut to fit. */
    public static ?float $deadline = null;

    function __construct(array $controller) {
        $this->c = $controller;
        // v6.1.2 — the Open API is HTTPS only: "http://169.58.93.38:8043" answered "HTTP 400" to every token request
        $b = (string)($controller['base_url'] ?? '');
        if ($b !== '' && !OmadaRelay::isCloudHost((string)parse_url($b, PHP_URL_HOST))) {
            $fixed = omadaControllerBase($b);
            if ($fixed !== '' && $fixed !== rtrim($b, '/')) {
                $this->c['base_url'] = $fixed;
                $this->c['access_token'] = null; $this->c['token_expires'] = null;
                if (!empty($controller['id'])) {
                    try { run("UPDATE hs_controllers SET base_url=?, access_token=NULL, token_expires=NULL WHERE id=?", 'si', $fixed, (int)$controller['id']); }
                    catch (Throwable $e) { error_log('OmadaApi base fix: ' . $e->getMessage()); }
                }
            }
            // v6.1.2 — the Inform URL must point to THIS controller (an old one for another host, e.g. 65.109.35.14, is replaced)
            $host = strtolower((string)parse_url((string)$this->c['base_url'], PHP_URL_HOST));
            $inf = parseInformUrl((string)($this->c['inform_url'] ?? ''));
            if ($host !== '' && (!$inf || $inf['host'] !== $host)) {
                $this->c['inform_url'] = 'omada://' . $host . '?dPort=29810&mPort=29814' . ((string)($this->c['omadac_id'] ?? '') !== '' ? '&omadacId=' . $this->c['omadac_id'] : '');
                if (!empty($controller['id'])) {
                    try { run("UPDATE hs_controllers SET inform_url=? WHERE id=?", 'si', $this->c['inform_url'], (int)$controller['id']); }
                    catch (Throwable $e) { error_log('OmadaApi inform fix: ' . $e->getMessage()); }
                }
            }
        }
    }

    static function load(int $id, int $uid = 0): ?self {
        $r = $uid ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $id, $uid) : row("SELECT * FROM hs_controllers WHERE id=?", 'i', $id);
        return $r ? new self($r) : null;
    }
    function row(): array { return $this->c; }
    function base(): string { return rtrim((string)$this->c['base_url'], '/'); }
    function id(): int { return (int)$this->c['id']; }
    /** True when this controller row has everything the Open API needs (Inform URL alone is enough for provisioning, not for the API). */
    static function canApi(?array $c): bool {
        return $c && trim((string)($c['base_url'] ?? '')) !== '' && trim((string)($c['client_id'] ?? '')) !== '' && trim((string)($c['client_secret'] ?? '')) !== ''
            && !OmadaRelay::isCloudHost((string)parse_url((string)$c['base_url'], PHP_URL_HOST));   // v6.1: Omada Cloud is not supported
    }
    /** Short hint added to API errors when the Inform URL points to an Omada Central Essentials organization. */
    function essentialsHint(): string {
        $i = parseInformUrl((string)($this->c['inform_url'] ?? ''));
        return ($i && $i['essentials']) ? ' ' . t('ctrl_essentials_hint') : '';
    }

    /** Refuse loopback / link-local / reserved targets (and private LANs for non-admin sellers) — the website itself makes these calls. */
    static function hostAllowed(string $url, bool $allowPrivate, ?string &$ip = null, ?string &$why = null): bool {
        $host = (string)parse_url($url, PHP_URL_HOST);
        if ($host === '') { $why = 'Invalid URL'; return false; }
        $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : resolveHost($host);
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && canCall('dns_get_record')) {
            // v5.7: hosts that disable gethostbyname() — ask DNS directly
            foreach ((array)@dns_get_record($host, DNS_A) as $rec) if (!empty($rec['ip'])) { $ip = (string)$rec['ip']; break; }
        }
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            // TP-Link cloud names are always public: let cURL resolve them itself when PHP cannot
            if (preg_match('/(^|\.)tplinkcloud\.com$/i', $host)) { $ip = ''; return true; }
            $why = "Cannot resolve $host"; return false;
        }
        if (preg_match('/^(127\.|0\.|169\.254\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.)/', $ip)) { $why = "Address $ip is not allowed"; return false; }
        if (!$allowPrivate && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            $why = "$host ($ip) is a private LAN address — use the public address of your Omada Controller on the VPS, e.g. " . OMADA_CONTROLLER_URL;
            return false;
        }
        return true;
    }

    /** v5.9 — 'relay' (through the RADIUS box) or 'direct' for the last call; shown on the controller page. */
    public string $via = '';

    /**
     * One HTTP call. Returns [httpCode, decoded JSON or null, curl error, raw body].
     * v5.9: self-hosted controllers are reached THROUGH THE RADIUS SERVER (OmadaRelay) because shared hosting blocks
     * outgoing connections to ports like 8043; a direct call that cannot connect is retried through the relay.
     */
    private function http(string $method, string $url, ?array $body = null, array $headers = [], int $timeout = 0): array {
        $ip = null; $why = null;
        $route = OmadaRelay::routeFor($this->c, $url);
        if (!self::hostAllowed($url, false, $ip, $why)) {   // v6.1.2: public controller address only (no private LAN controllers)
            // the RADIUS box resolves names itself — a name this host cannot resolve is fine for the relay
            if ($route !== 'relay' || strpos((string)$why, 'Cannot resolve') !== 0) return [0, null, (string)$why, ''];
        }
        if ($body === null && in_array($method, ['POST', 'PUT', 'PATCH'], true)) $body = (object)[];   // v5.7: Omada rejects body-less POSTs (adopt, reboot, block…)
        $timeout = $timeout ?: (int)OMADA_HTTP_TIMEOUT;
        if ($route === 'relay') return $this->viaRelay($method, $url, $body, $headers, $timeout);
        $res = $this->direct($method, $url, $body, $headers, $timeout, $ip);
        if ($res[0] === 0 && $res[2] !== '' && ($this->c['conn_mode'] ?? 'auto') === 'auto' && OmadaRelay::alive()
            && strpos($res[2], 'time limit') === false) {
            // shared hosting could not connect → remember it for 30 min and use the RADIUS box
            $this->note(['direct_fail_at' => date('Y-m-d H:i:s')]);
            return $this->viaRelay($method, $url, $body, $headers, $timeout);
        }
        if ($res[0] === 0 && $res[2] !== '' && !OmadaRelay::isCloudHost((string)parse_url($url, PHP_URL_HOST)) && !OmadaRelay::alive())
            $res[2] .= ' — ' . t('relay_hint_start');
        return $res;
    }

    private function viaRelay(string $method, string $url, $body, array $headers, int $timeout): array {
        $this->via = 'relay';
        $hdr = array_merge(['Accept: application/json'], $headers);
        $payload = null;
        if ($body !== null) { $hdr[] = 'Content-Type: application/json'; $payload = (string)json_encode($body, JSON_UNESCAPED_SLASHES); }
        $r = OmadaRelay::http($method, $url, $hdr, $payload, $timeout, (bool)$this->c['verify_ssl'], (int)($this->c['id'] ?? 0));
        if (($this->c['last_via'] ?? '') !== 'relay') $this->note(['last_via' => 'relay']);
        return $r;
    }

    private function direct(string $method, string $url, $body, array $headers, int $timeout, ?string $ip): array {
        $this->via = 'direct';
        if (!function_exists('curl_init')) return [0, null, 'PHP cURL is not installed on this host', ''];
        $p = parse_url($url);
        $port = (int)($p['port'] ?? (($p['scheme'] ?? 'http') === 'https' ? 443 : 80));
        if (self::$deadline !== null) {
            $left = (int)floor(self::$deadline - microtime(true));
            if ($left < 2) return [0, null, 'time limit of this request reached', ''];
            $timeout = min($timeout, $left);
        }
        $ch = curl_init($url);
        $hdr = array_merge(['Accept: application/json'], $headers);
        $opts = [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => min(6, $timeout), CURLOPT_USERAGENT => 'SkyTanzaWiFi/' . APP_VERSION,
            CURLOPT_SSL_VERIFYPEER => (bool)$this->c['verify_ssl'], CURLOPT_SSL_VERIFYHOST => $this->c['verify_ssl'] ? 2 : 0];
        if ($ip !== '' && $ip !== null) $opts[CURLOPT_RESOLVE] = [$p['host'] . ':' . $port . ':' . $ip];   // pin the checked IP (no DNS rebinding)
        if (defined('CURLOPT_PROTOCOLS')) $opts[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        if ($body !== null) { $hdr[] = 'Content-Type: application/json'; $opts[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_SLASHES); }
        $opts[CURLOPT_HTTPHEADER] = $hdr;
        curl_setopt_array($ch, $opts);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        $json = is_string($raw) ? json_decode($raw, true) : null;
        if ($err === '' && ($this->c['last_via'] ?? '') !== 'direct') $this->note(['last_via' => 'direct']);
        return [$code, is_array($json) ? $json : null, $err, is_string($raw) ? $raw : ''];
    }

    /** saveRow() that never breaks an Omada call (v5.9 bookkeeping columns). */
    private function note(array $f): void {
        if (empty($this->c['id'])) { foreach ($f as $k => $v) $this->c[$k] = $v; return; }
        try { $this->saveRow($f); } catch (Throwable $e) { error_log('OmadaApi note: ' . $e->getMessage()); }
    }

    private function saveRow(array $f): void {
        if (!$f) return;
        $sets = []; $types = ''; $vals = [];
        foreach ($f as $k => $v) { $sets[] = "`$k`=?"; $types .= 's'; $vals[] = $v === null ? null : (string)$v; $this->c[$k] = $v; }
        $types .= 'i'; $vals[] = $this->id();
        run("UPDATE hs_controllers SET " . implode(',', $sets) . " WHERE id=?", $types, ...$vals);
    }
    private function fail(string $msg): array {
        $this->error = $msg;
        $this->saveRow(['last_error' => substr($msg, 0, 255)]);
        return ['ok' => false, 'msg' => $msg, 'result' => null, 'code' => -1];
    }

    /** GET /api/info — Omada ID and versions (local controllers; the Cloud-Based Controller gives the Omada ID on its Open API page). */
    function info(bool $fixOmadac = false): array {
        [$code, $j, $err, $raw] = $this->http('GET', $this->base() . '/api/info', null, [], 8);
        if ($err) return ['ok' => false, 'msg' => 'Cannot reach controller: ' . $err . (stripos($err, 'SSL') !== false ? ' — ' . t('tok_ssl') : '')];
        if (!$j || (int)($j['errorCode'] ?? -1) !== 0) return ['ok' => false, 'msg' => "/api/info HTTP $code" . self::bodyHint((string)$raw)];
        $r = (array)($j['result'] ?? []);
        $f = ['controller_ver' => substr((string)($r['controllerVer'] ?? ''), 0, 40), 'api_ver' => substr((string)($r['apiVer'] ?? ''), 0, 20)];
        if ((empty($this->c['omadac_id']) || $fixOmadac) && !empty($r['omadacId'])) $f['omadac_id'] = substr((string)$r['omadacId'], 0, 64);
        $this->saveRow($f);
        return ['ok' => true, 'result' => $r];
    }

    /** Access token (cached until 2 minutes before expiry). */
    function token(bool $force = false): string {
        if (!$force && !empty($this->c['access_token']) && !empty($this->c['token_expires']) && strtotime($this->c['token_expires']) > time() + 120)
            return (string)$this->c['access_token'];
        if (empty($this->c['omadac_id'])) {
            $i = $this->info();
            if (!$i['ok'] && empty($this->c['omadac_id'])) { $this->fail($i['msg'] . ' — and no Omada ID is saved (type the Omada ID from the Open API page)'); return ''; }
        }
        if (empty($this->c['omadac_id']) || empty($this->c['client_id']) || empty($this->c['client_secret'])) { $this->error = t('prov_need_keys'); return ''; }
        [$code, $j, $err, $raw] = $this->tokenRequest();
        if ($err) { $this->fail('Token: cannot reach controller: ' . $err . (stripos($err, 'SSL') !== false ? ' — ' . t('tok_ssl') : '')); return ''; }
        $note = '';
        if (!$j || (int)($j['errorCode'] ?? -1) !== 0 || empty($j['result']['accessToken'])) {
            // v6.1.2 — plain HTTP sent to the HTTPS port (nginx "400 Bad Request"): switch to https and try again
            if (!is_array($j) && stripos($this->base(), 'http://') === 0) {
                $fixed = omadaControllerBase($this->base());
                if ($fixed !== '' && $fixed !== $this->base()) {
                    $this->saveRow(['base_url' => $fixed]);
                    $note = sprintf(t('tok_http'), $fixed);
                    [$code, $j, $err, $raw] = $this->tokenRequest();
                }
            }
        }
        if (!$err && (!$j || (int)($j['errorCode'] ?? -1) !== 0 || empty($j['result']['accessToken']))) {
            // v6.1.2 — the saved Omada ID may belong to another controller: read the real one from /api/info and retry once
            $old = (string)$this->c['omadac_id'];
            $i = $this->info(true);
            if ($i['ok'] && (string)$this->c['omadac_id'] !== '' && (string)$this->c['omadac_id'] !== $old) {
                $note = trim($note . ' ' . sprintf(t('tok_omadac'), $this->c['omadac_id']));
                [$code, $j, $err, $raw] = $this->tokenRequest();
            }
        }
        if ($err) { $this->fail('Token: cannot reach controller: ' . $err); return ''; }
        if (!$j || (int)($j['errorCode'] ?? -1) !== 0 || empty($j['result']['accessToken'])) {
            $ec = is_array($j) ? (int)($j['errorCode'] ?? -1) : null;
            $why = is_array($j) ? (string)($j['msg'] ?? '') : '';
            $this->fail('Token refused (HTTP ' . $code . ($ec !== null ? ', errorCode ' . $ec : '') . '): '
                . ($why !== '' ? $why . ' — ' : self::bodyHint((string)$raw) . ' — ')
                . 'controller ' . $this->base() . ' • Omada ID ' . ($this->c['omadac_id'] ?: '?') . '. ' . t('tok_keys') . ($note !== '' ? ' ' . $note : '') . $this->essentialsHint());
            return '';
        }
        $r = $j['result'];
        $this->saveRow(['access_token' => (string)$r['accessToken'], 'refresh_token' => (string)($r['refreshToken'] ?? ''),
            'token_expires' => date('Y-m-d H:i:s', time() + max(300, (int)($r['expiresIn'] ?? 7200)))]);
        return (string)$r['accessToken'];
    }

    /** v6.1.2 — POST /openapi/authorize/token (Client Credentials). Returns [code, json|null, error, raw]. */
    private function tokenRequest(): array {
        return $this->http('POST', $this->base() . '/openapi/authorize/token?grant_type=client_credentials',
            ['omadacId' => (string)$this->c['omadac_id'], 'client_id' => (string)$this->c['client_id'], 'client_secret' => (string)$this->c['client_secret']]);
    }
    /** v6.1.2 — short readable reason from a non-JSON answer (HTML error page of the controller's web server). */
    static function bodyHint(string $raw): string {
        if (stripos($raw, 'plain HTTP request was sent to HTTPS port') !== false) return ' (plain HTTP sent to the HTTPS port — use https://IP:8043)';
        $t = trim((string)preg_replace('/\s+/', ' ', strip_tags($raw)));
        return $t !== '' ? ' (' . substr($t, 0, 140) . ')' : '';
    }

    /** Authenticated Open API call. $path is relative to /openapi, e.g. "/v1/sites". */
    function call(string $method, string $path, array $query = [], ?array $body = null, int $timeout = 0): array {
        for ($attempt = 0; $attempt < 2; $attempt++) {
            $tok = $this->token($attempt > 0);
            if ($tok === '') return ['ok' => false, 'msg' => $this->error ?: 'No access token', 'result' => null, 'code' => -1];
            $ver = '/v1'; $rest = $path;
            if (preg_match('#^(/v\d+)(/.*)?$#', $path, $m)) { $ver = $m[1]; $rest = $m[2] ?? ''; }
            $url = $this->base() . '/openapi' . $ver . '/' . rawurlencode((string)$this->c['omadac_id']) . $rest . ($query ? '?' . http_build_query($query) : '');
            [$code, $j, $err] = $this->http($method, $url, $body, ['Authorization: AccessToken=' . $tok], $timeout);
            if ($err) return $this->fail("$method $rest: " . $err);
            $ec = is_array($j) ? (int)($j['errorCode'] ?? -1) : -1;
            if ($attempt === 0 && ($code === 401 || in_array($ec, [-44112, -44113, -44106, -44111], true))) { $this->saveRow(['token_expires' => null]); continue; }
            if ($ec === 0) { $this->saveRow(['last_ok' => date('Y-m-d H:i:s'), 'last_error' => null]); return ['ok' => true, 'msg' => (string)($j['msg'] ?? 'OK'), 'result' => $j['result'] ?? null, 'code' => 0, 'http' => $code]; }
            $msg = is_array($j) ? (string)($j['msg'] ?? 'error') : 'HTTP ' . $code;
            return ['ok' => false, 'msg' => "$method $rest → $msg (errorCode $ec, HTTP $code)", 'result' => $j['result'] ?? null, 'code' => $ec, 'http' => $code];
        }
        return ['ok' => false, 'msg' => 'Unauthorized', 'result' => null, 'code' => -1];
    }

    /** Read the controller's own OpenAPI spec and remember which documented path serves each action. */
    function discover(): array {
        $found = []; $specOk = false; $addBody = null;
        // Omada Central's spec is several MB — the documented cloud paths above are used as they are.
        foreach (($this->c['ctype'] ?? '') === 'cloud' ? [] : self::SPEC_URLS as $u) {
            [$code, $j] = $this->http('GET', $this->base() . $u, null, [], 30);
            if ($code !== 200 || !is_array($j) || empty($j['paths'])) continue;
            $specOk = true;
            $paths = [];
            foreach ($j['paths'] as $p => $ops) {
                if (!is_array($ops)) continue;
                $norm = preg_replace('#^/openapi(/v\d+)/\{omadacId\}#', '$1', (string)$p);
                if ($norm === $p) continue;
                foreach ($ops as $verb => $op) $paths[strtoupper((string)$verb)][$norm] = $op;
            }
            foreach (self::ACTIONS as $name => [$verb, $cands, $rx]) {
                foreach ($cands as $cand) if (isset($paths[$verb][$cand])) { $found[$name] = $cand; break; }
                if (!isset($found[$name]) && $rx) foreach (array_keys($paths[$verb] ?? []) as $p) if (preg_match($rx, $p)) { $found[$name] = $p; break; }
            }
            unset($j);
            break;
        }
        $this->paths = ['spec' => $specOk, 'found' => $found, 'at' => date('c')];
        $this->saveRow(['paths_json' => json_encode($this->paths, JSON_UNESCAPED_SLASHES)]);
        return $this->paths;
    }
    /** [method, path] for an action — discovered path, else the documented default. */
    function route(string $name): array {
        if ($this->paths === null) $this->paths = json_decode((string)($this->c['paths_json'] ?? ''), true) ?: ['found' => []];
        [$verb, $cands] = self::ACTIONS[$name];
        return [$verb, $this->paths['found'][$name] ?? ($cands[0] ?? '')];
    }
    private function act(string $name, array $vars, array $query = [], ?array $body = null): array {
        [$verb, $path] = $this->route($name);
        if ($path === '') return ['ok' => false, 'msg' => "This controller's Open API does not offer '$name' (run Test connection to re-read its API list)"];
        foreach ($vars as $k => $v) $path = str_replace('{' . $k . '}', rawurlencode((string)$v), $path);
        $path = preg_replace('/\{[^}]+\}/', rawurlencode((string)($vars['siteId'] ?? '')), $path);
        return $this->call($verb, $path, $query, $body);
    }
    /** All pages of a paged list. */
    private function paged(string $name, array $vars, int $max = 2000): array {
        $all = [];
        for ($page = 1; $page <= 20; $page++) {
            $r = $this->act($name, $vars, ['page' => $page, 'pageSize' => 100]);
            if (!$r['ok']) { if ($page === 1) { $this->error = $r['msg']; return []; } break; }
            $res = $r['result'];
            $data = is_array($res) && isset($res['data']) ? (array)$res['data'] : (is_array($res) && isset($res[0]) ? $res : []);
            $all = array_merge($all, $data);
            $total = (int)($res['totalRows'] ?? count($all));
            if (!$data || count($all) >= $total || count($all) >= $max) break;
        }
        return $all;
    }

    function sites(): array {
        $this->error = '';
        $list = [];
        foreach ($this->paged('sites', []) as $s) {
            $id = (string)($s['siteId'] ?? $s['id'] ?? '');
            if ($id !== '') $list[] = ['id' => $id, 'name' => (string)($s['name'] ?? $id)];
        }
        if ($this->sharedScope()) $list = array_values(array_filter($list, fn($x) => $this->siteAllowed($x['id'])));
        if ($list) $this->saveRow(['sites_json' => json_encode($list, JSON_UNESCAPED_UNICODE)]);
        return $list;
    }
    function cachedSites(): array {
        $l = json_decode((string)($this->c['sites_json'] ?? ''), true) ?: [];
        return $this->sharedScope() ? array_values(array_filter($l, fn($x) => is_array($x) && $this->siteAllowed((string)($x['id'] ?? '')))) : $l;
    }
    /** v5.9 — sites created by this seller in this request (shared-key controllers). */
    private static array $ownCreated = [];
    /** True when this seller uses the platform's shared Open API keys (he must only see / touch his own Omada sites). */
    function sharedScope(): bool {
        if (empty($this->c['shared_keys'])) return false;
        static $admin = [];
        $u = (int)$this->c['user_id'];
        if (!isset($admin[$u])) $admin[$u] = (bool)val("SELECT 1 FROM users WHERE id=? AND user_type='admin'", 'i', $u);
        return !$admin[$u];
    }
    /** May this seller use this Omada site? (always true for his own keys / for the admin). */
    function siteAllowed(string $siteId): bool {
        if ($siteId === '' || !$this->sharedScope()) return true;
        if (in_array($siteId, self::$ownCreated, true)) return true;
        if (OmadaManager::ownsSite((int)$this->c['user_id'], $siteId)) return true;   // v6.0: sites the seller created in Omada Manager
        return (bool)val("SELECT 1 FROM hs_devices WHERE user_id=? AND omada_site_id=? LIMIT 1", 'is', (int)$this->c['user_id'], $siteId);
    }
    function devices(string $siteId): array { $this->error = ''; return array_map([self::class, 'mapDevice'], $this->paged('devices', ['siteId' => $siteId])); }
    function clients(string $siteId): array { $this->error = ''; return $this->paged('clients', ['siteId' => $siteId], 5000); }

    /** Adopt (claim) a PENDING device into the site. Username/password = the AP's own login (factory default admin/admin). */
    function adopt(string $siteId, string $mac, string $user, string $pass): array {
        $r = $this->act('adopt', ['siteId' => $siteId, 'deviceMac' => dashMac($mac)], [], ['username' => $user, 'password' => $pass]);
        if ($r['ok']) {
            pauseMs(1500);
            $res = $this->act('adopt_result', ['siteId' => $siteId, 'deviceMac' => dashMac($mac)]);
            if ($res['ok'] && is_array($res['result'])) $r['adopt_result'] = $res['result'];
        }
        return $r;
    }
    function reboot(string $siteId, string $mac): array {
        [, $path] = $this->route('reboot');
        $body = strpos($path, '{deviceMac}') === false && strpos($path, '{mac}') === false ? ['deviceMacs' => [dashMac($mac)]] : null;
        return $this->act('reboot', ['siteId' => $siteId, 'deviceMac' => dashMac($mac)], [], $body);
    }
    function locate(string $siteId, string $mac): array { return $this->act('locate', ['siteId' => $siteId, 'deviceMac' => dashMac($mac)], [], ['locateEnable' => true]); }
    function adoptResult(string $siteId, string $mac): array { return $this->act('adopt_result', ['siteId' => $siteId, 'deviceMac' => dashMac($mac)]); }

    // ---------------------------------------------------------------- v5.6 client management
    /** block | unblock | reconnect one client (phone) in an Omada site. */
    function clientCmd(string $siteId, string $mac, string $cmd): array {
        if (!in_array($cmd, ['block', 'unblock', 'reconnect'], true)) return ['ok' => false, 'msg' => 'Unknown command'];
        $mac = normMac($mac);
        if ($mac === '' || $siteId === '') return ['ok' => false, 'msg' => 'Site / MAC missing'];
        return $this->act('client_' . $cmd, ['siteId' => $siteId, 'clientMac' => dashMac($mac)]);
    }
    /** Live clients of a site, normalised. Tries the v1 GET list, then the v2 POST list used by newer controllers. */
    function clientList(string $siteId, string $apMac = ''): array {
        $this->error = '';
        $raw = $this->clients($siteId);
        if (!$raw && $this->error !== '') {
            $first = $this->error;
            $r = $this->call('POST', '/v2/sites/' . rawurlencode($siteId) . '/clients', [], ['page' => 1, 'pageSize' => 500, 'filters' => (object)[]]);
            if ($r['ok']) { $this->error = ''; $raw = self::listOf($r['result']); }
            else $this->error = $first;
        }
        $out = [];
        foreach ($raw as $c) {
            if (!is_array($c)) continue;
            $m = self::mapClient($c);
            if ($m['mac'] === '') continue;
            if ($apMac !== '' && $m['ap_mac'] !== '' && $m['ap_mac'] !== $apMac) continue;
            $out[] = $m;
        }
        return $out;
    }
    static function mapClient(array $c): array {
        $auth = $c['authStatus'] ?? ($c['authInfo']['authStatus'] ?? null);
        return ['mac' => normMac((string)($c['mac'] ?? '')), 'name' => (string)($c['name'] ?? $c['hostName'] ?? ''), 'ip' => (string)($c['ip'] ?? ''),
            'ap_mac' => normMac((string)($c['apMac'] ?? '')), 'ap_name' => (string)($c['apName'] ?? $c['deviceName'] ?? ''), 'ssid' => (string)($c['ssid'] ?? ''),
            'uptime' => (int)($c['uptime'] ?? 0), 'down' => (float)($c['trafficDown'] ?? $c['downPacket'] ?? 0), 'up' => (float)($c['trafficUp'] ?? 0),
            'rssi' => isset($c['rssi']) ? (int)$c['rssi'] : null, 'blocked' => !empty($c['blocked']),
            'auth' => $auth === null ? '' : (is_numeric($auth) ? ([0 => 'none', 1 => 'pending', 2 => 'authorized', 3 => 'authorized'][(int)$auth] ?? (string)$auth) : strtolower((string)$auth))];
    }

    /**
     * Add (claim) a device to a site by serial number (or by device key / QR code) — Omada Central / Cloud-Based Controller.
     * Body: {"devices":[{"sn":"...", "name":"...", "username":"admin", "password":"admin"}]} → result.operateId
     */
    function addBySerial(string $siteId, string $sn, string $key, string $name, string $user = '', string $pass = ''): array {
        $item = ($name !== '' ? ['name' => substr($name, 0, 128)] : []) + ($user !== '' ? ['username' => $user, 'password' => $pass] : []);
        if ($sn !== '') return $this->act('add_by_sn', ['siteId' => $siteId], [], ['devices' => [['sn' => $sn] + $item]]);
        if ($key !== '') return $this->act('add_by_key', ['siteId' => $siteId], [], ['devices' => [['deviceKey' => $key] + $item]]);
        return ['ok' => false, 'msg' => 'S/N or device key required'];
    }
    /** Progress of an add-by-S/N operation: processStatus 0 init / 1 doing / 2 done, devices[].status 0 = success. */
    function addStatus(string $siteId, string $operateId): array { return $this->act('add_status', ['siteId' => $siteId, 'operateId' => $operateId]); }

    // ---------------------------------------------------------------- auto-setup (sites, SSID, RADIUS, portal, vouchers)
    private function sitePath(string $siteId, string $rest = ''): string { return '/v1/sites/' . rawurlencode($siteId) . $rest; }
    /** A list from an Open API result: plain array or {data:[...]}. */
    static function listOf($res): array {
        if (!is_array($res)) return [];
        if (isset($res['data']) && is_array($res['data'])) return $res['data'];
        return ($res === [] || array_keys($res) === range(0, count($res) - 1)) ? $res : [];   // PHP 8.0-safe list check
    }
    function scenarios(): array {
        $r = $this->call('GET', '/v1/scenarios');
        return $r['ok'] ? array_values(array_filter(array_map(fn($x) => is_array($x) ? (string)($x['name'] ?? '') : (string)$x, self::listOf($r['result'])))) : [];
    }
    function siteByName(string $name): ?array {
        $r = $this->call('GET', '/v1/sites', ['page' => 1, 'pageSize' => 100, 'searchKey' => $name]);
        foreach (self::listOf($r['result'] ?? null) as $s) if (strcasecmp((string)($s['name'] ?? ''), $name) === 0) return ['id' => (string)($s['siteId'] ?? $s['id'] ?? ''), 'name' => (string)$s['name']];
        return null;
    }
    /** Create a site and return ['ok', 'id', 'msg']. */
    function createSite(string $name, string $region, string $tz, string $scenario, string $devUser, string $devPass): array {
        // v5.9: controllers name time zones differently (IANA id or "UTC+03:00") — try the saved value first, then the others
        $bodies = [];
        foreach (array_unique([$tz, 'Africa/Nairobi', 'UTC+03:00', 'Africa/Dar_es_Salaam']) as $z)
            $bodies[] = ['name' => $name, 'type' => 0, 'region' => $region, 'timeZone' => $z, 'scenario' => $scenario,
                'deviceAccountSetting' => ['username' => $devUser, 'password' => $devPass]];
        $r = self::firstOk(function ($b) { $x = $this->call('POST', '/v1/sites', [], $b, 20);
            if (!$x['ok'] && stripos((string)$x['msg'], 'exist') !== false) { $x['code'] = -1; $x['http'] = 0; }   // name taken: another body will not help
            return $x; }, $bodies);
        if (!$r['ok']) return ['ok' => false, 'id' => '', 'msg' => $r['msg']];
        $id = is_array($r['result']) ? (string)($r['result']['siteId'] ?? $r['result']['id'] ?? '') : (is_string($r['result']) ? $r['result'] : '');
        if ($id === '') { pauseMs(800); $id = (string)(($this->siteByName($name) ?? [])['id'] ?? ''); }
        if ($id !== '') { self::$ownCreated[] = $id; $this->saveRow(['sites_json' => null]); $this->sites(); }
        return ['ok' => $id !== '', 'id' => $id, 'msg' => $id !== '' ? 'OK' : 'Site created but its ID was not returned — press "Run setup again"'];
    }
    function wlanGroups(string $siteId): array { $r = $this->call('GET', $this->sitePath($siteId, '/wireless-network/wlans')); $this->error = $r['ok'] ? '' : $r['msg']; return self::listOf($r['result']); }
    function createWlanGroup(string $siteId, string $name): array { return $this->call('POST', $this->sitePath($siteId, '/wireless-network/wlans'), [], ['name' => $name, 'clone' => false]); }
    function ssidList(string $siteId, string $wlanId): array {
        $r = $this->call('GET', $this->sitePath($siteId, '/wireless-network/wlans/' . rawurlencode($wlanId) . '/ssids'), ['page' => 1, 'pageSize' => 100]);
        $this->error = $r['ok'] ? '' : $r['msg'];
        return self::listOf($r['result']);
    }
    function createSsid(string $siteId, string $wlanId, array $body): array { return $this->call('POST', $this->sitePath($siteId, '/wireless-network/wlans/' . rawurlencode($wlanId) . '/ssids'), [], $body, 20); }
    function updateSsidBasic(string $siteId, string $wlanId, string $ssidId, array $body): array {
        return $this->call('PATCH', $this->sitePath($siteId, '/wireless-network/wlans/' . rawurlencode($wlanId) . '/ssids/' . rawurlencode($ssidId) . '/update-basic-config'), [], $body, 20);
    }
    function deleteSsid(string $siteId, string $wlanId, string $ssidId): array {
        return $this->call('DELETE', $this->sitePath($siteId, '/wireless-network/wlans/' . rawurlencode($wlanId) . '/ssids/' . rawurlencode($ssidId)), [], null, 20);
    }
    /** v5.7 — every SSID of a site across all WLAN groups, with its group: [ssidId, wlanId, wlanName, name, band, security, guest, broadcast, portal?]. */
    function allSsids(string $siteId): array {
        $out = [];
        $groups = $this->wlanGroups($siteId);
        if (!$groups && $this->error !== '') return [];
        foreach ($groups as $g) {
            $wid = (string)($g['wlanId'] ?? $g['id'] ?? '');
            if ($wid === '') continue;
            foreach ($this->ssidList($siteId, $wid) as $x) {
                if (!is_array($x)) continue;
                $out[] = ['ssid_id' => (string)($x['ssidId'] ?? $x['id'] ?? ''), 'wlan_id' => $wid, 'wlan_name' => (string)($g['name'] ?? ''),
                    'name' => (string)($x['name'] ?? ''), 'band' => (int)($x['band'] ?? 0), 'security' => (int)($x['security'] ?? 0),
                    'guest' => !empty($x['guestNetEnable']), 'broadcast' => !isset($x['broadcast']) || !empty($x['broadcast']),
                    'enabled' => !isset($x['enable']) || !empty($x['enable'])];
            }
        }
        $this->error = '';
        return $out;
    }
    /** v5.7 — try several request bodies (Omada firmware versions accept slightly different fields); first success wins. */
    static function firstOk(callable $send, array $bodies): array {
        $first = null; $n = 0;
        foreach ($bodies as $b) {
            if (self::$deadline !== null && microtime(true) > self::$deadline - 3) break;
            $n++;
            $r = $send($b);
            if (!empty($r['ok'])) { if ($n > 1) $r['msg'] = ($r['msg'] ?? 'OK') . ' (variant ' . $n . ')'; return $r; }
            $first = $first ?? $r;
            if ((int)($r['code'] ?? 0) === -1 && (int)($r['http'] ?? 0) === 0) break;   // network / auth problem — another body will not help
        }
        return ($first ?? ['ok' => false, 'msg' => 'no request sent', 'result' => null, 'code' => -1]) + ['tries' => $n];
    }
    function radiusProfiles(string $siteId): array { $r = $this->call('GET', $this->sitePath($siteId, '/profiles/radius')); return self::listOf($r['result']); }
    function createRadiusProfile(string $siteId, array $body): array { return $this->call('POST', $this->sitePath($siteId, '/profiles/radius'), [], $body); }
    function updateRadiusProfile(string $siteId, string $id, array $body): array { return $this->call('PATCH', $this->sitePath($siteId, '/profiles/radius/' . rawurlencode($id)), [], $body); }
    function portals(string $siteId): array { $r = $this->call('GET', $this->sitePath($siteId, '/portals')); return self::listOf($r['result']); }
    function createPortal(string $siteId, array $body): array { return $this->call('POST', $this->sitePath($siteId, '/portal'), [], $body, 20); }
    function updatePortal(string $siteId, string $id, array $body): array { return $this->call('PATCH', $this->sitePath($siteId, '/portal/' . rawurlencode($id)), [], $body, 20); }
    function accessControl(string $siteId): array { return $this->call('GET', $this->sitePath($siteId, '/setting/access-control')); }
    function setAccessControl(string $siteId, array $body): array { return $this->call('PATCH', $this->sitePath($siteId, '/setting/access-control'), [], $body); }
    function createVoucherGroup(string $siteId, array $body): array { return $this->call('POST', $this->sitePath($siteId, '/hotspot/voucher-groups'), [], $body, 30); }
    /** Unused voucher codes of one Omada voucher group. */
    function voucherCodes(string $siteId, string $groupId): array {
        $r = $this->call('GET', $this->sitePath($siteId, '/hotspot/voucher-groups/' . rawurlencode($groupId) . '/print-unused'), [], null, 30);
        $out = [];
        foreach (self::listOf($r['result'] ?? null) as $v) if (is_array($v) && ($v['code'] ?? '') !== '') $out[] = (string)$v['code'];
        $this->error = $r['ok'] ? '' : $r['msg'];
        return $out;
    }

    /** Normalise one device record from the Open API into the fields this app uses. */
    static function mapDevice(array $d): array {
        return ['mac' => normMac((string)($d['mac'] ?? '')), 'name' => (string)($d['name'] ?? ''), 'type' => strtolower((string)($d['type'] ?? '')),
            'model' => (string)($d['model'] ?? $d['showModel'] ?? ''), 'ip' => (string)($d['ip'] ?? ''), 'fw' => (string)($d['firmwareVersion'] ?? $d['version'] ?? ''),
            'uptime' => (string)($d['uptime'] ?? ''), 'clients' => (int)($d['clientNum'] ?? $d['clients'] ?? 0), 'sn' => (string)($d['sn'] ?? ''),
            'status' => self::statusOf($d), 'raw_status' => (string)($d['status'] ?? '')];
    }
    /** Omada status codes → connected | provisioning | pending | adopting | adopt_failed | managed_by_others | heartbeat_missed | isolated | disconnected */
    static function statusOf(array $d): string {
        $det = $d['detailStatus'] ?? null;
        if (is_numeric($det)) {
            $n = (int)$det;
            if ($n >= 14 && $n <= 17) return 'connected';
            if (($n >= 10 && $n <= 13) || $n === 50) return 'provisioning';
            if ($n === 20 || $n === 21) return 'pending';
            if ($n === 22 || $n === 23) return 'adopting';
            if ($n === 24 || $n === 25) return 'adopt_failed';
            if ($n >= 26 && $n <= 29) return 'managed_by_others';
            if ($n >= 30 && $n <= 39) return 'heartbeat_missed';
            if ($n >= 40) return 'isolated';
            return 'disconnected';
        }
        $cat = $d['statusCategory'] ?? $d['status'] ?? null;
        if (is_numeric($cat)) return [0 => 'disconnected', 1 => 'connected', 2 => 'pending', 3 => 'heartbeat_missed', 4 => 'isolated'][(int)$cat] ?? 'disconnected';
        $s = strtolower((string)$cat);
        foreach (['connected' => 'connected', 'provision' => 'provisioning', 'pending' => 'pending', 'adopting' => 'adopting', 'heartbeat' => 'heartbeat_missed', 'isolat' => 'isolated'] as $k => $v)
            if (strpos($s, $k) !== false) return $v;
        return 'disconnected';
    }

    /** Full connection test: /api/info → token → spec discovery → sites. Returns human-readable lines. */
    function test(): array {
        $out = []; $ok = true;
        $out[] = '• Controller URL: ' . $this->base() . ' • ' . t('inform_url') . ': ' . informUrlOf($this->c);   // v6.1.2
        $inf = parseInformUrl((string)($this->c['inform_url'] ?? ''));
        if ($inf && $inf['cloud']) $out[] = '✔ Inform URL: ' . $inf['host'] . ' • Omada ID ' . ($inf['omadac_id'] ?: '?') . (self::canApi($this->c) ? ' • API ' . ($inf['api_base'] ?: '?') : '');
        // v5.9 — which way the website talks to this controller
        $route = OmadaRelay::routeOf($this->c);
        $local = !OmadaRelay::isCloudHost((string)parse_url($this->base(), PHP_URL_HOST));
        if ($route === 'relay') $out[] = (OmadaRelay::alive() ? '✔ ' : '✘ ') . t('route_label') . ': ' . OmadaRelay::labelFor((string)parse_url($this->base(), PHP_URL_HOST)) . (OmadaRelay::alive() ? '' : ' — ' . t('relay_down'));
        if ($route !== 'relay') $out[] = '• ' . t('route_label') . ': ' . t('route_direct') . ($local && !OmadaRelay::alive() ? ' — ' . t('relay_hint_start') : '');
        $infoOk = null;
        if (($this->c['ctype'] ?? '') !== 'cloud' || $local) {
            $i = $this->info();
            $infoOk = $i['ok'];
            $out[] = $i['ok'] ? '✔ ' . t('ctrl_reach_ok') . ' — ' . ($this->via === 'relay' ? OmadaRelay::labelFor((string)parse_url($this->base(), PHP_URL_HOST)) : t('route_direct')) . ' • v' . ($i['result']['controllerVer'] ?? '?') . ' • Omada ID ' . ($this->c['omadac_id'] ?: '?')
                : '✘ /api/info: ' . $i['msg'];
        }
        if (!self::canApi($this->c)) {
            // v5.5 — linked by Inform URL only (no Client ID / Client Secret): check the device port (through the RADIUS box for self-hosted)
            $r = $inf ? omadaCloudReach($inf['raw'], $this->c) : ['ok' => null, 'msg' => ''];
            if ($r['msg'] !== '') $out[] = ($r['ok'] === true ? '✔ ' : ($r['ok'] === false ? '✘ ' : '• ')) . $r['msg'];
            if ($local) $out[] = '• ' . t('ctrl_local_keys_hint');
            $good = $r['ok'] === true || $infoOk === true || ($r['ok'] === null && $inf !== null && $infoOk !== false);
            $this->saveRow($good ? ['last_ok' => date('Y-m-d H:i:s'), 'last_error' => null]
                : ['last_error' => substr(($infoOk === false ? 'Controller not reachable' : '') ?: ($r['msg'] ?: 'Inform URL missing'), 0, 255)]);
            return ['ok' => $good, 'lines' => $out];
        }
        if ($inf && !$inf['cloud']) {
            $r = omadaCloudReach($inf['raw'], $this->c);
            if ($r['msg'] !== '') $out[] = ($r['ok'] === true ? '✔ ' : ($r['ok'] === false ? '✘ ' : '• ')) . $r['msg'];
        }
        $t = $this->token(true);
        if ($t === '') { $out[] = '✘ ' . $this->error; return ['ok' => false, 'lines' => $out]; }
        $out[] = '✔ Open API access token received';
        $p = $this->discover();
        $out[] = $p['spec'] ? '✔ API list read from the controller (' . count($p['found']) . ' actions matched)' : '• API list not published at this address — using the documented default paths';
        $sites = $this->sites();
        if ($sites) $out[] = '✔ ' . count($sites) . ' site(s): ' . implode(', ', array_column($sites, 'name'));
        elseif ($this->sharedScope() && $this->error === '') $out[] = '✔ ' . t('ctrl_shared_sites');
        else { $ok = false; $out[] = '✘ Sites: ' . ($this->error ?: 'none — give the Open API app access to your sites'); }
        if ($ok) $this->saveRow(['last_ok' => date('Y-m-d H:i:s'), 'last_error' => null]);
        return ['ok' => $ok, 'lines' => $out];
    }

    /**
     * v5.6 — read-only probe of every Open API feature this app uses. Returns rows [feature, ok|fail|skip, detail].
     * Nothing is created or changed in Omada.
     */
    function apiCheck(string $siteId = ''): array {
        $rows = [];
        $add = function (string $f, string $st, string $msg) use (&$rows) { $rows[] = [$f, $st, substr($msg, 0, 300)]; };
        if (!self::canApi($this->c)) { $add('Open API', 'skip', t('prov_need_keys')); return $rows; }
        if (($this->c['ctype'] ?? '') !== 'cloud') { $i = $this->info(); $add('Controller info (/api/info)', $i['ok'] ? 'ok' : 'fail', $i['ok'] ? 'v' . ($i['result']['controllerVer'] ?? '?') . ' • API ' . ($i['result']['apiVer'] ?? '?') : $i['msg']); }
        $t = $this->token(true);
        $add('Access token (client_credentials)', $t !== '' ? 'ok' : 'fail', $t !== '' ? 'Omada ID ' . $this->c['omadac_id'] : $this->error);
        if ($t === '') return $rows;
        $sites = $this->sites();
        $add('Sites (GET /sites)', $sites ? 'ok' : 'fail', $sites ? count($sites) . ': ' . implode(', ', array_slice(array_column($sites, 'name'), 0, 8)) : ($this->error ?: 'none'));
        $sc = $this->scenarios();
        $add('Scenarios (GET /scenarios)', $sc ? 'ok' : 'fail', $sc ? implode(', ', array_slice($sc, 0, 8)) : 'not available — site creation uses "Office"');
        if ($siteId === '') $siteId = (string)($sites[0]['id'] ?? '');
        if ($siteId === '') { $add('Site features', 'skip', 'No site to test'); return $rows; }
        $probe = function (string $label, string $path, array $q = []) use ($add, $siteId) {
            $r = $this->call('GET', '/v1/sites/' . rawurlencode($siteId) . $path, $q);
            $n = count(self::listOf($r['result'] ?? null));
            $add($label, $r['ok'] ? 'ok' : 'fail', $r['ok'] ? $n . ' item(s)' : $r['msg']);
            return $r;
        };
        $d = $this->devices($siteId);
        $add('Devices (GET /sites/{site}/devices)', $this->error === '' ? 'ok' : 'fail', $this->error === '' ? count($d) . ' device(s)' : $this->error);
        $cl = $this->clientList($siteId);
        $add('Clients (GET /sites/{site}/clients)', $this->error === '' ? 'ok' : 'fail', $this->error === '' ? count($cl) . ' client(s) online' : $this->error);
        $w = $this->wlanGroups($siteId);
        $add('WLAN groups', $this->error === '' ? 'ok' : 'fail', $this->error === '' ? count($w) . ' group(s)' : $this->error);
        if ($w && isset($w[0]['wlanId'])) { $ss = $this->ssidList($siteId, (string)$w[0]['wlanId']); $add('SSIDs', $this->error === '' ? 'ok' : 'fail', $this->error === '' ? count($ss) . ' SSID(s)' : $this->error); }
        $probe('RADIUS profiles', '/profiles/radius');
        $probe('Portals', '/portals');
        $probe('Access control (Pre-Authentication)', '/setting/access-control');
        $probe('Hotspot voucher groups', '/hotspot/voucher-groups', ['page' => 1, 'pageSize' => 10]);
        $p = $this->discover();
        $add('Device / client commands', 'ok', 'adopt • reboot • locate • add by S/N • block / unblock / reconnect client' . ($p['spec'] ? ' (' . count($p['found']) . ' paths confirmed in the controller spec)' : ' (documented paths)'));
        return $rows;
    }
}

// ============================================================
// OMADA SYNC — keeps every hotspot's Omada status, model, IP, firmware and client count fresh,
// and notifies the seller when an EAP goes offline / comes back.
// ============================================================
class OmadaSync {
    /** Throttled: at most one controller batch per minute site-wide; each controller at most every OMADA_SYNC_EVERY seconds. */
    static function maybe(int $onlyUser = 0): void {
        try {
            if (!$onlyUser) {
                $last = getSetting('omada_last_sync', '0');
                if (time() - (int)$last < 60) return;
                if (run("UPDATE settings SET setting_value=? WHERE setting_key='omada_last_sync' AND setting_value=?", 'ss', (string)time(), $last) !== 1) return;
            }
            $sql = "SELECT * FROM hs_controllers WHERE client_id IS NOT NULL AND client_id<>'' AND (last_sync IS NULL OR last_sync < DATE_SUB(NOW(), INTERVAL ? SECOND))";
            $list = $onlyUser ? rows($sql . " AND user_id=? ORDER BY last_sync LIMIT 3", 'ii', (int)OMADA_SYNC_EVERY, $onlyUser)
                              : rows($sql . " ORDER BY last_sync LIMIT 5", 'i', (int)OMADA_SYNC_EVERY);
            $prev = OmadaApi::$deadline;
            OmadaApi::$deadline = min($prev ?? PHP_FLOAT_MAX, microtime(true) + ($onlyUser ? 15 : 40));   // a slow controller never hangs a page
            try { foreach ($list as $c) { if (microtime(true) > OmadaApi::$deadline - 2) break; self::controller($c); } }
            finally { OmadaApi::$deadline = $prev; }
        } catch (Throwable $e) { error_log('OmadaSync: ' . $e->getMessage()); }
    }

    /** Sync one controller. Returns [updated hotspots, message]. */
    static function controller(array $c, bool $force = false): array {
        if (!$force && run("UPDATE hs_controllers SET last_sync=NOW() WHERE id=? AND (last_sync IS NULL OR last_sync < DATE_SUB(NOW(), INTERVAL 30 SECOND))", 'i', $c['id']) !== 1) return [0, 'busy'];
        if ($force) run("UPDATE hs_controllers SET last_sync=NOW() WHERE id=?", 'i', $c['id']);
        $devs = rows("SELECT * FROM hs_devices WHERE user_id=? AND (controller_id=? OR controller_id IS NULL)", 'ii', $c['user_id'], $c['id']);
        if (!$devs) return [0, 'no hotspots'];
        $api = new OmadaApi($c);
        $siteIds = array_values(array_unique(array_filter(array_map(fn($d) => (int)$d['controller_id'] === (int)$c['id'] ? (string)$d['omada_site_id'] : '', $devs))));
        $needAll = (bool)array_filter($devs, fn($d) => (int)$d['controller_id'] !== (int)$c['id'] || (string)$d['omada_site_id'] === '');
        if ($needAll || !$siteIds) {
            $sites = $api->sites() ?: $api->cachedSites();
            $siteIds = array_values(array_unique(array_merge($siteIds, array_column($sites, 'id'))));
        }
        if (!$siteIds) return [0, $api->error ?: 'no sites'];
        $seen = []; $errors = 0;
        foreach (array_slice($siteIds, 0, 30) as $sid) {
            $list = $api->devices($sid);
            if (!$list && $api->error !== '') { $errors++; if (!$seen) break; continue; }   // controller unreachable → stop early
            foreach ($list as $od) if ($od['mac'] !== '') $seen[$od['mac']] = $od + ['site' => $sid];
        }
        if ($errors && !$seen) return [0, $api->error];
        $n = 0;
        foreach ($devs as $d) {
            $mine = (int)$d['controller_id'] === (int)$c['id'];
            if (!isset($seen[$d['ap_mac']])) {
                if ($mine && !$errors) { run("UPDATE hs_devices SET omada_status='not_found', omada_status_at=NOW() WHERE id=?", 'i', $d['id']); $n++; }
                continue;
            }
            $o = $seen[$d['ap_mac']];
            $prev = (string)$d['omada_status'];
            run("UPDATE hs_devices SET controller_id=?, omada_site_id=?, omada_status=?, omada_status_at=NOW(), omada_online_at=IF(?='connected', NOW(), omada_online_at),
                 omada_clients=?, omada_model=?, omada_ip=?, omada_fw=?, omada_uptime=? WHERE id=?", 'isssissssi',
                $c['id'], $o['site'], $o['status'], $o['status'], $o['clients'], substr($o['model'], 0, 64), substr($o['ip'], 0, 45),
                substr($o['fw'], 0, 80), substr($o['uptime'], 0, 64), $d['id']);
            if ($o['status'] === 'connected') run("UPDATE hs_devices SET prov_state='done' WHERE id=? AND prov_state IN ('ready','provisioning','partial')", 'i', $d['id']);
            $n++;
            if ($prev === 'connected' && $o['status'] !== 'connected')
                Notify::add((int)$d['user_id'], 'Access point offline', $d['device_name'] . ' → Omada status ' . strtoupper($o['status']), 'error', '?page=hotspot&id=' . (int)$d['id'], 'triangle-exclamation');
            elseif ($prev !== '' && $prev !== 'connected' && $o['status'] === 'connected')
                Notify::add((int)$d['user_id'], 'Access point online', $d['device_name'] . ' CONNECTED • ' . $o['clients'] . ' client(s)', 'success', '?page=hotspot&id=' . (int)$d['id'], 'wifi');
        }
        return [$n, $errors ? $api->error : 'ok'];
    }
}

// ============================================================
// v5.6 — OMADA CLIENT OPERATIONS: the seller's actions on the website (disconnect, block, unblock) are also applied
// in every Omada site the seller's routers belong to (only for controllers that have Open API keys).
// ============================================================
final class OmadaClientOps
{
    /** Distinct [controller row, siteId] pairs of this seller's routers with Open API keys (optionally one router only). */
    static function targets(int $uid, int $deviceId = 0): array {
        $sql = "SELECT DISTINCT c.*, d.omada_site_id AS site FROM hs_devices d JOIN hs_controllers c ON c.id=d.controller_id AND c.user_id=d.user_id
                WHERE d.user_id=? AND d.omada_site_id IS NOT NULL AND d.omada_site_id<>'' AND c.client_id IS NOT NULL AND c.client_id<>''";
        try { return $deviceId ? rows($sql . " AND d.id=?", 'ii', $uid, $deviceId) : rows($sql, 'i', $uid); } catch (Throwable $e) { return []; }
    }
    /** Run block | unblock | reconnect for a phone MAC. Returns [successes, last message]. Never throws, never takes more than ~20 s. */
    static function apply(int $uid, string $mac, string $cmd, int $deviceId = 0): array {
        $mac = normMac($mac);
        if ($mac === '') return [0, ''];
        $prev = OmadaApi::$deadline;
        OmadaApi::$deadline = min($prev ?? PHP_FLOAT_MAX, microtime(true) + workBudget(20));
        $ok = 0; $msg = '';
        try {
            foreach (self::targets($uid, $deviceId) as $t) {
                if (microtime(true) > OmadaApi::$deadline - 2) break;
                $site = (string)$t['site'];
                unset($t['site']);
                $r = (new OmadaApi($t))->clientCmd($site, $mac, $cmd);
                if ($r['ok']) $ok++; else $msg = (string)$r['msg'];
            }
        } catch (Throwable $e) { error_log('OmadaClientOps: ' . $e->getMessage()); $msg = $e->getMessage(); }
        finally { OmadaApi::$deadline = $prev; }
        if ($ok) logActivity($uid, 'omada_client_' . $cmd, $mac . ' (' . $ok . ' site(s))');
        return [$ok, $msg];
    }
}

// ============================================================
// OMADA AUTO-SETUP — runs when an EAP225 is added (and on "Run setup again"), then "Start provisioning"
// adopts the EAP225 live. Every step is idempotent: the site, SSID, RADIUS profile and portal are found by
// their saved ID or name and updated, never duplicated. Steps that need the Open API are skipped (with a
// clear message) when the controller was saved with the Inform URL only.
// ============================================================
final class OmadaProvision
{
    const RADIUS_PREFIX = 'SkyRadius-';
    const PORTAL_PREFIX = 'SkyPortal-';
    const STARTER = [['1 Hour', 500, 60, 30], ['1 Day', 1000, 1440, 30], ['1 Week', 5000, 10080, 60]];

    /** Options chosen on the add / re-run form. */
    static function optsFromInput(array $in): array {
        $site = (string)($in['omada_site_mode'] ?? 'new');
        $pkg = (string)($in['prov_pkg'] ?? '0');
        return [
            'site_mode' => $site === 'new' ? 'new' : substr(preg_replace('/[^A-Za-z0-9_\-]/', '', $site), 0, 64),
            'site_name' => trim(substr((string)($in['omada_site_name'] ?? ''), 0, 64)),
            'scenario' => trim(substr(preg_replace('/[^\x20-\x7E]/', '', (string)($in['omada_scenario'] ?? '')), 0, 64)),
            'sn' => strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', (string)($in['omada_sn'] ?? '')), 0, 32)),
            'voucher_mode' => ($in['voucher_mode'] ?? '') === 'omada' ? 'omada' : 'radius',
            'pkg_id' => $pkg === 'starter' ? -1 : max(0, (int)$pkg),
            'qty' => max(0, min(500, (int)($in['prov_qty'] ?? 0))),
        ];
    }
    /** Save the EAP225 login used for adding / adopting it (factory default admin/admin). */
    static function saveDeviceCreds(int $deviceId, string $user, string $pass): void {
        $user = trim(substr($user, 0, 64));
        if ($user === '') return;
        // prov_adopt_at=NULL → the next "Start provisioning" tick adopts straight away with the new login
        run("UPDATE hs_devices SET prov_user=?, prov_pass=?, prov_adopt_at=NULL WHERE id=?", 'ssi', $user, sealSecret(substr($pass, 0, 64)), $deviceId);
    }
    static function deviceCreds(array $d): array {
        $u = trim((string)($d['prov_user'] ?? ''));
        $p = openSecret($d['prov_pass'] ?? '');
        return [$u !== '' ? $u : 'admin', $p !== '' ? $p : 'admin'];
    }
    /** Omada site name rules: 1-64 chars, must not start with space + - @ = and must not end with a space. */
    static function siteName(string $s, int $id): string {
        $s = rtrim(substr(ltrim(preg_replace('/[\x00-\x1F]/', '', $s), " +-@="), 0, 64));
        return $s !== '' ? $s : 'SkyTanza-' . $id;
    }
    /** Device account (username/password) Omada pushes to every AP of sites this system creates — generated once per controller. */
    static function siteAccount(array $ctl): array {
        $u = trim((string)($ctl['site_dev_user'] ?? ''));
        $p = openSecret($ctl['site_dev_pass'] ?? '');
        if ($u !== '' && $p !== '') return [$u, $p];
        $u = 'skyadmin'; $p = genDevicePassword();
        run("UPDATE hs_controllers SET site_dev_user=?, site_dev_pass=? WHERE id=?", 'ssi', $u, sealSecret($p), $ctl['id']);
        return [$u, $p];
    }
    /** Days the Omada portal keeps a client authorised — at least the seller's longest package (RADIUS Session-Timeout still ends each session on time). */
    static function authTimeoutDays(int $uid): int {
        $max = (int)val("SELECT COALESCE(MAX(duration_minutes),0) FROM hs_packages WHERE seller_id=? AND is_active=1", 'i', $uid);
        return max(1, min(1000, (int)ceil(max(1440, $max) / 1440)));
    }
    private static function finish(int $deviceId, string $state, array $log): array {
        $fails = count(array_filter($log, fn($x) => $x['status'] === 'fail'));
        run("UPDATE hs_devices SET prov_state=IF(prov_state='done' AND ?='ready', 'done', ?), prov_log=?, prov_at=NOW() WHERE id=?", 'sssi',
            $state, $state, json_encode($log, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $deviceId);
        return ['ok' => $fails === 0, 'state' => $state, 'log' => $log, 'fails' => $fails];
    }
    /** Store the live Omada record (status, model, IP...) on the hotspot. */
    static function applyRecord(array $d, array $o, int $ctlId, string $site): void {
        run("UPDATE hs_devices SET controller_id=?, omada_site_id=?, omada_status=?, omada_status_at=NOW(), omada_online_at=IF(?='connected', NOW(), omada_online_at),
             omada_clients=?, omada_model=?, omada_ip=?, omada_fw=?, omada_uptime=?, omada_sn=IF(?<>'', ?, omada_sn) WHERE id=?", 'isssissssssi',
            $ctlId, $site, $o['status'], $o['status'], (int)$o['clients'], substr((string)$o['model'], 0, 64), substr((string)$o['ip'], 0, 45),
            substr((string)$o['fw'], 0, 80), substr((string)$o['uptime'], 0, 64), substr((string)$o['sn'], 0, 32), substr((string)$o['sn'], 0, 32), $d['id']);
    }

    /**
     * Save an Omada controller from a form. The Inform URL alone is enough (Omada ID + API address are read from it);
     * v5.5: forms no longer ask for Client ID / Client Secret (modern Omada Cloud does not show them); keys saved by older
     * versions are kept unchanged. The same Inform URL is never saved twice for a seller. Returns ['ok', 'id', 'msg' (HTML-safe)].
     */
    static function saveController(array $in, int $uid, bool $isAdmin, int $cid = 0): array {
        // v6.1 — own Omada Controller only. Controller URL, Omada ID, Client ID and Client Secret are REQUIRED.
        $fail = fn(string $m) => ['ok' => false, 'id' => $cid, 'msg' => h($m)];
        $old = $cid ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $cid, $uid) : null;
        if ($cid && !$old) return $fail('Not found');
        $informIn = trim((string)($in['inform_url'] ?? ''));
        $inf = $informIn !== '' ? parseInformUrl($informIn) : null;
        if ($informIn !== '' && !$inf) return $fail(t('ctrl_inform_invalid'));
        if ($inf && $inf['cloud']) return $fail(t('ctrl_cloud_unsupported'));
        if (!$old && $inf && ($dup = row("SELECT * FROM hs_controllers WHERE user_id=? AND inform_url=? LIMIT 1", 'is', $uid, $inf['raw']))) { $old = $dup; $cid = (int)$dup['id']; }
        $base = omadaControllerBase((string)($in['base_url'] ?? ''));   // v6.1.2: always https://IP:8043 (the Open API is HTTPS only)
        if ($base === '' && $inf) $base = informApiBase($inf);   // https://<controller IP>:8043
        if ($base === '') return $fail(t('ctrl_url_invalid'));
        if (OmadaRelay::isCloudHost((string)parse_url($base, PHP_URL_HOST))) return $fail(t('ctrl_cloud_unsupported'));
        if (!$old && ($dup = row("SELECT * FROM hs_controllers WHERE user_id=? AND base_url=? LIMIT 1", 'is', $uid, $base))) { $old = $dup; $cid = (int)$dup['id']; }
        $omadac = substr(preg_replace('/[^A-Za-z0-9]/', '', (string)($in['omadac_id'] ?? '')), 0, 64);
        if ($omadac === '' && $inf) $omadac = $inf['omadac_id'];
        if ($omadac === '' && $old && strtolower((string)parse_url((string)$old['base_url'], PHP_URL_HOST)) === strtolower((string)parse_url($base, PHP_URL_HOST)))
            $omadac = (string)($old['omadac_id'] ?? '');
        // v6.1.2: an empty Omada ID is read from https://IP:8043/api/info by the connection test below
        // Client ID + Client Secret (blank secret on edit = keep the saved one)
        $clientId = substr(trim((string)($in['client_id'] ?? '')), 0, 128);
        if ($clientId === '' && $old) $clientId = (string)($old['client_id'] ?? '');
        $secret = substr(trim((string)($in['client_secret'] ?? '')), 0, 255);
        if ($secret === '' && $old) $secret = (string)$old['client_secret'];
        // platform keys (shared_keys) stay managed by the admin; typing your own keys replaces them
        $shared = $old && !empty($old['shared_keys']) && trim((string)($in['client_id'] ?? '')) === '' && trim((string)($in['client_secret'] ?? '')) === '' ? 1 : 0;
        if ($clientId === '' || $secret === '') return $fail(t('ctrl_required'));
        if (preg_match('/[^\x21-\x7E]/', $clientId . $secret)) return $fail(t('ctrl_client_id') . ' / ' . t('ctrl_client_secret') . ': invalid characters (copy them again from Omada)');
        $why = null; $ipx = null;
        $connMode = in_array($in['conn_mode'] ?? '', ['auto', 'direct', 'relay'], true) ? (string)$in['conn_mode'] : (string)($old['conn_mode'] ?? 'auto');
        if (!OmadaApi::hostAllowed($base, false, $ipx, $why)                                                 // v6.1.2: public controller address only
            && !($connMode !== 'direct' && strpos((string)$why, 'Cannot resolve') === 0))                     // the RADIUS box resolves it
            return $fail((string)$why);
        $name = trim(substr((string)($in['name'] ?? ''), 0, 100));
        if ($name === '' && $old) $name = (string)$old['name'];
        if ($name === '') $name = 'Omada Controller ' . (string)parse_url($base, PHP_URL_HOST);
        $host = (string)parse_url($base, PHP_URL_HOST);
        // v6.1.2: the Inform URL always points to THIS controller's host (an old one for another host is replaced)
        $oldInf = $old ? parseInformUrl((string)$old['inform_url']) : null;
        $inform = $inf ? $inf['raw'] : ($oldInf && !$oldInf['cloud'] && $oldInf['host'] === strtolower($host)
            ? (string)$old['inform_url'] : 'omada://' . strtolower($host) . '?dPort=29810&mPort=29814' . ($omadac !== '' ? '&omadacId=' . $omadac : ''));
        $defInf = parseInformUrl(defaultInformUrl());
        if (!$inf && $defInf && $defInf['host'] === strtolower($host)) $inform = $defInf['raw'];   // same controller as the platform default
        $verify = !empty($in['verify_ssl']) ? 1 : 0;   // self-hosted controllers usually have a self-signed certificate
        $type = 'local';
        if ($old) {
            $changed = $old['base_url'] !== $base || (string)$old['omadac_id'] !== $omadac || (string)$old['client_id'] !== $clientId || (string)$old['client_secret'] !== $secret;
            run("UPDATE hs_controllers SET name=?, ctype=?, base_url=?, omadac_id=?, client_id=?, client_secret=?, inform_url=?, verify_ssl=?, region=NULL" . ($changed ? ", access_token=NULL, token_expires=NULL, paths_json=NULL, sites_json=NULL" : '') . " WHERE id=? AND user_id=?",
                'sssssssiii', $name, $type, $base, $omadac, $clientId, $secret, $inform, $verify, $cid, $uid);
        } else {
            q("INSERT INTO hs_controllers (user_id,name,ctype,base_url,omadac_id,client_id,client_secret,inform_url,verify_ssl) VALUES (?,?,?,?,?,?,?,?,?)",
                'isssssssi', $uid, $name, $type, $base, $omadac, $clientId, $secret, $inform, $verify);
            $cid = (int)db()->insert_id;
        }
        try { run("UPDATE hs_controllers SET conn_mode=?, shared_keys=?, direct_fail_at=NULL WHERE id=? AND user_id=?", 'siii', $connMode, $shared, $cid, $uid); }
        catch (Throwable $e) { error_log('saveController v5.9 columns: ' . $e->getMessage()); }
        if ($inform !== '' && $inform === defaultInformUrl()) applyDefaultOmadaKeys($uid);   // the default controller gets the platform keys
        logActivity($uid, 'omada_controller_save', $name . ' ' . $base . ' (Open API)');
        run("UPDATE hs_controllers SET last_sync=NULL WHERE id=?", 'i', $cid);   // routers refresh their Omada status on the next page view
        $api = OmadaApi::load($cid, $uid);
        if (OmadaApi::$deadline === null) OmadaApi::$deadline = microtime(true) + workBudget(45);
        $t = $api->test();
        return ['ok' => true, 'id' => $cid, 'test_ok' => $t['ok'], 'msg' => implode('<br>', array_map('h', $t['lines']))];
    }

    /** Run (or re-run) the complete Omada setup for one hotspot. Returns ['ok', 'state', 'log', 'fails']. */
    /** True when this request is close to the host's time limit — the setup stops cleanly and "Run setup again" continues it. */
    static function outOfTime(): bool { return OmadaApi::$deadline !== null && microtime(true) > OmadaApi::$deadline - 3; }

    static function run(int $deviceId, int $uid, ?array $opt = null): array {
        if (OmadaApi::$deadline === null) OmadaApi::$deadline = microtime(true) + workBudget(150);
        $d = Device::get($deviceId, $uid);
        if (!$d) return ['ok' => false, 'state' => 'failed', 'log' => [['step' => 'device', 'status' => 'fail', 'msg' => 'Device not found', 'at' => date('H:i:s')]], 'fails' => 1];
        $saved = json_decode((string)($d['prov_opts'] ?? ''), true) ?: [];
        $opt = ($opt ?? []) + $saved + self::optsFromInput([]);
        $keep = $opt; unset($keep['qty'], $keep['pkg_id']);            // a re-run never creates vouchers again unless asked
        $mode = $opt['voucher_mode'];
        run("UPDATE hs_devices SET voucher_mode=?, prov_opts=?, omada_sn=IF(?<>'', ?, omada_sn) WHERE id=?", 'ssssi',
            $mode, json_encode($keep, JSON_UNESCAPED_UNICODE), $opt['sn'], $opt['sn'], $deviceId);
        $d = Device::get($deviceId, $uid);
        $log = [];
        $L = function (string $step, string $st, string $msg) use (&$log): void { $log[] = ['step' => $step, 'status' => $st, 'msg' => substr($msg, 0, 500), 'at' => date('H:i:s')]; };
        $ctl = $d['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $d['controller_id'], $uid) : null;
        $api = null; $site = (string)$d['omada_site_id']; $portalId = ''; $apiWhy = '';
        $late = false;
        $go = function () use (&$late, $L): bool {          // false once the time budget is used up
            if (!$late && self::outOfTime()) { $late = true; $L('server', 'fail', t('prov_time_up')); }
            return !$late;
        };
        try {
        if (!$ctl) $L('controller', 'fail', $apiWhy = t('ctrl_not_linked'));
        elseif (!OmadaApi::canApi($ctl)) $L('controller', 'fail', $apiWhy = t('prov_need_keys'));
        else {
            $api = new OmadaApi($ctl);
            if ($api->token() === '') { $L('controller', 'fail', $apiWhy = $api->error); $api = null; }
            else $L('controller', 'ok', t('prov_api_ok') . ' • ' . $ctl['name']);
        }
        if ($api) {
            // 1 — SITE
            if ($site === '') {
                if ($opt['site_mode'] !== 'new' && $opt['site_mode'] !== '' && $api->siteAllowed($opt['site_mode'])) { $site = $opt['site_mode']; $L('site', 'ok', t('prov_site_existing') . ': ' . $site); }
                else {
                    $name = self::siteName($opt['site_name'] !== '' ? $opt['site_name'] : (string)$d['device_name'], (int)$d['id']);
                    if ($api->sharedScope()) {   // v5.9: one controller for many sellers — the site name carries the seller's username
                        $un = (string)val("SELECT username FROM users WHERE id=?", 'i', $uid);
                        if ($un !== '' && stripos($name, $un . '-') !== 0) $name = self::siteName($un . '-' . $name, (int)$d['id']);
                    }
                    $ex = $api->siteByName($name);
                    if ($ex && $ex['id'] !== '') { $site = $ex['id']; $L('site', 'ok', t('prov_site_reused') . ': ' . $name); }
                    else {
                        [$du, $dp] = self::siteAccount($ctl);
                        $scen = $opt['scenario'];
                        if ($scen === '') {
                            $list = $api->scenarios();
                            foreach (['Hotel', 'Restaurant', 'Cafe', 'Shop', 'Office'] as $pref) if (in_array($pref, $list, true)) { $scen = $pref; break; }
                            if ($scen === '') $scen = $list[0] ?? 'Office';
                        }
                        $r = $api->createSite($name, getSetting('omada_site_region', 'Tanzania'), getSetting('omada_site_timezone', 'Africa/Nairobi'), $scen, $du, $dp);
                        if ($r['ok']) { $site = $r['id']; $L('site', 'ok', t('prov_site_created') . ': ' . $name . ' (' . $scen . ')'); }
                        else $L('site', 'fail', $r['msg']);
                    }
                    if ($site !== '') run("UPDATE hs_devices SET site_name=? WHERE id=?", 'si', $name, $d['id']);
                }
                if ($site !== '') { run("UPDATE hs_devices SET omada_site_id=? WHERE id=?", 'si', $site, $d['id']); $d['omada_site_id'] = $site; }
            } else $L('site', 'ok', t('prov_site_existing') . ': ' . ($d['site_name'] ?: $site));
            if ($site !== '') {
                if ($go()) self::stepDevice($api, $d, $site, $opt, $L);
                $radiusId = ($mode === 'radius' && $go()) ? self::stepRadius($api, $d, $site, $L) : '';
                $ssid = $go() ? self::stepSsid($api, $d, $site, $L) : '';
                if ($ssid !== '' && ($mode === 'omada' || $radiusId !== '') && $go()) $portalId = self::stepPortal($api, $d, $site, $ssid, $radiusId, $mode, $L);
                elseif (!$late) $L('portal', 'skip', t('prov_portal_waits'));
                if ($mode === 'radius' && $portalId !== '' && $go()) self::stepPreAuth($api, $site, $L);
            }
        }
        if ($mode === 'radius' || $go()) self::stepVouchers($api, $site, Device::get($deviceId, $uid) ?? $d, $opt, $mode, $portalId, $L, $uid, $apiWhy);
        } catch (Throwable $e) {
            // never a blank HTTP 500: the error goes into the setup log and the EAP225 stays saved
            error_log('OmadaProvision #' . $deviceId . ': ' . $e->getMessage() . ' @' . $e->getLine());
            $L('server', 'fail', $e->getMessage());
        }
        $fails = count(array_filter($log, fn($x) => $x['status'] === 'fail'));
        $state = !$api ? 'failed' : ($fails ? 'partial' : 'ready');
        logActivity($uid, 'omada_setup', $d['device_name'] . ' → ' . $state);
        return self::finish($deviceId, $state, $log);
    }

    private static function addStatusText(int $code): string {
        return [0 => 'OK', -51451 => 'serial number not found — check the S/N on the label', -52201 => 'device is offline — it is added as soon as it reaches the cloud',
            -52202 => 'device is already bound to another Omada account — unbind it there first', -52208 => 'device went offline while being added'][$code] ?? 'status ' . $code;
    }
    private static function stepDevice(OmadaApi $api, array $d, string $site, array $opt, callable $L): void {
        foreach ($api->devices($site) as $od) if ($od['mac'] === $d['ap_mac']) {
            self::applyRecord($d, $od, $api->id(), $site);
            $L('device', 'ok', t('prov_dev_in_site') . ' • ' . strtoupper(str_replace('_', ' ', $od['status'])));
            return;
        }
        $sn = $opt['sn'] !== '' ? $opt['sn'] : strtoupper((string)$d['omada_sn']);
        if ($sn === '') { $L('device', 'skip', t('prov_no_sn')); return; }
        [$u, $p] = self::deviceCreds($d);
        $r = $api->addBySerial($site, $sn, '', (string)$d['device_name'], $u, $p);
        if (!$r['ok']) { $L('device', 'skip', t('prov_no_sn') . ' (' . $r['msg'] . ')'); return; }
        $msg = t('prov_dev_added') . ' • S/N ' . $sn;
        $op = is_array($r['result']) ? (string)($r['result']['operateId'] ?? '') : '';
        for ($i = 0; $op !== '' && $i < 4 && !self::outOfTime(); $i++) {
            pauseMs(1500);
            $s = $api->addStatus($site, $op);
            if (!$s['ok'] || !is_array($s['result'])) break;
            $devs = (array)($s['result']['devices'] ?? []);
            $dev = is_array($devs[0] ?? null) ? $devs[0] : [];
            if (isset($dev['status']) && !in_array((int)$dev['status'], [1, 2], true)) {
                $code = (int)$dev['status'];
                $msg .= ' • ' . self::addStatusText($code);
                if (!in_array($code, [0, -52201, -52208], true)) { $L('device', 'fail', $msg); return; }
                break;
            }
            if ((int)($s['result']['processStatus'] ?? 0) === 2) break;
        }
        $L('device', 'ok', $msg);
    }
    private static function stepRadius(OmadaApi $api, array $d, string $site, callable $L): string {
        $c = Device::radiusConfig($d);
        if ($c['server_ip'] === '') { $L('radius', 'fail', t('radius_ip_missing')); return ''; }
        $name = self::RADIUS_PREFIX . (int)$d['id'];
        $dae = getSetting('dae_enabled', '1') === '1';
        $body = ['name' => $name,
            'authServer' => [['radiusServerIp' => $c['server_ip'], 'radiusPort' => (int)$c['auth_port'], 'radiusPwd' => $c['auth_secret']]],
            'radiusAccountingEnable' => true, 'interimUpdateEnable' => true, 'interimUpdateInterval' => max(60, (int)$c['interim']),
            'acctServer' => [['accountingServerIp' => $c['acct_ip'] ?: $c['server_ip'], 'accountingServerPort' => (int)$c['acct_port'], 'accountingServerPwd' => $c['acct_secret']]],
            'wirelessVlanAssignment' => false, 'coaEnable' => $dae, 'requireMessageAuthenticator' => true];
        if ($dae) $body['coaPassword'] = $c['auth_secret'];
        $find = function () use ($api, $site, $name, $d): string {
            foreach ($api->radiusProfiles($site) as $p) {
                $pid = (string)($p['radiusProfileId'] ?? $p['id'] ?? '');
                if ($pid !== '' && ($pid === (string)$d['omada_radius_id'] || ($p['name'] ?? '') === $name)) return $pid;
            }
            return '';
        };
        $min = ['name' => $name, 'authServer' => $body['authServer'], 'radiusAccountingEnable' => true, 'acctServer' => $body['acctServer'],
            'interimUpdateEnable' => true, 'interimUpdateInterval' => $body['interimUpdateInterval']];
        $variants = [$body, array_diff_key($body, ['requireMessageAuthenticator' => 1]), array_diff_key($body, ['requireMessageAuthenticator' => 1, 'coaEnable' => 1, 'coaPassword' => 1]), $min];
        $id = $find();
        if ($id !== '') { $r = OmadaApi::firstOk(fn($b) => $api->updateRadiusProfile($site, $id, $b), $variants); $what = t('prov_updated'); }
        else {
            $r = OmadaApi::firstOk(fn($b) => $api->createRadiusProfile($site, $b), $variants); $what = t('prov_created');
            if ($r['ok']) $id = is_string($r['result']) ? $r['result'] : (is_array($r['result']) ? (string)($r['result']['radiusProfileId'] ?? $r['result']['id'] ?? '') : '');
            if ($r['ok'] && $id === '') $id = $find();
        }
        if (!$r['ok'] || $id === '') { $L('radius', 'fail', $r['ok'] ? 'RADIUS profile ID not returned' : $r['msg']); return ''; }
        run("UPDATE hs_devices SET omada_radius_id=? WHERE id=?", 'si', $id, $d['id']);
        $L('radius', 'ok', t('prov_radius_ok') . ' (' . $what . '): ' . $name . ' → ' . $c['server_ip'] . ':' . $c['auth_port'] . '/' . $c['acct_port']);
        return $id;
    }
    private static function ssidBody(string $name): array {
        return ['name' => $name, 'deviceType' => 1, 'band' => 3, 'guestNetEnable' => true, 'security' => 0, 'broadcast' => true, 'vlanEnable' => false,
            'mloEnable' => false, 'pmfMode' => 3, 'enable11r' => false, 'hidePwd' => false];
    }
    /** v5.7 — the same SSID in several shapes (older / newer Omada firmware). $psk = '' → open hotspot SSID; else WPA2-Personal. */
    static function ssidBodies(string $name, string $psk = '', bool $guest = true, int $band = 3): array {
        $base = ['name' => $name, 'deviceType' => 1, 'band' => $band, 'guestNetEnable' => $guest, 'broadcast' => true, 'vlanEnable' => false];
        if ($psk === '') $sec = ['security' => 0];
        else $sec = ['security' => 3, 'pskSetting' => ['securityKey' => $psk, 'versionPsk' => 2, 'encryptionPsk' => 3, 'gikRekeyPskEnable' => false]];
        $full = $base + $sec + ['mloEnable' => false, 'pmfMode' => $psk === '' ? 3 : 2, 'enable11r' => false, 'hidePwd' => false];
        return [$full, $base + $sec + ['hidePwd' => false], $base + $sec, ['name' => $name, 'band' => $band, 'guestNetEnable' => $guest] + $sec];
    }
    private static function stepSsid(OmadaApi $api, array $d, string $site, callable $L): string {
        $name = trim((string)$d['ssid']) !== '' ? trim((string)$d['ssid']) : 'SKY WIFI';
        $name = function_exists('mb_strcut') ? mb_strcut($name, 0, 32, 'UTF-8') : substr($name, 0, 32);
        $groups = $api->wlanGroups($site);
        if (!$groups && $api->error !== '') { $L('ssid', 'fail', $api->error); return ''; }
        $wlan = '';
        foreach ($groups as $g) if ((string)($g['wlanId'] ?? '') === (string)$d['omada_wlan_id']) $wlan = (string)$g['wlanId'];
        if ($wlan === '') foreach ($groups as $g) if (!empty($g['primary'])) { $wlan = (string)$g['wlanId']; break; }
        if ($wlan === '' && $groups) $wlan = (string)($groups[0]['wlanId'] ?? '');
        if ($wlan === '') {
            $r = $api->createWlanGroup($site, 'SkyTanza');
            if (!$r['ok']) { $L('ssid', 'fail', $r['msg']); return ''; }
            foreach ($api->wlanGroups($site) as $g) if (($g['name'] ?? '') === 'SkyTanza') $wlan = (string)$g['wlanId'];
            if ($wlan === '') { $L('ssid', 'fail', 'WLAN group ID not returned'); return ''; }
        }
        $find = function (bool $byIdFirst) use ($api, $site, $wlan, $name, $d): array {
            $list = $api->ssidList($site, $wlan);
            if ($byIdFirst) foreach ($list as $s) if ((string)($s['ssidId'] ?? '') !== '' && (string)$s['ssidId'] === (string)$d['omada_ssid_id']) return $s;
            foreach ($list as $s) if ((string)($s['name'] ?? '') === $name) return $s;
            return [];
        };
        $s = $find(true);
        if ($s && (string)$s['name'] !== $name) {                 // seller renamed the WiFi → rename it in Omada
            $r = OmadaApi::firstOk(fn($b) => $api->updateSsidBasic($site, $wlan, (string)$s['ssidId'], $b), self::ssidBodies($name, '', (bool)($s['guestNetEnable'] ?? true), (int)($s['band'] ?? 3) ?: 3));
            $L('ssid', $r['ok'] ? 'ok' : 'fail', $r['ok'] ? t('prov_ssid_ok') . ' (' . t('prov_updated') . '): ' . $name : $r['msg']);
        } elseif ($s) $L('ssid', 'ok', t('prov_ssid_ok') . ': ' . $name);
        else {
            $r = OmadaApi::firstOk(fn($b) => $api->createSsid($site, $wlan, $b), self::ssidBodies($name));
            if (!$r['ok']) { $L('ssid', 'fail', $r['msg']); return ''; }
            pauseMs(600);
            $s = $find(false);
            if (!$s) { $L('ssid', 'fail', 'SSID created but not found in the WLAN group'); return ''; }
            $L('ssid', 'ok', t('prov_ssid_ok') . ' (' . t('prov_created') . '): ' . $name . ' • 2.4 + 5 GHz • open + guest isolation');
        }
        run("UPDATE hs_devices SET omada_wlan_id=?, omada_ssid_id=? WHERE id=?", 'ssi', $wlan, (string)$s['ssidId'], $d['id']);
        return (string)$s['ssidId'];
    }
    private static function stepPortal(OmadaApi $api, array $d, string $site, string $ssidId, string $radiusId, string $mode, callable $L): string {
        $name = self::PORTAL_PREFIX . (int)$d['id'];
        $u = parse_url(portalUrl());
        $scheme = in_array($u['scheme'] ?? '', ['http', 'https'], true) ? $u['scheme'] : 'https';
        $ext = ($u['host'] ?? '') . (isset($u['port']) ? ':' . (int)$u['port'] : '') . ($u['path'] ?? '/index.php');
        $body = ['name' => $name, 'enable' => true, 'ssidList' => self::portalSsids($d, $ssidId), 'httpsRedirectEnable' => false, 'landingPage' => 1,
            'authTimeout' => ['customTimeout' => self::authTimeoutDays((int)$d['user_id']), 'customTimeoutUnit' => 3]];
        if ($mode === 'radius') {
            $body['authType'] = 2;
            $body['externalRadius'] = ['radiusProfileId' => $radiusId, 'authMode' => 1, 'nasId' => (string)$d['nas_id'], 'portalCustom' => 2,
                'externalUrlScheme' => $scheme, 'externalUrl' => $ext, 'disconnectReq' => getSetting('dae_enabled', '1') === '1', 'receiverPort' => RADIUS_DAE_PORT];
        } else {
            $body['authType'] = 11;
            $body['hotspot'] = ['enabledTypes' => [3]];
        }
        $find = function () use ($api, $site, $name, $d): string {
            foreach ($api->portals($site) as $p) {
                $pid = (string)($p['id'] ?? '');
                if ($pid !== '' && ($pid === (string)$d['omada_portal_id'] || ($p['name'] ?? '') === $name)) return $pid;
            }
            return '';
        };
        $lean = array_diff_key($body, ['httpsRedirectEnable' => 1, 'landingPage' => 1, 'authTimeout' => 1]);
        $variants = [$body, $lean];
        if ($mode === 'radius') {
            $fullUrl = $lean;   // some firmware expects the complete URL in externalUrl
            $fullUrl['externalRadius']['externalUrl'] = $scheme . '://' . $ext;
            $variants[] = $fullUrl;
            $noDae = $lean;
            unset($noDae['externalRadius']['disconnectReq'], $noDae['externalRadius']['receiverPort']);
            $variants[] = $noDae;
        }
        $id = $find();
        if ($id !== '') { $r = OmadaApi::firstOk(fn($b) => $api->updatePortal($site, $id, $b), $variants); $what = t('prov_updated'); }
        else { $r = OmadaApi::firstOk(fn($b) => $api->createPortal($site, $b), $variants); $what = t('prov_created'); if ($r['ok']) { pauseMs(600); $id = $find(); } }
        if (!$r['ok'] || $id === '') { $L('portal', 'fail', $r['ok'] ? 'Portal created but not found in the portal list' : $r['msg']); return ''; }
        run("UPDATE hs_devices SET omada_portal_id=? WHERE id=?", 'si', $id, $d['id']);
        if ($mode === 'radius') {
            // The NAS ID is now set by this system → the RADIUS server and Disconnect-Requests use it directly.
            run("UPDATE hs_devices SET omada_nas_id=nas_id, nas_learned_at=NOW() WHERE id=?", 'i', $d['id']);
            $L('portal', 'ok', t('prov_portal_ok') . ' (' . $what . '): External RADIUS • PAP • NAS ID ' . $d['nas_id'] . ' • ' . $scheme . '://' . $ext);
        } else $L('portal', 'ok', t('prov_portal_ok') . ' (' . $what . '): Hotspot → Voucher');
        return $id;
    }
    /** v6.3 — main hotspot SSID + the seller's extra "hotspot" SSIDs (all of them open the same portal). */
    static function portalSsids(array $d, string $mainId): array {
        $ids = [$mainId];
        foreach ((json_decode((string)($d['extra_ssids'] ?? ''), true) ?: []) as $x)
            if (is_array($x) && ($x['type'] ?? '') === 'hotspot' && (string)($x['id'] ?? '') !== '') $ids[] = (string)$x['id'];
        return array_values(array_unique(array_filter($ids, fn($v) => $v !== '')));
    }
    /** v6.3 — re-apply only the portal (after the seller adds / removes a hotspot SSID). Returns ['ok', 'msg']. */
    static function refreshPortal(int $deviceId, int $uid): array {
        $d = Device::get($deviceId, $uid);
        if (!$d) return ['ok' => false, 'msg' => 'Device not found'];
        $ctl = $d['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $d['controller_id'], $uid) : null;
        if (!OmadaApi::canApi($ctl) || (string)$d['omada_site_id'] === '' || (string)$d['omada_ssid_id'] === '') return ['ok' => false, 'msg' => t('ssid_need_setup')];
        $mode = ($d['voucher_mode'] ?? 'radius') === 'omada' ? 'omada' : 'radius';
        $rid = $mode === 'radius' ? (string)$d['omada_radius_id'] : '';
        if ($mode === 'radius' && $rid === '') return ['ok' => false, 'msg' => t('prov_portal_waits')];
        $log = [];
        $L = function (string $step, string $st, string $msg) use (&$log): void { $log[] = ['step' => $step, 'status' => $st, 'msg' => $msg]; };
        $pid = self::stepPortal(new OmadaApi($ctl), $d, (string)$d['omada_site_id'], (string)$d['omada_ssid_id'], $rid, $mode, $L);
        $last = end($log);
        return ['ok' => $pid !== '', 'msg' => is_array($last) ? (string)$last['msg'] : ''];
    }

    private static function stepPreAuth(OmadaApi $api, string $site, callable $L): void {
        $host = (string)parse_url(appUrl(), PHP_URL_HOST);
        if ($host === '') { $L('preauth', 'skip', 'Website host unknown'); return; }
        $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : resolveHost($host);
        $r = $api->accessControl($site);
        if (!$r['ok']) { $L('preauth', 'fail', $r['msg']); return; }
        $cur = is_array($r['result']) ? $r['result'] : [];
        $pre = array_values(array_filter((array)($cur['preAuthAccessPolicies'] ?? []), 'is_array'));
        $have = fn(int $type, string $v) => (bool)array_filter($pre, fn($p) => (int)($p['type'] ?? 0) === $type && strcasecmp((string)($type === 2 ? ($p['url'] ?? '') : ($p['ip'] ?? '')), $v) === 0);
        $added = [];
        if (!$have(2, $host)) { $pre[] = ['type' => 2, 'url' => $host, 'description' => 'SkyTanza portal']; $added[] = $host; }
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && $ip !== $host && !$have(1, $ip)) { $pre[] = ['type' => 1, 'ip' => $ip, 'subnetMask' => 32, 'description' => 'SkyTanza portal IP']; $added[] = $ip . '/32'; }
        // v6.6.1 — the HTTPS browserauth domain (omada.skytanzania.co.tz) must also open before login
        $ah = strtolower((string)parse_url(omadaPortalAuthUrl(), PHP_URL_HOST));
        if ($ah !== '' && strcasecmp($ah, $host) !== 0) {
            $aip = filter_var($ah, FILTER_VALIDATE_IP) ? $ah : resolveHost($ah);
            if (!filter_var($ah, FILTER_VALIDATE_IP) && !$have(2, $ah)) { $pre[] = ['type' => 2, 'url' => $ah, 'description' => 'SkyTanza browserauth']; $added[] = $ah; }
            if (filter_var($aip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && $aip !== $ip && !$have(1, $aip)) { $pre[] = ['type' => 1, 'ip' => $aip, 'subnetMask' => 32, 'description' => 'SkyTanza browserauth IP']; $added[] = $aip . '/32'; }
        }
        if (!$added && !empty($cur['preAuthAccessEnable'])) { $L('preauth', 'ok', t('prov_preauth_ok') . ': ' . $host); return; }
        $body = ['preAuthAccessEnable' => true, 'preAuthAccessPolicies' => $pre, 'freeAuthClientEnable' => (bool)($cur['freeAuthClientEnable'] ?? false)];
        if (!empty($cur['freeAuthClientPolicies'])) $body['freeAuthClientPolicies'] = $cur['freeAuthClientPolicies'];
        $w = $api->setAccessControl($site, $body);
        $L('preauth', $w['ok'] ? 'ok' : 'fail', $w['ok'] ? t('prov_preauth_ok') . ': ' . implode(', ', $added ?: [$host]) : $w['msg']);
    }
    /** Starter packages for a brand-new seller (created only when missing, by name). */
    private static function starterPackages(int $uid): array {
        $out = [];
        foreach (self::STARTER as $i => [$name, $price, $min, $days]) {
            $p = row("SELECT * FROM hs_packages WHERE seller_id=? AND name=?", 'is', $uid, $name);
            if (!$p) {
                q("INSERT INTO hs_packages (seller_id,name,price,duration_minutes,time_mode,data_limit_mb,speed_down_mbps,speed_up_mbps,max_devices,validity_days,show_on_portal,is_active,sort_order)
                   VALUES (?,?,?,?,'continuous',0,5,2,1,?,1,1,?)", 'isdiii', $uid, $name, $price, $min, $days, $i + 1);
                $p = row("SELECT * FROM hs_packages WHERE id=?", 'i', db()->insert_id);
            }
            if ($p) $out[] = $p;
        }
        return $out;
    }
    private static function stepVouchers(?OmadaApi $api, string $site, array $d, array $opt, string $mode, string $portalId, callable $L, int $uid, string $apiWhy = ''): void {
        $qty = (int)$opt['qty']; $pkgId = (int)$opt['pkg_id'];
        if ($qty <= 0 || $pkgId === 0) { $L('vouchers', 'skip', t('prov_no_vouchers')); return; }
        $pkgs = $pkgId === -1 ? self::starterPackages($uid) : array_filter([row("SELECT * FROM hs_packages WHERE id=? AND seller_id=?", 'ii', $pkgId, $uid)]);
        if (!$pkgs) { $L('vouchers', 'fail', 'Package not found'); return; }
        foreach ($pkgs as $p) {
            if ($mode === 'omada') {
                // v6.1.1: say WHY (controller unreachable / no site yet) instead of always blaming missing keys
                if (!$api) { $L('vouchers', 'skip', t('prov_vouchers_wait') . ($apiWhy !== '' ? ' — ' . $apiWhy : '')); return; }
                if ($site === '') { $L('vouchers', 'skip', t('prov_vouchers_wait') . ' — ' . t('prov_no_site')); return; }
                $r = self::omadaVouchers($api, $site, $d, $p, $qty, $portalId);
                $L('vouchers', $r['ok'] ? 'ok' : 'fail', $r['msg']);
            } else {
                $r = Vouchers::generate((int)$p['id'], $uid, $qty);
                $L('vouchers', !empty($r['success']) ? 'ok' : 'fail', !empty($r['success']) ? count($r['codes']) . ' × ' . $p['name'] . ' • ' . t('batch') . ' ' . $r['batch'] : (string)($r['message'] ?? 'error'));
            }
        }
    }
    /**
     * Create an Omada Hotspot voucher group from a package, read its codes and keep a copy (source = omada) so the seller can print them here.
     * Package → voucher group: duration (voucher duration), time counting, devices per voucher (limited online users), speed, data, price, validity.
     */
    static function omadaVouchers(OmadaApi $api, string $site, array $d, array $p, int $qty, string $portalId = ''): array {
        $down = (int)round((float)$p['speed_down_mbps'] * 1000); $up = (int)round((float)$p['speed_up_mbps'] * 1000);
        $body = ['name' => rtrim(substr('SKY ' . $p['name'], 0, 20)) . ' ' . date('dHi') . strtoupper(bin2hex(random_bytes(1))), 'amount' => max(1, min(5000, $qty)),
            'codeLength' => max(6, min(10, (int)getSetting('voucher_length', '8'))), 'codeForm' => [0, 1],
            'limitType' => 1, 'limitNum' => max(1, min(999, (int)$p['max_devices'])),
            'durationType' => 1, 'duration' => max(1, (int)$p['duration_minutes']), 'timingType' => $p['time_mode'] === 'online' ? 1 : 0,
            'rateLimit' => ['mode' => 0, 'customRateLimit' => ['downLimitEnable' => $down > 0, 'downLimit' => max(0, $down), 'upLimitEnable' => $up > 0, 'upLimit' => max(0, $up)]],
            'trafficLimitEnable' => (int)$p['data_limit_mb'] > 0, 'applyToAllPortals' => $portalId === '', 'logout' => true,
            'description' => substr('SkyTanza WiFi • ' . $d['device_name'], 0, 120), 'printComments' => substr('WiFi: ' . ($d['ssid'] ?: SITE_NAME), 0, 100)];
        if ((int)$p['data_limit_mb'] > 0) { $body['trafficLimit'] = min(10485760, (int)$p['data_limit_mb']); $body['trafficLimitFrequency'] = 0; }
        if ($portalId !== '') $body['portals'] = [$portalId];
        $validUntil = null;
        if ((int)$p['validity_days'] > 0) {
            $exp = time() + (int)$p['validity_days'] * 86400;
            $body += ['validityType' => 1, 'effectiveTime' => time() * 1000, 'expirationTime' => $exp * 1000];
            $validUntil = date('Y-m-d H:i:s', $exp);
        } else $body['validityType'] = 0;
        if ((float)$p['price'] >= 1) { $body['unitPrice'] = (int)round((float)$p['price']); $body['currency'] = CURRENCY; }
        $r = $api->createVoucherGroup($site, $body);
        if (!$r['ok'] && isset($body['currency'])) { unset($body['unitPrice'], $body['currency']); $r = $api->createVoucherGroup($site, $body); }
        if (!$r['ok']) return ['ok' => false, 'msg' => $r['msg']];
        $gid = is_array($r['result']) ? (string)($r['result']['id'] ?? '') : (string)$r['result'];
        $codes = [];
        for ($i = 0; $gid !== '' && $i < 4 && !$codes; $i++) { if ($i) pauseMs(1000); $codes = $api->voucherCodes($site, $gid); }
        if ($gid === '' || !$codes) return ['ok' => false, 'msg' => t('prov_omada_vouchers_nocodes') . ($api->error !== '' ? ' — ' . $api->error : '')];
        $batch = 'OM' . date('ymdHi') . strtoupper(bin2hex(random_bytes(1)));
        $n = 0;
        foreach ($codes as $code) {
            $n += q("INSERT IGNORE INTO hs_vouchers (package_id,seller_id,device_id,code,batch,price,duration_minutes,time_mode,data_limit_mb,speed_down_mbps,speed_up_mbps,max_devices,status,source,valid_until,ext_ref)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'available','omada',?,?)", 'iiissdisiddiss',
                $p['id'], $d['user_id'], $d['id'], substr($code, 0, 20), $batch, $p['price'], $p['duration_minutes'], $p['time_mode'], $p['data_limit_mb'],
                $p['speed_down_mbps'], $p['speed_up_mbps'], $p['max_devices'], $validUntil, $gid)->affected_rows;
        }
        run("UPDATE hs_devices SET omada_vgroup_id=? WHERE id=?", 'si', $gid, $d['id']);
        return ['ok' => true, 'batch' => $batch, 'count' => $n, 'msg' => sprintf(t('prov_omada_vouchers'), $n, $p['name']) . ' • ' . t('batch') . ' ' . $batch];
    }

    /**
     * One "Start provisioning" tick, called every few seconds by the browser while the seller watches.
     * EAP225 not in the site yet → wait (Inform URL) · PENDING → adopt with the EAP225 login · ADOPTING / PROVISIONING → wait · CONNECTED → done.
     */
    static function tick(int $deviceId, int $uid): array {
        $d = Device::get($deviceId, $uid);
        $out = fn(string $phase, string $msg, bool $done = false, array $x = []) => ['ok' => true, 'phase' => $phase, 'msg' => $msg, 'done' => $done] + $x;
        if (!$d) return ['ok' => false, 'phase' => 'error', 'msg' => 'Device not found', 'done' => true];
        $ctl = $d['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $d['controller_id'], $uid) : null;
        if (!$ctl || !OmadaApi::canApi($ctl)) return ['ok' => false, 'phase' => 'error', 'msg' => t('prov_need_keys'), 'done' => true];   // v6.1: Open API required
        $api = new OmadaApi($ctl);
        $site = (string)$d['omada_site_id'];
        if ($site === '') return ['ok' => false, 'phase' => 'error', 'msg' => t('prov_no_site'), 'done' => true];
        run("UPDATE hs_devices SET prov_state='provisioning' WHERE id=? AND (prov_state IS NULL OR prov_state NOT IN ('done'))", 'i', $d['id']);
        $list = $api->devices($site);
        if (!$list && $api->error !== '') return ['ok' => false, 'phase' => 'error', 'msg' => $api->error, 'done' => false];
        $od = null;
        foreach ($list as $x) if ($x['mac'] === $d['ap_mac']) { $od = $x; break; }
        if (!$od) {
            // The EAP225 has not reached this site yet. With a serial number, (re)try adding it once a minute.
            if ((string)$d['omada_sn'] !== '' && (empty($d['prov_adopt_at']) || time() - strtotime($d['prov_adopt_at']) > 60)) {
                [$u, $p] = self::deviceCreds($d);
                $api->addBySerial($site, (string)$d['omada_sn'], '', (string)$d['device_name'], $u, $p);
                run("UPDATE hs_devices SET prov_adopt_at=NOW() WHERE id=?", 'i', $d['id']);
            }
            return $out('waiting', t('prov_wait_inform'));
        }
        self::applyRecord($d, $od, $api->id(), $site);
        $extra = ['status' => $od['status'], 'model' => $od['model'], 'ip' => $od['ip'], 'fw' => $od['fw']];
        switch ($od['status']) {
            case 'connected':
                if (($d['prov_state'] ?? '') !== 'done') {
                    run("UPDATE hs_devices SET prov_state='done' WHERE id=?", 'i', $d['id']);
                    Notify::add($uid, 'Hotspot live', $d['device_name'] . ' CONNECTED • ' . ($od['model'] ?: 'EAP225'), 'success', '?page=hotspot&id=' . (int)$d['id'], 'wifi');
                    logActivity($uid, 'omada_provisioned', $d['device_name'] . ' ' . $d['ap_mac']);
                }
                return $out('connected', t('prov_done') . ($od['ip'] !== '' ? ' • IP ' . $od['ip'] : ''), true, $extra);
            case 'pending':
            case 'adopt_failed':
                if ($od['status'] === 'adopt_failed' && !empty($d['prov_adopt_at'])) {   // same login already failed → ask for the right one
                    $ar = $api->adoptResult($site, $d['ap_mac']);
                    if ($ar['ok'] && is_array($ar['result']) && (int)($ar['result']['adoptErrorCode'] ?? 0) === -39003) return $out('need_login', t('prov_bad_dev_pass'), false, $extra + ['need_login' => true]);
                }
                if (empty($d['prov_adopt_at']) || time() - strtotime($d['prov_adopt_at']) > 25) {
                    [$u, $p] = self::deviceCreds($d);
                    run("UPDATE hs_devices SET prov_adopt_at=NOW() WHERE id=?", 'i', $d['id']);
                    $r = $api->adopt($site, $d['ap_mac'], $u, $p);
                    if (!$r['ok']) return $out('adopting', $r['msg'], false, $extra);
                    if ((int)($r['adopt_result']['adoptErrorCode'] ?? 0) === -39003) return $out('need_login', t('prov_bad_dev_pass'), false, $extra + ['need_login' => true]);
                }
                return $out('adopting', t('prov_adopting'), false, $extra);
            case 'adopting':
                return $out('adopting', t('prov_adopting'), false, $extra);
            case 'provisioning':
                return $out('provisioning', t('prov_provisioning'), false, $extra);
            case 'managed_by_others':
                return $out('error', t('prov_managed_others'), false, $extra);
            default:
                return $out('offline', sprintf(t('prov_offline'), strtoupper(str_replace('_', ' ', $od['status']))), false, $extra);
        }
    }
}

// ============================================================
// v5.7 — OMADA LINK ENGINE: checks that Router ↔ Omada controller ↔ RADIUS server ↔ website really talk to each
// other, explains every broken link in plain words and repairs what the Open API can repair (idempotent re-setup).
// ============================================================
final class OmadaLink
{
    const LABELS = ['website', 'radius_ip', 'radius_box', 'router', 'cloud', 'relay', 'api', 'site', 'device', 'ssid', 'radius_profile', 'portal', 'preauth', 'portal_reach', 'radius_traffic'];

    /** First value of $key anywhere inside a nested Omada record (field placement differs between firmware versions). */
    static function deep($a, string $key) {
        if (!is_array($a)) return null;
        if (array_key_exists($key, $a)) return $a[$key];
        foreach ($a as $v) if (is_array($v)) { $r = self::deep($v, $key); if ($r !== null) return $r; }
        return null;
    }

    /** Run every check for one router. Returns rows [key, status ok|warn|fail|skip, msg, fix]. Saved on the router for the pages. */
    static function check(int $deviceId, int $uid, int $budget = 45): array {
        $d = Device::get($deviceId, $uid);
        if (!$d) return [];
        if (!$d['nas_id'] || !$d['radius_secret'] || !$d['acct_secret']) { Device::ensureCredentials($deviceId); $d = Device::get($deviceId, $uid); }
        $prev = OmadaApi::$deadline;
        OmadaApi::$deadline = min($prev ?? PHP_FLOAT_MAX, microtime(true) + workBudget($budget));
        $out = [];
        $add = function (string $k, string $st, string $msg, string $fix = '') use (&$out): void { $out[] = ['key' => $k, 'status' => $st, 'msg' => substr($msg, 0, 400), 'fix' => $fix]; };
        try {
            // 1 — website / portal URL
            $url = appUrl();
            $add('website', stripos($url, 'https://') === 0 ? 'ok' : 'warn', portalUrl() . (stripos($url, 'https://') === 0 ? '' : ' — ' . t('hl_http_warn')), 'admin');
            // 2 — RADIUS server IP (what Omada must send to)
            $rip = getSetting('radius_server_ip');
            $add('radius_ip', $rip !== '' ? 'ok' : 'fail', $rip !== '' ? $rip . ' • UDP ' . RADIUS_AUTH_PORT . '/' . RADIUS_ACCT_PORT : t('radius_ip_missing'), 'admin');
            // 3 — RADIUS server box ↔ website
            $seen = (int)getSetting('radius_server_seen', '0');
            $info = json_decode(getSetting('radius_server_info'), true) ?: [];
            if (radiusApiKeyWeak()) $add('radius_box', 'fail', t('hl_key_weak'), 'admin');
            elseif ($seen > time() - 180) {
                $v = (string)($info['version'] ?? '?');
                $add('radius_box', version_compare($v, '5.1.0', '>=') ? 'ok' : 'warn', 'v' . $v . ' • ' . ($info['host'] ?? '?') . ' • ' . t('contact_from') . ' ' . ($info['ip'] ?? '?'), 'admin');
                $boxIp = (string)($info['ip'] ?? '');
                if ($rip !== '' && $boxIp !== '' && $boxIp !== $rip && filter_var($rip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))
                    $add('radius_ip', 'warn', sprintf(t('hl_ip_mismatch'), $boxIp, $rip), 'admin');
            } else $add('radius_box', 'fail', t('hl_box_down') . ($seen ? ' (' . fmtSecs(time() - $seen) . ')' : ''), 'admin');
            // 4 — this router's RADIUS passwords (and what the RADIUS box saw from Omada)
            $bad = array_filter((array)($info['badpw'] ?? []), fn($x) => is_array($x) && strtoupper((string)($x['key'] ?? '')) === strtoupper((string)$d['nas_id']) && (int)($x['ts'] ?? time()) > time() - 900);
            if ($bad) foreach ($bad as $b) $add('router', 'fail', sprintf(t('hl_badpw'), (string)($b['kind'] ?? 'password')) . ' (' . ($b['ip'] ?? '') . ')', 'setup');
            else $add('router', 'ok', sprintf(t('hl_secrets_ok'), $d['omada_nas_id'] ?: $d['nas_id']));
            // 5 — Omada Cloud / controller link
            $ctl = $d['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $d['controller_id'], $uid) : null;
            if (!$ctl) $add('cloud', 'fail', t('ctrl_not_linked'), 'link');
            else $add('cloud', informUrlOf($ctl) !== '' ? 'ok' : 'warn', $ctl['name'] . ' • ' . (informUrlOf($ctl) ?: t('not_set')), 'link');
            // v5.9 — self-hosted controller: the website reaches it through the RADIUS server (Omada relay)
            if ($ctl && (OmadaRelay::routeOf($ctl) === 'relay' || (!OmadaRelay::isCloudHost((string)parse_url((string)$ctl['base_url'], PHP_URL_HOST)) && ($ctl['conn_mode'] ?? 'auto') !== 'direct'))) {
                $ri = OmadaRelay::info();
                $add('relay', OmadaRelay::alive() ? 'ok' : 'fail', OmadaRelay::alive() ? OmadaRelay::label() . ' • v' . ($ri['version'] ?? '?') : t('relay_down') . ' — ' . t('relay_off_help'), 'admin');
            }
            // 6..12 — everything inside Omada (needs the Open API keys)
            if ($ctl && OmadaApi::canApi($ctl)) self::checkOmada(new OmadaApi($ctl), $d, $rip, $add);
            else foreach (['api', 'ssid', 'radius_profile', 'portal', 'preauth'] as $k) $add($k, 'skip', $k === 'api' ? t('prov_need_keys') : t('hl_manual'), $k === 'api' ? 'keys' : 'sheet');
            // 13 — phones reach the external portal (Omada redirect works)
            $d = Device::get($deviceId, $uid) ?? $d;
            if (!empty($d['portal_seen_at']) && strtotime($d['portal_seen_at']) > time() - 86400 * 7)
                $add('portal_reach', 'ok', sprintf(t('hl_portal_reach_ok'), date('d M H:i', strtotime($d['portal_seen_at'])), $d['portal_target'] ?: '—'));
            else $add('portal_reach', 'warn', t('hl_portal_reach_none'), 'sheet');
            // 14 — the EAP225 / Omada really sends RADIUS packets to our server
            if (!empty($d['last_seen']) && time() - strtotime($d['last_seen']) < 600)
                $add('radius_traffic', 'ok', sprintf(t('hl_traffic_ok'), $d['radius_src_ip'] ?: '?', date('H:i:s', strtotime($d['last_seen']))));
            else $add('radius_traffic', 'warn', t('hl_traffic_none') . ($d['last_seen'] ? ' • ' . t('last_seen') . ': ' . date('d M H:i', strtotime($d['last_seen'])) : ''), 'sheet');
        } catch (Throwable $e) {
            error_log('OmadaLink::check #' . $deviceId . ': ' . $e->getMessage());
            $add('api', 'fail', $e->getMessage());
        } finally { OmadaApi::$deadline = $prev; }
        try { run("UPDATE hs_devices SET health_json=?, health_at=NOW() WHERE id=?", 'si', json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $deviceId); }
        catch (Throwable $e) { error_log('OmadaLink save: ' . $e->getMessage()); }
        return $out;
    }

    private static function checkOmada(OmadaApi $api, array $d, string $rip, callable $add): void {
        if ($api->token() === '') { $add('api', 'fail', $api->error . $api->essentialsHint(), 'keys'); return; }
        $add('api', 'ok', t('prov_api_ok') . ' • Omada ID ' . ($api->row()['omadac_id'] ?? '?'));
        // site
        $site = (string)$d['omada_site_id'];
        $sites = $api->sites();
        if ($site === '') { $add('site', 'fail', t('prov_no_site'), 'setup'); return; }
        if ($sites && !in_array($site, array_column($sites, 'id'), true)) { $add('site', 'fail', t('hl_site_missing') . ' (' . $site . ')', 'setup'); return; }
        $sname = $site;
        foreach ($sites as $s) if ($s['id'] === $site) $sname = $s['name'];
        $add('site', 'ok', $sname);
        // device in the site
        $od = null;
        foreach ($api->devices($site) as $x) if ($x['mac'] === $d['ap_mac']) { $od = $x; break; }
        if (!$od) $add('device', 'fail', t('hl_dev_missing') . ' — ' . t('prov_wait_inform'), 'adopt');
        else {
            OmadaProvision::applyRecord($d, $od, $api->id(), $site);
            [$lbl] = Device::omadaBadge($od['status']);
            $add('device', $od['status'] === 'connected' ? 'ok' : (in_array($od['status'], ['pending', 'adopting', 'provisioning'], true) ? 'warn' : 'fail'),
                $lbl . ($od['model'] ? ' • ' . $od['model'] : '') . ($od['ip'] ? ' • ' . $od['ip'] : '') . ' • ' . (int)$od['clients'] . ' client(s)', 'adopt');
        }
        if (($d['voucher_mode'] ?? 'radius') === 'omada') { $add('radius_profile', 'skip', t('vm_omada')); }
        // SSID
        $want = trim((string)$d['ssid']) !== '' ? trim((string)$d['ssid']) : 'SKY WIFI';
        $ssid = null;
        foreach ($api->allSsids($site) as $x) if ($x['ssid_id'] === (string)$d['omada_ssid_id'] || $x['name'] === $want) { $ssid = $x; if ($x['name'] === $want) break; }
        if (!$ssid) $add('ssid', 'fail', sprintf(t('hl_ssid_missing'), $want), 'setup');
        elseif ($ssid['security'] !== 0) $add('ssid', 'warn', sprintf(t('hl_ssid_secured'), $ssid['name']), 'setup');
        else $add('ssid', 'ok', $ssid['name'] . ' • ' . ($ssid['guest'] ? t('ssid_guest') . ' • ' : '') . t('ssid_open'));
        // RADIUS profile
        $profId = '';
        if (($d['voucher_mode'] ?? 'radius') !== 'omada') {
            $prof = null;
            foreach ($api->radiusProfiles($site) as $p) {
                $pid = (string)($p['radiusProfileId'] ?? $p['id'] ?? '');
                if ($pid !== '' && ($pid === (string)$d['omada_radius_id'] || ($p['name'] ?? '') === OmadaProvision::RADIUS_PREFIX . (int)$d['id'])) { $prof = $p; $profId = $pid; break; }
            }
            if (!$prof) $add('radius_profile', 'fail', t('hl_profile_missing'), 'setup');
            else {
                $ip = (string)(self::deep($prof, 'radiusServerIp') ?? '');
                $port = (int)(self::deep($prof, 'radiusPort') ?? RADIUS_AUTH_PORT);
                $aip = (string)(self::deep($prof, 'accountingServerIp') ?? '');
                $acctIp = getSetting('acct_server_ip') ?: $rip;
                if ($ip === '') $add('radius_profile', 'ok', ($prof['name'] ?? '') . ' (' . t('hl_details_hidden') . ')');
                elseif ($ip !== $rip || $port !== RADIUS_AUTH_PORT || ($aip !== '' && $aip !== $acctIp))
                    $add('radius_profile', 'fail', sprintf(t('hl_profile_wrong'), $ip . ':' . $port . ($aip !== '' ? ' / ' . $aip : ''), $rip . ':' . RADIUS_AUTH_PORT), 'setup');
                else $add('radius_profile', 'ok', ($prof['name'] ?? '') . ' → ' . $ip . ':' . $port . '/' . RADIUS_ACCT_PORT);
            }
        }
        // portal
        $portal = null;
        foreach ($api->portals($site) as $p) {
            $pid = (string)($p['id'] ?? '');
            if ($pid !== '' && ($pid === (string)$d['omada_portal_id'] || ($p['name'] ?? '') === OmadaProvision::PORTAL_PREFIX . (int)$d['id'])) { $portal = $p; break; }
        }
        if (!$portal) $add('portal', 'fail', t('hl_portal_missing'), 'setup');
        else {
            $problems = [];
            if (isset($portal['enable']) && !$portal['enable']) $problems[] = t('hl_portal_off');
            $list = self::deep($portal, 'ssidList');
            if (is_array($list) && $ssid && $list && !in_array($ssid['ssid_id'], array_map('strval', $list), true)) $problems[] = t('hl_portal_ssid');
            if (($d['voucher_mode'] ?? 'radius') !== 'omada') {
                $nas = self::deep($portal, 'nasId');
                if ($nas !== null && (string)$nas !== '' && strcasecmp((string)$nas, (string)$d['nas_id']) !== 0 && strcasecmp((string)$nas, (string)$d['omada_nas_id']) !== 0)
                    $problems[] = sprintf(t('hl_portal_nas'), (string)$nas, $d['nas_id']);
                $rp = self::deep($portal, 'radiusProfileId');
                if ($rp !== null && $profId !== '' && (string)$rp !== $profId) $problems[] = t('hl_profile_missing');
                $ext = (string)(self::deep($portal, 'externalUrl') ?? '');
                $host = (string)parse_url(appUrl(), PHP_URL_HOST);
                if ($ext !== '' && $host !== '' && stripos($ext, $host) === false) $problems[] = 'External Web Portal URL: ' . $ext . ' ≠ ' . portalUrl();
            }
            $add('portal', $problems ? 'fail' : 'ok', $problems ? implode(' • ', $problems) : ($portal['name'] ?? '') . ' • NAS ID ' . $d['nas_id'], 'setup');
        }
        // pre-authentication access
        if (($d['voucher_mode'] ?? 'radius') !== 'omada') {
            $r = $api->accessControl($site);
            $host = (string)parse_url(appUrl(), PHP_URL_HOST);
            if (!$r['ok']) $add('preauth', 'warn', $r['msg'], 'setup');
            else {
                $cur = is_array($r['result']) ? $r['result'] : [];
                $has = false;
                foreach ((array)($cur['preAuthAccessPolicies'] ?? []) as $p) if (is_array($p) && strcasecmp((string)($p['url'] ?? ''), $host) === 0) $has = true;
                $add('preauth', $has && !empty($cur['preAuthAccessEnable']) ? 'ok' : 'fail', $has && !empty($cur['preAuthAccessEnable']) ? $host : t('hl_preauth_missing'), 'setup');
            }
        }
    }

    /** Saved result of the last check (no network). */
    static function saved(array $d): array { return json_decode((string)($d['health_json'] ?? ''), true) ?: []; }
    /** [ok, warn, fail] counts. */
    static function counts(array $rows): array {
        $c = ['ok' => 0, 'warn' => 0, 'fail' => 0, 'skip' => 0];
        foreach ($rows as $r) $c[$r['status']] = ($c[$r['status']] ?? 0) + 1;
        return $c;
    }
    /** Status of one hop of the chain Phone → EAP225 → Omada → RADIUS → Website from the saved checks. */
    static function hop(array $rows, array $keys): string {
        $st = 'skip';
        foreach ($rows as $r) if (in_array($r['key'], $keys, true)) {
            if ($r['status'] === 'fail') return 'fail';
            if ($r['status'] === 'warn') $st = 'warn';
            elseif ($r['status'] === 'ok' && $st === 'skip') $st = 'ok';
        }
        return $st;
    }

    /** Repair: re-run the idempotent Omada setup (no vouchers), push the adoption once, then check again. */
    static function repair(int $deviceId, int $uid): array {
        $res = OmadaProvision::run($deviceId, $uid, ['qty' => 0, 'pkg_id' => 0]);
        ProvisionLog::add($deviceId, $uid, 'setup', (string)$res['state'], 'auto-repair: ' . t('prov_state_' . $res['state']));
        if ($res['state'] !== 'manual' && !OmadaProvision::outOfTime()) {
            try { $t = OmadaProvision::tick($deviceId, $uid); ProvisionLog::add($deviceId, $uid, 'connect', (string)($t['phase'] ?? ''), (string)($t['msg'] ?? ''), true); }
            catch (Throwable $e) { error_log('repair tick: ' . $e->getMessage()); }
        }
        OmadaApi::$deadline = null;
        return ['setup' => $res, 'checks' => self::check($deviceId, $uid)];
    }

    /**
     * Push the current RADIUS settings (server IP, passwords, portal) into every Omada router with Open API keys that was
     * set up before $since. $uid = 0 → all sellers (admin). Stops before the host time limit; returns [done, still pending].
     */
    static function pushAll(int $uid, int $since): array {
        $sql = "SELECT d.id, d.user_id FROM hs_devices d JOIN hs_controllers c ON c.id=d.controller_id AND c.user_id=d.user_id
                WHERE c.client_id IS NOT NULL AND c.client_id<>'' AND c.client_secret IS NOT NULL AND c.client_secret<>''
                  AND d.omada_site_id IS NOT NULL AND d.omada_site_id<>'' AND (d.prov_at IS NULL OR d.prov_at < FROM_UNIXTIME(?))";
        $list = $uid ? rows($sql . " AND d.user_id=? ORDER BY d.id", 'ii', $since, $uid) : rows($sql . " ORDER BY d.id", 'i', $since);
        OmadaApi::$deadline = microtime(true) + workBudget(150);
        $done = 0;
        foreach ($list as $r) {
            if (OmadaProvision::outOfTime() || microtime(true) > OmadaApi::$deadline - 20) break;
            $res = OmadaProvision::run((int)$r['id'], (int)$r['user_id'], ['qty' => 0, 'pkg_id' => 0]);
            ProvisionLog::add((int)$r['id'], (int)$r['user_id'], 'setup', (string)$res['state'], 'sync: ' . t('prov_state_' . $res['state']));
            $done++;
        }
        OmadaApi::$deadline = null;
        return [$done, max(0, count($list) - $done)];
    }
}

// ============================================================
// v6.0 — OMADA MANAGER: one page that runs the whole Omada side through the Omada Open API (Client Credentials mode),
// for an Omada Software Controller on your VPS, an OC200/OC300 or Omada Cloud:
//   • Sites    — list, create (owned by the seller), delete, live counts
//   • EAP225   — add by serial number, adopt PENDING, rename, locate, reboot, forget, turn into a hotspot (+ full auto-setup)
//   • Vouchers — Omada Hotspot voucher groups: create from a package, import groups made in Omada, print, see each code's
//                state (unused / in use / expired), sync that state back into the website, delete a code or a whole group
//   • Clients  — live phones per site with block / unblock / reconnect
// Only public OmadaApi calls are used, so every request goes direct or through the RADIUS-box relay exactly like v5.9.
// ============================================================
final class OmadaManager
{
    const SYNC_EVERY = 300;   // seconds between automatic voucher-state syncs per seller

    static function sp(string $site, string $rest = ''): string { return '/v1/sites/' . rawurlencode($site) . $rest; }

    /** Controllers of this user that have Open API keys (Client ID + Client Secret). */
    static function controllers(int $uid): array {
        try { return array_values(array_filter(rows("SELECT * FROM hs_controllers WHERE user_id=? ORDER BY id", 'i', $uid), fn($c) => OmadaApi::canApi($c))); }
        catch (Throwable $e) { return []; }
    }
    static function api(int $ctrlId, int $uid): ?OmadaApi {
        $a = $ctrlId ? OmadaApi::load($ctrlId, $uid) : null;
        return ($a && OmadaApi::canApi($a->row())) ? $a : null;
    }
    /** First request [method, path, body] the controller accepts (paths differ a little between Omada versions). */
    static function tryCalls(OmadaApi $api, array $calls, int $timeout = 0): array {
        $first = null;
        foreach ($calls as [$m, $p, $b]) {
            if (OmadaApi::$deadline !== null && microtime(true) > OmadaApi::$deadline - 3) break;
            $r = $api->call($m, $p, [], $b, $timeout);
            if (!empty($r['ok'])) return $r;
            $first = $first ?? $r;
            if ((int)($r['http'] ?? 0) === 0) break;   // no answer at all — another path will not help
        }
        return $first ?? ['ok' => false, 'msg' => 'no request sent', 'result' => null, 'code' => -1];
    }

    // ---------------------------------------------------------------- sites
    static function ownsSite(int $uid, string $siteId): bool {
        if ($siteId === '' || $uid <= 0) return false;
        try { return (bool)val("SELECT 1 FROM hs_omada_sites WHERE user_id=? AND site_id=? LIMIT 1", 'is', $uid, $siteId); } catch (Throwable $e) { return false; }
    }
    static function rememberSite(int $uid, int $ctrlId, string $siteId, string $name): void {
        try { q("INSERT INTO hs_omada_sites (user_id, ctrl_id, site_id, name) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE ctrl_id=VALUES(ctrl_id), name=VALUES(name)", 'iiss',
            $uid, $ctrlId, substr($siteId, 0, 64), substr($name, 0, 100)); } catch (Throwable $e) { error_log('OmadaManager::rememberSite: ' . $e->getMessage()); }
    }
    /** Create (or reuse) an Omada site. Sellers on the platform keys get their username in front of the name. */
    static function createSite(OmadaApi $api, int $uid, string $name, string $scenario = ''): array {
        $name = OmadaProvision::siteName($name, random_int(100, 999));
        if ($api->sharedScope()) {
            $un = (string)val("SELECT username FROM users WHERE id=?", 'i', $uid);
            if ($un !== '' && stripos($name, $un . '-') !== 0) $name = OmadaProvision::siteName($un . '-' . $name, random_int(100, 999));
        }
        if ($ex = $api->siteByName($name)) {
            if (!$api->siteAllowed($ex['id'])) return ['ok' => false, 'id' => '', 'name' => $name, 'msg' => t('ctrl_site_not_yours')];
            self::rememberSite($uid, $api->id(), $ex['id'], $name);
            return ['ok' => true, 'id' => $ex['id'], 'name' => $name, 'msg' => t('prov_site_reused')];
        }
        [$du, $dp] = OmadaProvision::siteAccount($api->row());
        if ($scenario === '') {
            $list = $api->scenarios();
            foreach (['Hotel', 'Restaurant', 'Cafe', 'Shop', 'Office'] as $pref) if (in_array($pref, $list, true)) { $scenario = $pref; break; }
            if ($scenario === '') $scenario = $list[0] ?? 'Office';
        }
        $r = $api->createSite($name, getSetting('omada_site_region', 'Tanzania'), getSetting('omada_site_timezone', 'Africa/Nairobi'), $scenario, $du, $dp);
        if ($r['ok']) self::rememberSite($uid, $api->id(), $r['id'], $name);
        return $r + ['name' => $name];
    }
    /** Delete a site in Omada and unlink everything of this seller that pointed to it. */
    static function deleteSite(OmadaApi $api, int $uid, string $siteId): array {
        $r = $api->call('DELETE', self::sp($siteId), [], null, 30);
        if ($r['ok']) {
            run("UPDATE hs_devices SET omada_site_id=NULL, omada_wlan_id=NULL, omada_ssid_id=NULL, omada_radius_id=NULL, omada_portal_id=NULL, omada_vgroup_id=NULL,
                 omada_status=NULL, prov_state=NULL WHERE user_id=? AND controller_id=? AND omada_site_id=?", 'iis', $uid, $api->id(), $siteId);
            run("DELETE FROM hs_omada_sites WHERE user_id=? AND site_id=?", 'is', $uid, $siteId);
            run("UPDATE hs_vouchers v JOIN hs_omada_vgroups g ON g.group_id=v.ext_ref AND g.user_id=v.seller_id SET v.status='cancelled'
                 WHERE g.user_id=? AND g.site_id=? AND v.source='omada' AND v.status IN ('available','sold','active')", 'is', $uid, $siteId);
            run("DELETE FROM hs_omada_vgroups WHERE user_id=? AND site_id=?", 'is', $uid, $siteId);
            run("UPDATE hs_controllers SET sites_json=NULL WHERE id=?", 'i', $api->id());
        }
        return $r;
    }
    /** Counts for the overview tiles. */
    static function siteStats(array $devices, array $clients): array {
        $s = ['devices' => count($devices), 'connected' => 0, 'pending' => 0, 'offline' => 0, 'clients' => count($clients)];
        foreach ($devices as $d) {
            if ($d['status'] === 'connected') $s['connected']++;
            elseif (in_array($d['status'], ['pending', 'adopting', 'provisioning', 'adopt_failed'], true)) $s['pending']++;
            else $s['offline']++;
        }
        return $s;
    }

    // ---------------------------------------------------------------- devices
    static function forget(OmadaApi $api, string $site, string $mac): array {
        $m = rawurlencode(dashMac(normMac($mac)));
        return self::tryCalls($api, [['POST', self::sp($site, "/devices/$m/forget"), null], ['DELETE', self::sp($site, "/devices/$m"), null]], 20);
    }
    static function rename(OmadaApi $api, string $site, string $mac, string $name): array {
        $m = rawurlencode(dashMac(normMac($mac)));
        $b = ['name' => $name];
        return self::tryCalls($api, [['PATCH', self::sp($site, "/aps/$m/general-config"), $b], ['PATCH', self::sp($site, "/devices/$m/general-config"), $b],
            ['PATCH', self::sp($site, "/devices/$m"), $b]], 20);
    }

    // ---------------------------------------------------------------- Omada Hotspot vouchers
    static function num(array $a, array $keys): int { foreach ($keys as $k) if (isset($a[$k]) && is_numeric($a[$k])) return (int)$a[$k]; return 0; }
    static function mapGroup(array $g): array {
        $ct = $g['createdTime'] ?? $g['createTime'] ?? null;
        return ['id' => (string)($g['id'] ?? $g['groupId'] ?? ''), 'name' => (string)($g['name'] ?? ''),
            'total' => self::num($g, ['totalCount', 'amount', 'total', 'totalAmount']), 'unused' => self::num($g, ['unusedCount', 'unused']),
            'in_use' => self::num($g, ['inUseCount', 'inUse', 'usingCount']), 'used' => self::num($g, ['usedCount', 'used']),
            'expired' => self::num($g, ['expiredCount', 'expired']), 'duration' => self::num($g, ['duration']), 'limit' => max(1, self::num($g, ['limitNum'])),
            'timing' => self::num($g, ['timingType']), 'price' => self::num($g, ['unitPrice']),
            'created' => is_numeric($ct) ? date('Y-m-d H:i', (int)((float)$ct > 1e11 ? (float)$ct / 1000 : (float)$ct)) : (string)$ct];
    }
    /** Omada voucher state → unused | in_use | expired (0 unused, 1 in use, 2 expired; text values too). */
    static function vStatus(array $v): string {
        $s = $v['status'] ?? $v['voucherStatus'] ?? 0;
        if (is_numeric($s)) return [0 => 'unused', 1 => 'in_use', 2 => 'expired', 3 => 'expired'][(int)$s] ?? 'unused';
        $s = strtolower(str_replace([' ', '_', '-'], '', (string)$s));
        if ($s === '' || strpos($s, 'unused') !== false || $s === 'new') return 'unused';
        if (strpos($s, 'expir') !== false || strpos($s, 'invalid') !== false || $s === 'used') return 'expired';
        return 'in_use';
    }
    /** Voucher groups of a site (all pages). Error text in $api->error. */
    static function groups(OmadaApi $api, string $site): array {
        $api->error = ''; $all = [];
        for ($page = 1; $page <= 20; $page++) {
            $r = $api->call('GET', self::sp($site, '/hotspot/voucher-groups'), ['page' => $page, 'pageSize' => 100], null, 20);
            if (!$r['ok']) { if ($page === 1) $api->error = $r['msg']; break; }
            $list = OmadaApi::listOf($r['result']);
            foreach ($list as $g) if (is_array($g)) { $m = self::mapGroup($g); if ($m['id'] !== '') $all[] = $m; }
            $total = (int)(is_array($r['result']) ? ($r['result']['totalRows'] ?? count($all)) : count($all));
            if (!$list || count($all) >= $total) break;
        }
        return $all;
    }
    /** One group with every code and its state. Falls back to the "print unused" list on controllers without the detail call. */
    static function groupDetail(OmadaApi $api, string $site, string $gid): array {
        $out = ['ok' => false, 'group' => ['id' => $gid], 'vouchers' => [], 'msg' => ''];
        for ($page = 1; $page <= 10; $page++) {
            $r = $api->call('GET', self::sp($site, '/hotspot/voucher-groups/' . rawurlencode($gid)), ['page' => $page, 'pageSize' => 1000], null, 30);
            if (!$r['ok']) { $out['msg'] = $r['msg']; break; }
            $res = is_array($r['result']) ? $r['result'] : [];
            if ($page === 1) $out['group'] = $res + ['id' => $gid];
            $list = $res['data'] ?? ($res['vouchers']['data'] ?? ($res['vouchers'] ?? []));
            if (!is_array($list)) $list = [];
            foreach ($list as $v) if (is_array($v) && (string)($v['code'] ?? '') !== '')
                $out['vouchers'][] = ['id' => (string)($v['id'] ?? $v['voucherId'] ?? ''), 'code' => (string)$v['code'], 'status' => self::vStatus($v)];
            $out['ok'] = true;
            $total = (int)($res['totalRows'] ?? ($res['vouchers']['totalRows'] ?? count($out['vouchers'])));
            if (!$list || count($out['vouchers']) >= $total) break;
        }
        if (!$out['vouchers']) {
            foreach ($api->voucherCodes($site, $gid) as $c) $out['vouchers'][] = ['id' => '', 'code' => $c, 'status' => 'unused'];
            if ($out['vouchers']) { $out['ok'] = true; $out['msg'] = ''; }
        }
        return $out;
    }
    static function rememberGroup(int $uid, int $ctrlId, string $site, string $gid, string $name, ?int $pkgId, string $batch, int $amount): void {
        try { q("INSERT INTO hs_omada_vgroups (user_id, ctrl_id, site_id, group_id, name, package_id, batch, amount) VALUES (?,?,?,?,?,?,?,?)
                 ON DUPLICATE KEY UPDATE ctrl_id=VALUES(ctrl_id), site_id=VALUES(site_id), name=VALUES(name), batch=VALUES(batch), amount=VALUES(amount)", 'iisssisi',
            $uid, $ctrlId, substr($site, 0, 64), substr($gid, 0, 64), substr($name, 0, 100), $pkgId ?: null, substr($batch, 0, 20), $amount); }
        catch (Throwable $e) { error_log('OmadaManager::rememberGroup: ' . $e->getMessage()); }
    }
    /** Copy Omada's state of each code into the website (unused stays, in use → active, expired → expired). Returns changed rows. */
    static function applyStatuses(int $uid, array $vouchers): int {
        $n = 0;
        foreach ($vouchers as $v) {
            $code = substr((string)$v['code'], 0, 20);
            if ($v['id'] !== '') run("UPDATE hs_vouchers SET ext_vid=? WHERE seller_id=? AND source='omada' AND code=? AND (ext_vid IS NULL OR ext_vid<>?)", 'siss', $v['id'], $uid, $code, $v['id']);
            if ($v['status'] === 'in_use') {
                $chg = run("UPDATE hs_vouchers SET status='active', first_used_at=COALESCE(first_used_at,NOW()), sold_at=COALESCE(sold_at,NOW()), last_seen=NOW()
                           WHERE seller_id=? AND source='omada' AND code=? AND status IN ('available','sold')", 'is', $uid, $code);
                $n += $chg;
                if ($chg) {   // v6.4: an Omada voucher in use counts in the seller's balance
                    $cvid = (int)val("SELECT id FROM hs_vouchers WHERE seller_id=? AND source='omada' AND code=? LIMIT 1", 'is', $uid, $code);
                    if ($cvid) Earnings::creditVoucher($cvid);
                }
            }
            elseif ($v['status'] === 'expired')
                $n += run("UPDATE hs_vouchers SET status='expired' WHERE seller_id=? AND source='omada' AND code=? AND status IN ('available','sold','active')", 'is', $uid, $code);
        }
        return $n;
    }
    /** A router of this seller in that site (for device_id / SSID on printed cards), preferring Omada-voucher hotspots. */
    static function siteRouter(int $uid, int $ctrlId, string $site): ?array {
        return row("SELECT * FROM hs_devices WHERE user_id=? AND controller_id=? AND omada_site_id=? ORDER BY (voucher_mode='omada') DESC, id LIMIT 1", 'iis', $uid, $ctrlId, $site);
    }
    /** Create a voucher group in Omada from one of the seller's packages and keep the codes for printing. */
    static function createGroup(OmadaApi $api, int $uid, string $site, array $pkg, int $qty): array {
        $dev = self::siteRouter($uid, $api->id(), $site);
        $d = $dev ?: ['id' => null, 'user_id' => $uid, 'device_name' => 'Omada site', 'ssid' => ''];
        $portal = ($dev && ($dev['voucher_mode'] ?? '') === 'omada') ? (string)$dev['omada_portal_id'] : '';
        $r = OmadaProvision::omadaVouchers($api, $site, $d, $pkg, $qty, $portal);
        if ($r['ok']) {
            $gid = (string)val("SELECT ext_ref FROM hs_vouchers WHERE seller_id=? AND batch=? AND ext_ref IS NOT NULL LIMIT 1", 'is', $uid, $r['batch']);
            if ($gid !== '') {
                self::rememberGroup($uid, $api->id(), $site, $gid, 'SKY ' . $pkg['name'], (int)$pkg['id'], $r['batch'], (int)$r['count']);
                $det = self::groupDetail($api, $site, $gid);
                if ($det['ok']) self::applyStatuses($uid, $det['vouchers']);
                $r['group_id'] = $gid;
            }
        }
        return $r;
    }
    /** Import a group that was made inside Omada so its codes can be printed / tracked here. */
    static function importGroup(OmadaApi $api, int $uid, string $site, string $gid, int $packageId = 0): array {
        $det = self::groupDetail($api, $site, $gid);
        if (!$det['ok'] || !$det['vouchers']) return ['ok' => false, 'msg' => $det['msg'] !== '' ? $det['msg'] : t('prov_omada_vouchers_nocodes')];
        $g = self::mapGroup($det['group']);
        $pkg = $packageId ? row("SELECT * FROM hs_packages WHERE id=? AND seller_id=?", 'ii', $packageId, $uid) : null;
        $dev = self::siteRouter($uid, $api->id(), $site);
        $batch = 'OG' . strtoupper(substr(md5($gid), 0, 10));
        $dur = $pkg ? (int)$pkg['duration_minutes'] : max(1, $g['duration'] ?: 60);
        $price = $pkg ? (float)$pkg['price'] : (float)$g['price'];
        $mode = $pkg ? (string)$pkg['time_mode'] : ($g['timing'] === 1 ? 'online' : 'continuous');
        $map = ['unused' => 'available', 'in_use' => 'active', 'expired' => 'expired'];
        $n = 0;
        foreach ($det['vouchers'] as $v) {
            $st = $map[$v['status']] ?? 'available';
            $n += q("INSERT IGNORE INTO hs_vouchers (package_id,seller_id,device_id,code,batch,price,duration_minutes,time_mode,data_limit_mb,speed_down_mbps,speed_up_mbps,max_devices,status,source,first_used_at,ext_ref,ext_vid)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'omada',?,?,?)", 'iiissdisiddissss',
                $pkg ? (int)$pkg['id'] : null, $uid, $dev ? (int)$dev['id'] : null, substr($v['code'], 0, 20), $batch, $price, $dur, $mode,
                $pkg ? (int)$pkg['data_limit_mb'] : 0, $pkg ? (float)$pkg['speed_down_mbps'] : 0, $pkg ? (float)$pkg['speed_up_mbps'] : 0,
                $pkg ? (int)$pkg['max_devices'] : $g['limit'], $st, $st === 'active' ? date('Y-m-d H:i:s') : null, $gid, $v['id'] !== '' ? $v['id'] : null)->affected_rows;
        }
        self::applyStatuses($uid, $det['vouchers']);
        self::rememberGroup($uid, $api->id(), $site, $gid, $g['name'] !== '' ? $g['name'] : 'Omada ' . $gid, $pkg ? (int)$pkg['id'] : null, $batch, count($det['vouchers']));
        return ['ok' => true, 'batch' => $batch, 'count' => $n, 'msg' => sprintf(t('om_vg_imported'), $n, count($det['vouchers']))];
    }
    static function deleteGroup(OmadaApi $api, int $uid, string $site, string $gid): array {
        $r = $api->call('DELETE', self::sp($site, '/hotspot/voucher-groups/' . rawurlencode($gid)), [], null, 30);
        if ($r['ok']) {
            run("UPDATE hs_vouchers SET status='cancelled' WHERE seller_id=? AND source='omada' AND ext_ref=? AND status IN ('available','sold','active')", 'is', $uid, $gid);
            run("DELETE FROM hs_omada_vgroups WHERE user_id=? AND group_id=?", 'is', $uid, $gid);
            run("UPDATE hs_devices SET omada_vgroup_id=NULL WHERE user_id=? AND omada_vgroup_id=?", 'is', $uid, $gid);
        }
        return $r;
    }
    static function deleteVoucher(OmadaApi $api, int $uid, string $site, string $vid, string $code): array {
        $r = self::tryCalls($api, [['DELETE', self::sp($site, '/hotspot/vouchers/' . rawurlencode($vid)), null]], 20);
        if ($r['ok'] && $code !== '') run("UPDATE hs_vouchers SET status='cancelled' WHERE seller_id=? AND source='omada' AND code=?", 'is', $uid, substr($code, 0, 20));
        return $r;
    }
    /** Groups of this seller that still have open codes on the website: [ctrl_id, site_id, group_id]. */
    static function openGroups(int $uid): array {
        $out = [];
        foreach (rows("SELECT g.ctrl_id, g.site_id, g.group_id FROM hs_omada_vgroups g WHERE g.user_id=? AND EXISTS (SELECT 1 FROM hs_vouchers v
                       WHERE v.seller_id=g.user_id AND v.source='omada' AND v.ext_ref=g.group_id AND v.status IN ('available','sold','active'))", 'i', $uid) as $r)
            $out[$r['group_id']] = $r;
        // groups made by "Add router" (v5.4+) before this page existed: site and controller come from the router
        foreach (rows("SELECT DISTINCT v.ext_ref AS group_id, d.controller_id AS ctrl_id, d.omada_site_id AS site_id FROM hs_vouchers v JOIN hs_devices d ON d.id=v.device_id
                       WHERE v.seller_id=? AND v.source='omada' AND v.ext_ref IS NOT NULL AND v.status IN ('available','sold','active')
                         AND d.controller_id IS NOT NULL AND d.omada_site_id IS NOT NULL", 'i', $uid) as $r)
            if (!isset($out[$r['group_id']])) $out[$r['group_id']] = $r;
        return array_values($out);
    }
    /** Pull the state of every open Omada voucher of this seller. Returns [groups checked, codes changed, last error]. */
    static function syncAll(int $uid, int $budget = 25): array {
        $prev = OmadaApi::$deadline;
        OmadaApi::$deadline = min($prev ?? PHP_FLOAT_MAX, microtime(true) + workBudget($budget));
        $apis = []; $g = 0; $n = 0; $err = '';
        try {
            foreach (self::openGroups($uid) as $r) {
                if (microtime(true) > OmadaApi::$deadline - 4) break;
                $cid = (int)$r['ctrl_id'];
                if (!array_key_exists($cid, $apis)) $apis[$cid] = self::api($cid, $uid);
                if (!$apis[$cid]) continue;
                $det = self::groupDetail($apis[$cid], (string)$r['site_id'], (string)$r['group_id']);
                $g++;
                if ($det['ok']) $n += self::applyStatuses($uid, $det['vouchers']); else $err = $det['msg'];
            }
        } catch (Throwable $e) { $err = $e->getMessage(); error_log('OmadaManager::syncAll: ' . $err); }
        finally { OmadaApi::$deadline = $prev; }
        try { setSetting('om_vsync_' . $uid, (string)time()); } catch (Throwable $e) {}
        return [$g, $n, $err];
    }
    /** Throttled background sync (vouchers / Omada Manager pages). */
    static function maybeSync(int $uid): void {
        try {
            if ($uid <= 0 || (int)getSetting('om_vsync_' . $uid, '0') > time() - self::SYNC_EVERY) return;
            setSetting('om_vsync_' . $uid, (string)time());
            if (self::openGroups($uid)) self::syncAll($uid, 12);
        } catch (Throwable $e) { error_log('OmadaManager::maybeSync: ' . $e->getMessage()); }
    }

    // ---------------------------------------------------------------- VPS install kit (Omada Software Controller + RADIUS server)
    static function vpsKit(): array {
        $inf = parseInformUrl(defaultInformUrl());
        $baUrl = omadaPortalAuthUrl() ?: 'https://omada.skytanzania.co.tz/portal/radius/browserauth';
        $baHost = (string)parse_url($baUrl, PHP_URL_HOST);
        $ip = getSetting('radius_server_ip') ?: ($inf['host'] ?? 'YOUR-VPS-IP');
        $omada = "# Ubuntu 22.04 / 24.04 VPS with a PUBLIC IP — Omada Software Controller in Docker (TP-Link's own package inside)\n"
            . "sudo apt update && sudo apt install -y ca-certificates curl ufw\n"
            . "curl -fsSL https://get.docker.com | sudo sh\n"
            . "sudo docker volume create omada-data && sudo docker volume create omada-logs\n"
            . "sudo docker run -d --name omada-controller --restart unless-stopped --net host \\\n"
            . "  -e TZ=Africa/Dar_es_Salaam \\\n"
            . "  -v omada-data:/opt/tplink/EAPController/data -v omada-logs:/opt/tplink/EAPController/logs \\\n"
            . "  mbentley/omada-controller:5.15        # any newer 5.x / 6.x tag also has the Open API\n"
            . "sudo docker logs -f omada-controller    # wait for 'Omada Controller started' (2-4 minutes), Ctrl+C\n\n"
            . "# Firewall (also open the same ports in your VPS provider's firewall)\n"
            . "sudo ufw allow OpenSSH\n"
            . "sudo ufw allow 8043/tcp          # Omada web UI + Open API (HTTPS)\n"
            . "sudo ufw allow 8088/tcp          # Omada HTTP / portal\n"
            . "sudo ufw allow 8843/tcp          # Omada portal HTTPS\n"
            . "sudo ufw allow 29810/udp         # EAP225 discovery\n"
            . "sudo ufw allow 29811:29817/tcp   # EAP225 manage / adopt / inform / upgrade\n"
            . "sudo ufw allow 27001/udp         # Omada app discovery (optional)\n"
            . "sudo ufw allow 1812/udp && sudo ufw allow 1813/udp   # SkyTanza RADIUS server (same VPS)\n"
            . "sudo ufw --force enable\n\n"
            . "# Omada ID of the controller (needed for the Inform URL):\n"
            . "curl -sk https://$ip:8043/api/info\n\n"
            . "# v6.6.1 — HTTPS browserauth with a VALID certificate (phones never see an SSL error)\n"
            . "# DNS: A record  $baHost  →  $ip   (then:)\n"
            . "sudo apt install -y nginx certbot python3-certbot-nginx\n"
            . "sudo ufw allow 80/tcp && sudo ufw allow 443/tcp\n"
            . "sudo tee /etc/nginx/sites-available/omada >/dev/null <<'NGINX'\n"
            . "server {\n"
            . "    listen 80;\n"
            . "    server_name $baHost;\n"
            . '    location /portal/ {' . "\n"
            . '        proxy_pass https://127.0.0.1:8843;' . "\n"
            . '        proxy_ssl_verify off;' . "\n"
            . '        proxy_set_header Host $host;' . "\n"
            . '        proxy_set_header X-Real-IP $remote_addr;' . "\n"
            . '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;' . "\n"
            . '        proxy_set_header X-Forwarded-Proto https;' . "\n"
            . '    }' . "\n"
            . '    location / {' . "\n"
            . '        proxy_pass https://127.0.0.1:8043;' . "\n"
            . '        proxy_ssl_verify off;' . "\n"
            . '        proxy_http_version 1.1;' . "\n"
            . '        proxy_set_header Upgrade $http_upgrade;' . "\n"
            . '        proxy_set_header Connection "upgrade";' . "\n"
            . '        proxy_set_header Host $host;' . "\n"
            . '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;' . "\n"
            . '        proxy_set_header X-Forwarded-Proto https;' . "\n"
            . '    }' . "\n"
            . "}\n"
            . "NGINX\n"
            . "sudo ln -sf /etc/nginx/sites-available/omada /etc/nginx/sites-enabled/omada\n"
            . "sudo nginx -t && sudo systemctl reload nginx\n"
            . "sudo certbot --nginx -d $baHost --redirect -m you@example.com --agree-tos -n   # free Let's Encrypt certificate\n"
            . "curl -I $baUrl   # must answer WITHOUT -k (any HTTP code is fine, no SSL error)\n";
        $steps = "1. Open https://$ip:8043 → create the admin account (keep \"Cloud Access\" off or on, both work).\n"
            . "2. Global View → Settings → Platform Integration → Open API → Add New App → Mode \"Client\" (Client Credentials), role Administrator\n"
            . "   (or a role with Site + Device + Hotspot management) → Apply → copy Client ID and Client Secret.\n"
            . "3. On this website: Admin → RADIUS Setup → \"Default Omada Inform URL\" = omada://$ip?dPort=29810&mPort=29814&omadacId=<omadacId from /api/info>\n"
            . "   and paste the Client ID + Client Secret into \"Open API keys of the default controller\" → Save.\n"
            . "4. Install the SkyTanza RADIUS server on the SAME VPS (Admin → RADIUS Setup → Install the RADIUS server). Its Omada relay lets\n"
            . "   the cPanel website reach port 8043 even when shared hosting blocks it. Keep Omada's own built-in RADIUS server OFF (port 1812).\n"
            . "5. EAP225 at the customer site (any internet line, behind NAT is fine): open http://192.168.0.254 (admin/admin) →\n"
            . "   Controller Settings → Controller Inform URL = $ip → Save. It appears as PENDING in Omada Manager → Devices → Adopt,\n"
            . "   or add it by serial number there and tick \"Turn into a hotspot\" to create SSID, RADIUS profile, portal and vouchers in one go.\n";
        return [['om_vps_controller', $omada], ['om_vps_steps', $steps]];
    }
}

// ============================================================
// VOUCHERS — single source of truth for portal checks AND RADIUS decisions
// ============================================================
class Vouchers {
    static function generate(int $packageId, int $sellerId, int $qty, string $source = 'batch', ?string $phone = null): array {
        $p = row("SELECT * FROM hs_packages WHERE id=? AND seller_id=?", 'ii', $packageId, $sellerId);
        if (!$p) return ['success' => false, 'message' => 'Package not found'];
        $qty = max(1, min(1000, $qty));
        $batch = 'B' . date('ymdHi') . strtoupper(bin2hex(random_bytes(2)));
        $validUntil = (int)$p['validity_days'] > 0 ? date('Y-m-d H:i:s', time() + (int)$p['validity_days'] * 86400) : null;
        $status = $source === 'batch' ? 'available' : 'sold';
        $soldAt = $source === 'batch' ? null : date('Y-m-d H:i:s');
        $len = max(6, min(12, (int)getSetting('voucher_length', '8')));
        $out = [];
        for ($i = 0; $i < $qty; $i++) {
            for ($try = 0; $try < 8; $try++) {
                $code = genCode($len);
                try {
                    q("INSERT INTO hs_vouchers (package_id,seller_id,device_id,code,batch,price,duration_minutes,time_mode,data_limit_mb,speed_down_mbps,speed_up_mbps,max_devices,status,source,sold_to_phone,sold_at,valid_until)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 'iiissdisiddisssss',
                       $p['id'], $sellerId, $p['device_id'], $code, $batch, $p['price'], $p['duration_minutes'], $p['time_mode'], $p['data_limit_mb'],
                       $p['speed_down_mbps'], $p['speed_up_mbps'], $p['max_devices'], $status, $source, $phone, $soldAt, $validUntil);
                    $out[] = ['id' => db()->insert_id, 'code' => $code];
                    break;
                } catch (mysqli_sql_exception $e) { if ($e->getCode() != 1062) throw $e; }
            }
        }
        return ['success' => true, 'batch' => $batch, 'codes' => $out];
    }

    static function remainingSeconds(array $v): int {
        $dur = (int)$v['duration_minutes'] * 60;
        if ($v['time_mode'] === 'online') return max(0, $dur - (int)$v['seconds_used']);
        if (empty($v['first_used_at'])) return $dur;
        return max(0, strtotime($v['expires_at']) - time());
    }

    static function refreshUsage(int $vid): void {
        run("UPDATE hs_vouchers v SET
               data_used_bytes = (SELECT COALESCE(SUM(s.bytes_in + s.bytes_out),0) FROM hs_sessions s WHERE s.voucher_id=v.id),
               seconds_used    = (SELECT COALESCE(SUM(s.session_time),0) FROM hs_sessions s WHERE s.voucher_id=v.id)
             WHERE v.id=?", 'i', $vid);
    }

    static function setStatus(int $vid, string $status, string $reason): void {
        run("UPDATE hs_vouchers SET status=? WHERE id=?", 'si', $status, $vid);
        Radius::queueVoucherDisconnect($vid, $reason);
    }

    /**
     * Decide whether $code may go online for $mac on hotspot $dev (null = not known yet, e.g. portal pre-check on an unregistered AP).
     * $commit=false → read-only check (portal pre-check / simulator). $commit=true → RADIUS authorize: starts the clock & binds the MAC.
     */
    static function check(string $code, string $mac = '', ?array $dev = null, bool $commit = false): array {
        $code = strtoupper(preg_replace('/\s+/', '', $code));
        $fail = fn($k) => ['ok' => false, 'key' => $k, 'msg' => t($k)];
        if ($code === '' || strlen($code) > 20) return $fail('invalid_voucher');
        $v = row("SELECT v.*, p.name AS package_name FROM hs_vouchers v LEFT JOIN hs_packages p ON p.id=v.package_id WHERE v.code=?", 's', $code);
        if (!$v) return $fail('invalid_voucher');
        if (($v['source'] ?? '') === 'omada') return $fail('voucher_omada_only');   // Omada Hotspot vouchers are checked by Omada itself
        if (in_array($v['status'], ['blocked', 'cancelled'], true)) return $fail('voucher_blocked');
        if ($v['status'] === 'expired') return $fail('voucher_expired');
        if ($v['status'] === 'exhausted') return $fail('voucher_exhausted');
        if (in_array($v['status'], ['available', 'sold'], true) && $v['valid_until'] && strtotime($v['valid_until']) < time()) {
            run("UPDATE hs_vouchers SET status='expired' WHERE id=?", 'i', $v['id']);
            return $fail('voucher_expired');
        }
        if ($dev) {
            if ((int)$dev['user_id'] !== (int)$v['seller_id']) return $fail('voucher_wrong_hotspot');
            if ($v['device_id'] && (int)$v['device_id'] !== (int)$dev['id']) return $fail('voucher_wrong_hotspot');
        }
        if ($mac !== '') {
            if (val("SELECT 1 FROM hs_blocked_macs WHERE seller_id=? AND mac=?", 'is', $v['seller_id'], $mac)) return $fail('device_blocked');
            $bound = array_column(rows("SELECT mac FROM hs_voucher_macs WHERE voucher_id=?", 'i', $v['id']), 'mac');
            if (!in_array($mac, $bound, true) && count($bound) >= max(1, (int)$v['max_devices'])) return $fail('voucher_in_use_other');
        }
        if ($v['time_mode'] === 'online' && $v['first_used_at']) { self::refreshUsage((int)$v['id']); $v = row("SELECT * FROM hs_vouchers WHERE id=?", 'i', $v['id']) + $v; }
        $remaining = self::remainingSeconds($v);
        if ($remaining <= 0) { self::setStatus((int)$v['id'], 'expired', 'Time used up'); return $fail('voucher_expired'); }
        $limit = (int)$v['data_limit_mb'] * 1048576;
        if ($limit > 0 && (int)$v['data_used_bytes'] >= $limit) { self::setStatus((int)$v['id'], 'exhausted', 'Data used up'); return $fail('voucher_exhausted'); }

        if ($commit) {
            if (empty($v['first_used_at'])) {
                $exp = $v['time_mode'] === 'continuous' ? date('Y-m-d H:i:s', time() + (int)$v['duration_minutes'] * 60) : null;
                $firstUse = run("UPDATE hs_vouchers SET first_used_at=NOW(), expires_at=?, status='active', sold_at=COALESCE(sold_at,NOW()) WHERE id=? AND first_used_at IS NULL", 'si', $exp, $v['id']);
                if ($firstUse === 1) Earnings::creditVoucher((int)$v['id']);   // v6.4: a voucher entered on the portal counts in the seller's balance
                $v = row("SELECT * FROM hs_vouchers WHERE id=?", 'i', $v['id']) + $v;
                $remaining = self::remainingSeconds($v);
            } elseif ($v['status'] !== 'active') {
                run("UPDATE hs_vouchers SET status='active' WHERE id=?", 'i', $v['id']);
            }
            if ($mac !== '') q("INSERT INTO hs_voucher_macs (voucher_id,mac,first_seen,last_seen) VALUES (?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE last_seen=NOW()", 'is', $v['id'], $mac);
            run("UPDATE hs_vouchers SET last_mac=?, last_seen=NOW() WHERE id=?", 'si', $mac, $v['id']);
        }
        $dataLeft = $limit > 0 ? max(0, $limit - (int)$v['data_used_bytes']) : null;
        return ['ok' => true, 'voucher' => $v, 'remaining' => $remaining, 'data_left' => $dataLeft, 'msg' => t('welcome_online') . ': ' . fmtSecs($remaining)];
    }
}

// ============================================================
// RADIUS WEBSITE API — called ONLY by our external RADIUS server (php index.php radius-server) over HTTPS
// ============================================================
class Radius {
    static function handle(): void {
        global $currentLang;
        if (radiusApiKeyWeak()) jsonOut(['error' => 'RADIUS_API_KEY is still the default. Set a long random key in config.local.php on the website and on the RADIUS server.'], 503);
        $key = (string)($_SERVER['HTTP_X_API_KEY'] ?? '');   // v5.7.1: header only — a key in the URL ends up in access logs
        if ($key === '' || !hash_equals((string)RADIUS_API_KEY, $key)) jsonOut(['error' => 'forbidden (wrong RADIUS_API_KEY)'], 403);
        $allowed = trim(getSetting('radius_allowed_ips', ''));
        if ($allowed !== '' && !in_array(clientIp(), array_map('trim', explode(',', $allowed)), true)) jsonOut(['error' => 'ip ' . clientIp() . ' not allowed'], 403);
        $currentLang = 'en';   // v6.2: English only
        $b = self::body();
        switch ((string)$_GET['radius']) {
            case 'ping': jsonOut(['ok' => true, 'time' => date('c'), 'version' => APP_VERSION]);
            case 'clients': self::clients($b);
            case 'authorize': self::authorize($b);
            case 'accounting': self::accountingBatch($b);
            case 'dae_queue': self::daeQueue();
            case 'dae_ack': self::daeAck($b);
            case 'omada_jobs': OmadaRelay::jobs($b);        // v5.9 — Omada relay long-poll
            case 'omada_result': OmadaRelay::result($b);
            case 'omada_targets': OmadaRelay::targets();
        }
        jsonOut(['error' => 'unknown action'], 400);
    }

    static function body(): array {
        static $b = null;
        if ($b === null) { $j = json_decode((string)file_get_contents('php://input'), true); $b = is_array($j) ? $j : $_POST; }
        return $b;
    }
    static function attrs(array $b): array {
        $o = [];
        foreach ((array)($b['attrs'] ?? []) as $k => $v) if (is_scalar($v)) $o[(string)$k] = (string)$v;
        return $o;
    }

    static function log(string $kind, string $user, string $mac, string $ap, string $nasId, string $src, string $result, string $msg): void {
        q("INSERT INTO hs_radius_log (kind,username,mac,ap_mac,nas_id,src_ip,result,message) VALUES (?,?,?,?,?,?,?,?)", 'ssssssss',
            $kind, asciiClean($user, 64), $mac, $ap, asciiClean($nasId, 32), substr($src, 0, 45), $result, substr($msg, 0, 255));
    }

    /** Heartbeat from the RADIUS server + the list of routers it may serve (hotspot key → passwords + NAS ID Omada sends). */
    static function clients(array $b): void {
        if (!empty($b['server']) && is_array($b['server'])) {
            setSetting('radius_server_seen', (string)time());
            setSetting('radius_server_info', (string)json_encode($b['server'] + ['ip' => clientIp()], JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
        }
        // Omada status sync runs AFTER the reply reaches the RADIUS box, so a slow controller never delays RADIUS
        register_shutdown_function(function () {
            if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
            elseif (function_exists('litespeed_finish_request')) litespeed_finish_request();
            else return;
            Payments::pollPending(8);   // v6.5: Sonic Pesa order_status for unconfirmed payments
            OmadaSync::maybe();
            PaymentOps::nudgeLate();   // v6.4: connect customers whose payment was confirmed late
        });
        $list = [];
        foreach (rows("SELECT nas_id, radius_secret, acct_secret, radius_src_ip, omada_nas_id FROM hs_devices WHERE nas_id IS NOT NULL AND radius_secret IS NOT NULL") as $r)
            $list[strtoupper($r['nas_id'])] = ['auth' => $r['radius_secret'], 'acct' => $r['acct_secret'] ?: $r['radius_secret'], 'ip' => (string)$r['radius_src_ip'],
                'nas' => (string)$r['omada_nas_id']];
        Housekeeping::maybe();
        jsonOut(['ok' => true, 'clients' => (object)$list, 'dae' => getSetting('dae_enabled', '1') === '1', 'interim' => (int)RADIUS_INTERIM, 'time' => date('c')]);
    }

    /** PAP: the decrypted password must equal the voucher code. CHAP: MD5(id + code + challenge) must match. */
    static function passwordOk(string $code, array $auth): bool {
        if ($code === '') return false;
        $type = (string)($auth['type'] ?? '');
        if ($type === 'pap') return hash_equals($code, strtoupper(trim((string)($auth['password'] ?? ''))));
        if ($type === 'chap') {
            $hex = fn($k, $len = 0) => is_string($auth[$k] ?? null) && $auth[$k] !== '' && strlen($auth[$k]) % 2 === 0 && ctype_xdigit($auth[$k])
                && (!$len || strlen($auth[$k]) === $len) ? hex2bin($auth[$k]) : null;
            $id = $hex('id', 2); $resp = $hex('response', 32); $chal = $hex('challenge');
            if ($id === null || $resp === null || $chal === null) return false;
            foreach (array_unique([$code, strtolower($code)]) as $pw) if (hash_equals(md5($id . $pw . $chal, true), $resp)) return true;
        }
        return false;
    }

    /** Reply for the RADIUS server (also shown by the admin simulator). */
    static function buildReply(array $res): array {
        if (!$res['ok']) return ['decision' => 'reject', 'message' => $res['msg'], 'reply' => ['Reply-Message' => $res['msg']]];
        $v = $res['voucher'];
        $reply = ['Reply-Message' => $res['msg'], 'Session-Timeout' => max(60, (int)$res['remaining']), 'Acct-Interim-Interval' => (int)RADIUS_INTERIM];
        $idle = (int)getSetting('radius_idle_timeout', '900');
        if ($idle > 0) $reply['Idle-Timeout'] = $idle;
        if ((float)$v['speed_down_mbps'] > 0) $reply['WISPr-Bandwidth-Max-Down'] = (int)round((float)$v['speed_down_mbps'] * 1000000);
        if ((float)$v['speed_up_mbps'] > 0) $reply['WISPr-Bandwidth-Max-Up'] = (int)round((float)$v['speed_up_mbps'] * 1000000);
        return ['decision' => 'accept', 'message' => $res['msg'], 'reply' => $reply];
    }

    static function authorize(array $b): void {
        $a = self::attrs($b);
        $omadaNas = trim((string)($b['omada_nas_id'] ?? ($a['NAS-Identifier'] ?? '')));
        $nasDev = Device::find((string)($b['nas_id'] ?? ''), $omadaNas);
        $nasId = $nasDev ? (string)$nasDev['nas_id'] : ($omadaNas !== '' ? $omadaNas : (string)($b['nas_id'] ?? ''));
        $src = substr((string)($b['src_ip'] ?? ''), 0, 45);
        $user = strtoupper(trim($a['User-Name'] ?? ''));
        $mac = normMac($a['Calling-Station-Id'] ?? '');
        $ap = normMac($a['Called-Station-Id'] ?? '');
        $auth = is_array($b['auth'] ?? null) ? $b['auth'] : [];
        $reject = function (string $key, string $why = '') use ($user, $mac, $ap, $nasId, $src): void {
            $m = t($key);
            self::log('auth', $user, $mac, $ap, $nasId, $src, 'reject', $why !== '' ? $why : $m);
            jsonOut(['decision' => 'reject', 'message' => $m, 'reply' => ['Reply-Message' => $m]]);
        };
        if (!$nasDev) $reject('unknown_nas');
        Device::learnNas($nasDev, $omadaNas);
        Device::touchRadius((int)$nasDev['id'], $src, substr((string)($a['NAS-IP-Address'] ?? ''), 0, 45), true);
        if (!(int)$nasDev['is_active'] || $nasDev['seller_status'] !== 'active') $reject('hotspot_disabled');
        if (!self::passwordOk($user, $auth)) {
            $why = !empty($auth['garbled']) ? 'Password unreadable: Authentication Password in Omada does not match this hotspot'
                 : (($auth['type'] ?? 'none') === 'none' ? 'No password in request (set Authentication Mode PAP)' : t('invalid_voucher'));
            $reject('invalid_voucher', $why);
        }
        $dev = Device::resolve($nasDev, $ap);
        if ((int)$dev['id'] !== (int)$nasDev['id']) Device::touch((int)$dev['id']);
        $res = Vouchers::check($user, $mac, $dev, true);
        self::log('auth', $user, $mac, $ap, $nasId, $src, $res['ok'] ? 'accept' : 'reject', $res['msg']);
        jsonOut(self::buildReply($res));
    }

    static function accountingBatch(array $b): void {
        $n = 0;
        foreach (array_slice((array)($b['records'] ?? []), 0, 500) as $r) {
            if (!is_array($r)) continue;
            try { self::processAccounting($r); $n++; } catch (Throwable $e) { error_log('RADIUS accounting: ' . $e->getMessage()); }
        }
        Housekeeping::maybe();
        jsonOut(['ok' => true, 'processed' => $n]);
    }

    static function processAccounting(array $r): void {
        $a = self::attrs($r);
        $omadaNas = trim((string)($r['omada_nas_id'] ?? ($a['NAS-Identifier'] ?? '')));
        $nasDev = Device::find((string)($r['nas_id'] ?? ''), $omadaNas);
        $nasId = $nasDev ? (string)$nasDev['nas_id'] : ($omadaNas !== '' ? $omadaNas : (string)($r['nas_id'] ?? ''));
        $src = substr((string)($r['src_ip'] ?? ''), 0, 45);
        $at = min(time(), max(time() - 172800, (int)($r['ts'] ?? time())));   // when the packet reached the RADIUS server
        $type = $a['Acct-Status-Type'] ?? '';
        $user = strtoupper(trim($a['User-Name'] ?? ''));
        $mac = normMac($a['Calling-Station-Id'] ?? '');
        $ap = normMac($a['Called-Station-Id'] ?? '');
        $nasIp = substr((string)($a['NAS-IP-Address'] ?? ''), 0, 45);
        if (!$nasDev) { self::log('acct', $user, $mac, $ap, $nasId, $src, 'drop', 'Unknown hotspot (NAS ID ' . asciiClean($omadaNas, 64) . ')'); return; }
        Device::learnNas($nasDev, $omadaNas);
        Device::touchRadius((int)$nasDev['id'], $src, $nasIp, false);
        $dev = Device::resolve($nasDev, $ap);
        if ((int)$dev['id'] !== (int)$nasDev['id']) Device::touch((int)$dev['id'], $nasIp);

        if (in_array($type, ['Accounting-On', 'Accounting-Off'], true)) {
            run("UPDATE hs_sessions SET status='closed', stopped_at=NOW(), terminate_cause='NAS-Reboot' WHERE status='active' AND nas_id=?", 's', $nasId);
            self::log('acct', '', '', '', $nasId, $src, 'ok', $type . ' (router restarted)');
            return;
        }
        $sid = substr((string)($a['Acct-Session-Id'] ?? ''), 0, 64);
        $unique = md5($user . '|' . $sid . '|' . $nasId . '|' . $mac);
        $in = (float)($a['Acct-Input-Octets'] ?? 0) + (float)($a['Acct-Input-Gigawords'] ?? 0) * 4294967296;
        $out = (float)($a['Acct-Output-Octets'] ?? 0) + (float)($a['Acct-Output-Gigawords'] ?? 0) * 4294967296;
        $time = max(0, (int)($a['Acct-Session-Time'] ?? 0));
        $ip = substr((string)($a['Framed-IP-Address'] ?? ''), 0, 45);
        $isStop = $type === 'Stop';
        $v = $user !== '' ? row("SELECT id, seller_id FROM hs_vouchers WHERE code=?", 's', $user) : null;
        if ($v && (int)$v['seller_id'] !== (int)$nasDev['user_id']) $v = null;   // never count another seller's voucher here
        $vid = $v ? (int)$v['id'] : null;
        $seller = (int)$nasDev['user_id'];
        $devId = (int)$dev['id'];
        $started = date('Y-m-d H:i:s', $at - $time);
        $updated = date('Y-m-d H:i:s', $at);
        $stopped = $isStop ? $updated : null;
        $cause = $isStop ? substr((string)($a['Acct-Terminate-Cause'] ?? 'Stop'), 0, 64) : null;
        $status = $isStop ? 'closed' : 'active';
        q("INSERT INTO hs_sessions (voucher_id,seller_id,device_id,username,unique_id,acct_session_id,mac,ip,nas_ip,nas_id,ap_mac,started_at,updated_at,stopped_at,session_time,bytes_in,bytes_out,status,terminate_cause)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
           ON DUPLICATE KEY UPDATE updated_at=GREATEST(updated_at, VALUES(updated_at)), session_time=GREATEST(session_time, VALUES(session_time)),
             bytes_in=GREATEST(bytes_in, VALUES(bytes_in)), bytes_out=GREATEST(bytes_out, VALUES(bytes_out)),
             ip=IF(VALUES(ip)<>'', VALUES(ip), ip), status=IF(status='closed','closed',VALUES(status)),
             stopped_at=COALESCE(stopped_at, VALUES(stopped_at)), terminate_cause=COALESCE(VALUES(terminate_cause), terminate_cause)",
           'iii' . 'sssssssssss' . 'i' . 'ssss',
           $vid, $seller, $devId, asciiClean($user, 64), $unique, $sid, $mac, $ip, $nasIp, $nasId, $ap, $started, $updated, $stopped, $time,
           sprintf('%.0f', $in), sprintf('%.0f', $out), $status, $cause);

        if ($vid) {
            Vouchers::refreshUsage($vid);
            $vv = row("SELECT * FROM hs_vouchers WHERE id=?", 'i', $vid);
            if ($vv && in_array($vv['status'], ['active', 'sold', 'available'], true) && !$isStop) {
                $limit = (int)$vv['data_limit_mb'] * 1048576;
                if ($limit > 0 && (int)$vv['data_used_bytes'] >= $limit) Vouchers::setStatus($vid, 'exhausted', 'Data limit reached');
                elseif ($vv['first_used_at'] && Vouchers::remainingSeconds($vv) <= 0) Vouchers::setStatus($vid, 'expired', 'Time used up');
            }
        }
        if ($type === 'Start' || $isStop) self::log('acct', $user, $mac, $ap, $nasId, $src, 'ok', $type . ($isStop ? ' ' . $cause . ' ' . fmtBytes($in + $out) . ' ' . fmtSecs($time) : ''));
    }

    // ---------- Disconnect (RFC 5176) queue ----------
    static function queueSessionDisconnect(array $s, string $reason): void {
        if (val("SELECT id FROM hs_dae_queue WHERE status IN ('pending','sent') AND acct_session_id=? AND mac=? LIMIT 1", 'ss', $s['acct_session_id'], $s['mac'])) return;
        q("INSERT INTO hs_dae_queue (voucher_id,session_id,username,mac,acct_session_id,nas_ip,framed_ip,reason) VALUES (?,?,?,?,?,?,?,?)", 'iissssss',
            $s['voucher_id'], $s['id'], $s['username'], $s['mac'], $s['acct_session_id'], $s['nas_ip'], $s['ip'], substr($reason, 0, 100));
    }
    static function queueVoucherDisconnect(int $vid, string $reason): void {
        foreach (rows("SELECT * FROM hs_sessions WHERE voucher_id=? AND status='active'", 'i', $vid) as $s) self::queueSessionDisconnect($s, $reason);
    }
    /** Jobs for the RADIUS server: who to kick, which router (address + password + Omada NAS ID) to send the Disconnect-Request to. */
    static function daeQueue(): void {
        if (getSetting('dae_enabled', '1') !== '1') jsonOut(['ok' => true, 'jobs' => []]);
        $jobs = rows("SELECT q.*, d.nas_id AS dev_nas, d.omada_nas_id, d.radius_secret, d.dae_target, d.radius_src_ip
                      FROM hs_dae_queue q LEFT JOIN hs_sessions s ON s.id=q.session_id LEFT JOIN hs_devices d ON d.nas_id=s.nas_id
                      WHERE q.status='pending' OR (q.status='sent' AND q.updated_at < DATE_SUB(NOW(), INTERVAL 2 MINUTE) AND q.attempts < 3)
                      ORDER BY q.id LIMIT 20");
        $out = [];
        foreach ($jobs as $j) {
            $dest = trim((string)$j['dae_target']) ?: (string)$j['radius_src_ip'];
            if ($dest !== '' && strpos($dest, ':') === false) $dest .= ':' . RADIUS_DAE_PORT;
            if (!$j['dev_nas'] || !$j['radius_secret'] || $dest === '') {
                run("UPDATE hs_dae_queue SET status='failed', last_result='Router address not known yet' WHERE id=?", 'i', $j['id']);
                continue;
            }
            run("UPDATE hs_dae_queue SET status='sent', attempts=attempts+1 WHERE id=?", 'i', $j['id']);
            $out[] = ['id' => (int)$j['id'], 'username' => (string)$j['username'], 'mac' => $j['mac'] ? dashMac($j['mac']) : '',
                'acct_session_id' => (string)$j['acct_session_id'], 'nas_ip' => (string)$j['nas_ip'], 'framed_ip' => (string)$j['framed_ip'],
                'nas_id' => (string)($j['omada_nas_id'] ?? ''), 'secret' => (string)$j['radius_secret'], 'dest' => $dest];
        }
        jsonOut(['ok' => true, 'jobs' => $out]);
    }
    static function daeAck(array $b): void {
        $id = (int)($b['id'] ?? 0);
        $ok = !empty($b['ok']);
        $res = substr((string)($b['result'] ?? ''), 0, 255);
        $j = row("SELECT * FROM hs_dae_queue WHERE id=?", 'i', $id);
        if ($j) {
            $st = $ok ? 'done' : ((int)$j['attempts'] >= 3 ? 'failed' : 'pending');
            run("UPDATE hs_dae_queue SET status=?, last_result=? WHERE id=?", 'ssi', $st, $res, $id);
            if ($ok && $j['session_id']) run("UPDATE hs_sessions SET status='closed', stopped_at=COALESCE(stopped_at,NOW()), terminate_cause='Admin-Reset' WHERE id=?", 'i', $j['session_id']);
        }
        jsonOut(['ok' => true]);
    }
}

// ============================================================
// PAYMENTS (portal purchases) — automatic push or "Lipa Namba" manual confirmation
// ============================================================
/**
 * v6.3 — Sonic Pesa collection endpoint (relative to SONIC_PESA_API_BASE, default https://api.sonicpesa.com/api/v1).
 * Order: SONIC_PESA_COLLECT_ENDPOINT in config.local.php → Admin setting "Sonic Pesa collection endpoint" → /payment/create_order.
 */
function sonicCollectEndpoint(): string { return '/payment/create_order'; }   // v6.7.3: MIKEKA APP spCurl('/payment/create_order', ...)
function sonicStatusEndpoint(): string { return '/payment/order_status'; }    // v6.7.3: MIKEKA APP spCurl('/payment/order_status', ...)
function sonicMailHost(): string {
    $h = strtolower((string)parse_url(appUrl(), PHP_URL_HOST));
    return preg_match('/^[a-z0-9.\-]+\.[a-z]{2,}$/', $h) ? $h : 'skytanzania.co.tz';
}
/** v6.3 — "JE UNATAKA MFUMO HUU?" contact on the captive portal: admin setting, else the business number. */
function salesContactPhone(): string {
    $p = '';
    try { $p = trim(getSetting('sales_contact_phone')); } catch (Throwable $t) {}
    $p = normalizePhone($p !== '' ? $p : '0612710364');
    return preg_match('/^0\d{9}$/', $p) ? $p : '0612710364';
}
/** v6.3 — one withdrawal fee in % (platform fee and Sonic Pesa fee combined exactly as they are deducted). */
function withdrawalFeePercent(): float {
    return round(100 - (100 - (float)WITHDRAWAL_FEE_PERCENT) * (100 - (float)SONIC_PESA_FEE_PERCENT) / 100, 2);
}

/**
 * v6.6 — Sonic Pesa keys. config.local.php (SONIC_PESA_API_KEY / SONIC_PESA_API_SECRET) wins; otherwise the keys the
 * administrator saved under Admin → Platform settings (stored sealed with APP_SECRET). Only the API key is required — exactly
 * like the Sonic Pesa integration that already works in MIKEKA APP (X-API-KEY header only). The secret is optional.
 */
function sonicApiKey(): string {
    $k = trim((string)SONIC_PESA_API_KEY);
    if ($k === '') { try { $k = trim(openSecret(getSetting('sonic_api_key'))); } catch (Throwable $t) {} }
    if ($k === '') $k = trim((string)SONIC_PESA_DEFAULT_KEY);   // v6.7: MIKEKA APP key
    return $k;
}
function sonicApiSecret(): string {
    $k = trim((string)SONIC_PESA_API_SECRET);
    if ($k === '') { try { $k = trim(openSecret(getSetting('sonic_api_secret'))); } catch (Throwable $t) {} }
    return $k;
}
/** Callback (webhook) URL Sonic Pesa calls after the customer approves or cancels the USSD push. */
function sonicCallbackUrl(): string {
    $u = machineUrl();
    return $u . (strpos($u, '?') === false ? '?' : '&') . 'webhook=sonicpesa&secret=' . urlencode((string)PAYMENT_WEBHOOK_SECRET);
}

class Payments {
    /** Exact reason of the last failed voucher issue / gateway call (shown to the seller / admin). */
    public static string $lastError = '';
    /** Last order_status answer (shown to the seller / admin under Transactions → Payments). */
    public static string $lastStatusRaw = '';

    // ---------------------------------------------------------------- payment event log (table hs_payment_events)
    static function log(?array $o, string $source, int $http, string $state, string $msg, string $body = ''): void {
        try {
            q("INSERT INTO hs_payment_events (order_id,order_ref,gateway_ref,source,http_code,state,message,body,ip) VALUES (?,?,?,?,?,?,?,?,?)", 'isssissss',
                $o ? (int)$o['id'] : null, substr((string)($o['order_ref'] ?? ''), 0, 40), substr((string)($o['gateway_ref'] ?? ''), 0, 100),
                substr($source, 0, 20), $http, substr($state, 0, 30), substr($msg, 0, 500), substr($body, 0, 4000), substr(clientIp(), 0, 45));
        } catch (Throwable $e) { error_log('payment log: ' . $e->getMessage()); }
    }
    static function events(int $orderId, int $limit = 8): array {
        try { return rows("SELECT * FROM hs_payment_events WHERE order_id=? ORDER BY id DESC LIMIT ?", 'ii', $orderId, $limit); } catch (Throwable $e) { return []; }
    }
    /** Write optional (v6.6) columns of an order without ever breaking the payment flow. */
    static function note(int $orderId, array $f): void {
        if (!$f || $orderId <= 0) return;
        $sets = []; $types = ''; $vals = [];
        foreach ($f as $k => $v) {
            if ($v === '__INC__') { $sets[] = "`$k`=`$k`+1"; continue; }
            if ($v === '__NOW__') { $sets[] = "`$k`=NOW()"; continue; }
            $sets[] = "`$k`=?"; $types .= is_int($v) ? 'i' : 's'; $vals[] = $v;
        }
        $types .= 'i'; $vals[] = $orderId;
        try { run("UPDATE hs_orders SET " . implode(',', $sets) . " WHERE id=?", $types, ...$vals); }
        catch (Throwable $e) { error_log('Payments::note: ' . $e->getMessage()); }
    }

    static function createOrder(array $pkg, ?array $dev, string $phone, string $mac, string $ssid = ''): array {
        $phone = normalizePhone($phone);
        if (!preg_match('/^0[67]\d{8}$/', $phone)) return ['success' => false, 'message' => t('p_invalid_phone')];
        if ((int)val("SELECT COUNT(*) FROM hs_orders WHERE client_mac=? AND status='pending' AND created_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE)", 's', $mac) >= 3)
            return ['success' => false, 'message' => t('rate_limited')];
        $ref = 'SKY' . date('ymdHis') . strtoupper(bin2hex(random_bytes(2)));
        q("INSERT INTO hs_orders (order_ref,seller_id,package_id,device_id,phone,amount,client_mac) VALUES (?,?,?,?,?,?,?)", 'siiisds',
            $ref, $pkg['seller_id'], $pkg['id'], $dev['id'] ?? null, $phone, $pkg['price'], $mac);
        $oid = (int)db()->insert_id;
        // v6.4: hotspot public IP + SSID • v6.6: a copy of the package, so the voucher can still be issued if the package is deleted later
        self::note($oid, ['client_ip' => substr(clientIp(), 0, 45), 'ssid' => asciiClean($ssid, 64)]);
        self::note($oid, ['pkg_name' => substr((string)$pkg['name'], 0, 100), 'pkg_minutes' => (int)$pkg['duration_minutes'], 'pkg_mode' => (string)$pkg['time_mode'],
            'pkg_data_mb' => (int)$pkg['data_limit_mb'], 'pkg_down' => (string)(float)$pkg['speed_down_mbps'], 'pkg_up' => (string)(float)$pkg['speed_up_mbps'],
            'pkg_devices' => (int)$pkg['max_devices'], 'pkg_valid_days' => (int)$pkg['validity_days']]);
        $o = row("SELECT * FROM hs_orders WHERE id=?", 'i', $oid);
        $gw = self::collect($ref, (float)$pkg['price'], $phone, (string)$pkg['name'], (int)$pkg['seller_id'], (int)$pkg['id']);
        if (!empty($gw['success'])) {
            run("UPDATE hs_orders SET gateway_ref=?, gateway_response=? WHERE id=?", 'ssi', (string)($gw['gateway_ref'] ?? ''), (string)($gw['raw'] ?? ''), $oid);
            self::note($oid, ['sp_status' => 'PUSH_SENT']);
            $o['gateway_ref'] = (string)($gw['gateway_ref'] ?? '');
            self::log($o, 'create', (int)($gw['http'] ?? 200), 'PUSH_SENT', 'USSD push sent to ' . $phone, (string)($gw['raw'] ?? ''));
            return ['success' => true, 'ref' => $ref, 'mode' => 'push', 'message' => t('p_push_sent'),
                'sp_http' => (int)($gw['http'] ?? 0), 'sp_response' => substr((string)($gw['raw'] ?? ''), 0, 1500)];   // v6.7.2: shown on the portal
        }
        if (empty($gw['manual']) && !empty($gw['raw'])) {   // keep the gateway error so the admin can see why the push failed
            error_log('Sonic Pesa collect ' . $ref . ': ' . substr((string)$gw['raw'], 0, 300));
            run("UPDATE hs_orders SET gateway_response=? WHERE id=?", 'si', 'PUSH FAILED: ' . substr((string)$gw['raw'], 0, 3000), $oid);
            self::note($oid, ['sp_status' => 'PUSH_FAILED']);
            self::log($o, 'create', (int)($gw['http'] ?? 0), 'PUSH_FAILED', 'USSD push failed', (string)$gw['raw']);
        }
        if (empty($gw['manual'])) {
            // v6.7.1 — a Sonic Pesa key exists: never send the customer to "contact the administrator". Fail clearly instead,
            // keep the exact reason for the admin and tell the seller, so the customer can simply try again.
            run("UPDATE hs_orders SET status='failed' WHERE id=? AND status='pending'", 'i', $oid);
            $why = substr(trim(preg_replace('/\s+/', ' ', strip_tags((string)($gw['raw'] ?? 'no answer')))), 0, 300);
            try { setSetting('sp_last_push_error', date('Y-m-d H:i:s') . ' • ' . $ref . ' • ' . $phone . ' • ' . money($pkg['price']) . ' • ' . $why); } catch (Throwable $e) {}
            if (rateLimitCheck('spfail' . (int)$pkg['seller_id'], 'sp_push_fail', 1, 600))
                Notify::add((int)$pkg['seller_id'], t('sp_push_failed_title'), $ref . ' • ' . $phone . ' • ' . $why, 'error', '?page=transactions&status=failed', 'triangle-exclamation');
            return ['success' => false, 'message' => t('p_push_failed'),
                'sp_http' => (int)($gw['http'] ?? 0), 'sp_response' => substr((string)($gw['raw'] ?? ''), 0, 1500)];   // v6.7.2: shown on the portal
        }
        // v6.7.2 — the manual "Lipa Namba / Contact: seller + Ref" fallback is removed: no Sonic Pesa key (or a broken endpoint
        // setting) is reported as such, the customer is never asked to contact the administrator.
        run("UPDATE hs_orders SET status='failed', gateway_response=? WHERE id=? AND status='pending'", 'si', 'NO SONIC PESA KEY / ENDPOINT', $oid);
        self::log($o, 'create', 0, 'NO_KEY', 'Sonic Pesa API key or collection endpoint missing');
        try { setSetting('sp_last_push_error', date('Y-m-d H:i:s') . ' • ' . $ref . ' • ' . t('p_sp_no_key')); } catch (Throwable $e) {}
        return ['success' => false, 'message' => t('p_sp_no_key'), 'sp_http' => 0,
            'sp_response' => sonicCollectEndpoint() === '' ? 'Collection endpoint setting is invalid (Admin → Platform settings → clear it).' : 'SONIC_PESA_API_KEY is empty.'];
    }

    /**
     * v6.6 — Sonic Pesa USSD push, exactly as in MIKEKA APP (proven working):
     * POST {base}/payment/create_order  headers X-API-KEY (+ secret only if one is set)
     * body {buyer_email, buyer_name, buyer_phone 255XXXXXXXXX, amount, currency TZS, callback_url, metadata}
     * answer {status:"success", data:{order_id:"..."}} → order_id is saved as gateway_ref and checked with /payment/order_status.
     * Without an API key it returns manual=true and the portal falls back to "Lipa Namba" confirmation by the seller.
     */
    static function collect(string $ref, float $amount, string $phone, string $desc, int $sellerId = 0, int $packageId = 0): array {
        $ep = sonicCollectEndpoint();
        if ($ep === '' || !self::sonicConfigured()) return ['success' => false, 'manual' => true, 'http' => 0,
            'raw' => $ep === '' ? 'Collection endpoint setting is invalid' : 'SONIC_PESA_API_KEY is empty'];
        $phone255 = '255' . substr(normalizePhone($phone), 1);
        // v6.7.2 — MIKEKA APP's exact create_order body (buyer_email customer@mikekaapp.com, buyer_name, buyer_phone 255…, amount,
        // currency TZS, callback_url, metadata user_id / package_type / phone_number) + our order_ref so the callback finds the order
        $payload = [
            'buyer_email' => 'customer@mikekaapp.com',
            'buyer_name' => 'Customer',
            'buyer_phone' => $phone255,
            'amount' => (int)round($amount),
            'currency' => 'TZS',
            'callback_url' => sonicCallbackUrl(),
            'metadata' => ['user_id' => $sellerId, 'package_type' => 'wifi', 'phone_number' => $phone255, 'order_ref' => $ref],
        ];
        [$http, $err, $d, $res] = self::sonicPost($ep, $payload, 25);
        if ($err !== '') return ['success' => false, 'raw' => $err, 'http' => $http];
        $st = strtolower((string)($d['status'] ?? ''));
        $gref = self::orderIdOf($d);
        if ($http >= 400 && $http < 500 && !in_array($http, [401, 403, 429], true) && $gref === '') {
            // v6.7.2 — refused (validation): try once more with this website's own e-mail domain and the full metadata
            $first = 'HTTP ' . $http . ' ' . substr($res, 0, 600);
            $payload['buyer_email'] = 'customer@' . sonicMailHost();
            $payload['buyer_name'] = 'WiFi Customer';
            $payload['metadata'] = ['order_ref' => $ref, 'seller_id' => $sellerId, 'package_id' => $packageId, 'phone_number' => $phone255, 'description' => substr($desc, 0, 60)];
            [$http, $err, $d, $res] = self::sonicPost($ep, $payload, 25);
            if ($err !== '') return ['success' => false, 'raw' => $first . ' | retry: ' . $err, 'http' => $http];
            $st = strtolower((string)($d['status'] ?? ''));
            $gref = self::orderIdOf($d);
            if (!($http >= 200 && $http < 300)) $res = $first . ' | retry: HTTP ' . $http . ' ' . $res;
        }
        if ($http >= 200 && $http < 300 && ($st === 'success' || ($st === '' && $gref !== ''))) {
            return ['success' => true, 'gateway_ref' => substr($gref, 0, 100), 'raw' => substr($res, 0, 2000), 'http' => $http];
        }
        return ['success' => false, 'raw' => 'HTTP ' . $http . ' ' . (isset($d['message']) && is_scalar($d['message']) ? $d['message'] . ' • ' : '') . substr($res, 0, 1500), 'http' => $http];
    }

    /** Only the Sonic Pesa API key is required (the secret is optional), the same as MIKEKA APP. */
    static function sonicConfigured(): bool { return sonicApiKey() !== ''; }

    /** POST to the Sonic Pesa API (2 attempts on a connection error). Returns [http code, curl error, decoded JSON array, raw body]. */
    static function sonicPost(string $path, array $body, int $timeout = 20): array {
        if (!canCall('curl_init')) return [0, 'cURL unavailable on this host', [], ''];
        $hdr = ['Content-Type: application/json', 'Accept: application/json', 'X-API-KEY: ' . sonicApiKey()];
        $sec = sonicApiSecret();
        if ($sec !== '') { $hdr[] = 'X-SECRET-KEY: ' . $sec; $hdr[] = 'X-API-SECRET: ' . $sec; }
        $http = 0; $err = ''; $res = '';
        for ($i = 1; $i <= 2; $i++) {
            $ch = curl_init(SONIC_PESA_MIKEKA_URL . $path);   // v6.7.3: exactly MIKEKA APP (SP_URL . $endpoint)
            curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_SLASHES), CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_HTTPHEADER => $hdr,
                CURLOPT_USERAGENT => 'SkyTanzaWiFi/' . APP_VERSION]);
            $r = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = (string)curl_error($ch); curl_close($ch);
            $res = is_string($r) ? $r : '';
            if ($err === '') break;
            if ($i < 2) pauseMs(500);
        }
        return [$http, $err, json_decode($res, true) ?: [], $res];
    }

    /** The Sonic Pesa order_id from a create_order / order_status / callback answer. */
    static function orderIdOf(array $d): string {
        foreach ([$d['data']['order_id'] ?? null, $d['order_id'] ?? null, $d['transaction']['order_id'] ?? null, $d['data']['order']['order_id'] ?? null,
                  $d['data']['transaction']['order_id'] ?? null, $d['data']['id'] ?? null] as $v)
            if (is_scalar($v) && trim((string)$v) !== '') return trim((string)$v);
        return '';
    }
    /** Mobile-money transaction id from a Sonic Pesa answer. */
    static function txIdOf(array $d): string {
        foreach ([$d['transaction']['id'] ?? null, $d['transaction']['transid'] ?? null, $d['data']['transaction_id'] ?? null, $d['data']['transid'] ?? null,
                  $d['data']['transaction']['id'] ?? null, $d['transaction_id'] ?? null, $d['transid'] ?? null, $d['data']['reference'] ?? null] as $v)
            if (is_scalar($v) && trim((string)$v) !== '') return substr(trim((string)$v), 0, 100);
        return '';
    }
    /** The payment state text Sonic Pesa reported (SUCCESS / PENDING / CANCELLED …) for display. */
    static function rawState(array $d): string {
        foreach ([$d['transaction']['status'] ?? null, $d['data']['payment_status'] ?? null, $d['data']['transaction']['status'] ?? null, $d['payment_status'] ?? null,
                  $d['data']['transaction_status'] ?? null, $d['transaction_status'] ?? null, $d['data']['order_status'] ?? null, $d['order_status'] ?? null,
                  $d['data']['status'] ?? null, $d['event'] ?? null] as $v)
            if (is_scalar($v) && trim((string)$v) !== '') return strtoupper(substr(trim((string)$v), 0, 30));
        return '';
    }

    private static function classify(string $s): ?bool {
        $s = str_replace([' ', '-', '_', '.'], '', strtolower(trim($s)));
        if ($s === '') return null;
        if (in_array($s, ['success', 'successful', 'succeeded', 'completed', 'complete', 'paid', 'settled', 'approved', 'paymentsuccess', 'paymentcompleted'], true)) return true;
        if (in_array($s, ['failed', 'fail', 'failure', 'cancelled', 'canceled', 'usercancelled', 'usercanceled', 'rejected', 'declined', 'expired', 'reversed',
                          'paymentfailed', 'paymentcancelled', 'paymentcanceled', 'insufficientfunds', 'timeout'], true)) return false;
        return null;
    }

    /**
     * Read a payment state from a Sonic Pesa answer (order_status reply or callback). true = paid, false = failed, null = still pending / unknown.
     * Same rules as MIKEKA APP: event "payment.success"; transaction.status / data.payment_status = SUCCESS | COMPLETED → paid.
     * A success anywhere wins (Sonic Pesa sometimes leaves data.payment_status = PENDING while transaction.status is already SUCCESS).
     * A bare top-level "status":"success" only means "request OK", so it is never taken as "paid".
     */
    static function paidState(array $d): ?bool {
        $ev = (string)($d['event'] ?? '');
        if ($ev !== '') { $e = self::classify(preg_replace('/^.*[.:]/', '', $ev)); if ($e !== null) return $e; }
        $vals = [];
        foreach ([$d['transaction']['status'] ?? null, $d['data']['payment_status'] ?? null, $d['data']['transaction']['status'] ?? null,
                  $d['payment_status'] ?? null, $d['data']['transaction_status'] ?? null, $d['transaction_status'] ?? null,
                  $d['data']['order_status'] ?? null, $d['order_status'] ?? null, $d['data']['status'] ?? null] as $i => $v) {
            if (!is_scalar($v) || trim((string)$v) === '') continue;
            if ($i === 8 && strtolower(trim((string)$v)) === 'success') continue;   // v6.7: data.status "success" = request OK, not "paid"
            $vals[] = self::classify((string)$v);
        }
        if (in_array(true, $vals, true)) return true;
        if (in_array(false, $vals, true)) return false;
        if (!$vals && !isset($d['data']) && !isset($d['transaction'])) {   // flat callbacks: {"status":"COMPLETED"} (but never plain "success")
            $s = strtolower(trim((string)($d['status'] ?? '')));
            if ($s !== '' && $s !== 'success') return self::classify($s);
        }
        return null;   // PENDING (waiting for the customer's PIN) or unknown
    }

    /**
     * Ask Sonic Pesa for the state of an order we created (POST {base}/payment/order_status {"order_id": gateway_ref}).
     * SUCCESS → the order is paid: a voucher for the package is created, the seller is credited and the customer is connected.
     * CANCELLED / USERCANCELLED / REJECTED → failed. PENDING → nothing changes (polled again later).
     */
    static function checkGateway(array $o, string $source = 'status'): ?bool {
        if ((string)($o['gateway_ref'] ?? '') === '' || !self::sonicConfigured()) return null;
        [$http, $err, $d, $res] = self::sonicPost(sonicStatusEndpoint(), ['order_id' => (string)$o['gateway_ref']], 15);
        self::$lastStatusRaw = $err !== '' ? $err : substr($res, 0, 4000);
        $ok = $err === '' && $http >= 200 && $http < 300 && $d;
        $paid = $ok ? self::paidState($d) : null;
        $raw = $ok ? self::rawState($d) : ($err !== '' ? 'ERROR' : 'HTTP_' . $http);
        $txid = $ok ? self::txIdOf($d) : '';
        $channel = $ok ? substr((string)($d['data']['channel'] ?? ($d['transaction']['channel'] ?? '')), 0, 50) : '';
        $f = ['sp_status' => $raw, 'sp_checked_at' => '__NOW__', 'sp_check_count' => '__INC__'];
        if ($txid !== '') $f['sp_transid'] = $txid;
        if ($channel !== '') $f['sp_channel'] = $channel;
        self::note((int)$o['id'], $f);
        self::log($o, $source, $http, $raw, $err !== '' ? $err : ($paid === true ? 'paid' : ($paid === false ? 'failed' : 'pending')), $res);
        if (!$ok) { error_log('Sonic Pesa order_status ' . $o['order_ref'] . ': HTTP ' . $http . ' ' . $err . ' ' . substr($res, 0, 300)); return null; }
        $amt = $d['transaction']['amount'] ?? ($d['data']['amount'] ?? ($d['amount'] ?? null));
        if ($paid === true && is_numeric($amt) && (float)$amt > 0 && (float)$amt + 0.5 < (float)$o['amount']) {   // paid less than the price
            run("UPDATE hs_orders SET gateway_response=? WHERE id=?", 'si', 'UNDERPAID ' . substr($res, 0, 3900), (int)$o['id']);
            self::note((int)$o['id'], ['sp_status' => 'UNDERPAID']);
            return null;
        }
        if ($paid === true) {
            $r = self::fulfill((string)$o['order_ref'], (string)$o['gateway_ref'], substr($res, 0, 4000), 'sonicpesa', $txid);
            return ($r && ($r['status'] ?? '') === 'paid') ? true : null;   // voucher not issued yet → retried on the next poll
        }
        if ($paid === false) run("UPDATE hs_orders SET status='failed', gateway_response=? WHERE id=? AND status IN ('pending','expired')", 'si', substr($res, 0, 4000), (int)$o['id']);
        else run("UPDATE hs_orders SET gateway_response=? WHERE id=? AND status IN ('pending','expired','failed')", 'si', substr($res, 0, 4000), (int)$o['id']);
        return $paid;
    }

    /**
     * Background polling of Sonic Pesa order_status for every unconfirmed portal payment, so the status is updated even when the customer
     * closed the WiFi login page and the callback never arrived. Throttled (whole site: every 20 s; each order: every 20 s in the first
     * 10 minutes, then every 60 s). Pending / expired orders of the last 6 hours and "failed" orders of the last 2 hours are checked.
     */
    static function pollPending(int $limit = 8, bool $force = false): int {
        if (!self::sonicConfigured()) return 0;
        try {
            if (!$force) {
                $last = getSetting('sp_poll_last', '0');
                if (time() - (int)$last < 20) return 0;
                if (run("UPDATE settings SET setting_value=? WHERE setting_key='sp_poll_last' AND setting_value=?", 'ss', (string)time(), $last) !== 1) {
                    q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES ('sp_poll_last', ?, 'system')", 's', (string)time());
                    if ($last !== '0') return 0;
                }
            }
            $n = 0;
            $t0 = microtime(true);
            foreach (rows("SELECT * FROM hs_orders WHERE gateway_ref IS NOT NULL AND gateway_ref<>''
                           AND ((status IN ('pending','expired') AND created_at > DATE_SUB(NOW(), INTERVAL 6 HOUR))
                             OR (status='failed' AND created_at > DATE_SUB(NOW(), INTERVAL 2 HOUR)))
                           ORDER BY id DESC LIMIT ?", 'i', max(1, $limit)) as $o) {
                if (microtime(true) - $t0 > 25) break;
                $young = strtotime($o['created_at']) > time() - 600;
                if (!$force && !rateLimitCheck('sp' . $o['order_ref'], 'sp_bg', 1, $o['status'] === 'failed' ? 120 : ($young ? 20 : 60))) continue;
                try { if (self::checkGateway($o, $force ? 'recheck' : 'poll') === true) $n++; } catch (Throwable $e) { error_log('pollPending ' . $o['order_ref'] . ': ' . $e->getMessage()); }
            }
            return $n;
        } catch (Throwable $e) { error_log('pollPending: ' . $e->getMessage()); return 0; }
    }

    /** The package an order pays for (falls back to the seller's package with the same price if it was deleted). */
    static function packageFor(array $o): int {
        $pid = (int)($o['package_id'] ?? 0);
        if ($pid && val("SELECT 1 FROM hs_packages WHERE id=? AND seller_id=?", 'ii', $pid, (int)$o['seller_id'])) return $pid;
        return (int)val("SELECT id FROM hs_packages WHERE seller_id=? AND price=? ORDER BY is_active DESC, id LIMIT 1", 'id', (int)$o['seller_id'], (float)$o['amount']);
    }

    /**
     * v6.6 — what the voucher of a paid order looks like: the package (or one with the same price), else the copy of the package
     * saved on the order when it was created. null = nothing usable (the reason is in self::$lastError).
     */
    static function voucherSpec(array $o): ?array {
        $pid = self::packageFor($o);
        $p = $pid ? row("SELECT * FROM hs_packages WHERE id=?", 'i', $pid) : null;
        if ($p) return ['package_id' => (int)$p['id'], 'device_id' => $p['device_id'] !== null ? (int)$p['device_id'] : null, 'minutes' => max(1, (int)$p['duration_minutes']),
            'mode' => $p['time_mode'] === 'online' ? 'online' : 'continuous', 'data_mb' => (int)$p['data_limit_mb'], 'down' => (float)$p['speed_down_mbps'],
            'up' => (float)$p['speed_up_mbps'], 'devices' => max(1, (int)$p['max_devices']), 'valid_days' => (int)$p['validity_days']];
        if ((int)($o['pkg_minutes'] ?? 0) > 0) return ['package_id' => null, 'device_id' => null, 'minutes' => (int)$o['pkg_minutes'],
            'mode' => ($o['pkg_mode'] ?? '') === 'online' ? 'online' : 'continuous', 'data_mb' => (int)($o['pkg_data_mb'] ?? 0), 'down' => (float)($o['pkg_down'] ?? 0),
            'up' => (float)($o['pkg_up'] ?? 0), 'devices' => max(1, (int)($o['pkg_devices'] ?? 1)), 'valid_days' => (int)($o['pkg_valid_days'] ?? 30)];
        self::$lastError = t('pay_no_package');
        return null;
    }

    /** Insert the voucher of a paid order (status "sold", source "online"). Returns [id, code]. Throws on a database error. */
    private static function issueVoucher(array $spec, array $o): array {
        $len = max(6, min(12, (int)getSetting('voucher_length', '8')));
        $batch = 'P' . date('ymdHi') . strtoupper(bin2hex(random_bytes(2)));
        $validUntil = $spec['valid_days'] > 0 ? date('Y-m-d H:i:s', time() + $spec['valid_days'] * 86400) : null;
        $last = null;
        for ($try = 0; $try < 10; $try++) {
            $code = genCode($len);
            try {
                q("INSERT INTO hs_vouchers (package_id,seller_id,device_id,code,batch,price,duration_minutes,time_mode,data_limit_mb,speed_down_mbps,speed_up_mbps,max_devices,status,source,sold_to_phone,sold_at,valid_until)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'sold','online',?,NOW(),?)", 'iiissdisiddiss',
                    $spec['package_id'], (int)$o['seller_id'], $spec['device_id'], $code, $batch, (float)$o['amount'], $spec['minutes'], $spec['mode'],
                    $spec['data_mb'], $spec['down'], $spec['up'], $spec['devices'], substr((string)$o['phone'], 0, 20), $validUntil);
                return [(int)db()->insert_id, $code];
            } catch (mysqli_sql_exception $e) {
                if ($e->getCode() != 1062) throw $e;   // only a duplicate code is retried
                $last = $e;
            }
        }
        throw new RuntimeException('Could not create a unique voucher code' . ($last ? ': ' . $last->getMessage() : ''));
    }

    /**
     * Idempotent: issues exactly one voucher per paid order and credits the seller (mobile money / manual confirmation).
     * v6.6: on any failure the exact database error is kept in self::$lastError and hs_orders.fulfill_error (shown on Transactions → Payments)
     * instead of the old generic "the voucher could not be issued".
     */
    static function fulfill(string $ref, string $gatewayRef = '', string $raw = '', string $method = 'mobile_money', string $txid = ''): ?array {
        self::$lastError = '';
        $o0 = row("SELECT * FROM hs_orders WHERE order_ref=?", 's', $ref);
        if (!$o0) { self::$lastError = 'Order ' . $ref . ' not found'; return null; }
        if ($o0['status'] === 'paid') return $o0;
        $spec = self::voucherSpec($o0);
        if (!$spec) {
            self::note((int)$o0['id'], ['fulfill_error' => substr(self::$lastError, 0, 500), 'fulfill_attempts' => '__INC__']);
            self::log($o0, 'fulfill', 0, 'ERROR', self::$lastError);
            return null;
        }
        try { db()->query("SET SESSION innodb_lock_wait_timeout = 15"); } catch (Throwable $e) {}
        $o = $o0; $code = ''; $vid = 0;
        db()->begin_transaction();
        try {
            $o = row("SELECT * FROM hs_orders WHERE id=? FOR UPDATE", 'i', (int)$o0['id']);
            if (!$o || $o['status'] === 'paid') { db()->commit(); return $o; }
            [$vid, $code] = self::issueVoucher($spec, $o);
            run("UPDATE hs_orders SET status='paid', paid_at=NOW(), voucher_id=?, gateway_ref=IF(?<>'',?,gateway_ref), gateway_response=IF(?<>'',?,gateway_response) WHERE id=?",
                'issssi', $vid, $gatewayRef, $gatewayRef, $raw, $raw, (int)$o['id']);
            $commission = max(0, min(100, (float)getSetting('platform_commission_percent', '0')));
            $amount = round((float)$o['amount'], 2);
            $net = round($amount * (1 - $commission / 100), 2);
            run("UPDATE users SET balance=balance+? WHERE id=?", 'di', $net, (int)$o['seller_id']);
            q("INSERT INTO transactions (seller_id,voucher_id,transaction_ref,amount,payment_method,payment_phone,type,status,completed_at,notes)
               VALUES (?,?,?,?,?,?,'purchase','completed',NOW(),?)
               ON DUPLICATE KEY UPDATE seller_id=VALUES(seller_id), voucher_id=VALUES(voucher_id), amount=VALUES(amount), payment_method=VALUES(payment_method),
                 type='purchase', status='completed', completed_at=NOW(), notes=VALUES(notes)",
                'iisdsss', (int)$o['seller_id'], $vid, (string)$o['order_ref'], $amount, substr($method, 0, 30), substr((string)$o['phone'], 0, 20),
                'Portal order' . ($txid !== '' ? ' | ' . $txid : ''));
            if ($commission > 0 && $amount - $net > 0) {
                q("INSERT INTO transactions (seller_id,voucher_id,transaction_ref,amount,payment_method,type,status,completed_at,notes)
                   VALUES (?,?,?,?,'internal','commission','completed',NOW(),?)
                   ON DUPLICATE KEY UPDATE amount=VALUES(amount), status='completed', completed_at=NOW()",
                    'iisds', (int)$o['seller_id'], $vid, $o['order_ref'] . '-C', round($amount - $net, 2), "Platform commission {$commission}%");
            }
            db()->commit();
        } catch (Throwable $e) {
            try { db()->rollback(); } catch (Throwable $t) {}
            self::$lastError = $e->getMessage();
            error_log('fulfill ' . $ref . ': ' . $e->getMessage() . ' @' . $e->getLine());
            self::note((int)$o0['id'], ['fulfill_error' => substr($e->getMessage(), 0, 500), 'fulfill_attempts' => '__INC__']);
            self::log($o0, 'fulfill', 0, 'ERROR', $e->getMessage());
            return null;
        }
        $f = ['fulfill_error' => '', 'sp_status' => $method === 'sonicpesa' ? 'SUCCESS' : 'CONFIRMED'];
        if ($txid !== '') $f['sp_transid'] = $txid;
        self::note((int)$o['id'], $f);
        self::log($o, 'fulfill', 200, 'PAID', 'Voucher ' . $code . ' issued (' . $method . ')');
        Notify::add((int)$o['seller_id'], 'New sale', $o['order_ref'] . ' • ' . money($o['amount']) . ' • ' . $o['phone'] . ' • ' . $code, 'success', '?page=transactions&status=paid', 'check');
        return row("SELECT * FROM hs_orders WHERE id=?", 'i', (int)$o['id']);
    }

    /** v6.7.1 — Admin → "Send a test USSD push": a real create_order to $phone, returns the full Sonic Pesa answer. */
    static function testPush(string $phone, int $amount): array {
        $phone = normalizePhone($phone);
        if (!preg_match('/^0[67]\d{8}$/', $phone)) return ['ok' => false, 'msg' => t('p_invalid_phone')];
        if (!self::sonicConfigured()) return ['ok' => false, 'msg' => 'No Sonic Pesa API key is set.'];
        $ep = sonicCollectEndpoint();
        if ($ep === '') return ['ok' => false, 'msg' => 'The Sonic Pesa collection endpoint setting is invalid — clear it (empty = /payment/create_order).'];
        $gw = self::collect('TEST' . date('ymdHis'), (float)max(100, $amount), $phone, 'Test push', 0, 0);
        $raw = (string)($gw['raw'] ?? '');
        return ['ok' => !empty($gw['success']), 'msg' => (!empty($gw['success']) ? 'USSD push sent to ' . $phone . ' • order ' . ($gw['gateway_ref'] ?? '?') : 'Push refused')
            . ' • HTTP ' . (int)($gw['http'] ?? 0) . ' • ' . SONIC_PESA_MIKEKA_URL . $ep . ' • ' . substr($raw, 0, 1500)];
    }

    /** Admin → "Test Sonic Pesa": order_status for a dummy order — proves the key, the network and the API address. */
    static function testConnection(): array {
        if (!self::sonicConfigured()) return ['ok' => false, 'msg' => 'No Sonic Pesa API key is set.'];
        [$http, $err, $d, $res] = self::sonicPost(sonicStatusEndpoint(), ['order_id' => 'sp_connection_test'], 15);
        if ($err !== '') return ['ok' => false, 'msg' => 'Connection error: ' . $err];
        $msg = isset($d['message']) && is_scalar($d['message']) ? (string)$d['message'] : substr(trim(strip_tags($res)), 0, 200);
        // 401/403 = key refused; 404/422/200 with a JSON answer = the key and the API answered
        $ok = !in_array($http, [0, 401, 403], true) && $http < 500;
        return ['ok' => $ok, 'msg' => 'HTTP ' . $http . ' • ' . $msg . ($ok ? ' — the API key is accepted.' : ' — check the API key.')];
    }
}

// ============================================================
// SONIC PESA PAYOUT (withdrawals)
// ============================================================
class SonicPesaPayout {
    private function req(string $method, string $path, ?array $body = null): array {
        $ch = curl_init(SONIC_PESA_MIKEKA_URL . $path);   // v6.7.3: same fixed Sonic Pesa address as MIKEKA APP
        $o = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json', 'Accept: application/json', 'X-API-KEY: ' . sonicApiKey()],
                sonicApiSecret() !== '' ? ['X-API-SECRET: ' . sonicApiSecret(), 'X-SECRET-KEY: ' . sonicApiSecret()] : [])];   // v6.7: secret only when set
        if ($method === 'POST') { $o[CURLOPT_POST] = true; $o[CURLOPT_POSTFIELDS] = json_encode($body); }
        curl_setopt_array($ch, $o);
        $res = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
        return [$http, $err, json_decode((string)$res, true) ?: []];
    }
    static function configured(): bool { return sonicApiKey() !== ''; }
    function createPayout(float $amount, string $method, string $acc, string $name): array {
        if (!self::configured()) return ['success' => false, 'message' => 'Payouts are not configured yet (Sonic Pesa keys missing in config.local.php).'];
        $map = ['mpesa' => 'M-Pesa', 'tigopesa' => 'Tigo Pesa', 'airtelmoney' => 'Airtel Money', 'halopesa' => 'Halopesa', 'crdb' => 'CRDB Bank', 'nmb' => 'NMB Bank', 'selcom' => 'Selcom'];
        $api = $map[$method] ?? $method;
        $clean = preg_replace('/\D/', '', $acc);
        if ($api === 'Selcom') { if (strlen($clean) == 10 && $clean[0] === '0') $clean = substr($clean, 1); if (strlen($clean) == 12 && substr($clean, 0, 3) === '255') $clean = substr($clean, 3); }
        else { if (strlen($clean) == 9) $clean = '255' . $clean; elseif (strlen($clean) == 10 && $clean[0] === '0') $clean = '255' . substr($clean, 1); }
        [$http, $err, $r] = $this->req('POST', '/payouts/create', ['amount' => $amount, 'method' => $api, 'account_number' => $clean, 'account_name' => $name]);
        if ($err) return ['success' => false, 'message' => 'Connection error: ' . $err];
        if ($http >= 200 && $http < 300 && in_array($r['status'] ?? 'pending', ['success', 'pending'], true)) return ['success' => true, 'data' => $r['data'] ?? $r];
        return ['success' => false, 'message' => $r['message'] ?? "Payout failed (HTTP $http)"];
    }
    function status(string $id): array {
        [$http, $err, $r] = $this->req('GET', '/payouts/status/' . urlencode($id));
        if (!$err && $http >= 200 && $http < 300 && ($r['status'] ?? '') === 'success') return ['success' => true, 'data' => $r['data'] ?? []];
        return ['success' => false];
    }
}

// ============================================================
// v6.4 — EARNINGS: mobile money + vouchers, withdrawals deducted from the total
// ============================================================
final class Earnings
{
    static function commissionPercent(): float { return max(0, min(100, (float)getSetting('platform_commission_percent', '0'))); }

    /**
     * Credit the seller the first time a voucher is used. Idempotent: one ledger row "VCH{id}" per voucher.
     * Vouchers bought with mobile money (source "online") are already credited when the payment arrived — skipped.
     */
    static function creditVoucher(int $vid): bool {
        $v = row("SELECT id, seller_id, price, source, code FROM hs_vouchers WHERE id=?", 'i', $vid);
        if (!$v || $v['source'] === 'online' || (float)$v['price'] <= 0) return false;
        $price = round((float)$v['price'], 2);
        $commission = self::commissionPercent();
        $net = round($price * (1 - $commission / 100), 2);
        $n = 0;
        try {
            db()->begin_transaction();
            $n = q("INSERT IGNORE INTO transactions (seller_id,voucher_id,transaction_ref,amount,payment_method,type,status,completed_at,notes)
                    VALUES (?,?,?,?,'voucher','purchase','completed',NOW(),?)", 'iisds',
                $v['seller_id'], $v['id'], 'VCH' . $v['id'], $price, 'Voucher ' . $v['code'] . ' used')->affected_rows;
            if ($n === 1) {
                run("UPDATE users SET balance=balance+? WHERE id=?", 'di', $net, $v['seller_id']);
                if ($commission > 0 && $price - $net > 0)
                    q("INSERT IGNORE INTO transactions (seller_id,voucher_id,transaction_ref,amount,payment_method,type,status,completed_at,notes)
                       VALUES (?,?,?,?,'internal','commission','completed',NOW(),?)", 'iisds',
                        $v['seller_id'], $v['id'], 'VCH' . $v['id'] . '-C', round($price - $net, 2), "Platform commission {$commission}%");
            }
            db()->commit();
        } catch (Throwable $e) {
            try { db()->rollback(); } catch (Throwable $t) {}
            error_log('creditVoucher #' . $vid . ': ' . $e->getMessage());
            return false;
        }
        return $n === 1;
    }

    /** Earnings of one seller ($uid) or of all sellers ($uid = 0). Amounts in CURRENCY. */
    static function summary(int $uid = 0): array {
        $sql = "SELECT
            COALESCE(SUM(CASE WHEN type='purchase' AND payment_method<>'voucher' THEN amount END),0) mm,
            COALESCE(SUM(CASE WHEN type='purchase' AND payment_method='voucher' THEN amount END),0) vc,
            COALESCE(SUM(CASE WHEN type='commission' THEN amount END),0) com,
            COALESCE(SUM(CASE WHEN type='purchase' AND payment_method<>'voucher' AND DATE(completed_at)=CURDATE() THEN amount END),0) mm_today,
            COALESCE(SUM(CASE WHEN type='purchase' AND payment_method='voucher' AND DATE(completed_at)=CURDATE() THEN amount END),0) vc_today,
            COALESCE(SUM(CASE WHEN type='commission' AND DATE(completed_at)=CURDATE() THEN amount END),0) com_today,
            COALESCE(SUM(CASE WHEN type='purchase' AND DATE_FORMAT(completed_at,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m') THEN amount END),0) gross_month,
            COALESCE(SUM(CASE WHEN type='commission' AND DATE_FORMAT(completed_at,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m') THEN amount END),0) com_month
            FROM transactions WHERE status='completed' AND type IN ('purchase','commission')";
        $r = $uid ? row($sql . " AND seller_id=?", 'i', $uid) : row($sql);
        $r = $r ?: [];
        $f = fn($k) => (float)($r[$k] ?? 0);
        $wdSql = "SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status IN ('pending','processing','completed')";
        $withdrawn = (float)($uid ? val($wdSql . " AND user_id=?", 'i', $uid) : val($wdSql));
        $balance = (float)($uid ? val("SELECT balance FROM users WHERE id=?", 'i', $uid) : val("SELECT COALESCE(SUM(balance),0) FROM users WHERE user_type IN ('seller','admin')"));
        $total = $f('mm') + $f('vc') - $f('com');
        return ['mobile' => $f('mm'), 'vouchers' => $f('vc'), 'commission' => $f('com'), 'total' => $total,
            'mobile_today' => $f('mm_today'), 'vouchers_today' => $f('vc_today'), 'today' => $f('mm_today') + $f('vc_today') - $f('com_today'),
            'month' => $f('gross_month') - $f('com_month'), 'withdrawn' => $withdrawn, 'balance' => $balance];
    }
}

// ============================================================
// v6.4 — PAYMENT RECOVERY: seller / admin confirms pending, failed or expired portal payments; the customer is connected
// ============================================================
final class PaymentOps
{
    static function canManage(?array $o, int $uid, bool $admin): bool { return $o !== null && ($admin || (int)$o['seller_id'] === $uid); }

    /** Confirm a payment by hand (money received on Lipa Namba / failed or late gateway payment). Issues the voucher and credits the seller. */
    static function confirm(int $orderId, int $byUid, string $gwRef = '', string $note = ''): array {
        $o = row("SELECT * FROM hs_orders WHERE id=?", 'i', $orderId);
        if (!$o) return ['ok' => false, 'msg' => 'Not found'];
        if ($o['status'] === 'paid') return ['ok' => true, 'msg' => t('pay_already_paid'), 'order' => $o];
        $gwRef = substr(preg_replace('/[^\x20-\x7E]/', '', trim($gwRef)), 0, 100);
        $r = Payments::fulfill((string)$o['order_ref'], $gwRef, '', 'manual', $gwRef);
        if (!$r || ($r['status'] ?? '') !== 'paid')
            return ['ok' => false, 'msg' => t('pay_confirm_failed') . (Payments::$lastError !== '' ? ' — ' . Payments::$lastError : '')];
        try { run("UPDATE hs_orders SET confirmed_by=?, confirmed_at=NOW(), admin_note=IF(?<>'', ?, admin_note), reconnect_done=0 WHERE id=?", 'issi', $byUid, $note, $note, $orderId); }
        catch (Throwable $e) { error_log('PaymentOps::confirm: ' . $e->getMessage()); }
        logActivity($byUid, 'payment_confirm', $o['order_ref'] . ' ' . money($o['amount']) . ' ' . $o['phone'] . ($gwRef !== '' ? ' • ' . $gwRef : ''));
        if ((int)$o['seller_id'] !== $byUid)
            Notify::add((int)$o['seller_id'], t('pay_admin_confirmed_title'), $o['order_ref'] . ' • ' . money($o['amount']) . ' • ' . $o['phone'], 'success', '?page=transactions&status=paid', 'check');
        $order = row("SELECT o.*, v.code FROM hs_orders o LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.id=?", 'i', $orderId);
        return ['ok' => true, 'msg' => sprintf(t('pay_confirmed'), $o['order_ref'], (string)($order['code'] ?? '')), 'order' => $order];
    }

    /**
     * v6.5 — seller / admin sets the status of a payment. "paid" creates the voucher for the order's package automatically
     * (via confirm → fulfill), credits the seller and connects the customer. Other statuses are only allowed on unpaid payments.
     */
    static function setStatus(int $orderId, int $byUid, string $to, string $gwRef = '', string $note = ''): array {
        $o = row("SELECT * FROM hs_orders WHERE id=?", 'i', $orderId);
        if (!$o) return ['ok' => false, 'msg' => 'Not found'];
        if ($to === 'paid') return self::confirm($orderId, $byUid, $gwRef, $note);
        if (!in_array($to, ['pending', 'failed', 'cancelled', 'expired'], true)) return ['ok' => false, 'msg' => 'Invalid status'];
        if ($o['status'] === 'paid') return ['ok' => false, 'msg' => t('pay_paid_locked')];
        run("UPDATE hs_orders SET status=?, admin_note=IF(?<>'', ?, admin_note) WHERE id=?", 'sssi', $to, $note, $note, $orderId);
        logActivity($byUid, 'payment_status', $o['order_ref'] . ' ' . $o['status'] . ' → ' . $to);
        return ['ok' => true, 'msg' => sprintf(t('pay_status_set'), $o['order_ref'], $to)];
    }

    /** Ask the Omada controller to reconnect the customer's phone so its WiFi login page reopens and connects it. [sites, message]. */
    static function connectClient(array $o): array {
        $mac = normMac((string)($o['client_mac'] ?? ''));
        if ($mac === '') return [0, t('pay_no_mac')];
        try { run("UPDATE hs_orders SET reconnect_done=1, reconnect_at=NOW() WHERE id=?", 'i', $o['id']); } catch (Throwable $e) {}
        return OmadaClientOps::apply((int)$o['seller_id'], $mac, 'reconnect', (int)($o['device_id'] ?? 0));
    }

    /**
     * Paid payments (confirmed by Sonic Pesa, by the callback, by background polling or by the seller / admin) whose voucher is
     * still unused ~45 s later: the customer is no longer on the portal, so reconnect the phone once — its WiFi login page reopens,
     * recognises the paid order (same phone MAC) and connects it with the new voucher automatically.
     */
    static function nudgeLate(int $limit = 5): void {
        try {
            foreach (rows("SELECT o.* FROM hs_orders o JOIN hs_vouchers v ON v.id=o.voucher_id
                           WHERE o.status='paid' AND o.reconnect_done=0 AND v.first_used_at IS NULL AND o.client_mac IS NOT NULL AND o.client_mac<>''
                             AND o.paid_at < DATE_SUB(NOW(), INTERVAL 45 SECOND) AND o.paid_at > DATE_SUB(NOW(), INTERVAL 3 HOUR)
                           ORDER BY o.id LIMIT ?", 'i', $limit) as $o) {
                if (run("UPDATE hs_orders SET reconnect_done=1, reconnect_at=NOW() WHERE id=? AND reconnect_done=0", 'i', $o['id']) !== 1) continue;
                OmadaClientOps::apply((int)$o['seller_id'], (string)$o['client_mac'], 'reconnect', (int)($o['device_id'] ?? 0));
            }
        } catch (Throwable $e) { error_log('PaymentOps::nudgeLate: ' . $e->getMessage()); }
    }
}

// ============================================================
// SELLER OPERATIONS (sessions, time adjustments, blocks, stats)
// ============================================================
class SessionOps {
    static function active(int $uid, int $deviceId = 0): array {
        $sql = "SELECT s.*, v.code, v.time_mode, v.duration_minutes, v.first_used_at, v.expires_at, v.seconds_used, v.data_limit_mb, v.data_used_bytes,
                       p.name AS package_name, d.device_name
                FROM hs_sessions s LEFT JOIN hs_vouchers v ON v.id=s.voucher_id LEFT JOIN hs_packages p ON p.id=v.package_id
                LEFT JOIN hs_devices d ON d.id=s.device_id WHERE s.seller_id=? AND s.status='active'";
        return $deviceId ? rows($sql . " AND s.device_id=? ORDER BY s.started_at DESC", 'ii', $uid, $deviceId) : rows($sql . " ORDER BY s.started_at DESC", 'i', $uid);
    }
    static function adjust(int $vid, int $uid, int $minutes, string $reason = ''): array {
        $v = row("SELECT * FROM hs_vouchers WHERE id=? AND seller_id=?", 'ii', $vid, $uid);
        if (!$v || $minutes === 0) return ['success' => false, 'message' => t('adjustment_failed')];
        if (in_array($v['status'], ['blocked', 'cancelled'], true)) return ['success' => false, 'message' => t('voucher_blocked')];
        if ($v['time_mode'] === 'continuous' && $v['first_used_at']) {
            $old = $v['expires_at'];
            $base = $minutes > 0 ? max(strtotime($old), time()) : strtotime($old);
            $new = date('Y-m-d H:i:s', $base + $minutes * 60);
            run("UPDATE hs_vouchers SET expires_at=? WHERE id=?", 'si', $new, $vid);
        } else {
            $old = (string)$v['duration_minutes'];
            $new = (string)max(1, (int)$v['duration_minutes'] + $minutes);
            run("UPDATE hs_vouchers SET duration_minutes=? WHERE id=?", 'ii', (int)$new, $vid);
        }
        q("INSERT INTO hs_adjustments (voucher_id,seller_id,minutes,old_value,new_value,reason) VALUES (?,?,?,?,?,?)", 'iiisss', $vid, $uid, $minutes, $old, $new, substr($reason, 0, 255));
        $v = row("SELECT * FROM hs_vouchers WHERE id=?", 'i', $vid);
        $rem = Vouchers::remainingSeconds($v);
        if ($rem <= 0) Vouchers::setStatus($vid, 'expired', 'Time reduced by seller');
        elseif ($v['status'] === 'expired') run("UPDATE hs_vouchers SET status=IF(first_used_at IS NULL,'available','active') WHERE id=?", 'i', $vid);
        return ['success' => true, 'message' => t('adjustment_success') . ' (' . t('remaining') . ': ' . fmtSecs($rem) . ')'];
    }
    static function disconnect(int $sid, int $uid): bool {
        $s = row("SELECT * FROM hs_sessions WHERE id=? AND seller_id=?", 'ii', $sid, $uid);
        if (!$s) return false;
        Radius::queueSessionDisconnect($s, 'Seller disconnect');
        return true;
    }
    static function blockMac(int $uid, string $mac, string $reason = ''): bool {
        $mac = normMac($mac);
        if ($mac === '') return false;
        q("INSERT IGNORE INTO hs_blocked_macs (seller_id, mac, reason) VALUES (?,?,?)", 'iss', $uid, $mac, substr($reason, 0, 255));
        foreach (rows("SELECT * FROM hs_sessions WHERE seller_id=? AND mac=? AND status='active'", 'is', $uid, $mac) as $s) Radius::queueSessionDisconnect($s, 'Blocked');
        return true;
    }
    static function stats(int $uid): array {
        $c = fn($sql) => val($sql, 'i', $uid);
        $e = Earnings::summary($uid);   // v6.4: mobile money + vouchers
        return [
            'active_sessions' => (int)$c("SELECT COUNT(*) FROM hs_sessions WHERE seller_id=? AND status='active'"),
            'today_revenue' => $e['today'], 'month_revenue' => $e['month'], 'total_revenue' => $e['total'],
            'earn_mobile' => $e['mobile'], 'earn_vouchers' => $e['vouchers'], 'earn_withdrawn' => $e['withdrawn'], 'earn_balance' => $e['balance'],
            'available' => (int)$c("SELECT COUNT(*) FROM hs_vouchers WHERE seller_id=? AND status IN ('available','sold')"),
            'active_vouchers' => (int)$c("SELECT COUNT(*) FROM hs_vouchers WHERE seller_id=? AND status='active'"),
            'used_today' => (int)$c("SELECT COUNT(*) FROM hs_vouchers WHERE seller_id=? AND DATE(first_used_at)=CURDATE()"),
            'pending_orders' => (int)$c("SELECT COUNT(*) FROM hs_orders WHERE seller_id=? AND status='pending'"),
            'attention_orders' => (int)$c("SELECT COUNT(*) FROM hs_orders WHERE seller_id=? AND status IN ('pending','failed','expired')"),
            'devices' => (int)$c("SELECT COUNT(*) FROM hs_devices WHERE user_id=?"),
            'devices_online' => (int)$c("SELECT COUNT(*) FROM hs_devices WHERE user_id=? AND (last_seen > DATE_SUB(NOW(), INTERVAL 10 MINUTE) OR (omada_status='connected' AND omada_status_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)))"),
        ];
    }
}

// ============================================================
// HOUSEKEEPING — "lazy cron": runs at most once a minute, triggered by RADIUS accounting
// traffic and dashboard visits. A real cPanel cron on ?cron=run is optional.
// ============================================================
class Housekeeping {
    static function maybe(): void {
        $last = getSetting('hk_last_run', '0');
        if (time() - (int)$last < 60) return;
        if (run("UPDATE settings SET setting_value=? WHERE setting_key='hk_last_run' AND setting_value=?", 'ss', (string)time(), $last) !== 1) return;
        try { self::run(false); } catch (Throwable $e) { error_log('Housekeeping: ' . $e->getMessage()); }
    }
    static function run(bool $withPayouts = true): array {
        $r = ['stale' => 0, 'expired' => 0, 'orders_expired' => 0, 'payouts' => 0];
        $staleAfter = (int)RADIUS_INTERIM * 3 + 120;
        $r['stale'] = run("UPDATE hs_sessions SET status='stale', terminate_cause=COALESCE(terminate_cause,'No-Accounting') WHERE status='active' AND updated_at < DATE_SUB(NOW(), INTERVAL ? SECOND)", 'i', $staleAfter);
        foreach (rows("SELECT id FROM hs_vouchers WHERE status='active' AND time_mode='continuous' AND expires_at IS NOT NULL AND expires_at < NOW() LIMIT 500") as $v) {
            Vouchers::setStatus((int)$v['id'], 'expired', 'Time expired'); $r['expired']++;
        }
        $r['expired'] += run("UPDATE hs_vouchers SET status='expired' WHERE status IN ('available','sold') AND valid_until IS NOT NULL AND valid_until < NOW()");
        try { $r['payments_confirmed'] = Payments::pollPending(10); } catch (Throwable $e) { error_log('Housekeeping pollPending: ' . $e->getMessage()); }   // v6.6
        $r['orders_expired'] = run("UPDATE hs_orders SET status='expired' WHERE status='pending' AND created_at < DATE_SUB(NOW(), INTERVAL 2 HOUR)");
        run("DELETE FROM hs_radius_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 14 DAY)");
        run("DELETE FROM hs_dae_queue WHERE status IN ('done','failed') AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
        try { run("DELETE FROM hs_omada_jobs WHERE created_at < DATE_SUB(NOW(), INTERVAL 10 MINUTE)"); } catch (Throwable $e) {}   // v5.9 relay queue
        run("UPDATE hs_dae_queue SET status='failed', last_result=COALESCE(last_result,'Expired: router did not answer on UDP 3799') WHERE status IN ('pending','sent') AND created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)");
        run("DELETE FROM rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 DAY)");
        try { run("DELETE FROM hs_payment_events WHERE created_at < DATE_SUB(NOW(), INTERVAL 60 DAY)"); } catch (Throwable $e) {}
        try { run("DELETE FROM hs_provision_runs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)"); } catch (Throwable $e) {}
        if ($withPayouts) $r['payouts'] = self::reconcilePayouts();
        setSetting('hk_last_result', date('Y-m-d H:i:s') . ' ' . json_encode($r));
        return $r;
    }
    static function reconcilePayouts(): int {
        if (!SonicPesaPayout::configured()) return 0;
        $sp = new SonicPesaPayout(); $n = 0;
        foreach (rows("SELECT * FROM withdrawals WHERE status IN ('pending','processing') AND sonic_pesa_withdrawal_id IS NOT NULL ORDER BY id LIMIT 30") as $w) {
            $st = $sp->status((string)$w['sonic_pesa_withdrawal_id']);
            if (empty($st['success'])) continue;
            $s = strtolower((string)($st['data']['status'] ?? ''));
            if (in_array($s, ['completed', 'success'], true)) {
                run("UPDATE withdrawals SET status='completed', processed_at=NOW() WHERE id=?", 'i', $w['id']);
                run("UPDATE transactions SET status='completed', completed_at=NOW() WHERE transaction_ref=?", 's', 'WD' . $w['id']);
                Notify::add((int)$w['user_id'], 'Withdrawal completed', money($w['net_amount']), 'success', '?page=withdraw', 'check'); $n++;
            } elseif (in_array($s, ['failed', 'rejected'], true)) {
                run("UPDATE withdrawals SET status='rejected', admin_notes='Sonic Pesa rejected' WHERE id=?", 'i', $w['id']);
                run("UPDATE users SET balance=balance+? WHERE id=?", 'di', $w['amount'], $w['user_id']);
                run("UPDATE transactions SET status='failed' WHERE transaction_ref=?", 's', 'WD' . $w['id']);
                Notify::add((int)$w['user_id'], 'Withdrawal rejected', 'Amount refunded: ' . money($w['amount']), 'error', '?page=withdraw', 'times'); $n++;
            }
        }
        return $n;
    }
}

$auth = new Auth();
try { if ((int)getSetting('schema_version', '0') < 6) migrateDatabase(); } catch (Throwable $e) { error_log('Migration v6: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 7) migrateDatabaseV7(); } catch (Throwable $e) { error_log('Migration v7: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 8) migrateDatabaseV8(); } catch (Throwable $e) { error_log('Migration v8: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 9) migrateDatabaseV9(); } catch (Throwable $e) { error_log('Migration v9: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 10) migrateDatabaseV10(); } catch (Throwable $e) { error_log('Migration v10: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 11) migrateDatabaseV11(); } catch (Throwable $e) { error_log('Migration v11: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 12) migrateDatabaseV12(); } catch (Throwable $e) { error_log('Migration v12: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 13) migrateDatabaseV13(); } catch (Throwable $e) { error_log('Migration v13: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 14) migrateDatabaseV14(); } catch (Throwable $e) { error_log('Migration v14: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 15) migrateDatabaseV15(); } catch (Throwable $e) { error_log('Migration v15: ' . $e->getMessage()); }
try { if ((int)getSetting('schema_version', '0') < 16) migrateDatabaseV16(); } catch (Throwable $e) { error_log('Migration v16: ' . $e->getMessage()); }
try { $sv = (int)getSetting('schema_version', '0'); if ($sv >= 16 && $sv < 17) migrateDatabaseV17(); } catch (Throwable $e) { error_log('Migration v17: ' . $e->getMessage()); }
/** v16 → v17 (v6.7): Sonic Pesa callback tracking like MIKEKA APP (last event + number of callbacks per order). */
function migrateDatabaseV17(): void {
    $hasCol = fn(string $t, string $c): bool => db()->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->num_rows > 0;
    foreach (['sp_event' => 'VARCHAR(40) NULL', 'sp_webhook_count' => 'INT NOT NULL DEFAULT 0', 'webhook_at' => 'DATETIME NULL',
              'sp_status' => 'VARCHAR(30) NULL', 'sp_transid' => 'VARCHAR(100) NULL'] as $c => $ddl)
        if (!$hasCol('hs_orders', $c)) db()->query("ALTER TABLE hs_orders ADD COLUMN `$c` $ddl");
    foreach ([['sonic_api_key', ''], ['sonic_api_secret', ''], ['sp_poll_last', '0']] as [$k, $v])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,'payment')", 'ss', $k, $v);
    setSetting('schema_version', '17');
}
/**
 * v15 → v16 (v6.6): Sonic Pesa status tracking + payment repair.
 *  - new table hs_payment_events: every push, status check, callback and voucher issue per order (Transactions → Payments → Log)
 *  - hs_orders: sp_status, sp_transid, sp_channel, sp_checked_at, sp_check_count, webhook_at, fulfill_error, fulfill_attempts and
 *    a copy of the package (pkg_*) so a paid order always gets its voucher, even after the package was deleted
 *  - repairs tables created by older versions (missing columns, payment_method as ENUM, short ENUM lists) — these made
 *    "Confirm paid" fail with "the voucher could not be issued"
 * Every step is independent: one failing ALTER never blocks the others, and the migration runs again until it is complete.
 */
function migrateDatabaseV16(): void {
    $failed = [];
    $try = function (string $sql) use (&$failed): void {
        try { db()->query($sql); } catch (Throwable $e) { $failed[] = $e->getMessage(); error_log('Migration v16: ' . $sql . ' → ' . $e->getMessage()); }
    };
    $opt = function (string $sql): void {   // repairs that may legitimately fail on unusual old data — never block the upgrade
        try { db()->query($sql); } catch (Throwable $e) { error_log('Migration v16 (optional): ' . $sql . ' → ' . $e->getMessage()); }
    };
    $cols = function (string $t): array {
        $out = [];
        try { foreach (db()->query("SHOW COLUMNS FROM `$t`")->fetch_all(MYSQLI_ASSOC) as $c) $out[strtolower($c['Field'])] = $c; } catch (Throwable $e) {}
        return $out;
    };
    $try("CREATE TABLE IF NOT EXISTS hs_payment_events (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, order_id INT NULL, order_ref VARCHAR(40) NULL, gateway_ref VARCHAR(100) NULL,
        source VARCHAR(20) NOT NULL DEFAULT '', http_code INT NOT NULL DEFAULT 0, state VARCHAR(30) NULL, message VARCHAR(500) NULL,
        body MEDIUMTEXT NULL, ip VARCHAR(45) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_order (order_id), INDEX idx_created (created_at), INDEX idx_gw (gateway_ref)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // ---- hs_orders: new v6.6 columns + every column older versions may lack
    $have = $cols('hs_orders');
    foreach (['package_id' => 'INT NULL', 'device_id' => 'INT NULL', 'phone' => 'VARCHAR(20) NULL', 'client_mac' => 'VARCHAR(17) NULL',
              'voucher_id' => 'INT NULL', 'gateway_ref' => 'VARCHAR(100) NULL', 'gateway_response' => 'TEXT NULL', 'paid_at' => 'DATETIME NULL',
              'client_ip' => 'VARCHAR(45) NULL', 'ssid' => 'VARCHAR(64) NULL', 'confirmed_by' => 'INT NULL', 'confirmed_at' => 'DATETIME NULL',
              'admin_note' => 'VARCHAR(500) NULL', 'reconnect_done' => 'TINYINT(1) NOT NULL DEFAULT 1', 'reconnect_at' => 'DATETIME NULL',
              'sp_status' => 'VARCHAR(30) NULL', 'sp_transid' => 'VARCHAR(100) NULL', 'sp_channel' => 'VARCHAR(50) NULL', 'sp_checked_at' => 'DATETIME NULL',
              'sp_check_count' => 'INT NOT NULL DEFAULT 0', 'webhook_at' => 'DATETIME NULL', 'fulfill_error' => 'VARCHAR(500) NULL',
              'fulfill_attempts' => 'INT NOT NULL DEFAULT 0', 'pkg_name' => 'VARCHAR(100) NULL', 'pkg_minutes' => 'INT NULL', 'pkg_mode' => 'VARCHAR(12) NULL',
              'pkg_data_mb' => 'INT NULL', 'pkg_down' => 'DECIMAL(7,2) NULL', 'pkg_up' => 'DECIMAL(7,2) NULL', 'pkg_devices' => 'INT NULL',
              'pkg_valid_days' => 'INT NULL'] as $c => $ddl)
        if ($have && !isset($have[$c])) $try("ALTER TABLE hs_orders ADD COLUMN `$c` $ddl");
    $opt("ALTER TABLE hs_orders MODIFY status ENUM('pending','paid','failed','expired','cancelled') NOT NULL DEFAULT 'pending'");
    // copy the package into orders that do not have the copy yet (orders made before v6.6)
    $opt("UPDATE hs_orders o JOIN hs_packages p ON p.id=o.package_id SET o.pkg_name=p.name, o.pkg_minutes=p.duration_minutes, o.pkg_mode=p.time_mode,
          o.pkg_data_mb=p.data_limit_mb, o.pkg_down=p.speed_down_mbps, o.pkg_up=p.speed_up_mbps, o.pkg_devices=p.max_devices, o.pkg_valid_days=p.validity_days
          WHERE o.pkg_minutes IS NULL");
    // ---- hs_vouchers: columns + ENUMs the payment flow writes
    $have = $cols('hs_vouchers');
    foreach (['package_id' => 'INT NULL', 'device_id' => 'INT NULL', 'batch' => 'VARCHAR(20) NULL', 'price' => 'DECIMAL(12,2) DEFAULT 0',
              'time_mode' => "ENUM('continuous','online') DEFAULT 'continuous'", 'data_limit_mb' => 'INT DEFAULT 0', 'speed_down_mbps' => 'DECIMAL(7,2) DEFAULT 0',
              'speed_up_mbps' => 'DECIMAL(7,2) DEFAULT 0', 'max_devices' => 'INT DEFAULT 1', 'sold_to_phone' => 'VARCHAR(20) NULL', 'sold_at' => 'DATETIME NULL',
              'first_used_at' => 'DATETIME NULL', 'expires_at' => 'DATETIME NULL', 'valid_until' => 'DATETIME NULL', 'data_used_bytes' => 'BIGINT UNSIGNED DEFAULT 0',
              'seconds_used' => 'INT DEFAULT 0', 'last_mac' => 'VARCHAR(17) NULL', 'last_seen' => 'DATETIME NULL', 'ext_ref' => 'VARCHAR(64) NULL',
              'ext_vid' => 'VARCHAR(64) NULL'] as $c => $ddl)
        if ($have && !isset($have[$c])) $try("ALTER TABLE hs_vouchers ADD COLUMN `$c` $ddl");
    $opt("ALTER TABLE hs_vouchers MODIFY status ENUM('available','sold','active','expired','exhausted','blocked','cancelled') DEFAULT 'available'");
    $opt("ALTER TABLE hs_vouchers MODIFY source ENUM('batch','online','manual','omada') DEFAULT 'batch'");
    // ---- transactions (ledger): an old table with payment_method as ENUM / missing seller_id made every voucher issue fail
    $have = $cols('transactions');
    foreach (['user_id' => 'INT NULL', 'seller_id' => 'INT NULL', 'voucher_id' => 'INT NULL', 'currency' => "VARCHAR(10) DEFAULT 'TZS'",
              'payment_phone' => 'VARCHAR(20) NULL', 'notes' => 'TEXT NULL', 'completed_at' => 'DATETIME NULL'] as $c => $ddl)
        if ($have && !isset($have[$c])) $try("ALTER TABLE transactions ADD COLUMN `$c` $ddl");
    $opt("ALTER TABLE transactions MODIFY payment_method VARCHAR(30) NOT NULL DEFAULT ''");
    $opt("ALTER TABLE transactions MODIFY type ENUM('purchase','deposit','withdrawal','commission','refund','adjustment') NOT NULL");
    $opt("ALTER TABLE transactions MODIFY status ENUM('pending','completed','failed','cancelled','refunded') DEFAULT 'pending'");
    $opt("ALTER TABLE transactions MODIFY user_id INT NULL");
    if (db()->query("SHOW INDEX FROM transactions WHERE Key_name='idx_seller'")->num_rows === 0) $opt("ALTER TABLE transactions ADD INDEX idx_seller (seller_id)");
    foreach ([['sonic_api_key', ''], ['sonic_api_secret', ''], ['sp_poll_last', '0']] as [$k, $v])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,'payment')", 'ss', $k, $v);
    if ($failed) throw new RuntimeException('Database upgrade v16 incomplete: ' . implode(' | ', array_slice($failed, 0, 3)));   // retried on the next request
    setSetting('schema_version', '16');
}
/** v14 → v15 (v6.4): payment recovery (who confirmed, note, reconnect state) + SSID / public IP of each portal payment. */
function migrateDatabaseV15(): void {
    $hasCol = fn(string $t, string $c): bool => db()->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->num_rows > 0;
    $fresh = !$hasCol('hs_orders', 'reconnect_done');
    foreach (['client_ip' => 'VARCHAR(45) NULL', 'ssid' => 'VARCHAR(64) NULL', 'confirmed_by' => 'INT NULL', 'confirmed_at' => 'DATETIME NULL',
              'admin_note' => 'VARCHAR(500) NULL', 'reconnect_done' => 'TINYINT(1) NOT NULL DEFAULT 0', 'reconnect_at' => 'DATETIME NULL'] as $c => $ddl)
        if (!$hasCol('hs_orders', $c)) db()->query("ALTER TABLE hs_orders ADD COLUMN `$c` $ddl");
    if ($fresh) db()->query("UPDATE hs_orders SET reconnect_done=1");   // never reconnect phones for payments made before v6.4
    if (db()->query("SHOW INDEX FROM hs_orders WHERE Key_name='idx_mac'")->num_rows === 0) db()->query("ALTER TABLE hs_orders ADD INDEX idx_mac (client_mac)");
    setSetting('schema_version', '15');
}
/** v13 → v14 (v6.3): extra SSIDs per router, Sonic Pesa collection endpoint, "JE UNATAKA MFUMO HUU?" contact. */
function migrateDatabaseV14(): void {
    if (db()->query("SHOW COLUMNS FROM hs_devices LIKE 'extra_ssids'")->num_rows === 0) db()->query("ALTER TABLE hs_devices ADD COLUMN extra_ssids TEXT NULL");
    if (db()->query("SHOW INDEX FROM hs_orders WHERE Key_name='idx_gw'")->num_rows === 0) db()->query("ALTER TABLE hs_orders ADD INDEX idx_gw (gateway_ref)");
    foreach ([['sonic_collect_endpoint', ''], ['sales_contact_phone', '0612710364']] as [$k, $v])
        q("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?,?,'payment')", 'ss', $k, $v);
    setSetting('schema_version', '14');
}

// ============================================================
// MACHINE ENDPOINTS
// ============================================================
// --- PWA ---
if (isset($_GET['pwa'])) {
    while (ob_get_level() > 0) ob_end_clean();
    if ($_GET['pwa'] === 'manifest') {
        header('Content-Type: application/manifest+json');
        header('Cache-Control: public, max-age=86400');
        echo json_encode(['name' => SITE_NAME, 'short_name' => 'SkyWiFi', 'start_url' => './index.php?page=dashboard', 'display' => 'standalone',
            'background_color' => '#060a13', 'theme_color' => '#060a13', 'icons' => [['src' => 'index.php?pwa=icon', 'sizes' => 'any', 'type' => 'image/svg+xml', 'purpose' => 'any maskable']]]);
    } elseif ($_GET['pwa'] === 'sw') {
        header('Content-Type: application/javascript');
        header('Cache-Control: no-cache');
        echo "self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));self.addEventListener('fetch',e=>{});";
    } else {
        header('Content-Type: image/svg+xml'); header('Cache-Control: public, max-age=604800, immutable');
        echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b8cff"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/><path d="M96 208a224 224 0 0 1 320 0l-36 36a173 173 0 0 0-248 0zm68 68a128 128 0 0 1 184 0l-36 36a77 77 0 0 0-112 0zm92 52 44 44-44 44-44-44z" fill="#fff"/></svg>';
    }
    exit;
}
// --- RADIUS ---
if (isset($_GET['radius'])) Radius::handle();

// --- Payment webhook ---
// v6.6 — Sonic Pesa callback (?webhook=sonicpesa), handled like MIKEKA APP: {"event":"payment.success","data":{"order_id":"...",
// "transaction_id":"..."}} marks the order paid. The order is found by the Sonic Pesa order_id saved when the push was created
// (or our reference in metadata). With the secret from our callback URL the callback is trusted; without it the payment is
// confirmed by asking Sonic Pesa (order_status) — a forged callback can never mark an order paid. Every callback is logged.
if (($_GET['webhook'] ?? '') === 'sonicpesa') {
    try {
        $raw = (string)file_get_contents('php://input');
        $d = json_decode($raw, true);
        if (!is_array($d)) $d = $_POST ?: $_GET;
        if ($raw === '') $raw = (string)json_encode($d, JSON_UNESCAPED_SLASHES);
        $data = isset($d['data']) && is_array($d['data']) ? $d['data'] : [];
        $meta = isset($d['metadata']) && is_array($d['metadata']) ? $d['metadata'] : (isset($data['metadata']) && is_array($data['metadata']) ? $data['metadata'] : []);
        $trusted = hash_equals((string)PAYMENT_WEBHOOK_SECRET, (string)($_GET['secret'] ?? ''));
        $ref = substr((string)($meta['order_ref'] ?? $d['reference'] ?? $data['reference'] ?? $d['order_ref'] ?? ''), 0, 40);
        $spId = substr(Payments::orderIdOf($d), 0, 100);
        $o = $spId !== '' ? row("SELECT * FROM hs_orders WHERE gateway_ref=? ORDER BY id DESC LIMIT 1", 's', $spId) : null;
        if (!$o && $ref !== '') $o = row("SELECT * FROM hs_orders WHERE order_ref=?", 's', $ref);
        $state = Payments::paidState($d);
        Payments::log($o, 'webhook', 200, Payments::rawState($d) ?: (string)($d['event'] ?? '?'), ($trusted ? 'trusted' : 'unsigned') . ' callback' . ($o ? '' : ' — order not found'), $raw);
        if (!$o) jsonOut(['success' => false, 'message' => 'unknown order'], 404);
        Payments::note((int)$o['id'], ['webhook_at' => '__NOW__', 'sp_webhook_count' => '__INC__', 'sp_event' => substr((string)($d['event'] ?? Payments::rawState($d)), 0, 40)]);
        if ($o['status'] === 'paid') jsonOut(['success' => true, 'status' => 'paid']);
        // v6.7 — amount in the callback lower than the price: never auto-confirm
        $cbAmt = $data['amount'] ?? ($d['amount'] ?? ($d['transaction']['amount'] ?? null));
        $underpaid = is_numeric($cbAmt) && (float)$cbAmt > 0 && (float)$cbAmt + 0.5 < (float)$o['amount'];
        if ($underpaid) { $state = null; Payments::note((int)$o['id'], ['sp_status' => 'UNDERPAID']); }
        $txid = Payments::txIdOf($d);
        if ($trusted && $state === true) {
            $r = Payments::fulfill((string)$o['order_ref'], $spId !== '' ? $spId : (string)$o['gateway_ref'], substr($raw, 0, 4000), 'sonicpesa', $txid);
            if (!$r || ($r['status'] ?? '') !== 'paid') {   // could not issue the voucher now — the background poll retries it
                error_log('webhook sonicpesa: fulfill failed for ' . $o['order_ref'] . ': ' . Payments::$lastError);
            }
        } elseif ($trusted && $state === false) {
            run("UPDATE hs_orders SET status='failed', gateway_response=? WHERE id=? AND status IN ('pending','expired')", 'si', substr($raw, 0, 4000), (int)$o['id']);
            Payments::note((int)$o['id'], ['sp_status' => Payments::rawState($d) ?: 'FAILED']);
        } else {
            // unsigned callback, or a state we do not recognise → ask Sonic Pesa itself (order_status)
            if ((string)$o['gateway_ref'] === '' && $spId !== '') run("UPDATE hs_orders SET gateway_ref=? WHERE id=? AND (gateway_ref IS NULL OR gateway_ref='')", 'si', $spId, (int)$o['id']);
            $o = row("SELECT * FROM hs_orders WHERE id=?", 'i', (int)$o['id']);
            $chk = (string)$o['gateway_ref'] !== '' ? Payments::checkGateway($o, 'webhook') : null;
            // v6.7 — exactly like MIKEKA APP: {"event":"payment.success"} for one of OUR Sonic Pesa order ids marks the order paid,
            // even when order_status still answers PENDING for a moment. Only when the order id matches (it is never shown to the
            // customer) and Sonic Pesa did not report the payment as failed.
            $o = row("SELECT * FROM hs_orders WHERE id=?", 'i', (int)$o['id']);
            if ($chk !== true && $chk !== false && !$underpaid && $state === true && $spId !== '' && hash_equals((string)$o['gateway_ref'], $spId)
                && in_array($o['status'], ['pending', 'expired', 'failed'], true)) {
                $r = Payments::fulfill((string)$o['order_ref'], $spId, substr($raw, 0, 4000), 'sonicpesa', $txid);
                if (!$r || ($r['status'] ?? '') !== 'paid') error_log('webhook sonicpesa: fulfill failed for ' . $o['order_ref'] . ': ' . Payments::$lastError);
            }
        }
        $now = row("SELECT status FROM hs_orders WHERE id=?", 'i', (int)$o['id']);
        jsonOut(['success' => true, 'status' => $now['status'] ?? 'pending']);
    } catch (Throwable $e) {
        error_log('webhook sonicpesa: ' . $e->getMessage());
        jsonOut(['success' => false], 500);
    }
}
if (isset($_GET['webhook'])) {
    if (!hash_equals((string)PAYMENT_WEBHOOK_SECRET, (string)($_GET['secret'] ?? ''))) jsonOut(['ok' => false], 403);
    $raw = (string)file_get_contents('php://input');
    $d = json_decode($raw, true);
    if (!is_array($d)) $d = $_POST;
    $flat = $d + (isset($d['data']) && is_array($d['data']) ? $d['data'] : []);
    $ref = (string)($flat['reference'] ?? $flat['order_ref'] ?? $flat['order_id'] ?? $flat['external_reference'] ?? '');
    $status = strtolower((string)($flat['status'] ?? $flat['payment_status'] ?? $flat['transaction_status'] ?? ''));
    $gref = (string)($flat['transaction_id'] ?? $flat['transid'] ?? $flat['id'] ?? '');
    if ($ref !== '') {
        if (in_array($status, ['success', 'successful', 'completed', 'paid', 'settled'], true)) Payments::fulfill($ref, $gref, substr($raw, 0, 4000));
        elseif (in_array($status, ['failed', 'cancelled', 'canceled', 'rejected', 'declined'], true))
            run("UPDATE hs_orders SET status='failed', gateway_response=? WHERE order_ref=? AND status='pending'", 'ss', substr($raw, 0, 4000), $ref);
    }
    jsonOut(['ok' => true]);
}

// --- HTTP cron (optional; lazy cron already runs) ---
if (isset($_GET['cron'])) {
    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: text/plain');
    if (!hash_equals((string)CRON_SECRET, (string)($_GET['secret'] ?? ''))) { http_response_code(403); exit("Forbidden\n"); }
    $r = Housekeeping::run(true);
    setSetting('hk_last_run', (string)time());
    setSetting('omada_last_sync', '0');
    $r['payments_confirmed'] = (int)($r['payments_confirmed'] ?? 0) + Payments::pollPending(30, true);
    OmadaSync::maybe();
    PaymentOps::nudgeLate(20);
    $r['omada'] = 'synced';
    echo '[' . date('Y-m-d H:i:s') . '] ' . json_encode($r) . "\n";
    exit;
}
// --- CLI ---
if (PHP_SAPI === 'cli') {
    $r = Housekeeping::run(true);
    $r['payments_confirmed'] = (int)($r['payments_confirmed'] ?? 0) + Payments::pollPending(30, true);
    PaymentOps::nudgeLate(20);
    setSetting('omada_last_sync', '0');
    OmadaSync::maybe();
    echo '[' . date('Y-m-d H:i:s') . '] ' . json_encode($r) . "\n";
    exit(0);
}

// --- Logout ---
if (($_GET['action'] ?? '') === 'logout') { $auth->logout(); redirectTo('?page=login'); }

// ============================================================
// AJAX
// ============================================================
if (isset($_GET['ajax'])) {
    $ajax = (string)$_GET['ajax'];
    $ctx = $_SESSION['portal_ctx'] ?? [];
    $ctxMac = normMac($ctx['clientMac'] ?? '');
    $ctxAp = normMac($ctx['apMac'] ?? '');

    // ---------- Public (captive portal) ----------
    if (str_starts_with($ajax, 'portal_')) {
        // v6.6: captive-portal browsers often lose their cookie while the customer approves the USSD push on the phone. The read-only
        // payment checks (order status, "my payment", "I have paid") therefore work without the session/CSRF token: the order must belong
        // to this phone (MAC sent by Omada / by the page, or the hotspot's public IP). Buying and voucher login still need the token.
        if ($ctxMac === '') $ctxMac = normMac((string)($_POST['mac'] ?? ''));
        if ($ctxAp === '') $ctxAp = normMac((string)($_POST['ap'] ?? ''));
        $readOnly = in_array($ajax, ['portal_order', 'portal_mine', 'portal_ipaid', 'portal_check'], true);   // v6.7: portal_check is read-only (auto-connect after payment)
        if (!$readOnly && !csrf_check($_POST['csrf'] ?? '')) jsonOut(['success' => false, 'message' => t('invalid_csrf'), 'reload' => true]);
        $ownsOrder = function (string $ref) use ($ctxMac): bool {
            if ($ref === '') return false;
            if (in_array($ref, $_SESSION['portal_orders'] ?? [], true)) return true;
            $own = row("SELECT client_mac, client_ip FROM hs_orders WHERE order_ref=? AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)", 's', $ref);
            if (!$own || !(($ctxMac !== '' && $own['client_mac'] === $ctxMac) || ((string)$own['client_ip'] !== '' && $own['client_ip'] === clientIp()))) return false;
            $_SESSION['portal_orders'][] = $ref;
            return true;
        };
        if ($ajax === 'portal_check') {
            if (!rateLimitCheck(clientIp() . '|' . $ctxMac, 'portal_check', 15, 300)) jsonOut(['success' => false, 'message' => t('rate_limited')]);
            $res = Vouchers::check((string)($_POST['code'] ?? ''), $ctxMac, Device::byApMac($ctxAp), false);
            if (!$res['ok']) jsonOut(['success' => false, 'message' => $res['msg']]);
            $v = $res['voucher'];
            jsonOut(['success' => true, 'code' => $v['code'], 'remaining' => $res['remaining'], 'remaining_text' => fmtSecs($res['remaining']),
                'data_left' => $res['data_left'] === null ? t('unlimited') : fmtBytes($res['data_left']), 'package' => $v['package_name'] ?? '',
                'started' => !empty($v['first_used_at'])]);
        }
        if ($ajax === 'portal_buy') {
            if (!rateLimitCheck(clientIp() . '|' . $ctxMac, 'portal_buy', 6, 900)) jsonOut(['success' => false, 'message' => t('rate_limited')]);
            $dev = Device::byApMac($ctxAp);
            $pkg = row("SELECT * FROM hs_packages WHERE id=? AND is_active=1 AND show_on_portal=1", 'i', (int)($_POST['package_id'] ?? 0));
            if (!$pkg || !$dev || (int)$pkg['seller_id'] !== (int)$dev['user_id'] || ($pkg['device_id'] && (int)$pkg['device_id'] !== (int)$dev['id']))
                jsonOut(['success' => false, 'message' => t('p_no_ctx')]);
            $r = Payments::createOrder($pkg, $dev, (string)($_POST['phone'] ?? ''), $ctxMac, (string)($ctx['ssidName'] ?? ''));
            if (!empty($r['success'])) $_SESSION['portal_orders'][] = $r['ref'];
            jsonOut($r);
        }
        if ($ajax === 'portal_order') {
            $ref = substr((string)preg_replace('/[^A-Z0-9]/', '', strtoupper((string)($_POST['ref'] ?? ''))), 0, 40);
            if (!$ownsOrder($ref)) jsonOut(['success' => false, 'message' => 'Unknown order']);
            // v6.3/v6.5: while pending, ask Sonic Pesa order_status directly (at most every 5 s per order) — works even when the callback never arrives
            $po = row("SELECT * FROM hs_orders WHERE order_ref=?", 's', $ref);
            if ($po && (string)$po['gateway_ref'] !== '' && ((in_array($po['status'], ['pending', 'expired'], true) && rateLimitCheck('sp' . $ref, 'sp_status', 1, 5))
                    || ($po['status'] === 'failed' && strtotime($po['created_at']) > time() - 7200 && rateLimitCheck('sp' . $ref, 'sp_status_f', 1, 60)))) {   // v6.4: a "failed" push is re-checked once a minute
                try { Payments::checkGateway($po); } catch (Throwable $e) { error_log('portal_order status: ' . $e->getMessage()); }
            }
            $o = row("SELECT o.status, o.sp_status, o.gateway_response, v.code FROM hs_orders o LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.order_ref=?", 's', $ref);
            jsonOut(['success' => true, 'status' => $o['status'] ?? 'failed', 'code' => ($o && $o['status'] === 'paid') ? $o['code'] : null,
                'sp_status' => (string)($o['sp_status'] ?? ''), 'sp_response' => substr((string)($o['gateway_response'] ?? ''), 0, 1500)]);   // v6.7.2
        }
        if ($ajax === 'portal_mine') {
            // v6.4 — the WiFi login page reopened: find this phone's recent payment (refs saved on the phone, or same MAC + same hotspot IP)
            if ($ctxMac === '' || !rateLimitCheck(clientIp() . '|' . $ctxMac, 'portal_mine', 30, 300)) jsonOut(['success' => true]);
            $refs = array_slice(array_values(array_filter(array_map(fn($r) => (string)preg_replace('/[^A-Z0-9]/', '', strtoupper($r)), explode(',', (string)($_POST['refs'] ?? ''))))), 0, 10);
            $mine = [];
            foreach (rows("SELECT o.*, p.name AS package_name, v.code, v.status AS v_status FROM hs_orders o LEFT JOIN hs_packages p ON p.id=o.package_id
                           LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.client_mac=? AND o.created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
                           ORDER BY o.id DESC LIMIT 10", 's', $ctxMac) as $o) {
                $known = in_array($o['order_ref'], $refs, true) || in_array($o['order_ref'], $_SESSION['portal_orders'] ?? [], true)
                    || ((string)($o['client_ip'] ?? '') !== '' && $o['client_ip'] === clientIp());
                if (!$known) continue;
                if (!in_array($o['order_ref'], $_SESSION['portal_orders'] ?? [], true)) $_SESSION['portal_orders'][] = $o['order_ref'];
                $mine[] = $o;
            }
            // v6.5: unconfirmed Sonic Pesa payments of this phone are checked with order_status before answering
            foreach ($mine as $k => $o) if (in_array($o['status'], ['pending', 'expired'], true) && (string)$o['gateway_ref'] !== '' && rateLimitCheck('sp' . $o['order_ref'], 'sp_status', 1, 5)) {
                try { if (Payments::checkGateway($o) === true) $mine[$k] = row("SELECT o.*, p.name AS package_name, v.code, v.status AS v_status FROM hs_orders o
                      LEFT JOIN hs_packages p ON p.id=o.package_id LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.id=?", 'i', (int)$o['id']) ?: $o; }
                catch (Throwable $e) { error_log('portal_mine status: ' . $e->getMessage()); }
            }
            foreach ($mine as $o) if ($o['status'] === 'paid' && (string)$o['code'] !== '' && in_array($o['v_status'], ['available', 'sold', 'active'], true)) {
                $chk = Vouchers::check((string)$o['code'], $ctxMac, null, false);
                if ($chk['ok']) jsonOut(['success' => true, 'status' => 'paid', 'ref' => $o['order_ref'], 'code' => $o['code'],
                    'package' => (string)$o['package_name'], 'amount' => money($o['amount'])]);
            }
            foreach ($mine as $o) if (in_array($o['status'], ['pending', 'failed', 'expired'], true) && strtotime($o['created_at']) > time() - 10800)
                jsonOut(['success' => true, 'status' => $o['status'], 'ref' => $o['order_ref'], 'code' => null, 'package' => (string)$o['package_name'], 'amount' => money($o['amount'])]);
            jsonOut(['success' => true]);
        }
        if ($ajax === 'portal_ipaid') {
            // v6.3 (from portal.php): "Nimekwisha lipa" — check the gateway now and tell the seller the customer says he paid
            if (!rateLimitCheck(clientIp() . '|' . $ctxMac, 'portal_ipaid', 10, 900)) jsonOut(['success' => false, 'message' => t('rate_limited')]);
            $ref = substr((string)preg_replace('/[^A-Z0-9]/', '', strtoupper((string)($_POST['ref'] ?? ''))), 0, 40);
            if (!$ownsOrder($ref)) jsonOut(['success' => false, 'message' => 'Unknown order']);
            $po = row("SELECT * FROM hs_orders WHERE order_ref=?", 's', $ref);
            if ($po && in_array($po['status'], ['pending', 'expired', 'failed'], true)) {
                if ((string)$po['gateway_ref'] !== '') { try { Payments::checkGateway($po, 'customer'); } catch (Throwable $e) { error_log('portal_ipaid: ' . $e->getMessage()); } }
                $po = row("SELECT * FROM hs_orders WHERE order_ref=?", 's', $ref);
                if ($po && $po['status'] !== 'paid' && rateLimitCheck('ipaid' . $ref, 'ipaid_notify', 1, 600))
                    Notify::add((int)$po['seller_id'], t('p_ipaid_notify'), $ref . ' • ' . money($po['amount']) . ' • ' . $po['phone'], 'payment', '?page=transactions&status=attention', 'money-bill');
            }
            $o = row("SELECT o.status, v.code FROM hs_orders o LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.order_ref=?", 's', $ref);
            $paid = $o && $o['status'] === 'paid';
            jsonOut(['success' => true, 'status' => $o['status'] ?? 'failed', 'code' => $paid ? $o['code'] : null,
                'message' => $paid ? t('p_payment_success') : t('p_ipaid_wait')]);
        }
        jsonOut(['success' => false, 'message' => 'Unknown action']);
    }

    // ---------- Authenticated ----------
    if (!$auth->isLoggedIn()) jsonOut(['success' => false, 'message' => 'Not authenticated'], 401);
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !csrf_check($_POST['csrf'] ?? '')) jsonOut(['success' => false, 'message' => t('invalid_csrf')]);
    $uid = (int)$_SESSION['user_id'];
    switch ($ajax) {
        case 'live':
            $st = SessionOps::stats($uid);
            jsonOut(['success' => true, 'stats' => $st, 'unread' => Notify::unread($uid)]);
        case 'simulate':
            if (!$auth->isAdmin()) jsonOut(['success' => false], 403);
            $simDev = Device::byNasId((string)($_POST['nas'] ?? ''));
            $res = Vouchers::check((string)($_POST['code'] ?? ''), normMac($_POST['mac'] ?? ''), $simDev, false);
            $rep = Radius::buildReply($res);
            jsonOut(['success' => true, 'decision' => $rep['decision'] === 'accept' ? 'Access-Accept' : 'Access-Reject', 'reply' => $rep['reply'],
                'hotspot' => $simDev ? $simDev['device_name'] . ' (NAS ID ' . ($simDev['omada_nas_id'] ?: '—') . ')' : 'none selected — hotspot rules not checked']);
        case 'prov_step':
            // "Start provisioning": one step per call (the page calls it every few seconds until the EAP225 is CONNECTED)
            if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !in_array($_SESSION['user_type'] ?? '', ['seller', 'admin'], true)) jsonOut(['ok' => false, 'msg' => 'Forbidden'], 403);
            $pid = (int)($_POST['id'] ?? 0);
            if (!Device::get($pid, $uid) && $auth->isAdmin() && ($ownDev = Device::get($pid))) $uid = (int)$ownDev['user_id'];   // v6.2
            if (!Device::get($pid, $uid)) jsonOut(['ok' => false, 'phase' => 'error', 'msg' => 'Device not found', 'done' => true]);
            if (trim((string)($_POST['dev_user'] ?? '')) !== '') OmadaProvision::saveDeviceCreds($pid, (string)$_POST['dev_user'], (string)($_POST['dev_pass'] ?? ''));
            if (canCall('session_write_close')) session_write_close();   // Omada calls can take a few seconds — do not block the seller's other tabs
            OmadaApi::$deadline = microtime(true) + workBudget(25);
            try {
                $res = OmadaProvision::tick($pid, $uid);
                ProvisionLog::add($pid, $uid, 'connect', (string)($res['phase'] ?? ''), (string)($res['msg'] ?? ''), true);   // Hotspot → history
                jsonOut($res);
            }
            catch (Throwable $e) { error_log('prov_step: ' . $e->getMessage()); jsonOut(['ok' => false, 'phase' => 'error', 'msg' => 'Server error: ' . $e->getMessage(), 'done' => false]); }
    }
    jsonOut(['success' => false, 'message' => 'Unknown action']);
}

// ============================================================
// SOURCE DOWNLOAD (admin) — the same index.php runs the RADIUS server on the VPS
// ============================================================
if (isset($_GET['export']) && $_GET['export'] === 'source') {
    $auth->requireAdmin();
    logActivity((int)$_SESSION['user_id'], 'download_source', 'index.php for RADIUS server');
    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="index.php"');
    header('Cache-Control: no-store');
    readfile(__FILE__);
    exit;
}

// ============================================================
// CSV EXPORT
// ============================================================
if (isset($_GET['export']) && $_GET['export'] === 'vouchers') {
    $auth->requireSeller();
    $uid = (int)$_SESSION['user_id'];
    $batch = (string)($_GET['batch'] ?? '');
    $list = $batch !== ''
        ? rows("SELECT v.code, p.name, v.price, v.duration_minutes, v.data_limit_mb, v.status, v.batch, v.created_at FROM hs_vouchers v LEFT JOIN hs_packages p ON p.id=v.package_id WHERE v.seller_id=? AND v.batch=? ORDER BY v.id", 'is', $uid, $batch)
        : rows("SELECT v.code, p.name, v.price, v.duration_minutes, v.data_limit_mb, v.status, v.batch, v.created_at FROM hs_vouchers v LEFT JOIN hs_packages p ON p.id=v.package_id WHERE v.seller_id=? ORDER BY v.id DESC LIMIT 5000", 'i', $uid);
    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="vouchers-' . ($batch ?: date('Ymd')) . '.csv"');
    $f = fopen('php://output', 'w');
    fputcsv($f, ['code', 'package', 'price', 'duration_minutes', 'data_limit_mb', 'status', 'batch', 'created_at']);
    foreach ($list as $r) fputcsv($f, array_values($r));
    exit;
}

// ============================================================
// GLOBAL CSRF GUARD FOR FORM POSTS
// ============================================================
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && !csrf_check($_POST['csrf'] ?? '')) {
    flash('danger', t('invalid_csrf'));
    redirectTo('?page=' . ($page ?: 'dashboard'));
}

// ============================================================
// CAPTIVE PORTAL (standalone, no CDN — works before the phone is authenticated)
// ============================================================
if ($page === 'portal') {
    $ctxKeys = ['clientMac', 'clientIp', 'apMac', 'gatewayMac', 'ssidName', 'radioId', 'vid', 'scheme', 'originUrl', 'redirectUrl', 'target', 'targetPort', 'site', 't'];
    if (isset($_GET['clientMac'])) {
        $ctx = [];
        foreach ($ctxKeys as $k) $ctx[$k] = substr(trim((string)($_GET[$k] ?? '')), 0, 600);
        $_SESSION['portal_ctx'] = $ctx;
    }
    $ctx = $_SESSION['portal_ctx'] ?? [];
    $ap = normMac($ctx['apMac'] ?? '');
    $dev = Device::byApMac($ap);
    if ($dev && isset($_GET['clientMac'])) {
        // v5.7: Omada redirected a phone here → the router ↔ portal link works; remember where Omada's portal service lives
        $tgt = '';
        if (!empty($ctx['target']) && preg_match('/^[A-Za-z0-9.\-]+$/', $ctx['target']))
            $tgt = (in_array($ctx['scheme'] ?? '', ['http', 'https'], true) ? $ctx['scheme'] : 'http') . '://' . $ctx['target'] . ((int)($ctx['targetPort'] ?? 0) ? ':' . (int)$ctx['targetPort'] : '');
        try { run("UPDATE hs_devices SET portal_seen_at=NOW(), portal_target=IF(?<>'', ?, portal_target) WHERE id=?", 'ssi', $tgt, $tgt, $dev['id']); } catch (Throwable $e) {}
    }
    $seller = $dev ? row("SELECT full_name, phone FROM users WHERE id=?", 'i', $dev['user_id']) : null;
    $pkgs = $dev ? rows("SELECT * FROM hs_packages WHERE seller_id=? AND is_active=1 AND show_on_portal=1 AND (device_id IS NULL OR device_id=?) ORDER BY sort_order, price", 'ii', $dev['user_id'], $dev['id']) : [];
    $authUrl = Device::authUrl($dev, $ctx);
    $done = isset($_GET['done']);
    $hasCtx = !empty($ctx['clientMac']);
    $origin = ($ctx['redirectUrl'] ?? '') ?: (($ctx['originUrl'] ?? '') ?: 'http://www.google.com');
    if (!preg_match('#^https?://#i', $origin)) $origin = 'http://www.google.com';
    // v6.4: show the WiFi name (SSID) the phone actually joined — Omada sends it as ssidName (each extra SSID shows its own name)
    $joinedSsid = trim(asciiClean((string)($ctx['ssidName'] ?? ''), 64));
    $title = $joinedSsid !== '' ? $joinedSsid : (trim((string)($dev['ssid'] ?? '')) !== '' ? (string)$dev['ssid'] : SITE_NAME);
    $csrf = csrf_token();
    while (ob_get_level() > 0) ob_end_clean();
    // v6.3 — customer care = the seller's phone; "JE UNATAKA MFUMO HUU?" = platform owner's phone
    $care = $seller ? normalizePhone((string)$seller['phone']) : '';
    $sales = salesContactPhone();
    $sales255 = '255' . substr($sales, 1);
    $mmPush = Payments::sonicConfigured() && sonicCollectEndpoint() !== '';
    header('Cache-Control: no-store');
    ?>
<!DOCTYPE html>
<html lang="sw" class="dark">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#05080f"><meta name="color-scheme" content="dark only"><meta name="format-detection" content="telephone=no">
<title><?= h($title ?: SITE_NAME) ?> — WiFi</title>
<style>
/* v6.3 captive portal — dark only, mobile money first */
:root{color-scheme:dark;--bg:#05080f;--card:rgba(14,21,36,.82);--card-2:rgba(20,29,49,.9);--field:rgba(4,7,14,.8);--line:rgba(148,163,184,.12);--line-2:rgba(148,163,184,.24);
 --txt:#eef2f9;--mut:#8d9cb5;--pri:#5b8cff;--pri-2:#8b5cf6;--ok:#22c55e;--ok-2:#16a34a;--bad:#f43f5e;--gold:#fbbf24;--r:20px;--mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg)}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Inter,"Helvetica Neue",Arial,sans-serif;color:var(--txt);min-height:100vh;min-height:100dvh;-webkit-font-smoothing:antialiased;overflow-x:hidden;line-height:1.45}
body::before,body::after{content:"";position:fixed;z-index:-1;border-radius:50%;filter:blur(90px);pointer-events:none}
body::before{width:420px;height:420px;background:var(--pri);top:-200px;left:-150px;opacity:.38}
body::after{width:380px;height:380px;background:var(--ok-2);bottom:-200px;right:-170px;opacity:.22}
.wrap{max-width:460px;margin:0 auto;padding:24px 16px calc(32px + env(safe-area-inset-bottom))}
.brand{text-align:center;margin:6px 0 20px}
.logo{width:66px;height:66px;border-radius:21px;background:linear-gradient(135deg,var(--pri),var(--pri-2));display:inline-grid;place-items:center;box-shadow:0 18px 40px -14px rgba(91,140,255,.75),inset 0 1px 0 rgba(255,255,255,.28)}
.logo svg{width:36px;height:36px}
/* v6.7.4 — animated WiFi logo: waves light up in turn + rings radiate outwards */
.wlogo{position:relative;overflow:visible;animation:wlFloat 3.2s ease-in-out infinite}
.wlogo svg{position:relative;z-index:2;overflow:visible}
.wlogo .wv{opacity:.25;animation:wlWave 1.8s ease-in-out infinite}
.wlogo .w1{animation-delay:0s}.wlogo .w2{animation-delay:.3s}.wlogo .w3{animation-delay:.6s}
.wlogo .wd{animation:wlDot 1.8s ease-in-out infinite;transform-origin:12px 20px;transform-box:view-box}
.wlogo::before,.wlogo::after{content:"";position:absolute;inset:0;border-radius:inherit;border:2px solid rgba(91,140,255,.55);z-index:1;pointer-events:none;animation:wlRing 2.4s ease-out infinite}
.wlogo::after{animation-delay:1.2s}
@keyframes wlWave{0%,100%{opacity:.25}35%,60%{opacity:1}}
@keyframes wlDot{0%,100%{transform:scale(1)}20%{transform:scale(1.25)}}
@keyframes wlRing{0%{transform:scale(1);opacity:.85}100%{transform:scale(1.85);opacity:0}}
@keyframes wlFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
@media(prefers-reduced-motion:reduce){.wlogo,.wlogo .wv,.wlogo .wd,.wlogo::before,.wlogo::after{animation:none}.wlogo .wv{opacity:1}.wlogo::before,.wlogo::after{display:none}}
h1{font-size:1.45rem;margin:14px 0 2px;letter-spacing:-.025em;font-weight:800}
h2{letter-spacing:-.02em}
.sub{color:var(--mut);font-size:.9rem;margin:0}
.mm{display:inline-flex;gap:6px;align-items:center;margin-top:10px;padding:6px 12px;border-radius:999px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#bbf7d0;font-size:.74rem;font-weight:700}
.card{background:var(--card);-webkit-backdrop-filter:blur(18px) saturate(160%);backdrop-filter:blur(18px) saturate(160%);border:1px solid var(--line);border-radius:var(--r);padding:18px;margin-bottom:14px;box-shadow:0 26px 56px -30px rgba(0,0,0,.9),inset 0 1px 0 rgba(255,255,255,.04)}
.sec{font-size:.72rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--mut);margin:4px 2px 10px}
/* horizontal package cards */
.plist{display:flex;flex-direction:column;gap:10px}
.pc{display:flex;align-items:center;gap:12px;padding:12px 12px 12px 14px;border-radius:18px;background:linear-gradient(180deg,var(--card-2),var(--card));border:1px solid var(--line-2);box-shadow:0 18px 34px -26px #000}
.pc .ic{width:48px;height:48px;border-radius:15px;flex-shrink:0;display:grid;place-items:center;font-weight:800;font-size:.78rem;text-align:center;line-height:1.05;color:#fff;background:linear-gradient(135deg,rgba(91,140,255,.35),rgba(139,92,246,.35));border:1px solid rgba(139,92,246,.4)}
.pc .ic small{display:block;font-size:.58rem;font-weight:700;opacity:.85;text-transform:uppercase;letter-spacing:.05em}
.pc .bd{flex:1;min-width:0}
.pc .nm{font-weight:800;font-size:1rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pc .pr{font-weight:900;font-size:1.15rem;color:var(--gold);letter-spacing:-.02em;margin-top:1px}
.pc .mt{color:var(--mut);font-size:.72rem;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lipia{flex-shrink:0;border:0;border-radius:13px;padding:12px 16px;font-weight:900;font-size:.9rem;letter-spacing:.06em;color:#fff;cursor:pointer;font-family:inherit;
 background:linear-gradient(135deg,var(--ok-2),var(--ok));box-shadow:0 12px 24px -12px rgba(34,197,94,.9);transition:transform .12s,filter .15s}
.lipia:hover{filter:brightness(1.08)}.lipia:active{transform:scale(.96)}
label{display:block;font-size:.8rem;color:var(--mut);margin-bottom:8px;font-weight:600}
input[type=text],input[type=tel]{width:100%;padding:15px 16px;border-radius:14px;border:1px solid var(--line-2);background:var(--field);color:var(--txt);font-size:1.05rem;outline:none;font-family:inherit;transition:border-color .2s,box-shadow .2s}
input:focus{border-color:var(--pri);box-shadow:0 0 0 4px rgba(91,140,255,.22)}
input::placeholder{color:var(--mut);opacity:.5}
input.code{text-transform:uppercase;letter-spacing:.3em;font-family:var(--mono);text-align:center;font-size:1.35rem;font-weight:700}
input.tel{font-size:1.3rem;letter-spacing:.06em;text-align:center;font-weight:700}
.btn{display:block;width:100%;border:0;border-radius:14px;padding:15px;font-size:1rem;font-weight:800;background:linear-gradient(135deg,var(--pri),var(--pri-2));color:#fff;margin-top:12px;cursor:pointer;font-family:inherit;text-align:center;text-decoration:none;box-shadow:0 14px 28px -14px rgba(91,140,255,.85);transition:transform .12s,filter .15s,opacity .15s}
.btn:hover{filter:brightness(1.08)}.btn:active{transform:scale(.985)}.btn:disabled{opacity:.6;cursor:wait}
.btn.ok{background:linear-gradient(135deg,var(--ok-2),var(--ok));box-shadow:0 14px 28px -14px rgba(34,197,94,.8)}
.btn.ghost{background:transparent;border:1px solid var(--line-2);color:var(--txt);box-shadow:none}
.btn.wa{background:linear-gradient(135deg,#128c7e,#25d366)}
.chk{display:flex;align-items:center;gap:10px;margin-top:12px;color:var(--mut);font-size:.86rem;cursor:pointer}
.chk input{width:18px;height:18px;accent-color:var(--pri);margin:0}
.msg{padding:12px 14px;border-radius:14px;margin-bottom:12px;font-size:.9rem;display:none;border:1px solid}
.msg.err{display:block;background:rgba(244,63,94,.12);border-color:rgba(244,63,94,.4);color:#fecdd3}
.msg.ok{display:block;background:rgba(34,197,94,.12);border-color:rgba(34,197,94,.4);color:#bbf7d0}
.msg.info{display:block;background:rgba(91,140,255,.12);border-color:rgba(91,140,255,.4);color:#c7d7ff}
details.vbox{border-radius:var(--r);border:1px dashed var(--line-2);background:rgba(10,15,27,.6);padding:0;margin-bottom:14px}
details.vbox summary{list-style:none;cursor:pointer;padding:15px 18px;font-weight:700;display:flex;justify-content:space-between;align-items:center;color:var(--txt)}
details.vbox summary::-webkit-details-marker{display:none}
details.vbox summary::after{content:"＋";color:var(--mut);font-weight:800}
details.vbox[open] summary::after{content:"－"}
details.vbox .in{padding:0 18px 18px}
.big{font-size:2.3rem;font-weight:800;text-align:center;margin:6px 0;letter-spacing:-.03em;background:linear-gradient(135deg,#fff,#a9c2ff);-webkit-background-clip:text;background-clip:text;color:transparent}
.mut{color:var(--mut)}.ctr{text-align:center}
.vc{font-family:var(--mono);letter-spacing:.26em;font-size:1.5rem;font-weight:800;text-align:center;padding:14px;border:2px dashed rgba(34,197,94,.6);border-radius:14px;margin:12px 0;background:rgba(34,197,94,.08)}
.spin{width:40px;height:40px;border:4px solid rgba(255,255,255,.12);border-top-color:var(--ok);border-right-color:var(--pri);border-radius:50%;animation:s .9s linear infinite;margin:10px auto}
@keyframes s{to{transform:rotate(360deg)}}
.hide{display:none!important}
.row{display:flex;gap:10px}.row .btn{margin-top:10px}
.foot{display:flex;flex-direction:column;gap:10px;margin-top:18px}
.care{display:flex;align-items:center;justify-content:center;gap:10px;padding:13px;border-radius:15px;background:var(--card);border:1px solid var(--line-2);color:var(--txt);text-decoration:none;font-weight:700}
.care b{font-family:var(--mono);color:var(--gold)}
.want{border:0;border-radius:15px;padding:14px;font-weight:900;letter-spacing:.04em;font-size:.92rem;cursor:pointer;font-family:inherit;color:#1a1200;background:linear-gradient(135deg,#f59e0b,#fbbf24);box-shadow:0 14px 28px -14px rgba(245,158,11,.8)}
.pw{text-align:center;color:var(--mut);font-size:.76rem;opacity:.8}
/* popups */
.ov{position:fixed;inset:0;z-index:50;background:rgba(2,4,9,.72);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);display:flex;align-items:flex-end;justify-content:center;padding:0}
.sheet{width:100%;max-width:460px;background:#0b1220;border:1px solid var(--line-2);border-bottom:0;border-radius:24px 24px 0 0;padding:20px 18px calc(22px + env(safe-area-inset-bottom));box-shadow:0 -20px 60px -20px #000;animation:up .28s cubic-bezier(.2,.8,.2,1) both;max-height:92vh;overflow:auto}
@media(min-width:520px){.ov{align-items:center}.sheet{border-radius:24px;border-bottom:1px solid var(--line-2)}}
@keyframes up{from{transform:translateY(40px);opacity:0}to{transform:none;opacity:1}}
.sh-h{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.sh-h h3{margin:0;font-size:1.1rem}
.x{border:0;background:var(--card-2);color:var(--txt);width:36px;height:36px;border-radius:12px;font-size:1.1rem;cursor:pointer}
.sel{display:flex;justify-content:space-between;align-items:center;padding:14px;border-radius:16px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.3);margin-bottom:14px}
.sel b{font-size:1rem}.sel .pr{color:var(--gold);font-weight:900;font-size:1.2rem}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="wrap">
  <div class="brand">
    <div class="logo wlogo"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path class="wd" d="M12 18.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z"/><path class="wv w1" d="M7.4 14.5a6.5 6.5 0 0 1 9.2 0L15 16.1a4.2 4.2 0 0 0-6 0z"/><path class="wv w2" d="M4.2 11.3a11 11 0 0 1 15.6 0l-1.6 1.6a8.7 8.7 0 0 0-12.4 0z"/><path class="wv w3" d="M1 8.1a15.6 15.6 0 0 1 22 0l-1.6 1.6a13.3 13.3 0 0 0-18.8 0z"/></svg></div>
    <h1><?= h($title ?: SITE_NAME) ?></h1>
    <p class="sub"><?= t('p_title') ?></p>
    <?php if ($joinedSsid !== ''): ?><div class="mm" style="background:rgba(91,140,255,.12);border-color:rgba(91,140,255,.35);color:#c7d7ff">📶 <?= t('p_on_ssid') ?>: <b><?= h($joinedSsid) ?></b></div><br><?php endif; ?>
    <?php if ($pkgs && !$done): ?><div class="mm">📱 <?= t('p_mm_hint') ?></div><?php endif; ?>
  </div>
  <div id="msg" class="msg" role="alert"></div>

  <?php if ($done): ?>
  <div class="card ctr" id="doneCard">
    <div style="font-size:2.8rem">✅</div>
    <h2 style="margin:6px 0"><?= t('p_connected') ?></h2>
    <div class="mut"><?= t('p_time_left') ?></div>
    <div class="big" id="doneLeft">—</div>
    <div class="mut" id="doneData"></div>
    <a class="btn ok" href="<?= h($origin) ?>"><?= t('p_open_internet') ?></a>
  </div>
  <?php else: ?>
  <?php if (!$hasCtx): ?><div class="msg info" style="display:block"><?= t('p_no_ctx') ?></div><?php endif; ?>

  <div class="card hide" id="resumeCard">
    <div class="mut" style="font-size:.85rem"><?= t('p_resume') ?></div>
    <div class="vc" id="resumeCode"></div>
    <div class="ctr mut"><?= t('p_time_left') ?>: <b id="resumeLeft" style="color:#fff"></b></div>
    <div class="row"><button class="btn ok" onclick="connect(saved)"><?= t('p_connect') ?></button><button class="btn ghost" style="flex:.5" onclick="forget()"><?= t('p_forget') ?></button></div>
  </div>

  <?php if ($pkgs): ?>
  <div class="sec"><?= t('p_choose_pkg_sw') ?></div>
  <div class="plist" style="margin-bottom:16px">
    <?php foreach ($pkgs as $p):
        $dm = (int)$p['duration_minutes'];
        $big = $dm >= 1440 && $dm % 1440 === 0 ? [$dm / 1440, 'Siku'] : ($dm >= 60 && $dm % 60 === 0 ? [$dm / 60, 'Saa'] : [$dm, 'Dak']);
        $meta = fmtDur($dm) . ((int)$p['data_limit_mb'] > 0 ? ' • ' . fmtBytes($p['data_limit_mb'] * 1048576) : ' • ' . t('unlimited'))
              . ((float)$p['speed_down_mbps'] > 0 ? ' • ' . (float)$p['speed_down_mbps'] . ' Mbps' : '') . ((int)$p['max_devices'] > 1 ? ' • ' . (int)$p['max_devices'] . ' 📱' : ''); ?>
    <div class="pc">
      <div class="ic"><?= (int)$big[0] ?><small><?= h($big[1]) ?></small></div>
      <div class="bd"><div class="nm"><?= h($p['name']) ?></div><div class="pr"><?= money($p['price']) ?></div><div class="mt"><?= h($meta) ?></div></div>
      <button type="button" class="lipia" data-id="<?= (int)$p['id'] ?>" data-name="<?= h($p['name']) ?>" data-price="<?= h(money($p['price'])) ?>" onclick="openPay(this)"><?= t('p_lipia') ?></button>
    </div>
    <?php endforeach; ?>
  </div>
  <?php elseif ($hasCtx): ?><div class="msg info" style="display:block"><?= t('p_no_pkgs') ?></div><?php endif; ?>

  <details class="vbox" id="vbox" <?= $pkgs ? '' : 'open' ?>>
    <summary>🎟️ <?= t('p_or_voucher') ?></summary>
    <div class="in">
      <label for="code"><?= t('p_enter_code') ?></label>
      <input type="text" id="code" class="code" maxlength="20" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="XXXXXXXX">
      <label class="chk"><input type="checkbox" id="remember" checked> <?= t('p_remember') ?></label>
      <button class="btn" id="btnV" onclick="connect(document.getElementById('code').value)"><?= t('p_connect') ?></button>
    </div>
  </details>
  <?php endif; ?>

  <div class="foot">
    <?php if ($care !== ''): ?><a class="care" href="tel:<?= h($care) ?>">📞 <?= t('p_customer_care') ?>: <b><?= h($care) ?></b></a><?php endif; ?>
    <button type="button" class="want" onclick="showSheet('wantSheet')">💡 <?= t('p_want_system') ?></button>
    <div class="pw">Powered by <?= h(SITE_NAME) ?></div>
  </div>
</div>

<?php if ($pkgs && !$done): ?>
<!-- Payment popup: phone number → mobile money push → auto-connect -->
<div class="ov hide" id="paySheet" role="dialog" aria-modal="true" aria-labelledby="payTitle">
  <div class="sheet">
    <div class="sh-h"><h3 id="payTitle"><?= t('p_pay_title') ?></h3><button type="button" class="x" onclick="closePay()" aria-label="<?= h(t('p_close')) ?>">✕</button></div>
    <div id="payMsg" class="msg" role="alert"></div>
    <div id="spBox" class="hide" style="margin-bottom:12px;border-radius:14px;border:1px solid rgba(148,163,184,.3);background:rgba(4,7,14,.85);padding:10px 12px">
      <div style="font-size:.72rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--mut);margin-bottom:6px">🔎 <?= h(t('p_sp_answer')) ?> <span id="spHttp"></span></div>
      <pre id="spResp" style="margin:0;white-space:pre-wrap;word-break:break-all;font-family:var(--mono);font-size:.72rem;line-height:1.45;color:#cbd5e1;max-height:220px;overflow:auto"></pre>
    </div>
    <div class="sel"><b id="selName"></b><span class="pr" id="selPrice"></span></div>
    <div id="buyForm">
      <label for="phone"><?= t('p_phone_sw') ?></label>
      <input type="tel" id="phone" class="tel" inputmode="numeric" maxlength="13" placeholder="07XXXXXXXX" autocomplete="tel">
      <div class="mut ctr" style="font-size:.76rem;margin-top:8px"><?= t('p_mm_hint') ?></div>
      <button class="btn ok" id="btnPay" onclick="buy()">💳 <?= t('p_pay_now') ?></button>
    </div>
    <div id="waitBox" class="hide ctr">
      <div class="spin"></div>
      <div id="waitMsg" style="font-weight:700"><?= t('p_waiting_sw') ?></div>
      <div id="payInstr" class="msg info" style="margin-top:12px;text-align:left"></div>
      <div class="mut" style="font-size:.8rem" id="orderRef"></div>
      <button class="btn ghost" id="btnIPaid" onclick="iPaid()">✓ <?= t('p_ipaid') ?></button>
      <button class="btn ghost" onclick="resetBuy()"><?= t('p_back_sw') ?></button>
    </div>
    <div id="paidBox" class="hide ctr">
      <div style="font-size:2.4rem">🎉</div>
      <div><?= t('p_paid_sw') ?>:</div><div class="vc" id="paidCode"></div>
      <div class="mut" id="paidStatus"><?= t('p_auto_connect') ?></div>
    </div>
  </div>
</div>
<!-- v6.7.4 — popup after the USSD push is sent: check phone, enter PIN, confirm -->
<div class="ov hide" id="pushPop" role="dialog" aria-modal="true" aria-labelledby="pushPopTitle" style="z-index:60">
  <div class="sheet ctr">
    <div style="font-size:2.6rem">📲</div>
    <h3 id="pushPopTitle" style="margin:6px 0 8px">Angalia simu yako</h3>
    <div style="line-height:1.5">Ombi la malipo limetumwa kwenye simu yako.<br><b>Weka PIN</b> yako kisha <b>thibitisha</b> malipo.</div>
    <div class="mut" style="margin-top:8px;font-size:.9em">Utaunganishwa kwenye WiFi moja kwa moja baada ya malipo kukamilika.</div>
    <button type="button" class="btn" style="margin-top:14px;width:100%" onclick="document.getElementById('pushPop').classList.add('hide')">Sawa</button>
  </div>
</div>
<?php endif; ?>

<!-- "JE UNATAKA MFUMO HUU?" — platform owner's contacts -->
<div class="ov hide" id="wantSheet" role="dialog" aria-modal="true" aria-labelledby="wantTitle">
  <div class="sheet">
    <div class="sh-h"><h3 id="wantTitle">💡 <?= t('p_want_system') ?></h3><button type="button" class="x" onclick="hideSheet('wantSheet')" aria-label="<?= h(t('p_close')) ?>">✕</button></div>
    <p class="mut" style="margin-top:0"><?= t('p_want_system_desc') ?></p>
    <div class="care" style="margin-bottom:4px">📞 <b><?= h($sales) ?></b></div>
    <a class="btn ok" href="tel:<?= h($sales) ?>">📞 <?= t('p_call') ?></a>
    <a class="btn wa" href="https://wa.me/<?= h($sales255) ?>?text=<?= rawurlencode('Habari, nataka mfumo wa WiFi billing kama ' . SITE_NAME) ?>">💬 <?= t('p_whatsapp') ?></a>
    <button type="button" class="btn ghost" onclick="hideSheet('wantSheet')"><?= t('p_close') ?></button>
  </div>
</div>

<!-- Form submitted by the phone's browser to the Omada controller (External RADIUS portal API) -->
<form id="authForm" method="POST" action="" class="hide">
  <input type="hidden" name="authType" value="2">
  <input type="hidden" name="username"><input type="hidden" name="password">
  <?php foreach (['clientMac', 'clientIp', 'apMac', 'gatewayMac', 'ssidName', 'radioId', 'vid', 'scheme'] as $k): ?>
  <input type="hidden" name="<?= $k ?>" value="<?= h($ctx[$k] ?? '') ?>">
  <?php endforeach; ?>
  <input type="hidden" name="originUrl" value="<?= h(portalUrl() . '?page=portal&done=1') ?>">
</form>

<script>
const CTX_MAC=<?= json_encode(dashMac(normMac($ctx['clientMac'] ?? ''))) ?>, CTX_AP=<?= json_encode(dashMac(normMac($ctx['apMac'] ?? ''))) ?>;
const CSRF=<?= json_encode($csrf) ?>, AUTH_URL=<?= json_encode($authUrl) ?>, HAS_CTX=<?= $hasCtx ? 'true' : 'false' ?>, MM_PUSH=<?= $mmPush ? 'true' : 'false' ?>, DONE=<?= $done ? 'true' : 'false' ?>;
const L2={notConf:<?= json_encode(t('p_not_confirmed')) ?>,wait:<?= json_encode(t('p_waiting_sw')) ?>,resumed:<?= json_encode(t('p_resumed')) ?>,lowBal:'Salio halitoshi kwenye simu yako. Ongeza salio kisha jaribu tena.'};
const L={noCtrl:<?= json_encode(t('p_no_controller')) ?>,noCtx:<?= json_encode(t('p_no_ctx')) ?>,phone:<?= json_encode(t('p_invalid_phone')) ?>,fail:<?= json_encode(t('p_order_failed')) ?>,exp:<?= json_encode(t('p_order_expired')) ?>,conn:<?= json_encode(t('p_connecting')) ?>,connect:<?= json_encode(t('p_connect')) ?>,pay:<?= json_encode('💳 ' . t('p_pay_now')) ?>,push:<?= json_encode(t('p_push_sw')) ?>,ipaid:<?= json_encode('✓ ' . t('p_ipaid')) ?>,ok:<?= json_encode(t('p_payment_success')) ?>,net:'Network error'};
const $=id=>document.getElementById(id);
let saved=null, pkgId=null, pollT=null, curRef=null, paidDone=false;
try{saved=localStorage.getItem('sky_voucher')}catch(e){}
function msg(t,c,box){const m=$(box||'msg');if(!m)return;m.className='msg '+(c||'err');m.textContent=t;if(t&&!box)window.scrollTo({top:0,behavior:'smooth'})}
function clearMsg(box){const m=$(box||'msg');if(m)m.className='msg'}
function api(a,data){const fd=new FormData();fd.append('csrf',CSRF);if(CTX_MAC)fd.append('mac',CTX_MAC);if(CTX_AP)fd.append('ap',CTX_AP);for(const k in data)fd.append(k,data[k]);
  return fetch('?ajax='+a,{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).then(d=>{if(d.reload){location.reload()}return d})}
function norm(c){return String(c||'').toUpperCase().replace(/\s+/g,'')}
function showSheet(id){const s=$(id);if(s){s.classList.remove('hide');document.body.style.overflow='hidden'}}
function hideSheet(id){const s=$(id);if(s){s.classList.add('hide');document.body.style.overflow=''}}
document.querySelectorAll('.ov').forEach(o=>o.addEventListener('click',e=>{if(e.target===o){if(o.id==='paySheet')closePay();else hideSheet(o.id)}}));
function connect(c,box){c=norm(c);if(!c)return;clearMsg();
  if(!HAS_CTX){msg(L.noCtx,'err',box);return}
  if(!AUTH_URL){msg(L.noCtrl,'err',box);return}
  const b=$('btnV');if(b){b.disabled=true;b.textContent=L.conn}
  api('portal_check',{code:c}).then(d=>{
    if(!d.success){msg(d.message,'err',box);if(b){b.disabled=false;b.textContent=L.connect}if(c===saved&&/expired|exhaust|blocked/i.test(d.message))forget();return}
    try{if(!$('remember')||$('remember').checked)localStorage.setItem('sky_voucher',c)}catch(e){}
    const f=$('authForm');f.action=AUTH_URL;f.username.value=c;f.password.value=c;f.submit();
  }).catch(()=>{msg(L.net,'err',box);if(b){b.disabled=false;b.textContent=L.connect}})}
function forget(){try{localStorage.removeItem('sky_voucher')}catch(e){}saved=null;if($('resumeCard'))$('resumeCard').classList.add('hide')}
function openPay(el){pkgId=el.dataset.id;$('selName').textContent=el.dataset.name;$('selPrice').textContent=el.dataset.price;
  if(!curRef)resetBuy();clearMsg('payMsg');showSheet('paySheet');setTimeout(()=>{const p=$('phone');if(p&&!$('buyForm').classList.contains('hide'))p.focus()},250)}
function closePay(){hideSheet('paySheet')}
// v6.7.4 — the Sonic Pesa answer is no longer displayed on the portal (kept hidden)
function spShow(){const b=$('spBox');if(b)b.classList.add('hide')}
// v6.7.4 — when Sonic Pesa reports a low / insufficient balance, show its message to the customer as a normal message
function spBalance(text){const t=String(text||'');if(!t)return '';
  const msgs=[];const re=/"(?:message|description|error|reason|status_message|result_desc|resultdesc)"\s*:\s*"((?:[^"\\]|\\.)*)"/gi;let m;
  while((m=re.exec(t))!==null){try{msgs.push(JSON.parse('"'+m[1]+'"'))}catch(e){msgs.push(m[1])}}
  const low=/(insufficient|low\s*balance|not\s*enough|balance|salio|funds)/i;
  for(const x of msgs){if(low.test(x))return x}
  return low.test(t)?L2.lowBal:''}
function buy(){clearMsg('payMsg');spShow(0,'');if(!pkgId){return}const p=$('phone').value.replace(/\D/g,'');if(!/^(0|255)?[67]\d{8}$/.test(p)){msg(L.phone,'err','payMsg');return}
  if(!HAS_CTX){msg(L.noCtx,'err','payMsg');return}
  try{localStorage.setItem('sky_phone',p)}catch(e){}
  const b=$('btnPay');b.disabled=true;b.textContent=L.conn;
  api('portal_buy',{package_id:pkgId,phone:p}).then(d=>{b.disabled=false;b.textContent=L.pay;
    if(!d.success){msg(spBalance(d.sp_response)||d.message,'err','payMsg');return}
    curRef=d.ref;paidDone=false;addRef(d.ref);$('buyForm').classList.add('hide');$('waitBox').classList.remove('hide');$('orderRef').textContent='Ref: '+d.ref;
    $('waitMsg').textContent=d.mode==='push'?L.push:d.message;
    if(d.mode==='push'&&$('pushPop'))$('pushPop').classList.remove('hide');
    if(d.mode==='manual'){$('payInstr').style.display='block';$('payInstr').textContent=(d.amount?d.amount+' → ':'')+(d.instructions||'')+' • Ref: '+d.ref}else{$('payInstr').style.display='none'}
    poll(d.ref,0)}).catch(()=>{b.disabled=false;b.textContent=L.pay;msg(L.net,'err','payMsg')})}
function paid(code){if(paidDone)return;paidDone=true;clearTimeout(pollT);
  $('waitBox').classList.add('hide');$('paidBox').classList.remove('hide');$('paidCode').textContent=code;
  try{localStorage.setItem('sky_voucher',code)}catch(e){};msg(L.ok,'ok','payMsg');setTimeout(()=>connect(code,'payMsg'),1500)}
// v6.4: a failed / expired payment keeps waiting — when the seller confirms it, the phone is connected automatically
function poll(ref,n){clearTimeout(pollT);pollT=setTimeout(()=>api('portal_order',{ref}).then(d=>{
  if(!d.success){if(n>1200)return;poll(ref,n+1);return}
  if(d.status==='paid'&&d.code){if($('pushPop'))$('pushPop').classList.add('hide');paid(d.code);return}
  if(d.status!=='pending'&&$('pushPop'))$('pushPop').classList.add('hide');
  if(d.status!=='pending'){const lb=spBalance(d.sp_response);if(lb){$('waitMsg').textContent=lb;msg(lb,'err','payMsg')}}
  if(['failed','cancelled','expired'].includes(d.status)&&!spBalance(d.sp_response)){$('waitMsg').textContent=L2.notConf}
  if(n>1200){resetBuy();msg(L.exp,'err','payMsg');return}
  poll(ref,n+1)}).catch(()=>poll(ref,n+1)),n<20?3000:(n<120?6000:10000))}
function getRefs(){try{const a=JSON.parse(localStorage.getItem('sky_orders')||'[]');return Array.isArray(a)?a:[]}catch(e){return []}}
function addRef(r){try{const a=getRefs().filter(x=>x!==r);a.unshift(r);localStorage.setItem('sky_orders',JSON.stringify(a.slice(0,10)))}catch(e){}}
function resumeOrder(){if(!HAS_CTX||DONE)return;
  api('portal_mine',{refs:getRefs().join(',')}).then(d=>{if(!d||!d.success||!d.ref)return;addRef(d.ref);
    if(!$('paySheet')){if(d.code)connect(d.code);return}
    curRef=d.ref;paidDone=false;$('selName').textContent=d.package||'';$('selPrice').textContent=d.amount||'';
    $('buyForm').classList.add('hide');$('paidBox').classList.add('hide');$('orderRef').textContent='Ref: '+d.ref;$('payInstr').style.display='none';
    showSheet('paySheet');
    if(d.code){msg(L2.resumed,'ok','payMsg');paid(d.code);return}
    $('waitBox').classList.remove('hide');$('waitMsg').textContent=d.status==='pending'?L2.wait:L2.notConf;poll(d.ref,20)}).catch(()=>{})}
function iPaid(){if(!curRef)return;const b=$('btnIPaid');b.disabled=true;
  api('portal_ipaid',{ref:curRef}).then(d=>{b.disabled=false;b.textContent=L.ipaid;
    if(d.success&&d.status==='paid'&&d.code){paid(d.code);return}
    msg(d.message||'', 'info','payMsg')}).catch(()=>{b.disabled=false;msg(L.net,'err','payMsg')})}
function resetBuy(){clearTimeout(pollT);curRef=null;paidDone=false;if(!$('buyForm'))return;$('buyForm').classList.remove('hide');$('waitBox').classList.add('hide');$('paidBox').classList.add('hide')}
if($('code'))$('code').addEventListener('keydown',e=>{if(e.key==='Enter')connect(e.target.value)});
if($('phone')){try{const sp=localStorage.getItem('sky_phone');if(sp)$('phone').value=sp}catch(e){}$('phone').addEventListener('keydown',e=>{if(e.key==='Enter')buy()})}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if($('paySheet')&&!$('paySheet').classList.contains('hide'))closePay();hideSheet('wantSheet')}});
// Auto-resume: a phone that already has a valid voucher reconnects with one tap
if(saved&&$('resumeCard')){api('portal_check',{code:saved}).then(d=>{if(d.success){$('resumeCode').textContent=saved;$('resumeLeft').textContent=d.remaining_text;$('resumeCard').classList.remove('hide')}else{forget()}}).catch(()=>{})}
resumeOrder();
if(saved&&$('doneCard')){api('portal_check',{code:saved}).then(d=>{if(d.success){$('doneLeft').textContent=d.remaining_text;$('doneData').textContent='Data: '+d.data_left}})}
</script>
</body>
</html>
<?php
    exit;
}

// ============================================================
// PRINTABLE VOUCHER CARDS
// ============================================================
if ($page === 'print') {
    $auth->requireSeller();
    $uid = (int)$_SESSION['user_id'];
    $batch = (string)($_GET['batch'] ?? '');
    $list = rows("SELECT v.*, p.name AS package_name, d.ssid FROM hs_vouchers v LEFT JOIN hs_packages p ON p.id=v.package_id LEFT JOIN hs_devices d ON d.id=v.device_id
                  WHERE v.seller_id=? AND v.batch=? AND v.status IN ('available','sold') ORDER BY v.id", 'is', $uid, $batch);
    $defaultSsid = val("SELECT ssid FROM hs_devices WHERE user_id=? ORDER BY id LIMIT 1", 'i', $uid);
    while (ob_get_level() > 0) ob_end_clean();
    ?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vouchers <?= h($batch) ?></title>
<style>
*{box-sizing:border-box}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Inter,Arial,sans-serif;margin:16px;color:#0e1726;background:#f3f5fa;-webkit-font-smoothing:antialiased}
.bar{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px;padding:12px 16px;background:#fff;border:1px solid #e4e9f2;border-radius:14px;font-size:14px;box-shadow:0 8px 24px -16px rgba(16,24,40,.25)}
.bar button{border:0;background:linear-gradient(135deg,#3d6df5,#7c3aed);color:#fff;padding:10px 18px;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 10px 20px -10px #3d6df5}
.bar b{font-family:ui-monospace,Menlo,Consolas,monospace}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
.v{position:relative;background:#fff;border:1.5px dashed #a3b1c6;border-radius:12px;padding:12px 8px 10px;text-align:center;page-break-inside:avoid;break-inside:avoid;overflow:hidden}
.v::before{content:"";position:absolute;inset:0 0 auto 0;height:4px;background:linear-gradient(90deg,#3d6df5,#7c3aed);-webkit-print-color-adjust:exact;print-color-adjust:exact}
.v .s{font-size:11px;color:#55627a}
.v .c{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:20px;font-weight:800;letter-spacing:3px;margin:6px 0;color:#0e1726}
.v .p{font-size:12px;font-weight:700;color:#1e293b}
@media print{body{background:#fff;margin:6mm}.bar{display:none}.v{border-color:#555}}
@media(max-width:600px){.grid{grid-template-columns:repeat(2,1fr)}}
</style></head>
<body><div class="bar"><button onclick="print()">🖨 Print</button> <span><?= count($list) ?> vouchers • <b><?= h($batch) ?></b></span></div><div class="grid">
<?php foreach ($list as $v): ?><div class="v"><div class="s">WiFi: <b><?= h($v['ssid'] ?: $defaultSsid ?: SITE_NAME) ?></b></div><div class="c"><?= h($v['code']) ?></div>
<div class="p"><?= h($v['package_name']) ?> • <?= money($v['price']) ?></div><div class="s"><?= fmtDur((int)$v['duration_minutes']) ?><?= (int)$v['data_limit_mb'] > 0 ? ' • ' . fmtBytes($v['data_limit_mb'] * 1048576) : '' ?><?= $v['valid_until'] ? ' • ≤ ' . date('d/m/Y', strtotime($v['valid_until'])) : '' ?></div></div><?php endforeach; ?>
</div></body></html>
<?php
    exit;
}

// ============================================================
// PAGE ACTIONS (POST → redirect, Post/Redirect/Get)
// ============================================================
$P = $_POST;
$isPost = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
if ($isPost && $auth->isLoggedIn()) {
    $uid = (int)$_SESSION['user_id'];
    $act = (string)($P['act'] ?? '');
    $isAdm = $auth->isAdmin();
    // v6.2 — Omada Controller, Omada Manager and RADIUS setup are managed by the administrator only
    $adminOnlyActs = ['ctrl_save', 'ctrl_test', 'ctrl_delete', 'ctrl_reboot', 'ctrl_locate', 'ctrl_claim', 'ctrl_import', 'ctrl_apicheck', 'ctrl_site_create',
        'ssid_create', 'ssid_delete', 'om_site_create', 'om_site_delete', 'om_device_add', 'om_device_rename', 'om_device_forget', 'om_vgroup_create',
        'om_vgroup_import', 'om_vgroup_delete', 'om_voucher_delete', 'om_vsync', 'admin_router_setup', 'admin_router_check', 'admin_router_delete',
        'admin_link_unlinked', 'admin_broadcast'];
    if (in_array($act, $adminOnlyActs, true) && !$isAdm) back('?page=hotspot', 'danger', h(t('admin_only')));
    // a seller may only adopt his own EAP225 (the "Adopt" button on his Hotspot page)
    if ($act === 'ctrl_adopt' && !$isAdm && !val("SELECT 1 FROM hs_devices WHERE user_id=? AND ap_mac=?", 'is', $uid, normMac((string)($P['mac'] ?? ''))))
        back('?page=hotspot', 'danger', h(t('admin_only')));
    // v6.2 — the admin can act on any seller's router from the Hotspot page: run the action as that seller
    if ($isAdm && in_array($act, ['prov_run', 'omada_vouchers', 'device_regen', 'link_check', 'link_fix', 'device_omada_cmd', 'device_toggle', 'router_ssid_create', 'router_ssid_delete'], true)
        && ($ownDev = Device::get((int)($P['id'] ?? 0))) && (int)$ownDev['user_id'] !== $uid) $uid = (int)$ownDev['user_id'];
    if ($isAdm && in_array($act, ['ctrl_adopt', 'ctrl_sync', 'omada_client_cmd'], true)
        && ($ownCtl = row("SELECT user_id FROM hs_controllers WHERE id=?", 'i', (int)($P['id'] ?? 0))) && (int)$ownCtl['user_id'] !== $uid) $uid = (int)$ownCtl['user_id'];
    // v5.9 — sellers on the platform's shared Omada keys may only act on the Omada sites of their own routers
    if (in_array($act, ['ctrl_adopt', 'ctrl_reboot', 'ctrl_locate', 'ctrl_claim', 'ctrl_import', 'omada_client_cmd', 'ssid_create', 'ssid_delete', 'ctrl_apicheck'], true)
        && (string)($P['site'] ?? '') !== '' && ($scopeApi = OmadaApi::load((int)($P['id'] ?? 0), $uid))
        && !$scopeApi->siteAllowed(preg_replace('/[^A-Za-z0-9_\-]/', '', (string)$P['site'])))
        back('?page=controller&id=' . (int)$P['id'], 'danger', h(t('ctrl_site_not_yours')));
    switch ($act) {
        // ----- Devices -----
        case 'device_save':
            $auth->requireSeller();
            // Routers → Add router (model chosen first) / Edit router
            $isNew = empty($P['id']);
            $rModel = RouterModels::byCode((string)($P['router_model'] ?? ''));
            if ($isNew && !$rModel) back('?page=routers&add=1', 'danger', t('choose_model'));
            $ret = $isNew ? '?page=routers&add=1&model=' . urlencode((string)$rModel['code']) : '?page=routers&edit=' . (int)$P['id'];
            $keepForm = function () use ($P): void { $_SESSION['router_form'] = array_diff_key($P, array_flip(['csrf', 'dev_pass', 'act', 'new_client_secret'])); };
            $ctrlNote = '';
            if (!$isAdm) {
                // v6.2 — the router is linked to the admin-managed Omada Controller automatically
                foreach (['omada_link', 'new_base_url', 'new_omadac_id', 'new_inform_url', 'new_client_id', 'new_client_secret'] as $k) unset($P[$k]);
                $cur0 = $isNew ? null : Device::get((int)$P['id'], $uid);
                if (!$isNew && !$cur0) back('?page=routers', 'danger', 'Not found');
                foreach (['controller_url', 'omada_nas_id', 'dae_target'] as $k) if (!array_key_exists($k, $P)) $P[$k] = (string)($cur0[$k] ?? '');
                $P['controller_id'] = ($cur0 && $cur0['controller_id']) ? (int)$cur0['controller_id'] : ensureDefaultController($uid);
                $P['omada_site_id'] = $cur0 ? (string)$cur0['omada_site_id'] : '';
            }
            if (($P['omada_link'] ?? '') === 'new') {
                // v6.1 — connect a new Omada Controller right inside Add router: URL + Omada ID + Client ID + Client Secret are required
                OmadaApi::$deadline = microtime(true) + workBudget(40);
                $c = OmadaProvision::saveController(['base_url' => $P['new_base_url'] ?? '', 'omadac_id' => $P['new_omadac_id'] ?? '',
                    'inform_url' => $P['new_inform_url'] ?? '', 'client_id' => $P['new_client_id'] ?? '', 'client_secret' => $P['new_client_secret'] ?? '',
                    'conn_mode' => 'auto'], $uid, $auth->isAdmin());
                OmadaApi::$deadline = null;
                if (!$c['ok']) { $keepForm(); back($ret, 'danger', $c['msg']); }
                $P['omada_link'] = $c['id'] . '|';
                $ctrlNote = $c['msg'];
            }
            if (array_key_exists('omada_link', $P)) {
                [$lc, $ls] = array_pad(explode('|', (string)$P['omada_link'], 2), 2, '');
                if ($ls !== '' && ($scopeApi = OmadaApi::load((int)$lc, $uid)) && !$scopeApi->siteAllowed($ls)) $ls = '';   // v5.9 shared keys
                $P['controller_id'] = (int)$lc; $P['omada_site_id'] = $ls;
            } elseif (!$isNew && ($cur = Device::get((int)$P['id'], $uid))) {
                $P['controller_id'] = (int)$cur['controller_id']; $P['omada_site_id'] = (string)$cur['omada_site_id'];
            }
            if (empty($P['controller_id']) && ($defCtl = ensureDefaultController($uid))) { $P['controller_id'] = $defCtl; $P['omada_site_id'] = ''; }   // v5.8: default Omada Inform URL
            if (!$isNew && ($cur = Device::get((int)$P['id'], $uid)) && ($P['omada_site_id'] ?? '') === '' && (int)$cur['controller_id'] === (int)($P['controller_id'] ?? 0))
                $P['omada_site_id'] = (string)$cur['omada_site_id'];   // keep the site the auto-setup created
            $linkCtl = !empty($P['controller_id']) ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', (int)$P['controller_id'], $uid) : null;
            $noCtl = !OmadaApi::canApi($linkCtl);
            if ($noCtl && $isAdm) { $keepForm(); back($ret, 'danger', h(t('ctrl_need_api_router'))); }   // v6.1: Open API controller is required
            if ($noCtl) { $P['controller_id'] = $linkCtl ? (int)$linkCtl['id'] : 0; unset($P['omada_auto']); }   // v6.2: seller — wait for the admin
            elseif ($isNew) $P['omada_auto'] = 1;                                                               // v6.1: a new router is always provisioned
            $r = Device::save($P, $uid, $isNew ? null : (int)$P['id']);
            if (!$r['success']) { $keepForm(); back($ret, 'danger', h($r['message'])); }
            $did = (int)$r['id'];
            unset($_SESSION['router_form']);
            if (array_key_exists('omada_sn', $P))   // v5.7.1 FIX: keep the S/N even when the setup is not re-run
                run("UPDATE hs_devices SET omada_sn=? WHERE id=? AND user_id=?", 'sii', strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', (string)$P['omada_sn']), 0, 32)) ?: null, $did, $uid);
            if ($rModel) RouterModels::assign($did, $rModel);
            ProvisionLog::add($did, $uid, $isNew ? 'added' : 'updated', '', RouterModels::label($rModel ?: RouterModels::forDevice(Device::get($did, $uid) ?? [])) . ' • ' . trim((string)($P['device_name'] ?? '')));
            if (trim((string)($P['dev_user'] ?? '')) !== '') OmadaProvision::saveDeviceCreds($did, (string)$P['dev_user'], (string)($P['dev_pass'] ?? ''));
            if (!empty($P['controller_id'])) run("UPDATE hs_controllers SET last_sync=NULL WHERE id=? AND user_id=?", 'ii', (int)$P['controller_id'], $uid); // status refreshes on the next page
            if (!empty($P['omada_auto'])) {
                if (trim((string)($P['omada_site_name'] ?? '')) === '' && !in_array(trim((string)($P['site_name'] ?? '')), ['', 'Default'], true)) $P['omada_site_name'] = $P['site_name'];
                // Add router = everything: site, EAP225 by S/N, SSID, RADIUS profile, portal, pre-auth access, vouchers → then "Start provisioning"
                try { $res = OmadaProvision::run($did, $uid, OmadaProvision::optsFromInput($P)); }
                catch (Throwable $e) { error_log('device_save setup: ' . $e->getMessage()); back('?page=hotspot&id=' . $did . '#setup', 'warning', t('saved') . ' — ' . h($e->getMessage())); }
                ProvisionLog::add($did, $uid, 'setup', (string)$res['state'], t('prov_state_' . $res['state']));
                $ft = $res['ok'] ? 'success' : ($res['state'] === 'manual' ? 'info' : 'warning');
                back('?page=hotspot&id=' . $did . ($res['state'] !== 'failed' ? '&autostart=1' : '') . '#setup', $ft, h(t('router_saved')) . ' — ' . h(t('prov_state_' . $res['state'])) . ($ctrlNote !== '' ? '<br>' . $ctrlNote : ''));
            }
            if ($noCtl) back('?page=hotspot&id=' . $did . '#setup', 'warning', h(t('router_saved')) . '<br>' . h(t('ctrl_admin_pending')));
            // a new router goes straight to Hotspot → provision & connect
            back($isNew ? '?page=hotspot&id=' . $did . '#setup' : '?page=routers', 'success', ($isNew ? h(t('router_saved')) : t('saved')) . ($ctrlNote !== '' ? '<br>' . $ctrlNote : ''));
        case 'prov_run':
            // "Run setup again" on the RADIUS settings page (idempotent)
            $auth->requireSeller();
            $did = (int)($P['id'] ?? 0);
            $cur = Device::get($did, $uid);
            if (!$cur) back('?page=routers', 'danger', 'Not found');
            if (isset($P['omada_link'])) {
                [$lc, $ls] = array_pad(explode('|', (string)$P['omada_link'], 2), 2, '');
                $lc = (int)$lc;
                if ($lc && !val("SELECT 1 FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $lc, $uid)) $lc = 0;
                $ls = substr(preg_replace('/[^A-Za-z0-9_\-]/', '', $ls), 0, 64);
                if ($ls !== '' && $lc && ($scopeApi = OmadaApi::load($lc, $uid)) && !$scopeApi->siteAllowed($ls)) $ls = '';   // v5.9 shared keys
                if ($lc !== (int)$cur['controller_id'] || ($ls !== '' && $ls !== (string)$cur['omada_site_id']))
                    run("UPDATE hs_devices SET controller_id=?, omada_site_id=?, omada_wlan_id=NULL, omada_ssid_id=NULL, omada_radius_id=NULL, omada_portal_id=NULL WHERE id=?",
                        'isi', $lc ?: null, $ls !== '' ? $ls : null, $did);
            }
            if (trim((string)($P['dev_user'] ?? '')) !== '') OmadaProvision::saveDeviceCreds($did, (string)$P['dev_user'], (string)($P['dev_pass'] ?? ''));
            try { $res = OmadaProvision::run($did, $uid, OmadaProvision::optsFromInput($P)); }
            catch (Throwable $e) { error_log('prov_run: ' . $e->getMessage()); back('?page=hotspot&id=' . $did . '#setup', 'danger', h($e->getMessage())); }
            ProvisionLog::add($did, $uid, 'setup', (string)$res['state'], t('prov_state_' . $res['state']));
            back('?page=hotspot&id=' . $did . '#setup', $res['ok'] ? 'success' : ($res['state'] === 'manual' ? 'info' : 'warning'), h(t('prov_state_' . $res['state'])));
        case 'omada_vouchers':
            // Generate more Omada Hotspot vouchers for a hotspot in "Omada vouchers" mode
            $auth->requireSeller();
            $did = (int)($P['id'] ?? 0);
            $cur = Device::get($did, $uid);
            $ctl = $cur && $cur['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $cur['controller_id'], $uid) : null;
            $pkg = row("SELECT * FROM hs_packages WHERE id=? AND seller_id=?", 'ii', (int)($P['package_id'] ?? 0), $uid);
            if (!$cur || !$pkg) back('?page=hotspot&id=' . $did, 'danger', 'Not found');
            if (!OmadaApi::canApi($ctl) || (string)$cur['omada_site_id'] === '') back('?page=hotspot&id=' . $did, 'danger', h(t('prov_need_keys')));
            OmadaApi::$deadline = microtime(true) + workBudget(90);
            try { $r = OmadaProvision::omadaVouchers(new OmadaApi($ctl), (string)$cur['omada_site_id'], $cur, $pkg, max(1, min(500, (int)($P['quantity'] ?? 20))), (string)$cur['omada_portal_id']); }
            catch (Throwable $e) { error_log('omada_vouchers: ' . $e->getMessage()); $r = ['ok' => false, 'msg' => $e->getMessage()]; }
            if (!$r['ok']) back('?page=hotspot&id=' . $did . '#setup', 'danger', h($r['msg']));
            back('?page=vouchers&batch=' . urlencode($r['batch']), 'success', h($r['msg']) . ' — <a href="?page=print&batch=' . urlencode($r['batch']) . '" target="_blank">' . t('print') . '</a>');
        case 'device_regen':
            $auth->requireSeller();
            $ok = Device::rotateSecrets((int)$P['id'], $uid);
            if ($ok) { logActivity($uid, 'radius_rotate', 'New RADIUS passwords for device #' . (int)$P['id']); ProvisionLog::add((int)$P['id'], $uid, 'secrets'); }
            $rd = $ok ? Device::get((int)$P['id'], $uid) : null;
            $rc = $rd && $rd['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $rd['controller_id'], $uid) : null;
            if ($rd && OmadaApi::canApi($rc) && (string)$rd['omada_site_id'] !== '' && $rd['voucher_mode'] === 'radius') {
                // push the new passwords into the Omada RADIUS profile straight away
                $res = OmadaProvision::run((int)$rd['id'], $uid, ['qty' => 0, 'pkg_id' => 0]);
                back('?page=hotspot&id=' . (int)$P['id'] . '#setup', $res['ok'] ? 'success' : 'warning', t('secrets_regenerated') . ' ' . h(t('prov_secrets_pushed')));
            }
            back('?page=hotspot&id=' . (int)$P['id'], $ok ? 'warning' : 'danger', $ok ? t('secrets_regenerated') : 'Error');
        case 'device_toggle':
            // v6.2 — Start / Stop hotspot (RADIUS refuses a stopped hotspot; live users are disconnected)
            $auth->requireSeller();
            $td = Device::get((int)($P['id'] ?? 0), $uid);
            if (!$td) back('?page=routers', 'danger', 'Not found');
            $toOn = (int)$td['is_active'] ? 0 : 1;
            run("UPDATE hs_devices SET is_active=? WHERE id=?", 'ii', $toOn, $td['id']);
            if (!$toOn) foreach (rows("SELECT * FROM hs_sessions WHERE device_id=? AND status='active'", 'i', $td['id']) as $ts) Radius::queueSessionDisconnect($ts, 'Hotspot stopped');
            ProvisionLog::add((int)$td['id'], $uid, 'updated', $toOn ? 'started' : 'stopped', $toOn ? t('hotspot_started') : t('hotspot_stopped'));
            logActivity((int)$_SESSION['user_id'], 'hotspot_' . ($toOn ? 'start' : 'stop'), $td['device_name']);
            back(safeReturn((string)($P['return'] ?? ''), '?page=hotspot&id=' . (int)$td['id']), $toOn ? 'success' : 'warning', h($toOn ? t('hotspot_started') : t('hotspot_stopped')));
        case 'admin_router_setup':
        case 'admin_router_check':
            $ad = Device::get((int)($P['id'] ?? 0));
            if (!$ad) back('?page=all_routers', 'danger', 'Not found');
            $owner = (int)$ad['user_id'];
            if (!$ad['controller_id'] && ($dc = ensureDefaultController($owner))) run("UPDATE hs_devices SET controller_id=? WHERE id=?", 'ii', $dc, $ad['id']);
            if ($act === 'admin_router_setup') {
                try { $res = OmadaProvision::run((int)$ad['id'], $owner, ['qty' => 0, 'pkg_id' => 0]); }
                catch (Throwable $e) { back('?page=all_routers', 'danger', h($e->getMessage())); }
                ProvisionLog::add((int)$ad['id'], $owner, 'setup', (string)$res['state'], 'admin: ' . t('prov_state_' . $res['state']));
                OmadaApi::$deadline = null;
                back('?page=all_routers', $res['ok'] ? 'success' : 'warning', h(sprintf(t('ar_setup_done'), $ad['device_name'], t('prov_state_' . $res['state']))));
            }
            $rows = OmadaLink::check((int)$ad['id'], $owner);
            $cn = OmadaLink::counts($rows);
            back('?page=all_routers', $cn['fail'] ? 'warning' : 'success', h($ad['device_name']) . ': ' . ($cn['fail'] ? h(sprintf(t('hl_problems'), $cn['fail'])) : h(t('hl_all_ok'))));
        case 'admin_router_delete':
            $ad = Device::get((int)($P['id'] ?? 0));
            if ($ad) { run("DELETE FROM hs_devices WHERE id=?", 'i', $ad['id']); logActivity($uid, 'admin_router_delete', $ad['device_name'] . ' ' . $ad['ap_mac'] . ' (seller #' . $ad['user_id'] . ')'); }
            back('?page=all_routers', 'success', t('deleted'));
        case 'admin_link_unlinked':
            $n = 0;
            foreach (rows("SELECT DISTINCT user_id FROM hs_devices WHERE controller_id IS NULL") as $r) {
                $before = (int)val("SELECT COUNT(*) FROM hs_devices WHERE user_id=? AND controller_id IS NULL", 'i', $r['user_id']);
                if (ensureDefaultController((int)$r['user_id'])) $n += $before - (int)val("SELECT COUNT(*) FROM hs_devices WHERE user_id=? AND controller_id IS NULL", 'i', $r['user_id']);
            }
            back('?page=all_routers', $n ? 'success' : 'warning', h(sprintf(t('linked_n'), $n)) . ($n ? '' : '<br>' . h(t('ctrl_admin_pending'))));
        case 'admin_broadcast':
            $bt = trim(substr((string)($P['title'] ?? ''), 0, 200));
            $bm = trim(substr((string)($P['message'] ?? ''), 0, 2000));
            if ($bt === '' || $bm === '') back('?page=admin', 'danger', t('all_fields_required'));
            $n = 0;
            foreach (rows("SELECT id FROM users WHERE user_type='seller' AND status='active'") as $r) { Notify::add((int)$r['id'], $bt, $bm, 'info', null, 'bullhorn'); $n++; }
            logActivity($uid, 'admin_broadcast', $bt . ' → ' . $n);
            back('?page=admin', 'success', h(sprintf(t('broadcast_sent'), $n)));
        case 'router_ssid_create':
        case 'router_ssid_delete':
            // v6.3 — sellers create several WiFi names (SSIDs) for their own router, in the router's Omada site
            $auth->requireSeller();
            $sd = Device::get((int)($P['id'] ?? 0), $uid);
            if (!$sd) back('?page=routers', 'danger', 'Not found');
            $sret = '?page=hotspot&id=' . (int)$sd['id'] . '#ssids';
            $sctl = $sd['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $sd['controller_id'], $uid) : null;
            $ssite = (string)$sd['omada_site_id'];
            if (!OmadaApi::canApi($sctl) || $ssite === '') back($sret, 'danger', h(t('ssid_need_setup')));
            $sapi = new OmadaApi($sctl);
            OmadaApi::$deadline = microtime(true) + workBudget(60);
            $extras = json_decode((string)($sd['extra_ssids'] ?? ''), true) ?: [];
            if ($act === 'router_ssid_delete') {
                $sid = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['ssid'] ?? ''));
                if ($sid === '' || $sid === (string)$sd['omada_ssid_id']) back($sret, 'danger', h(t('ssid_main_keep')));
                $hit = null;
                foreach ($sapi->allSsids($ssite) as $x) if ($x['ssid_id'] === $sid) { $hit = $x; break; }
                if (!$hit) back($sret, 'danger', h($sapi->error ?: t('ssid_not_found')));
                $wasHotspot = (bool)array_filter($extras, fn($e) => ($e['id'] ?? '') === $sid && ($e['type'] ?? '') === 'hotspot');
                $r = $sapi->deleteSsid($ssite, $hit['wlan_id'], $sid);
                if ($r['ok']) {
                    run("UPDATE hs_devices SET extra_ssids=? WHERE id=?", 'si', json_encode(array_values(array_filter($extras, fn($e) => ($e['id'] ?? '') !== $sid))), (int)$sd['id']);
                    if ($wasHotspot) OmadaProvision::refreshPortal((int)$sd['id'], $uid);
                    ProvisionLog::add((int)$sd['id'], $uid, 'updated', 'ssid', 'SSID deleted: ' . $hit['name']);
                }
                logActivity((int)$_SESSION['user_id'], 'router_ssid_delete', $sd['device_name'] . ' ' . $hit['name'] . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
                back($sret, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('ssid_deleted') . ': ' . $hit['name']) : h($r['msg']));
            }
            if (count($extras) >= 7) back($sret, 'danger', h(sprintf(t('ssid_limit'), 7)));
            $sname = trim((string)($P['name'] ?? ''));
            $sname = function_exists('mb_strcut') ? mb_strcut($sname, 0, 32, 'UTF-8') : substr($sname, 0, 32);
            $stype = ($P['type'] ?? 'hotspot') === 'private' ? 'private' : 'hotspot';
            $spsk = $stype === 'private' ? (string)($P['psk'] ?? '') : '';
            if ($sname === '') back($sret, 'danger', h(t('all_fields_required')));
            if ($stype === 'private' && (strlen($spsk) < 8 || strlen($spsk) > 63 || preg_match('/[^\x20-\x7E]/', $spsk))) back($sret, 'danger', h(t('ssid_pass_bad')));
            $sband = in_array((int)($P['band'] ?? 3), [1, 2, 3], true) ? (int)$P['band'] : 3;
            $all = $sapi->allSsids($ssite);
            foreach ($all as $x) if (strcasecmp($x['name'], $sname) === 0) back($sret, 'warning', h(t('ssid_exists')));
            $wlan = (string)$sd['omada_wlan_id'];
            if ($wlan === '') foreach ($sapi->wlanGroups($ssite) as $g) if (!empty($g['primary']) || $wlan === '') $wlan = (string)($g['wlanId'] ?? '');
            if ($wlan === '') back($sret, 'danger', h($sapi->error ?: t('ssid_need_setup')));
            $r = OmadaApi::firstOk(fn($b) => $sapi->createSsid($ssite, $wlan, $b), OmadaProvision::ssidBodies($sname, $spsk, $stype === 'hotspot', $sband));
            if (!$r['ok']) back($sret, 'danger', h($r['msg']));
            pauseMs(600);
            $newId = '';
            foreach ($sapi->ssidList($ssite, $wlan) as $x) if ((string)($x['name'] ?? '') === $sname) $newId = (string)($x['ssidId'] ?? '');
            $extras[] = ['id' => $newId, 'name' => $sname, 'type' => $stype, 'band' => $sband, 'at' => date('Y-m-d H:i')];
            run("UPDATE hs_devices SET extra_ssids=? WHERE id=?", 'si', json_encode($extras, JSON_UNESCAPED_UNICODE), (int)$sd['id']);
            $note = '';
            if ($stype === 'hotspot' && $newId !== '') { $pr = OmadaProvision::refreshPortal((int)$sd['id'], $uid); $note = $pr['ok'] ? ' • ' . t('ssid_portal_added') : ' • ' . $pr['msg']; }
            ProvisionLog::add((int)$sd['id'], $uid, 'updated', 'ssid', 'SSID created: ' . $sname . ' (' . $stype . ')');
            logActivity((int)$_SESSION['user_id'], 'router_ssid_create', $sd['device_name'] . ' ' . $sname . ' (' . $stype . ')');
            back($sret, 'success', h(t('ssid_created') . ': ' . $sname . $note));
        case 'device_delete':
            $auth->requireSeller();
            run("DELETE FROM hs_devices WHERE id=? AND user_id=?", 'ii', (int)$P['id'], $uid);
            back('?page=routers', 'success', t('deleted'));
        // ----- Omada Controller (Open API) -----
        case 'ctrl_save':
            $auth->requireSeller();
            $cid = (int)($P['id'] ?? 0);
            $c = OmadaProvision::saveController($P, $uid, $auth->isAdmin(), $cid);
            if (!$c['ok']) back('?page=controller' . ($cid ? '&edit=' . $cid : ''), 'danger', $c['msg']);
            back('?page=controller&id=' . (int)$c['id'], !empty($c['test_ok']) ? 'success' : 'warning', t('saved') . '<br>' . $c['msg']);
        case 'ctrl_test':
            $auth->requireSeller();
            $api = OmadaApi::load((int)$P['id'], $uid);
            if (!$api) back('?page=controller', 'danger', 'Not found');
            $t = $api->test();
            if (($ldev = (int)($P['device_id'] ?? 0)) && Device::get($ldev, $uid)) ProvisionLog::add($ldev, $uid, 'cloud', $t['ok'] ? 'ok' : 'fail', implode(' • ', $t['lines']));
            back($P['return'] ?? ('?page=controller&id=' . $api->id()), $t['ok'] ? 'success' : 'danger', implode('<br>', array_map('h', $t['lines'])));
        case 'ctrl_delete':
            $auth->requireSeller();
            run("UPDATE hs_devices SET controller_id=NULL WHERE controller_id=? AND user_id=?", 'ii', (int)$P['id'], $uid);
            run("DELETE FROM hs_controllers WHERE id=? AND user_id=?", 'ii', (int)$P['id'], $uid);
            back('?page=controller', 'success', t('deleted'));
        case 'ctrl_sync':
            $auth->requireSeller();
            $c = row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', (int)$P['id'], $uid);
            if (!$c) back('?page=controller', 'danger', 'Not found');
            [$n, $m] = OmadaSync::controller($c, true);
            back($P['return'] ?? ('?page=controller&id=' . (int)$c['id']), $m === 'ok' || $m === 'no hotspots' ? 'success' : 'warning', t('omada_synced') . ": $n • " . h($m));
        case 'ctrl_adopt':
        case 'ctrl_reboot':
        case 'ctrl_locate':
        case 'ctrl_claim':
            $auth->requireSeller();
            $api = OmadaApi::load((int)$P['id'], $uid);
            if (!$api) back('?page=controller', 'danger', 'Not found');
            $site = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['site'] ?? ''));
            $mac = normMac((string)($P['mac'] ?? ''));
            $ret = '?page=controller&id=' . $api->id() . '&site=' . urlencode($site);
            if ($site === '') back($ret, 'danger', t('ctrl_pick_site'));
            if ($act === 'ctrl_claim') {
                $sn = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)($P['sn'] ?? '')));
                if ($sn === '') back($ret, 'danger', t('all_fields_required'));
                $r = $api->addBySerial($site, $sn, trim((string)($P['device_key'] ?? '')), trim((string)($P['dname'] ?? '')));
            } else {
                if ($mac === '') back($ret, 'danger', 'MAC');
                if ($act === 'ctrl_adopt') $r = $api->adopt($site, $mac, trim((string)($P['dev_user'] ?? 'admin')) ?: 'admin', (string)($P['dev_pass'] ?? '') !== '' ? (string)$P['dev_pass'] : 'admin');
                elseif ($act === 'ctrl_reboot') $r = $api->reboot($site, $mac);
                else $r = $api->locate($site, $mac);
            }
            logActivity($uid, $act, $site . ' ' . ($mac ?: ($P['sn'] ?? '')) . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
            $extra = '';
            if (!empty($r['adopt_result']) && is_array($r['adopt_result'])) $extra = ' • ' . h(json_encode($r['adopt_result'], JSON_UNESCAPED_SLASHES));
            if ($r['ok']) run("UPDATE hs_controllers SET last_sync=NULL WHERE id=?", 'i', $api->id());   // re-sync on next page view
            back($P['return'] ?? $ret, $r['ok'] ? 'success' : 'danger', ($r['ok'] ? t('ctrl_cmd_sent') : h($r['msg'])) . $extra);
        case 'ctrl_import':
            $auth->requireSeller();
            $c = row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', (int)$P['id'], $uid);
            $mac = normMac((string)($P['mac'] ?? ''));
            $site = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['site'] ?? ''));
            if (!$c || $mac === '') back('?page=controller', 'danger', 'Error');
            $siteName = '';
            foreach ((json_decode((string)$c['sites_json'], true) ?: []) as $s) if ($s['id'] === $site) $siteName = $s['name'];
            $exists = row("SELECT id, user_id FROM hs_devices WHERE ap_mac=?", 's', $mac);
            if ($exists && (int)$exists['user_id'] !== $uid) back('?page=controller&id=' . (int)$c['id'] . '&site=' . urlencode($site), 'danger', 'This AP MAC is already registered.');
            if ($exists) {
                run("UPDATE hs_devices SET controller_id=?, omada_site_id=?, site_name=IF(?<>'', ?, site_name) WHERE id=?", 'isssi', $c['id'], $site, $siteName, $siteName, $exists['id']);
                $did = (int)$exists['id'];
            } else {
                $r = Device::save(['device_name' => trim((string)($P['name'] ?? '')) ?: 'EAP ' . substr(dashMac($mac), -5), 'ap_mac' => $mac, 'site_name' => $siteName ?: 'Default',
                    'ssid' => trim((string)($P['ssid'] ?? '')), 'is_active' => 1, 'controller_id' => $c['id'], 'omada_site_id' => $site], $uid);
                if (!$r['success']) back('?page=controller&id=' . (int)$c['id'] . '&site=' . urlencode($site), 'danger', h($r['message']));
                $did = (int)$r['id'];
            }
            OmadaSync::controller($c, true);
            back('?page=hotspot&id=' . $did, 'success', t('ctrl_imported'));
        case 'device_omada_cmd':
            $auth->requireSeller();
            $d = Device::get((int)$P['id'], $uid);
            if (!$d || !$d['controller_id'] || !$d['omada_site_id']) back('?page=routers', 'danger', t('ctrl_not_linked'));
            $api = OmadaApi::load((int)$d['controller_id'], $uid);
            if (!$api) back('?page=routers', 'danger', t('ctrl_not_linked'));
            $r = ($P['cmd'] ?? '') === 'locate' ? $api->locate($d['omada_site_id'], $d['ap_mac']) : $api->reboot($d['omada_site_id'], $d['ap_mac']);
            back('?page=hotspot&id=' . (int)$d['id'], $r['ok'] ? 'success' : 'danger', $r['ok'] ? t('ctrl_cmd_sent') : h($r['msg']));
        // ----- v5.6 Omada Open API: client commands, feature check, site creation -----
        case 'omada_client_cmd':
            $auth->requireSeller();
            $api = OmadaApi::load((int)($P['id'] ?? 0), $uid);
            $ret = safeReturn($P['return'] ?? '', '?page=controller');
            if (!$api || !OmadaApi::canApi($api->row())) back($ret, 'danger', h(t('prov_need_keys')));
            $site = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['site'] ?? ''));
            $mac = normMac((string)($P['mac'] ?? ''));
            $cmd = (string)($P['cmd'] ?? '');
            OmadaApi::$deadline = microtime(true) + workBudget(25);
            $r = $api->clientCmd($site, $mac, $cmd);
            if ($r['ok'] && $cmd === 'block') SessionOps::blockMac($uid, $mac, 'Blocked in Omada from the website');
            if ($r['ok'] && $cmd === 'unblock') run("DELETE FROM hs_blocked_macs WHERE seller_id=? AND mac=?", 'is', $uid, $mac);
            if ($r['ok'] && $cmd === 'reconnect') foreach (rows("SELECT * FROM hs_sessions WHERE seller_id=? AND mac=? AND status='active'", 'is', $uid, $mac) as $s2) Radius::queueSessionDisconnect($s2, 'Omada reconnect');
            logActivity($uid, 'omada_client_' . preg_replace('/[^a-z]/', '', $cmd), $site . ' ' . $mac . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
            back($ret, $r['ok'] ? 'success' : 'danger', $r['ok'] ? t('ctrl_cmd_sent') . ' • ' . h(dashMac($mac)) : h($r['msg']));
        case 'ctrl_apicheck':
            $auth->requireSeller();
            $api = OmadaApi::load((int)($P['id'] ?? 0), $uid);
            if (!$api) back('?page=controller', 'danger', 'Not found');
            OmadaApi::$deadline = microtime(true) + workBudget(90);
            try { $rows = $api->apiCheck(preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['site'] ?? ''))); }
            catch (Throwable $e) { $rows = [['Open API', 'fail', $e->getMessage()]]; }
            $fails = count(array_filter($rows, fn($x) => $x[1] === 'fail'));
            $ic = ['ok' => '✔', 'fail' => '✘', 'skip' => '•'];
            $html = '<b>' . h(t('ctrl_api_report')) . ' — ' . h($api->row()['name']) . '</b><div class="table-responsive mt-2"><table class="table table-sm mb-0">';
            foreach ($rows as [$f, $st, $m]) $html .= '<tr><td class="text-nowrap">' . $ic[$st] . ' ' . h($f) . '</td><td class="small" style="word-break:break-word">' . h($m) . '</td></tr>';
            $html .= '</table></div>';
            logActivity($uid, 'omada_api_check', $api->row()['name'] . ' → ' . $fails . ' failed');
            back($P['return'] ?? ('?page=controller&id=' . $api->id()), $fails ? 'warning' : 'success', $html);
        case 'ctrl_site_create':
            $auth->requireSeller();
            $api = OmadaApi::load((int)($P['id'] ?? 0), $uid);
            if (!$api || !OmadaApi::canApi($api->row())) back('?page=controller', 'danger', h(t('prov_need_keys')));
            if ($api->sharedScope()) back('?page=controller&id=' . $api->id(), 'info', h(t('ctrl_shared_sites')));   // v5.9: sites come from Add router
            $sname = OmadaProvision::siteName((string)($P['site_name'] ?? ''), random_int(100, 999));
            OmadaApi::$deadline = microtime(true) + workBudget(40);
            if ($ex = $api->siteByName($sname)) back('?page=controller&id=' . $api->id() . '&site=' . urlencode($ex['id']), 'info', h(t('prov_site_reused') . ': ' . $sname));
            [$du, $dp] = OmadaProvision::siteAccount($api->row());
            $sc = $api->scenarios();
            $scen = '';
            foreach (['Hotel', 'Restaurant', 'Cafe', 'Shop', 'Office'] as $pref) if (in_array($pref, $sc, true)) { $scen = $pref; break; }
            $r = $api->createSite($sname, getSetting('omada_site_region', 'Tanzania'), getSetting('omada_site_timezone', 'Africa/Nairobi'), $scen ?: ($sc[0] ?? 'Office'), $du, $dp);
            logActivity($uid, 'omada_site_create', $sname . ' → ' . ($r['ok'] ? $r['id'] : $r['msg']));
            back('?page=controller&id=' . $api->id() . ($r['ok'] ? '&site=' . urlencode($r['id']) : ''), $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('ctrl_site_created') . ': ' . $sname) : h($r['msg']));
        // ----- Packages -----
        case 'package_save':
            $auth->requireSeller();
            $devId = (int)($P['device_id'] ?? 0);
            if ($devId && !Device::get($devId, $uid)) $devId = 0;
            $f = [trim($P['name'] ?? ''), trim($P['description'] ?? ''), max(0, (float)($P['price'] ?? 0)), max(1, (int)($P['duration_minutes'] ?? 60)),
                ($P['time_mode'] ?? '') === 'online' ? 'online' : 'continuous', max(0, (int)($P['data_limit_mb'] ?? 0)), max(0, (float)($P['speed_down_mbps'] ?? 0)),
                max(0, (float)($P['speed_up_mbps'] ?? 0)), max(1, min(10, (int)($P['max_devices'] ?? 1))), max(0, (int)($P['validity_days'] ?? 30)),
                !empty($P['show_on_portal']) ? 1 : 0, !empty($P['is_active']) ? 1 : 0, (int)($P['sort_order'] ?? 0), $devId ?: null];
            if ($f[0] === '') back('?page=packages', 'danger', t('all_fields_required'));
            if (!empty($P['id'])) {
                run("UPDATE hs_packages SET name=?, description=?, price=?, duration_minutes=?, time_mode=?, data_limit_mb=?, speed_down_mbps=?, speed_up_mbps=?, max_devices=?, validity_days=?, show_on_portal=?, is_active=?, sort_order=?, device_id=? WHERE id=? AND seller_id=?",
                    'ssdisiddiiiiiiii', ...array_merge($f, [(int)$P['id'], $uid]));
            } else {
                q("INSERT INTO hs_packages (name,description,price,duration_minutes,time_mode,data_limit_mb,speed_down_mbps,speed_up_mbps,max_devices,validity_days,show_on_portal,is_active,sort_order,device_id,seller_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    'ssdisiddiiiiiii', ...array_merge($f, [$uid]));
            }
            back('?page=packages', 'success', t('saved'));
        case 'package_delete':
            $auth->requireSeller();
            run("DELETE FROM hs_packages WHERE id=? AND seller_id=?", 'ii', (int)$P['id'], $uid);
            back('?page=packages', 'success', t('deleted'));
        // ----- Vouchers -----
        case 'vouchers_generate':
            $auth->requireSeller();
            $r = Vouchers::generate((int)$P['package_id'], $uid, (int)($P['quantity'] ?? 10));
            if (empty($r['success'])) back('?page=vouchers', 'danger', $r['message']);
            back('?page=vouchers&batch=' . urlencode($r['batch']), 'success', count($r['codes']) . ' vouchers • ' . $r['batch'] . ' — <a href="?page=print&batch=' . urlencode($r['batch']) . '" target="_blank">' . t('print') . '</a>');
        case 'voucher_status':
            $auth->requireSeller();
            $vid = (int)$P['id'];
            $v = row("SELECT * FROM hs_vouchers WHERE id=? AND seller_id=?", 'ii', $vid, $uid);
            if ($v) {
                $to = (string)$P['to'];
                if ($to === 'blocked' || $to === 'cancelled') {
                    $liveMacs = rows("SELECT DISTINCT mac, device_id FROM hs_sessions WHERE voucher_id=? AND status='active' AND mac IS NOT NULL", 'i', $vid);
                    Vouchers::setStatus($vid, $to, 'Seller ' . $to);
                    // v5.6: kick the phones straight away through the Omada Open API (RADIUS then refuses the voucher)
                    foreach ($liveMacs as $lm) OmadaClientOps::apply($uid, (string)$lm['mac'], 'reconnect', (int)$lm['device_id']);
                }
                elseif ($to === 'unblock') run("UPDATE hs_vouchers SET status=IF(first_used_at IS NULL,'available','active') WHERE id=?", 'i', $vid);
            }
            back($_SERVER['HTTP_REFERER'] ?? '?page=vouchers', 'success', t('saved'));
        // ----- Sessions -----
        case 'adjust':
            $auth->requireSeller();
            $r = SessionOps::adjust((int)$P['voucher_id'], $uid, (int)$P['minutes'], trim($P['reason'] ?? ''));
            back($P['return'] ?? '?page=sessions', $r['success'] ? 'success' : 'danger', $r['message']);
        case 'bulk_adjust':
            $auth->requireSeller();
            $ok = 0;
            foreach ((array)($P['voucher_ids'] ?? []) as $vid) if (SessionOps::adjust((int)$vid, $uid, (int)$P['minutes'], trim($P['reason'] ?? 'Bulk'))['success']) $ok++;
            back('?page=sessions', 'success', t('adjustment_success') . " ($ok)");
        case 'disconnect':
            $auth->requireSeller();
            SessionOps::disconnect((int)$P['session_id'], $uid);
            $ss = row("SELECT mac, device_id FROM hs_sessions WHERE id=? AND seller_id=?", 'ii', (int)$P['session_id'], $uid);
            [$oN] = $ss ? OmadaClientOps::apply($uid, (string)$ss['mac'], 'reconnect', (int)$ss['device_id']) : [0, ''];
            back('?page=sessions', 'info', t('disconnect_queued') . ($oN ? ' • ' . t('omada_also') . ' (' . t('omada_reconnect') . ')' : ''));
        case 'block_mac':
            $auth->requireSeller();
            SessionOps::blockMac($uid, (string)$P['mac'], trim($P['reason'] ?? 'Blocked by seller'));
            [$oN] = OmadaClientOps::apply($uid, (string)$P['mac'], 'block');
            back('?page=sessions', 'success', t('device_blocked_ok') . ($oN ? ' • ' . t('omada_also') . " ($oN)" : ''));
        case 'unblock_mac':
            $auth->requireSeller();
            $bm = row("SELECT mac FROM hs_blocked_macs WHERE id=? AND seller_id=?", 'ii', (int)$P['id'], $uid);
            run("DELETE FROM hs_blocked_macs WHERE id=? AND seller_id=?", 'ii', (int)$P['id'], $uid);
            [$oN] = $bm ? OmadaClientOps::apply($uid, (string)$bm['mac'], 'unblock') : [0, ''];
            back('?page=sessions', 'success', t('device_unblocked_ok') . ($oN ? ' • ' . t('omada_also') . " ($oN)" : ''));
        // ----- Orders -----
        case 'order_confirm':
            $auth->requireSeller();
            $o = row("SELECT * FROM hs_orders WHERE id=? AND seller_id=?", 'ii', (int)$P['id'], $uid);
            if ($o && in_array($o['status'], ['pending', 'expired', 'failed', 'cancelled'], true)) {
                $r = PaymentOps::confirm((int)$o['id'], $uid, (string)($P['gateway_ref'] ?? ''));   // v6.4: voucher + balance + customer connected
                back(safeReturn((string)($P['return'] ?? ''), '?page=orders'), $r['ok'] ? 'success' : 'danger', h($r['msg']));
            }
            back('?page=orders');
        // ----- v6.4 Transactions → Payments (seller: own payments, admin: all) -----
        case 'pay_manage':
            $auth->requireSeller();
            $pret = safeReturn((string)($P['return'] ?? ''), '?page=transactions');
            $po = row("SELECT * FROM hs_orders WHERE id=?", 'i', (int)($P['id'] ?? 0));
            if (!PaymentOps::canManage($po, $uid, $isAdm)) back($pret, 'danger', 'Not found');
            $pnote = trim(substr(preg_replace('/[\x00-\x1F]/', ' ', (string)($P['note'] ?? '')), 0, 500));
            switch ((string)($P['op'] ?? '')) {
                case 'confirm':
                    $r = PaymentOps::confirm((int)$po['id'], $uid, (string)($P['gateway_ref'] ?? ''), $pnote);
                    back($pret, $r['ok'] ? 'success' : 'danger', h($r['msg']));
                case 'recheck':
                    if ((string)$po['gateway_ref'] === '' || !Payments::sonicConfigured()) back($pret, 'warning', h(t('pay_no_gateway')));
                    try { $st = Payments::checkGateway($po, 'recheck'); } catch (Throwable $e) { back($pret, 'danger', h($e->getMessage())); }
                    if ($st === true) run("UPDATE hs_orders SET confirmed_by=?, confirmed_at=NOW(), reconnect_done=0 WHERE id=?", 'ii', $uid, $po['id']);
                    if ($st === false && $po['status'] !== 'pending') run("UPDATE hs_orders SET status='failed' WHERE id=? AND status IN ('expired')", 'i', $po['id']);
                    logActivity($uid, 'payment_recheck', $po['order_ref'] . ' → ' . var_export($st, true));
                    $spNow = row("SELECT sp_status, fulfill_error FROM hs_orders WHERE id=?", 'i', $po['id']) ?: [];
                    $spMsg = ' • Sonic Pesa: ' . ((string)($spNow['sp_status'] ?? '') !== '' ? $spNow['sp_status'] : '?')
                        . ($st === null && Payments::$lastError !== '' ? ' • ' . t('pay_confirm_failed') . ' — ' . Payments::$lastError : '');
                    back($pret, $st === true ? 'success' : ($st === false ? 'danger' : 'warning'), h(t($st === true ? 'pay_recheck_paid' : ($st === false ? 'pay_recheck_failed' : 'pay_recheck_pending')) . $spMsg));
                case 'fail':
                    run("UPDATE hs_orders SET status='failed', admin_note=IF(?<>'', ?, admin_note) WHERE id=? AND status IN ('pending','expired')", 'ssi', $pnote, $pnote, $po['id']);
                    logActivity($uid, 'payment_fail', $po['order_ref']);
                    back($pret, 'warning', h(t('pay_marked_failed')));
                case 'cancel':
                    run("UPDATE hs_orders SET status='cancelled', admin_note=IF(?<>'', ?, admin_note) WHERE id=? AND status IN ('pending','failed','expired')", 'ssi', $pnote, $pnote, $po['id']);
                    logActivity($uid, 'payment_cancel', $po['order_ref']);
                    back($pret, 'warning', h(t('pay_cancelled')));
                case 'reconnect':
                    if ($po['status'] !== 'paid') back($pret, 'warning', 'Payment is not confirmed yet.');
                    [$rn, $rm] = PaymentOps::connectClient($po);
                    logActivity($uid, 'payment_reconnect', $po['order_ref'] . ' → ' . $rn);
                    back($pret, $rn ? 'success' : 'info', h($rn ? sprintf(t('pay_reconnect_sent'), $rn) : ($rm !== '' && normMac((string)$po['client_mac']) === '' ? $rm : t('pay_reconnect_none') . ($rm !== '' ? ' (' . $rm . ')' : ''))));
                case 'set_status':   // v6.5: "paid" → voucher for the package is created automatically and the customer is connected
                    $r = PaymentOps::setStatus((int)$po['id'], $uid, (string)($P['to'] ?? ''), (string)($P['gateway_ref'] ?? ''), $pnote);
                    back($pret, $r['ok'] ? 'success' : 'danger', h($r['msg']));
                case 'note':
                    run("UPDATE hs_orders SET admin_note=? WHERE id=?", 'si', $pnote !== '' ? $pnote : null, $po['id']);
                    back($pret, 'success', h(t('pay_note_saved')));
            }
            back($pret);
        case 'pay_recheck_all':
            // v6.6 — ask Sonic Pesa now for every unconfirmed payment (seller: his own, admin: all)
            $auth->requireSeller();
            if (!Payments::sonicConfigured()) back('?page=transactions', 'warning', h(t('pay_no_gateway')));
            OmadaApi::$deadline = microtime(true) + workBudget(60);
            $chk = 0; $paidN = 0;
            $sqlAll = "SELECT * FROM hs_orders WHERE gateway_ref IS NOT NULL AND gateway_ref<>'' AND status IN ('pending','expired','failed') AND created_at > DATE_SUB(NOW(), INTERVAL 3 DAY)";
            foreach (($isAdm ? rows($sqlAll . " ORDER BY id DESC LIMIT 40") : rows($sqlAll . " AND seller_id=? ORDER BY id DESC LIMIT 40", 'i', $uid)) as $po) {
                if (microtime(true) > OmadaApi::$deadline - 3) break;
                $chk++;
                try { if (Payments::checkGateway($po, 'recheck') === true) $paidN++; } catch (Throwable $e) { error_log('recheck_all: ' . $e->getMessage()); }
            }
            OmadaApi::$deadline = null;
            logActivity($uid, 'payment_recheck_all', $chk . ' checked, ' . $paidN . ' paid');
            back(safeReturn((string)($P['return'] ?? ''), '?page=transactions'), $paidN ? 'success' : 'info', h(sprintf(t('pay_recheck_all_done'), $chk, $paidN)));
        case 'order_cancel':
            $auth->requireSeller();
            run("UPDATE hs_orders SET status='cancelled' WHERE id=? AND seller_id=? AND status='pending'", 'ii', (int)$P['id'], $uid);
            back('?page=orders', 'success', t('saved'));
        // ----- Profile / settings -----
        case 'profile':
            try {
                run("UPDATE users SET full_name=?, email=?, phone=? WHERE id=?", 'sssi', trim($P['full_name']), trim($P['email']), normalizePhone($P['phone']), $uid);
                $_SESSION['full_name'] = trim($P['full_name']);
                back('?page=profile', 'success', t('saved'));
            } catch (mysqli_sql_exception $e) { back('?page=profile', 'danger', 'Email or phone already used.'); }
        case 'password':
            $u = $auth->user();
            if (!password_verify((string)$P['current'], $u['password'])) back('?page=profile', 'danger', t('wrong_password'));
            if (strlen((string)$P['new']) < 6) back('?page=profile', 'danger', t('password_min'));
            run("UPDATE users SET password=? WHERE id=?", 'si', password_hash((string)$P['new'], PASSWORD_DEFAULT), $uid);
            back('?page=profile', 'success', t('password_changed'));
        case 'prefs':
            run("UPDATE users SET sms_enabled=?, email_enabled=? WHERE id=?", 'iii', !empty($P['sms_enabled']) ? 1 : 0, !empty($P['email_enabled']) ? 1 : 0, $uid);
            back('?page=settings', 'success', t('saved'));
        case 'notif_read_all':
            Notify::readAll($uid);
            back('?page=notifications');
        // ----- Admin -----
        case 'admin_settings':
            $auth->requireAdmin();
            if (($P['form'] ?? '') === 'radius') {
                foreach (['radius_server_ip' => 'RADIUS Server IP', 'acct_server_ip' => 'Accounting Server IP'] as $k => $label) {
                    $ipv = trim((string)($P[$k] ?? ''));
                    if ($ipv !== '' && !filter_var($ipv, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) back('?page=radius', 'danger', h($label) . ': enter an IPv4 address such as 102.214.50.10 (Omada needs an IP, not a domain).');
                }
                if (array_key_exists('omada_default_inform', $P)) {   // v5.8 — Omada Inform URL used for every added router
                    $di = trim((string)$P['omada_default_inform']);
                    if ($di !== '' && !parseInformUrl($di)) back('?page=radius', 'danger', h(t('ctrl_inform_invalid')));
                    if ($di !== '' && (parseInformUrl($di)['cloud'] ?? false)) back('?page=radius', 'danger', h(t('ctrl_cloud_unsupported')));
                    setSetting('omada_default_inform', $di !== '' ? (string)parseInformUrl($di)['raw'] : '');
                }
                if (array_key_exists('omada_default_client_id', $P)) {   // v5.9 — platform Open API keys for the default controller
                    $dcid = substr(trim((string)$P['omada_default_client_id']), 0, 128);
                    $dsec = substr(trim((string)($P['omada_default_client_secret'] ?? '')), 0, 255);
                    if (!empty($P['omada_default_keys_remove'])) { setSetting('omada_default_client_id', ''); setSetting('omada_default_client_secret', ''); }
                    else {
                        if ($dcid !== '' && preg_match('/[^\x21-\x7E]/', $dcid . $dsec)) back('?page=radius', 'danger', h(t('ctrl_client_id') . ' / ' . t('ctrl_client_secret') . ': invalid characters'));
                        if ($dsec !== '' && $dcid === '') back('?page=radius', 'danger', h(t('ctrl_client_id') . ': ' . t('all_fields_required')));
                        if ($dcid !== '' && $dsec === '' && openSecret(getSetting('omada_default_client_secret')) === '') back('?page=radius', 'danger', h(t('ctrl_client_secret') . ': ' . t('all_fields_required')));
                        if ($dcid !== '') setSetting('omada_default_client_id', $dcid);
                        if ($dsec !== '') setSetting('omada_default_client_secret', sealSecret($dsec));
                    }
                    applyDefaultOmadaKeys(0);
                }
                foreach (['omada_site_region', 'omada_site_timezone'] as $k) if (array_key_exists($k, $P) && trim((string)$P[$k]) !== '') setSetting($k, substr(trim((string)$P[$k]), 0, 64));
                // v5.7.1 FIX: read the old values BEFORE saving anything, otherwise a new website URL was never noticed
                $before = [getSetting('radius_server_ip'), getSetting('acct_server_ip'), getSetting('dae_enabled', '1'), SITE_URL !== '' ? rtrim(SITE_URL, '/') : (getSetting('site_url') ?: appUrl())];
                if (array_key_exists('site_url', $P)) {
                    $su = rtrim(trim((string)$P['site_url']), '/');
                    if ($su !== '' && !preg_match('#^https?://[A-Za-z0-9.\-]+(:\d+)?(/[A-Za-z0-9._~\-/]*)?$#', $su)) back('?page=radius', 'danger', 'Website URL must look like https://wifi.example.co.tz');
                    setSetting('site_url', $su !== '' ? $su : detectedBaseUrl());
                }
                foreach (['radius_server_ip', 'acct_server_ip', 'radius_idle_timeout', 'radius_allowed_ips', 'radius_reply_lang'] as $k)
                    if (array_key_exists($k, $P)) setSetting($k, trim((string)$P[$k]));
                if (array_key_exists('controller_url', $P)) {
                    $cu = Device::normalizeOrigin((string)$P['controller_url']);
                    if (trim((string)$P['controller_url']) !== '' && $cu === '') back('?page=radius', 'danger', 'Controller URL must look like http://192.168.0.10:8088');
                    setSetting('controller_url', $cu);
                }
                setSetting('dae_enabled', !empty($P['dae_enabled']) ? '1' : '0');
                $after = [getSetting('radius_server_ip'), getSetting('acct_server_ip'), getSetting('dae_enabled', '1'), (SITE_URL !== '' ? rtrim(SITE_URL, '/') : (getSetting('site_url') ?: appUrl()))];
                $note = '';
                if ($before !== $after && $after[0] !== '') {
                    // v5.7: every Omada RADIUS profile / portal must follow the new server → mark them for a push and tell the sellers
                    setSetting('omada_push_since', (string)time());
                    setSetting('omada_push_needed', '1');
                    $n = 0;
                    foreach (rows("SELECT d.user_id, GROUP_CONCAT(d.device_name SEPARATOR ', ') names FROM hs_devices d LEFT JOIN hs_controllers c ON c.id=d.controller_id
                                   WHERE c.id IS NULL OR c.client_id IS NULL OR c.client_id='' GROUP BY d.user_id") as $r) {
                        Notify::add((int)$r['user_id'], t('radius_changed_title'), sprintf(t('radius_changed_msg'), $after[0], (string)$r['names']), 'warning', '?page=hotspot', 'network-wired');
                        $n++;
                    }
                    $note = '<br>' . h(t('push_needed')) . ($n ? ' ' . h(sprintf(t('push_manual_notified'), $n)) : '');
                }
                back('?page=radius', 'success', t('saved') . $note);
            }
            if (array_key_exists('sales_contact_phone', $P)) $P['sales_contact_phone'] = normalizePhone((string)$P['sales_contact_phone']);   // v6.3
            if (getSetting('sonic_collect_endpoint') !== '') setSetting('sonic_collect_endpoint', '');   // v6.7.3: fixed MIKEKA APP address, old value cleared
            foreach (['platform_commission_percent', 'voucher_length', 'min_withdrawal', 'sales_contact_phone'] as $k)
                if (array_key_exists($k, $P)) setSetting($k, trim((string)$P[$k]));
            if (($P['form'] ?? '') === 'platform') setSetting('allow_registration', !empty($P['allow_registration']) ? '1' : '0');
            // v6.6.1 — fixed HTTPS browserauth URL (empty = default OMADA_PORTAL_AUTH_URL)
            $baNote = '';
            if (array_key_exists('omada_portal_auth_url', $P)) {
                $raw = trim((string)$P['omada_portal_auth_url']);
                $norm = $raw === '' ? '' : normalizeBrowserAuthUrl($raw);
                if ($raw !== '' && $norm === '') back('?page=admin', 'danger', 'Omada browserauth URL is not valid — e.g. https://omada.skytanzania.co.tz/portal/radius/browserauth');
                setSetting('omada_portal_auth_url', $norm);
                $wn = browserAuthUrlWarning(omadaPortalAuthUrl());
                if ($wn !== '') $baNote .= '<br><span class="text-danger">browserauth: ' . h($wn) . '</span>';
                if (!empty($P['browserauth_test'])) { $bt = testBrowserAuthUrl(omadaPortalAuthUrl()); $baNote .= '<br>browserauth: <span class="text-' . ($bt['ok'] ? 'success' : 'danger') . '">' . h($bt['msg']) . '</span>'; }
            }
            // v6.6 — Sonic Pesa API key / secret saved in the database (sealed with APP_SECRET); empty field = keep the saved value
            $spNote = '';
            if (!empty($P['sonic_keys_remove'])) { setSetting('sonic_api_key', ''); setSetting('sonic_api_secret', ''); }
            else {
                foreach (['sonic_api_key' => 'sonic_api_key_in', 'sonic_api_secret' => 'sonic_api_secret_in'] as $k => $in) {
                    $v = trim((string)($P[$in] ?? ''));
                    if ($v === '') continue;
                    if (preg_match('/[^\x21-\x7E]/', $v) || strlen($v) > 200) back('?page=admin', 'danger', 'Sonic Pesa key: invalid characters — copy it again from your Sonic Pesa dashboard.');
                    setSetting($k, sealSecret($v));
                }
            }
            if (!empty($P['sonic_test'])) { $tst = Payments::testConnection(); $spNote = '<br>Sonic Pesa: ' . h($tst['msg']); }
            back('?page=admin', 'success', t('saved') . $spNote . $baNote);
        case 'admin_user_status':
            $auth->requireAdmin();
            $st = in_array($P['status'] ?? '', ['active', 'suspended'], true) ? $P['status'] : 'active';
            run("UPDATE users SET status=? WHERE id=? AND user_type<>'admin'", 'si', $st, (int)$P['id']);
            back('?page=admin', 'success', t('saved'));
        // ----- v5.7 Omada link engine -----
        case 'link_check':
        case 'link_fix':
            $auth->requireSeller();
            $did = (int)($P['id'] ?? 0);
            if (!Device::get($did, $uid)) back('?page=routers', 'danger', 'Not found');
            if ($act === 'link_fix') {
                try { $res = OmadaLink::repair($did, $uid); $rows = $res['checks']; }
                catch (Throwable $e) { error_log('link_fix: ' . $e->getMessage()); back('?page=hotspot&id=' . $did . '#health', 'danger', h($e->getMessage())); }
            } else $rows = OmadaLink::check($did, $uid);
            $cn = OmadaLink::counts($rows);
            logActivity($uid, $act, '#' . $did . ' ok ' . $cn['ok'] . ' warn ' . $cn['warn'] . ' fail ' . $cn['fail']);
            back('?page=hotspot&id=' . $did . '#health', $cn['fail'] ? 'warning' : 'success', $cn['fail'] ? h(sprintf(t('hl_problems'), $cn['fail'])) : h(t('hl_all_ok')));
        case 'routers_sync_all':
            $auth->requireSeller();
            [$done, $left] = OmadaLink::pushAll($uid, time() + 1);   // every router of this seller, set up before now
            back('?page=hotspot', $left ? 'warning' : 'success', h(sprintf(t('sync_all_done'), $done)) . ($left ? '<br>' . h(sprintf(t('sync_all_more'), $left)) : ''));
        case 'admin_push_all':
            $auth->requireAdmin();
            [$done, $left] = OmadaLink::pushAll(0, max(1, (int)getSetting('omada_push_since', (string)time())));
            if (!$left) setSetting('omada_push_needed', '0');
            back('?page=radius', $left ? 'warning' : 'success', h(sprintf(t('push_done'), $done)) . ($left ? '<br>' . h(sprintf(t('sync_all_more'), $left)) : ''));
        case 'ssid_create':
        case 'ssid_delete':
            $auth->requireSeller();
            $api = OmadaApi::load((int)($P['id'] ?? 0), $uid);
            $site = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['site'] ?? ''));
            $ret = '?page=controller&id=' . (int)($P['id'] ?? 0) . '&site=' . urlencode($site) . '#ssids';
            if (!$api || !OmadaApi::canApi($api->row()) || $site === '') back($ret, 'danger', h(t('prov_need_keys')));
            OmadaApi::$deadline = microtime(true) + workBudget(40);
            if ($act === 'ssid_delete') {
                $wid = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['wlan'] ?? ''));
                $sid = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['ssid'] ?? ''));
                $r = $api->deleteSsid($site, $wid, $sid);
                if ($r['ok']) run("UPDATE hs_devices SET omada_ssid_id=NULL WHERE user_id=? AND omada_ssid_id=?", 'is', $uid, $sid);
                logActivity($uid, 'omada_ssid_delete', $site . ' ' . $sid . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
                back($ret, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('ssid_deleted')) : h($r['msg']));
            }
            $name = trim((string)($P['name'] ?? ''));
            $name = function_exists('mb_strcut') ? mb_strcut($name, 0, 32, 'UTF-8') : substr($name, 0, 32);
            $psk = ($P['type'] ?? 'hotspot') === 'private' ? (string)($P['psk'] ?? '') : '';
            if ($name === '') back($ret, 'danger', h(t('all_fields_required')));
            if (($P['type'] ?? '') === 'private' && (strlen($psk) < 8 || strlen($psk) > 63 || preg_match('/[^\x20-\x7E]/', $psk))) back($ret, 'danger', h(t('ssid_pass_bad')));
            $band = in_array((int)($P['band'] ?? 3), [1, 2, 3], true) ? (int)$P['band'] : 3;
            $groups = $api->wlanGroups($site);
            $wlan = '';
            foreach ($groups as $g) if (!empty($g['primary'])) { $wlan = (string)$g['wlanId']; break; }
            if ($wlan === '' && $groups) $wlan = (string)($groups[0]['wlanId'] ?? '');
            if ($wlan === '') { $cg = $api->createWlanGroup($site, 'SkyTanza'); foreach ($api->wlanGroups($site) as $g) if (($g['name'] ?? '') === 'SkyTanza') $wlan = (string)$g['wlanId']; }
            if ($wlan === '') back($ret, 'danger', h($api->error ?: 'WLAN group not found'));
            foreach ($api->ssidList($site, $wlan) as $x) if ((string)($x['name'] ?? '') === $name) back($ret, 'warning', h(t('ssid_created') . ': ' . $name));
            $r = OmadaApi::firstOk(fn($b) => $api->createSsid($site, $wlan, $b), OmadaProvision::ssidBodies($name, $psk, $psk === '', $band));
            logActivity($uid, 'omada_ssid_create', $site . ' ' . $name . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
            back($ret, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('ssid_created') . ': ' . $name) : h($r['msg']));
        case 'admin_probe_api':
            $auth->requireAdmin();
            $pr = probeApiEndpoint(true);
            back('?page=radius#apiProbe', $pr['ok'] === true ? 'success' : ($pr['ok'] === false ? 'danger' : 'warning'),
                'Website API endpoint: ' . h(machineUrl()) . ($pr['redirects'] ? ' • redirects: ' . h(implode(' ; ', $pr['redirects'])) : '') . ($pr['msg'] !== '' ? ' • ' . h($pr['msg']) : ''));
        // ----- v6.0 Omada Manager (sites, EAP225, Omada vouchers) -----
        case 'om_site_create':
        case 'om_site_delete':
        case 'om_device_add':
        case 'om_device_rename':
        case 'om_device_forget':
        case 'om_vgroup_create':
        case 'om_vgroup_import':
        case 'om_vgroup_delete':
        case 'om_voucher_delete':
        case 'om_vsync':
            $auth->requireSeller();
            $omRet = safeReturn((string)($P['return'] ?? ''), '?page=omada_manager');
            if ($act === 'om_vsync') {
                [$g, $n, $err] = OmadaManager::syncAll($uid, 40);
                back($omRet, $err !== '' ? 'warning' : 'success', h(sprintf(t('om_vsync_done'), $g, $n)) . ($err !== '' ? '<br>' . h($err) : ''));
            }
            $omApi = OmadaManager::api((int)($P['c'] ?? 0), $uid);
            if (!$omApi) back($omRet, 'danger', h(t('om_no_api')));
            $omSite = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['site'] ?? ''));
            OmadaApi::$deadline = microtime(true) + workBudget(90);
            if ($act === 'om_site_create') {
                $r = OmadaManager::createSite($omApi, $uid, trim((string)($P['site_name'] ?? '')));
                logActivity($uid, 'omada_site_create', ($r['name'] ?? '') . ' → ' . ($r['ok'] ? $r['id'] : $r['msg']));
                back($r['ok'] ? '?page=omada_manager&c=' . $omApi->id() . '&site=' . urlencode($r['id']) : $omRet, $r['ok'] ? 'success' : 'danger',
                    h(($r['ok'] ? t('ctrl_site_created') . ': ' . $r['name'] : $r['msg'])));
            }
            if ($omSite === '' || !$omApi->siteAllowed($omSite)) back($omRet, 'danger', h(t('ctrl_site_not_yours')));
            switch ($act) {
                case 'om_site_delete':
                    $sn = '';
                    foreach ($omApi->sites() as $s) if ($s['id'] === $omSite) $sn = $s['name'];
                    if ($sn === '' || trim((string)($P['confirm_name'] ?? '')) !== $sn) back($omRet, 'danger', h(t('om_site_name_mismatch')));
                    $r = OmadaManager::deleteSite($omApi, $uid, $omSite);
                    logActivity($uid, 'omada_site_delete', $sn . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
                    back($r['ok'] ? '?page=omada_manager&c=' . $omApi->id() : $omRet, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('om_site_deleted') . ': ' . $sn) : h($r['msg']));
                case 'om_device_rename':
                    $nm = trim(substr(preg_replace('/[\x00-\x1F]/', '', (string)($P['name'] ?? '')), 0, 60));
                    if ($nm === '' || normMac((string)($P['mac'] ?? '')) === '') back($omRet, 'danger', h(t('all_fields_required')));
                    $r = OmadaManager::rename($omApi, $omSite, (string)$P['mac'], $nm);
                    back($omRet, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('om_renamed') . ': ' . $nm) : h($r['msg']));
                case 'om_device_forget':
                    $mac = normMac((string)($P['mac'] ?? ''));
                    if ($mac === '') back($omRet, 'danger', 'MAC');
                    $r = OmadaManager::forget($omApi, $omSite, $mac);
                    if ($r['ok']) run("UPDATE hs_devices SET omada_status='not_found', omada_status_at=NOW() WHERE user_id=? AND ap_mac=? AND controller_id=?", 'isi', $uid, $mac, $omApi->id());
                    logActivity($uid, 'omada_device_forget', $omSite . ' ' . $mac . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
                    back($omRet, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('om_dev_forgotten') . ': ' . dashMac($mac)) : h($r['msg']));
                case 'om_device_add':
                    $sn = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', (string)($P['sn'] ?? '')), 0, 32));
                    $mac = normMac((string)($P['mac'] ?? ''));
                    $nm = trim(substr((string)($P['name'] ?? ''), 0, 60)) ?: 'EAP225';
                    $du = trim((string)($P['dev_user'] ?? '')) ?: 'admin';
                    $dp = (string)($P['dev_pass'] ?? '') !== '' ? (string)$P['dev_pass'] : 'admin';
                    if ($sn === '' && $mac === '') back($omRet, 'danger', h(t('om_dev_need')));
                    $msgs = [];
                    if ($sn !== '') {
                        $r = $omApi->addBySerial($omSite, $sn, '', $nm, $du, $dp);
                        $msgs[] = $r['ok'] ? t('prov_dev_added') . ' • S/N ' . $sn : $r['msg'];
                        if (!$r['ok'] && ($mac === '' || empty($P['as_hotspot']))) back($omRet, 'danger', h($r['msg']));
                    }
                    if (empty($P['as_hotspot']) || $mac === '') {
                        if (!empty($P['as_hotspot']) && $mac === '') $msgs[] = t('om_dev_need_mac');
                        back($omRet, 'success', h(implode(' • ', $msgs)));
                    }
                    $sn2 = '';
                    foreach ($omApi->sites() as $s) if ($s['id'] === $omSite) $sn2 = $s['name'];
                    $ex = row("SELECT * FROM hs_devices WHERE ap_mac=?", 's', $mac);
                    if ($ex && (int)$ex['user_id'] !== $uid) back($omRet, 'danger', 'This AP MAC is already registered.');
                    if ($ex) {
                        run("UPDATE hs_devices SET controller_id=?, omada_site_id=?, site_name=IF(?<>'', ?, site_name), ssid=IF(?<>'', ?, ssid) WHERE id=?", 'isssssi',
                            $omApi->id(), $omSite, $sn2, $sn2, trim((string)($P['ssid'] ?? '')), trim((string)($P['ssid'] ?? '')), $ex['id']);
                        $did = (int)$ex['id'];
                    } else {
                        $sv = Device::save(['device_name' => $nm, 'ap_mac' => $mac, 'ssid' => trim((string)($P['ssid'] ?? '')), 'site_name' => $sn2 ?: 'Default',
                            'is_active' => 1, 'controller_id' => $omApi->id(), 'omada_site_id' => $omSite], $uid);
                        if (!$sv['success']) back($omRet, 'danger', h($sv['message']));
                        $did = (int)$sv['id'];
                        if ($m = RouterModels::byCode(RouterModels::DEFAULT_CODE)) RouterModels::assign($did, $m);
                        ProvisionLog::add($did, $uid, 'added', '', 'Omada Manager • ' . $nm);
                    }
                    if ($sn !== '') run("UPDATE hs_devices SET omada_sn=? WHERE id=?", 'si', $sn, $did);
                    OmadaProvision::saveDeviceCreds($did, $du, $dp);
                    if (!empty($P['run_setup'])) {
                        try { $res = OmadaProvision::run($did, $uid, ['site_mode' => $omSite, 'sn' => $sn, 'voucher_mode' => ($P['voucher_mode'] ?? '') === 'omada' ? 'omada' : 'radius', 'qty' => 0, 'pkg_id' => 0]); }
                        catch (Throwable $e) { error_log('om_device_add setup: ' . $e->getMessage()); back('?page=hotspot&id=' . $did . '#setup', 'warning', h($e->getMessage())); }
                        ProvisionLog::add($did, $uid, 'setup', (string)$res['state'], t('prov_state_' . $res['state']));
                        back('?page=hotspot&id=' . $did . '#setup', $res['ok'] ? 'success' : 'warning', h(implode(' • ', $msgs)) . ($msgs ? '<br>' : '') . h(t('prov_state_' . $res['state'])));
                    }
                    run("UPDATE hs_devices SET voucher_mode=? WHERE id=?", 'si', ($P['voucher_mode'] ?? '') === 'omada' ? 'omada' : 'radius', $did);
                    back('?page=hotspot&id=' . $did . '#setup', 'success', h(implode(' • ', array_merge($msgs, [t('router_saved')]))));
                case 'om_vgroup_create':
                    $pkg = row("SELECT * FROM hs_packages WHERE id=? AND seller_id=?", 'ii', (int)($P['package_id'] ?? 0), $uid);
                    if (!$pkg) back($omRet, 'danger', 'Package not found');
                    try { $r = OmadaManager::createGroup($omApi, $uid, $omSite, $pkg, max(1, min(500, (int)($P['quantity'] ?? 20)))); }
                    catch (Throwable $e) { error_log('om_vgroup_create: ' . $e->getMessage()); $r = ['ok' => false, 'msg' => $e->getMessage()]; }
                    logActivity($uid, 'omada_vouchers_create', $omSite . ' ' . $pkg['name'] . ' → ' . ($r['ok'] ? $r['batch'] : $r['msg']));
                    if (!$r['ok']) back($omRet, 'danger', h($r['msg']));
                    back($omRet . (!empty($r['group_id']) ? '&vgroup=' . urlencode($r['group_id']) : ''), 'success', h($r['msg']) . ' — <a href="?page=print&batch=' . urlencode($r['batch']) . '" target="_blank">' . t('print') . '</a>');
                case 'om_vgroup_import':
                    $gid = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['gid'] ?? ''));
                    $r = OmadaManager::importGroup($omApi, $uid, $omSite, $gid, (int)($P['package_id'] ?? 0));
                    back($omRet, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h($r['msg']) . ' — <a href="?page=print&batch=' . urlencode($r['batch']) . '" target="_blank">' . t('print') . '</a>' : h($r['msg']));
                case 'om_vgroup_delete':
                    $gid = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['gid'] ?? ''));
                    $r = OmadaManager::deleteGroup($omApi, $uid, $omSite, $gid);
                    logActivity($uid, 'omada_vouchers_delete', $omSite . ' ' . $gid . ' → ' . ($r['ok'] ? 'ok' : $r['msg']));
                    back(preg_replace('/&vgroup=[^&]*/', '', $omRet), $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('om_vg_deleted')) : h($r['msg']));
                case 'om_voucher_delete':
                    $vid = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($P['vid'] ?? ''));
                    $r = OmadaManager::deleteVoucher($omApi, $uid, $omSite, $vid, (string)($P['code'] ?? ''));
                    back($omRet, $r['ok'] ? 'success' : 'danger', $r['ok'] ? h(t('om_v_deleted') . ': ' . ($P['code'] ?? '')) : h($r['msg']));
            }
            back($omRet);
        case 'admin_sonic_push_test':
            $auth->requireAdmin();
            $tp = Payments::testPush((string)($P['phone'] ?? ''), (int)($P['amount'] ?? 1000));
            logActivity($uid, 'sonic_push_test', substr($tp['msg'], 0, 250));
            back('?page=admin', $tp['ok'] ? 'success' : 'danger', 'Sonic Pesa: ' . h($tp['msg']));
        case 'admin_sonic_test':
            $auth->requireAdmin();
            $tst = Payments::testConnection();
            back('?page=admin', $tst['ok'] ? 'success' : 'danger', 'Sonic Pesa: ' . h($tst['msg']));
        case 'admin_run_hk':
            $auth->requireAdmin();
            $r = Housekeeping::run(true);
            back('?page=radius', 'success', 'Housekeeping: ' . json_encode($r));
    }
}

// ============================================================
// LAYOUT
// ============================================================
$user = $auth->isLoggedIn() ? $auth->user() : null;
if ($auth->isLoggedIn() && (!$user || $user['status'] !== 'active')) { $auth->logout(); redirectTo('?page=login'); }
if ($page === '') redirectTo($auth->isLoggedIn() ? '?page=dashboard' : '?page=login');
$isAuthPage = in_array($page, ['login', 'register'], true);
if ($auth->isLoggedIn() && !$isAuthPage) {
    Housekeeping::maybe();
    // pin the public website URL the first time an admin uses the site (prevents Host-header spoofing later)
    if ($auth->isAdmin() && SITE_URL === '' && getSetting('site_url') === '' && detectedBaseUrl() !== '') setSetting('site_url', detectedBaseUrl());
    // keep this seller's Omada AP status fresh while they use the dashboard (throttled per controller)
    if (in_array($page, ['routers', 'hotspot', 'omada', 'controller'], true) && in_array($_SESSION['user_type'] ?? '', ['seller', 'admin'], true)) ensureDefaultController((int)$_SESSION['user_id']);   // v5.8
    if (in_array($page, ['dashboard', 'routers', 'hotspot', 'omada', 'controller'], true)) OmadaSync::maybe((int)$_SESSION['user_id']);
    if (in_array($page, ['dashboard', 'transactions', 'orders'], true)) { Payments::pollPending(5); PaymentOps::nudgeLate(3); }   // v6.4 / v6.5
    if (in_array($page, ['vouchers', 'omada_manager'], true) && in_array($_SESSION['user_type'] ?? '', ['seller', 'admin'], true)) OmadaManager::maybeSync((int)$_SESSION['user_id']);   // v6.0
}

$nav = [
    ['main_menu', [['dashboard', 'gauge-high']]],
    // v5.5 — "Routers" (add router: choose Omada EAP225 → router data) and "Hotspot" (provision & connect a router)
    ['network_menu', [['routers', 'tower-broadcast'], ['hotspot', 'wifi']]],   // v6.2: Omada Controller / Manager are admin-only
    ['wifi_menu', [['packages', 'box'], ['vouchers', 'ticket'], ['sessions', 'signal']]],
    ['money_menu', [['orders', 'cart-shopping'], ['transactions', 'receipt'], ['withdraw', 'money-bill-wave'], ['adjustments', 'clock-rotate-left']]],
    ['account_menu', [['profile', 'user'], ['settings', 'gear'], ['notifications', 'bell']]],
];
if ($auth->isAdmin()) $nav[] = ['admin_menu', [['admin', 'shield-halved'], ['all_routers', 'server'], ['controller', 'cloud'], ['omada_manager', 'sitemap'], ['radius', 'network-wired']]];
$navLabel = fn($k) => $k === 'admin' ? t('admin_panel') : ($k === 'radius' ? t('radius_setup') : ($k === 'omada' ? t('omada_setup') : ($k === 'controller' ? t('omada_controller') : t($k))));
$navPage = $page === 'omada' ? 'hotspot' : $page;
/** One copyable Omada field: label, value, copy button (and eye toggle for passwords). */
function cfgRow(string $label, string $value, string $hint = '', bool $secret = false): string {
    static $n = 0;
    $id = 'cf' . (++$n);
    $empty = $value === '';
    return '<div class="cfg-row"><div class="cfg-l">' . h($label) . ($hint !== '' ? '<div class="cfg-h">' . h($hint) . '</div>' : '') . '</div><div>'
        . '<div class="input-group input-group-sm"><input id="' . $id . '" class="form-control mono' . ($empty ? ' is-invalid' : '') . '" type="' . ($secret ? 'password' : 'text')
        . '" value="' . h($value) . '" placeholder="' . h($empty ? t('not_set') : '') . '" readonly onclick="this.select()">'
        . ($secret ? '<button type="button" class="btn btn-outline-secondary" onclick="tg(\'' . $id . '\')" aria-label="Show"><i class="fa-solid fa-eye"></i></button>' : '')
        . '<button type="button" class="btn btn-outline-primary" onclick="cp(\'' . $id . '\',this)" aria-label="' . h(t('copy')) . '"><i class="fa-regular fa-copy"></i></button></div></div></div>';
}
/** A switch / choice to set in Omada (nothing to copy). */
function cfgFixed(string $label, string $value, string $hint = ''): string {
    return '<div class="cfg-row"><div class="cfg-l">' . h($label) . ($hint !== '' ? '<div class="cfg-h">' . h($hint) . '</div>' : '') . '</div>'
        . '<div><span class="badge text-bg-primary bg-opacity-25 text-primary-emphasis border border-primary-subtle px-2 py-2 fw-semibold text-wrap">' . h($value) . '</span></div></div>';
}
/** v5.6 — table of live Omada clients with Block / Unblock / Reconnect (controller page + hotspot page). */
function omadaClientTable(array $clients, int $ctrlId, string $site, string $ret, int $uid): string {
    if (!$clients) return '<p class="text-secondary mb-0">' . h(t('omada_no_clients')) . '</p>';
    $codes = [];
    foreach (rows("SELECT s.mac, v.code FROM hs_sessions s LEFT JOIN hs_vouchers v ON v.id=s.voucher_id WHERE s.seller_id=? AND s.status='active'", 'i', $uid) as $r) if ($r['mac']) $codes[$r['mac']] = (string)$r['code'];
    $blocked = array_flip(array_column(rows("SELECT mac FROM hs_blocked_macs WHERE seller_id=?", 'i', $uid), 'mac'));
    $o = '<div class="table-responsive"><table class="table table-sm table-hover mcard align-middle mb-0"><thead><tr><th>' . h(t('omada_client')) . '</th><th>' . h(t('omada_ap')) . '</th><th>SSID</th><th>'
       . h(t('omada_traffic')) . '</th><th>' . h(t('omada_uptime')) . '</th><th>' . h(t('code')) . '</th><th></th></tr></thead><tbody>';
    $btn = function (string $cmd, string $mac, string $cls, string $icon, string $label, bool $confirm = false) use ($ctrlId, $site, $ret): string {
        return '<form method="POST" class="d-inline"' . ($confirm ? ' onsubmit="return confirm(\'' . h($label) . ' ' . h(dashMac($mac)) . '?\')"' : '') . '>' . csrf_field()
            . '<input type="hidden" name="act" value="omada_client_cmd"><input type="hidden" name="id" value="' . $ctrlId . '"><input type="hidden" name="site" value="' . h($site) . '">'
            . '<input type="hidden" name="mac" value="' . h($mac) . '"><input type="hidden" name="cmd" value="' . $cmd . '"><input type="hidden" name="return" value="' . h($ret) . '">'
            . '<button class="btn btn-sm btn-outline-' . $cls . '" title="' . h($label) . '"><i class="fa-solid fa-' . $icon . '"></i></button></form> ';
    };
    foreach ($clients as $c) {
        $isBlocked = $c['blocked'] || isset($blocked[$c['mac']]);
        $o .= '<tr><td data-label="' . h(t('omada_client')) . '"><b class="text-body-emphasis">' . h($c['name'] ?: '—') . '</b><div class="small text-secondary mono">' . h(dashMac($c['mac'])) . ($c['ip'] !== '' ? ' • ' . h($c['ip']) : '') . '</div></td>'
            . '<td data-label="' . h(t('omada_ap')) . '" class="small">' . h($c['ap_name'] ?: ($c['ap_mac'] ? dashMac($c['ap_mac']) : '—')) . '</td>'
            . '<td data-label="SSID" class="small">' . h($c['ssid'] ?: '—') . ($c['auth'] !== '' ? ' <span class="badge text-bg-' . ($c['auth'] === 'authorized' ? 'success' : 'secondary') . '">' . h($c['auth']) . '</span>' : '') . '</td>'
            . '<td data-label="' . h(t('omada_traffic')) . '" class="small"><i class="fa-solid fa-arrow-down text-success"></i> ' . fmtBytes($c['down']) . ' <i class="fa-solid fa-arrow-up text-info"></i> ' . fmtBytes($c['up']) . '</td>'
            . '<td data-label="' . h(t('omada_uptime')) . '" class="small">' . ($c['uptime'] > 0 ? fmtSecs($c['uptime']) : '—') . '</td>'
            . '<td data-label="' . h(t('code')) . '" class="mono">' . h($codes[$c['mac']] ?? '—') . '</td><td class="text-nowrap">'
            . $btn('reconnect', $c['mac'], 'info', 'rotate', t('omada_reconnect'))
            . ($isBlocked ? $btn('unblock', $c['mac'], 'success', 'unlock', t('omada_unblock')) : $btn('block', $c['mac'], 'danger', 'ban', t('omada_block'), true))
            . '</td></tr>';
    }
    return $o . '</tbody></table></div>';
}
function renderNav(array $nav, string $page, callable $label): string {
    $o = '';
    foreach ($nav as [$sec, $items]) {
        $o .= '<div class="nav-title">' . h(t($sec)) . '</div>';
        foreach ($items as [$k, $icon]) $o .= '<a class="nav-link' . ($page === $k ? ' active' : '') . '" href="?page=' . $k . '"' . ($page === $k ? ' aria-current="page"' : '') . '><i class="fa-solid fa-' . $icon . ' fa-fw"></i><span>' . h($label($k)) . '</span></a>';
    }
    return $o;
}
$unread = $user ? Notify::unread((int)$user['id']) : 0;
$flashes = $_SESSION['flash'] ?? []; unset($_SESSION['flash']);
$inApp = $user && !$isAuthPage;
$flashIcon = ['success' => 'circle-check', 'danger' => 'circle-exclamation', 'warning' => 'triangle-exclamation', 'info' => 'circle-info'];
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
?>
<!DOCTYPE html>
<html lang="<?= h($currentLang) ?>" data-bs-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#060a13">
<meta name="color-scheme" content="dark light">
<meta name="description" content="<?= h(SITE_NAME) ?> — <?= h(t('app_title')) ?> • Omada EAP225 + RADIUS">
<script>(function(){try{var t=localStorage.getItem('sky_theme');if(t==='light'||t==='dark'){document.documentElement.setAttribute('data-bs-theme',t);var m=document.querySelector('meta[name=theme-color]');if(m)m.content=t==='light'?'#f3f5fa':'#060a13'}}catch(e){}})();</script>
<link rel="manifest" href="?pwa=manifest">
<link rel="icon" href="?pwa=icon" type="image/svg+xml">
<link rel="apple-touch-icon" href="?pwa=icon">
<title><?= h(SITE_NAME) ?> — <?= h($navLabel($page)) ?></title>
<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" media="print" onload="this.media='all'">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"></noscript>
<style>
/* ===================== SkyTanza design system v5.2 ===================== */
:root{--sb:268px;--r:12px;--r-lg:18px;--ease:cubic-bezier(.2,.8,.2,1);
 --ff:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
 --mono:'JetBrains Mono',ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
[data-bs-theme=dark]{
 --bg:#060a13;--glow1:rgba(79,124,255,.15);--glow2:rgba(139,92,246,.10);
 --surface:#0c1320;--surface-2:#101828;--surface-3:#162036;--line:#19243a;--line-2:#25324d;
 --text:#c4cfe0;--heading:#f4f7fc;--muted:#7d8ba3;--brand:#5b8cff;--brand-2:#8b5cf6;--brand-soft:rgba(91,140,255,.14);
 --ok:#22c55e;--warn:#f59e0b;--bad:#ef4444;--info:#22d3ee;--side:#080d18;--topbar:rgba(6,10,19,.74);--input:#09101c;
 --shadow:0 1px 0 rgba(255,255,255,.035) inset,0 12px 32px -18px rgba(0,0,0,.75);--shadow-lg:0 24px 60px -24px rgba(0,0,0,.85);
 --bs-body-bg:var(--bg);--bs-body-color:var(--text);--bs-emphasis-color:var(--heading);--bs-heading-color:var(--heading);
 --bs-secondary-color:var(--muted);--bs-secondary-rgb:125,139,163;--bs-border-color:var(--line);--bs-border-color-translucent:var(--line);
 --bs-secondary-border-subtle:var(--line);--bs-tertiary-bg:var(--surface-2);--bs-secondary-bg:var(--surface-2);
 --bs-link-color:#7fa4ff;--bs-link-color-rgb:127,164,255;--bs-link-hover-color:#a9c2ff;--bs-link-hover-color-rgb:169,194,255}
[data-bs-theme=light]{
 --bg:#f3f5fa;--glow1:rgba(61,109,245,.09);--glow2:rgba(124,58,237,.06);
 --surface:#ffffff;--surface-2:#f7f9fc;--surface-3:#eef2f8;--line:#e4e9f2;--line-2:#d5ddea;
 --text:#3a4658;--heading:#0e1726;--muted:#6a778c;--brand:#3d6df5;--brand-2:#7c3aed;--brand-soft:rgba(61,109,245,.10);
 --ok:#16a34a;--warn:#d97706;--bad:#dc2626;--info:#0891b2;--side:#ffffff;--topbar:rgba(255,255,255,.8);--input:#ffffff;
 --shadow:0 1px 2px rgba(16,24,40,.04),0 10px 26px -16px rgba(16,24,40,.16);--shadow-lg:0 24px 56px -26px rgba(16,24,40,.3);
 --bs-body-bg:var(--bg);--bs-body-color:var(--text);--bs-emphasis-color:var(--heading);--bs-heading-color:var(--heading);
 --bs-secondary-color:var(--muted);--bs-secondary-rgb:106,119,140;--bs-border-color:var(--line);--bs-border-color-translucent:var(--line);
 --bs-secondary-border-subtle:var(--line);--bs-tertiary-bg:var(--surface-2);--bs-secondary-bg:var(--surface-2);
 --bs-link-color:#3d6df5;--bs-link-color-rgb:61,109,245;--bs-link-hover-color:#2a52d1;--bs-link-hover-color-rgb:42,82,209}

/* base */
html{-webkit-text-size-adjust:100%}
body{font-family:var(--ff);font-size:.92rem;line-height:1.55;background:var(--bg);min-height:100vh;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;
 background-image:radial-gradient(900px 520px at 100% -10%,var(--glow1),transparent 60%),radial-gradient(760px 460px at -10% 110%,var(--glow2),transparent 60%);background-attachment:fixed}
h1,h2,h3,h4,h5,h6{color:var(--heading);font-weight:700;letter-spacing:-.022em}
a{text-decoration:none}a:hover{text-decoration:underline;text-underline-offset:3px}
.btn:hover,.nav-link:hover,.bottom-nav a:hover,.icon-btn:hover,.brand:hover,.notif-item:hover,.side-logout:hover{text-decoration:none}
::selection{background:var(--brand);color:#fff}
:focus-visible{outline:2px solid var(--brand);outline-offset:2px}
.min-w-0{min-width:0}
.mono{font-family:var(--mono);letter-spacing:.04em;font-size:.92em;font-variant-numeric:tabular-nums}
code{color:var(--brand);background:var(--brand-soft);padding:.12rem .4rem;border-radius:6px;font-family:var(--mono);font-size:.85em}
.text-secondary{color:var(--muted)!important}
.text-body-emphasis{color:var(--heading)!important}
*{scrollbar-width:thin;scrollbar-color:var(--line-2) transparent}
::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--line-2);border-radius:10px;border:3px solid transparent;background-clip:content-box}

/* sidebar */
.sidebar{position:fixed;inset:0 auto 0 0;width:var(--sb);background:var(--side);border-right:1px solid var(--line);z-index:1030;display:flex;flex-direction:column;overflow-y:auto}
.brand{display:flex;align-items:center;gap:.75rem;padding:1.2rem 1.25rem 1rem;color:var(--heading);font-weight:800;letter-spacing:-.02em;font-size:1.04rem;line-height:1.15}
.brand small{display:block;font-size:.64rem;font-weight:700;color:var(--muted);letter-spacing:.09em;text-transform:uppercase;margin-top:3px}
.brand-logo{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;flex-shrink:0;color:#fff;background:linear-gradient(135deg,var(--brand),var(--brand-2));box-shadow:0 10px 22px -8px var(--brand)}
.side-user{margin:.2rem .9rem .6rem;padding:.7rem .75rem;border:1px solid var(--line);border-radius:14px;background:var(--surface-2);display:flex;align-items:center;gap:.7rem}
.avatar{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;font-weight:800;color:#fff;flex-shrink:0;background:linear-gradient(135deg,#06b6d4,var(--brand))}
.side-name{font-weight:650;font-weight:600;color:var(--heading);font-size:.87rem;line-height:1.2}
.side-bal{font-size:.77rem;color:var(--ok);font-weight:700;font-variant-numeric:tabular-nums}
.nav-title{font-size:.64rem;letter-spacing:.13em;text-transform:uppercase;color:var(--muted);padding:1.05rem 1.45rem .4rem;font-weight:700;opacity:.85}
.nav-side .nav-link{display:flex;align-items:center;gap:.75rem;color:var(--muted);margin:1px .75rem;padding:.56rem .8rem;border-radius:10px;font-size:.885rem;font-weight:500;position:relative;transition:background .15s,color .15s}
.nav-side .nav-link i{width:18px;text-align:center;opacity:.9;transition:color .15s}
.nav-side .nav-link:hover{color:var(--heading);background:var(--surface-3)}
.nav-side .nav-link.active{color:var(--heading);background:var(--brand-soft);font-weight:600}
.nav-side .nav-link.active i{color:var(--brand)}
.nav-side .nav-link.active::before{content:"";position:absolute;left:-.75rem;top:22%;bottom:22%;width:3px;border-radius:0 3px 3px 0;background:linear-gradient(var(--brand),var(--brand-2))}
.side-foot{padding:.8rem .9rem;border-top:1px solid var(--line)}
.side-logout{display:flex;align-items:center;gap:.65rem;padding:.55rem .8rem;border-radius:10px;color:var(--bad);font-weight:600;font-size:.87rem;transition:background .15s}
.side-logout:hover{background:rgba(239,68,68,.1);color:var(--bad)}
.offcanvas.sidebar-oc{--bs-offcanvas-bg:var(--side);--bs-offcanvas-width:288px;border-right:1px solid var(--line)}
.offcanvas.sidebar-oc .offcanvas-header{border-bottom:1px solid var(--line)}

/* main + topbar */
.main{margin-left:var(--sb);min-height:100vh;display:flex;flex-direction:column}
.topbar{position:sticky;top:0;z-index:1020;height:66px;padding:0 1.6rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;background:var(--topbar);-webkit-backdrop-filter:saturate(180%) blur(14px);backdrop-filter:saturate(180%) blur(14px);border-bottom:1px solid var(--line)}
.crumb{font-size:.66rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.1em;line-height:1}
.page-title{font-size:1.12rem;margin:.28rem 0 0;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.icon-btn{height:38px;min-width:38px;padding:0 .65rem;display:inline-grid;place-items:center;border-radius:11px;border:1px solid var(--line);background:var(--surface);color:var(--text);font-weight:800;font-size:.74rem;letter-spacing:.04em;position:relative;cursor:pointer;transition:background .15s,border-color .15s,color .15s}
.icon-btn:hover{border-color:var(--line-2);color:var(--heading);background:var(--surface-2)}
.nbadge{position:absolute;top:-6px;right:-6px;min-width:19px;height:19px;padding:0 5px;border-radius:10px;background:var(--bad);color:#fff;font-size:.62rem;font-weight:800;display:grid;place-items:center;border:2px solid var(--bg)}
.content{padding:1.6rem;width:100%;max-width:1580px;margin:0 auto;animation:fadeUp .35s var(--ease) both}
@keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}

/* cards */
.card{--bs-card-bg:var(--surface);--bs-card-border-color:var(--line);--bs-card-cap-bg:transparent;--bs-card-border-radius:var(--r-lg);--bs-card-inner-border-radius:calc(var(--r-lg) - 1px);--bs-card-color:var(--text);
 background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--shadow)}
.card-header{background:transparent;border-bottom:1px solid var(--line);padding:.95rem 1.15rem;font-weight:600;color:var(--heading);font-size:.9rem;letter-spacing:-.005em}
.card-header>i:first-child,.card-header>span>i:first-child{color:var(--brand)}
.card-body{padding:1.15rem}
.stat{border:0!important;color:#fff;position:relative;overflow:hidden;isolation:isolate;min-height:108px;box-shadow:var(--shadow-lg)!important;transition:transform .2s var(--ease)}
.stat:hover{transform:translateY(-2px)}
.stat::after{content:"";position:absolute;width:160px;height:160px;border-radius:50%;right:-55px;top:-70px;background:rgba(255,255,255,.14);z-index:-1}
.stat::before{content:"";position:absolute;width:96px;height:96px;border-radius:50%;right:34px;bottom:-60px;background:rgba(255,255,255,.08);z-index:-1}
.stat h6{opacity:.88;font-size:.68rem;text-transform:uppercase;letter-spacing:.1em;font-weight:700;color:#fff;margin-bottom:.55rem}
.stat h4{color:#fff;font-size:1.6rem;letter-spacing:-.025em;font-variant-numeric:tabular-nums}
.card.s1{background:linear-gradient(135deg,#3b6cf6 0%,#7c3aed 100%)}
.card.s2{background:linear-gradient(135deg,#047857 0%,#22c55e 100%)}
.card.s3{background:linear-gradient(135deg,#0369a1 0%,#06b6d4 100%)}
.card.s4{background:linear-gradient(135deg,#c2410c 0%,#f59e0b 100%)}
.card.s5{background:linear-gradient(135deg,#be123c 0%,#f43f5e 100%)}
.card.s6{background:linear-gradient(135deg,#4338ca 0%,#0ea5e9 100%)}
.earn-sub{font-size:.72rem;opacity:.85;margin-top:.25rem;font-variant-numeric:tabular-nums}

/* tables */
.table{--bs-table-bg:transparent;--bs-table-color:var(--text);--bs-table-border-color:var(--line);--bs-table-hover-bg:var(--surface-2);--bs-table-hover-color:var(--heading);--bs-table-striped-bg:var(--surface-2);margin-bottom:0;font-variant-numeric:tabular-nums}
.table thead th{font-size:.67rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);font-weight:700;white-space:nowrap;border-bottom:1px solid var(--line)}
.table>:not(caption)>*>*{background:transparent;padding:.7rem .65rem;border-bottom-color:var(--line)}
.table-sm>:not(caption)>*>*{padding:.5rem .55rem}
.table tbody tr:last-child>*{border-bottom:0}
.table-responsive{scrollbar-gutter:stable}

/* forms */
.form-control,.form-select{background-color:var(--input);border:1px solid var(--line-2);color:var(--heading);border-radius:11px;padding:.6rem .85rem;font-size:.9rem;transition:border-color .15s,box-shadow .15s}
.form-control-sm,.form-select-sm{padding:.4rem .7rem;font-size:.82rem;border-radius:9px}
.form-control:focus,.form-select:focus{background-color:var(--input);border-color:var(--brand);box-shadow:0 0 0 4px var(--brand-soft);color:var(--heading)}
.form-control::placeholder{color:var(--muted);opacity:.65}
.form-control:disabled,.form-control[readonly]{background-color:var(--surface-2)}
.form-control.is-invalid{border-color:var(--bad)}
.form-label{font-weight:600;color:var(--text);margin-bottom:.35rem;font-size:.82rem}
.form-label.small{font-size:.78rem}
.form-text{color:var(--muted);font-size:.74rem;margin-top:.3rem}
.form-check-input{background-color:var(--input);border-color:var(--line-2)}
.form-check-input:checked{background-color:var(--brand);border-color:var(--brand)}
.form-check-input:focus{box-shadow:0 0 0 4px var(--brand-soft);border-color:var(--brand)}
.form-switch .form-check-input{width:2.4em;height:1.3em;margin-top:.12em}
.input-group-text{background:var(--surface-2);border-color:var(--line-2);color:var(--muted)}

/* buttons */
.btn{--bs-btn-font-weight:600;--bs-btn-border-radius:11px;--bs-btn-padding-y:.55rem;--bs-btn-padding-x:1rem;--bs-btn-font-size:.87rem;--bs-btn-focus-box-shadow:0 0 0 4px var(--brand-soft);transition:transform .12s var(--ease),box-shadow .15s,background-color .15s,border-color .15s,color .15s,filter .15s}
.btn-sm{--bs-btn-padding-y:.34rem;--bs-btn-padding-x:.68rem;--bs-btn-font-size:.79rem;--bs-btn-border-radius:9px}
.btn:active{transform:translateY(1px)}
.btn-primary{--bs-btn-color:#fff;--bs-btn-bg:var(--brand);--bs-btn-border-color:transparent;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:var(--brand);--bs-btn-hover-border-color:transparent;--bs-btn-active-color:#fff;--bs-btn-active-bg:var(--brand);--bs-btn-active-border-color:transparent;--bs-btn-disabled-bg:var(--brand);--bs-btn-disabled-border-color:transparent;
 background-image:linear-gradient(135deg,var(--brand),var(--brand-2));box-shadow:0 10px 22px -12px var(--brand)}
.btn-primary:hover{filter:brightness(1.08);box-shadow:0 14px 28px -12px var(--brand)}
.btn-success{--bs-btn-color:#fff;--bs-btn-bg:#16a34a;--bs-btn-border-color:transparent;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#16a34a;--bs-btn-hover-border-color:transparent;--bs-btn-active-bg:#15803d;--bs-btn-active-border-color:transparent;
 background-image:linear-gradient(135deg,#15803d,#22c55e);box-shadow:0 10px 22px -12px #16a34a}
.btn-success:hover{filter:brightness(1.08)}
.btn-warning{--bs-btn-color:#1f1300;--bs-btn-bg:#f59e0b;--bs-btn-border-color:transparent;--bs-btn-hover-bg:#fbbf24;--bs-btn-hover-border-color:transparent;--bs-btn-hover-color:#1f1300}
.btn-outline-primary{--bs-btn-color:var(--brand);--bs-btn-border-color:var(--line-2);--bs-btn-hover-color:var(--brand);--bs-btn-hover-bg:var(--brand-soft);--bs-btn-hover-border-color:var(--brand);--bs-btn-active-color:#fff;--bs-btn-active-bg:var(--brand);--bs-btn-active-border-color:var(--brand)}
.btn-outline-secondary{--bs-btn-color:var(--text);--bs-btn-border-color:var(--line-2);--bs-btn-hover-color:var(--heading);--bs-btn-hover-bg:var(--surface-3);--bs-btn-hover-border-color:var(--line-2);--bs-btn-active-color:var(--heading);--bs-btn-active-bg:var(--surface-3);--bs-btn-active-border-color:var(--line-2)}
.btn-outline-success,.btn-outline-danger,.btn-outline-warning,.btn-outline-info{--bs-btn-border-color:var(--line-2)}
.btn-outline-success{--bs-btn-color:var(--ok);--bs-btn-hover-bg:rgba(34,197,94,.12);--bs-btn-hover-color:var(--ok);--bs-btn-hover-border-color:var(--ok)}
.btn-outline-danger{--bs-btn-color:var(--bad);--bs-btn-hover-bg:rgba(239,68,68,.12);--bs-btn-hover-color:var(--bad);--bs-btn-hover-border-color:var(--bad)}
.btn-outline-warning{--bs-btn-color:var(--warn);--bs-btn-hover-bg:rgba(245,158,11,.12);--bs-btn-hover-color:var(--warn);--bs-btn-hover-border-color:var(--warn)}
.btn-outline-info{--bs-btn-color:var(--info);--bs-btn-hover-bg:rgba(34,211,238,.12);--bs-btn-hover-color:var(--info);--bs-btn-hover-border-color:var(--info)}
.btn-link{--bs-btn-color:var(--brand)}

/* badges (soft) */
.badge{font-weight:600;letter-spacing:.02em;border-radius:8px;padding:.4em .65em;font-size:.72em}
.text-bg-success{background-color:rgba(34,197,94,.14)!important;color:var(--ok)!important;box-shadow:inset 0 0 0 1px rgba(34,197,94,.3)}
.text-bg-danger{background-color:rgba(239,68,68,.14)!important;color:var(--bad)!important;box-shadow:inset 0 0 0 1px rgba(239,68,68,.3)}
.text-bg-warning{background-color:rgba(245,158,11,.15)!important;color:var(--warn)!important;box-shadow:inset 0 0 0 1px rgba(245,158,11,.3)}
.text-bg-info{background-color:rgba(34,211,238,.13)!important;color:var(--info)!important;box-shadow:inset 0 0 0 1px rgba(34,211,238,.3)}
.text-bg-primary{background-color:var(--brand-soft)!important;color:var(--brand)!important;box-shadow:inset 0 0 0 1px rgba(91,140,255,.3)}
.text-bg-secondary{background-color:rgba(125,139,163,.14)!important;color:var(--muted)!important;box-shadow:inset 0 0 0 1px rgba(125,139,163,.25)}
.text-bg-dark{background-color:var(--surface-2)!important;color:var(--heading)!important;box-shadow:inset 0 0 0 1px var(--line-2)}
.badge.border{border:0!important}
.bg-danger.badge{background:var(--bad)!important}

/* alerts */
.alert{border-radius:14px;border:1px solid;border-left-width:4px;font-size:.87rem;padding:.85rem 1rem;color:var(--heading);box-shadow:var(--shadow)}
.alert a{font-weight:600}
.alert-success{--bs-alert-bg:rgba(34,197,94,.08);--bs-alert-border-color:rgba(34,197,94,.28);border-left-color:var(--ok);--bs-alert-color:var(--heading)}
.alert-danger{--bs-alert-bg:rgba(239,68,68,.08);--bs-alert-border-color:rgba(239,68,68,.28);border-left-color:var(--bad);--bs-alert-color:var(--heading)}
.alert-warning{--bs-alert-bg:rgba(245,158,11,.08);--bs-alert-border-color:rgba(245,158,11,.28);border-left-color:var(--warn);--bs-alert-color:var(--heading)}
.alert-info,.alert-primary{--bs-alert-bg:var(--brand-soft);--bs-alert-border-color:rgba(91,140,255,.28);border-left-color:var(--brand);--bs-alert-color:var(--heading)}
.alert .flash-ic{margin-right:.5rem;opacity:.9}
.alert-success .flash-ic{color:var(--ok)}.alert-danger .flash-ic{color:var(--bad)}.alert-warning .flash-ic{color:var(--warn)}.alert-info .flash-ic{color:var(--brand)}

/* status dots */
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:7px;vertical-align:middle;flex-shrink:0}
.dot.on{background:var(--ok);animation:pulse 2.2s infinite}
.dot.off{background:var(--bad);box-shadow:0 0 0 3px rgba(239,68,68,.15)}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(34,197,94,.55)}70%{box-shadow:0 0 0 7px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}

/* omada config sheet */
.cfg{border:1px solid var(--line);border-radius:14px;overflow:hidden;background:var(--surface-2)}
.cfg-row{display:grid;grid-template-columns:minmax(150px,40%) 1fr;gap:.75rem;align-items:center;padding:.62rem .9rem;border-bottom:1px solid var(--line)}
.cfg-row:last-child{border-bottom:0}
.cfg-l{font-size:.84rem;color:var(--heading);font-weight:600}.cfg-h{font-size:.71rem;color:var(--muted);font-weight:400;margin-top:2px}
.cfg-path{font-size:.75rem;color:var(--brand);background:var(--brand-soft);border:1px solid rgba(91,140,255,.25);border-radius:10px;padding:.4rem .7rem;display:inline-flex;align-items:center;gap:.25rem;margin-bottom:.8rem;font-weight:600}
.step-n{display:inline-grid;place-items:center;width:26px;height:26px;border-radius:8px;background:linear-gradient(135deg,var(--brand),var(--brand-2));color:#fff;font-weight:800;font-size:.78rem;margin-right:.6rem;flex-shrink:0;box-shadow:0 6px 14px -6px var(--brand)}
.kit{background:#05080f;color:#c9d6ea;border:1px solid var(--line);border-radius:12px;padding:.9rem 1rem;font-family:var(--mono);font-size:.75rem;line-height:1.6;white-space:pre;margin:0;max-height:340px;overflow:auto}

/* notifications */
.notif-item{display:flex;gap:.9rem;padding:1rem 1.15rem;border-bottom:1px solid var(--line);transition:background .15s}
.notif-item:hover{background:var(--surface-2)}
.notif-item:last-child{border-bottom:0}
.notif-ic{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;flex-shrink:0;background:var(--brand-soft);color:var(--brand)}
.notif-item.unread .notif-ic{background:linear-gradient(135deg,var(--brand),var(--brand-2));color:#fff}

/* auth pages */
body.auth .content{max-width:none;min-height:100vh;display:flex;flex-direction:column;justify-content:center}
body.auth .card{border-radius:22px;box-shadow:var(--shadow-lg)}
.auth-logo{width:66px;height:66px;margin:0 auto;border-radius:20px;display:grid;place-items:center;font-size:1.7rem;color:#fff;background:linear-gradient(135deg,var(--brand),var(--brand-2));box-shadow:0 18px 38px -14px var(--brand)}
.auth-theme{position:fixed;top:14px;right:14px;z-index:10}

/* bottom nav + mobile */
.bottom-nav{display:none}
@media(max-width:991.98px){
 .sidebar{display:none}.main{margin-left:0}.content{padding:1rem}.topbar{padding:0 1rem;height:60px}
 body.app{padding-bottom:calc(84px + env(safe-area-inset-bottom))}
 .bottom-nav{display:flex;position:fixed;left:10px;right:10px;bottom:calc(8px + env(safe-area-inset-bottom));z-index:1030;height:64px;padding:5px;gap:2px;background:var(--topbar);-webkit-backdrop-filter:blur(16px) saturate(180%);backdrop-filter:blur(16px) saturate(180%);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow-lg)}
 .bottom-nav a{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;color:var(--muted);font-size:.6rem;font-weight:700;border-radius:15px;transition:background .15s,color .15s;min-width:0}
 .bottom-nav a span{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 2px}
 .bottom-nav a i{font-size:1.08rem}
 .bottom-nav a.active{color:var(--brand);background:var(--brand-soft)}
}
@media(max-width:767.98px){
 table.mcard thead{display:none}
 table.mcard tr{display:block;margin-bottom:10px;padding:10px 12px;border:1px solid var(--line);border-radius:14px;background:var(--surface-2)}
 table.mcard td{display:flex;justify-content:space-between;gap:.75rem;border:0!important;padding:4px 0!important;text-align:right}
 table.mcard td::before{content:attr(data-label);color:var(--muted);font-weight:600;font-size:.76rem;text-align:left;flex-shrink:0}
 table.mcard td:not([data-label])::before{content:none}
 table.mcard td:not([data-label]){justify-content:flex-end;padding-top:8px!important}
}
@media(max-width:575.98px){.cfg-row{grid-template-columns:1fr;gap:.3rem}.stat h4{font-size:1.25rem}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
@media print{
 .sidebar,.topbar,.bottom-nav,.no-print,.btn,.auth-theme{display:none!important}
 .main{margin-left:0}body{background:#fff!important;color:#000}
 .card,.cfg{background:#fff!important;border-color:#999!important;box-shadow:none!important}
 .cfg-l,.cfg-h,h4{color:#000!important}input.form-control{color:#000!important;background:#fff!important;border:0}
 .content{animation:none;padding:0}
}
</style>
</head>
<body class="<?= $inApp ? 'app' : 'auth' ?>">
<?php if ($inApp): ?>
<aside class="sidebar" aria-label="Main navigation">
  <a class="brand" href="?page=dashboard"><span class="brand-logo"><i class="fa-solid fa-wifi"></i></span><span><?= h(SITE_NAME) ?><small>Omada · RADIUS</small></span></a>
  <div class="side-user">
    <div class="avatar"><?= h(strtoupper(substr($user['full_name'], 0, 1))) ?></div>
    <div class="min-w-0"><div class="side-name text-truncate"><?= h($user['full_name']) ?></div><div class="side-bal"><?= money($user['balance']) ?></div></div>
  </div>
  <nav class="nav-side flex-grow-1 pb-2"><?= renderNav($nav, $navPage, $navLabel) ?></nav>
  <div class="side-foot"><a class="side-logout" href="?action=logout"><i class="fa-solid fa-right-from-bracket"></i><?= t('logout') ?></a></div>
</aside>
<div class="offcanvas offcanvas-start sidebar-oc" tabindex="-1" id="mobileMenu" aria-label="Menu">
  <div class="offcanvas-header"><a class="brand p-0" href="?page=dashboard"><span class="brand-logo"><i class="fa-solid fa-wifi"></i></span><span><?= h(SITE_NAME) ?><small>Omada · RADIUS</small></span></a><button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button></div>
  <div class="offcanvas-body p-0 nav-side">
    <div class="side-user mt-3">
      <div class="avatar"><?= h(strtoupper(substr($user['full_name'], 0, 1))) ?></div>
      <div class="min-w-0"><div class="side-name text-truncate"><?= h($user['full_name']) ?></div><div class="side-bal"><?= money($user['balance']) ?></div></div>
    </div>
    <?= renderNav($nav, $navPage, $navLabel) ?>
    <div class="side-foot mt-2"><a class="side-logout" href="?action=logout"><i class="fa-solid fa-right-from-bracket"></i><?= t('logout') ?></a></div></div>
</div>
<?php endif; ?>

<div class="<?= $inApp ? 'main' : '' ?>">
<?php if ($inApp): ?>
  <header class="topbar">
    <div class="d-flex align-items-center gap-2 min-w-0">
      <button class="icon-btn d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
      <div class="min-w-0"><div class="crumb"><?= h(SITE_NAME) ?></div><h1 class="page-title"><?= h($navLabel($page)) ?></h1></div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <button type="button" class="icon-btn" onclick="toggleTheme()" aria-label="Theme" title="Light / Dark"><i class="fa-solid fa-circle-half-stroke"></i></button>
      <a href="?page=notifications" class="icon-btn" aria-label="<?= h(t('notifications')) ?>"><i class="fa-solid fa-bell"></i><?php if ($unread): ?><span class="nbadge"><?= $unread > 9 ? '9+' : $unread ?></span><?php endif; ?></a>
    </div>
  </header>
<?php else: ?>
  <button type="button" class="icon-btn auth-theme" onclick="toggleTheme()" aria-label="Theme"><i class="fa-solid fa-circle-half-stroke"></i></button>
<?php endif; ?>
<main class="content">
<?php foreach ($flashes as [$ft, $fm]): ?>
  <div class="alert alert-<?= h($ft) ?> alert-dismissible fade show" role="alert"><i class="fa-solid fa-<?= $flashIcon[$ft] ?? 'circle-info' ?> flash-ic"></i><?= $fm /* trusted: built from t() and app values */ ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>
<?php endforeach; ?>
<?php
// ============================================================
// PAGES
// ============================================================
switch ($page) {

case 'login':
    if ($auth->isLoggedIn()) redirectTo('?page=dashboard');
    $error = '';
    if ($isPost) {
        if (!rateLimitCheck(clientIp(), 'login', 8, 600)) $error = t('rate_limited');
        elseif ($auth->login(trim($P['username'] ?? ''), (string)($P['password'] ?? ''))) redirectTo('?page=dashboard');
        else $error = t('invalid_credentials');
    }
    ?>
    <div class="row justify-content-center py-4"><div class="col-sm-9 col-md-6 col-lg-4">
      <div class="card p-4 p-md-5">
        <div class="text-center mb-4"><div class="auth-logo"><i class="fa-solid fa-wifi"></i></div><h3 class="mt-3 mb-1"><?= h(SITE_NAME) ?></h3><small class="text-secondary"><?= t('app_title') ?> • Omada EAP225 + RADIUS</small></div>
        <?php if (isset($_GET['timeout'])): ?><div class="alert alert-warning"><?= t('session_expired') ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
        <form method="POST"><?= csrf_field() ?>
          <div class="mb-3"><label class="form-label"><?= t('username_email_phone') ?></label><input name="username" class="form-control" autocomplete="username" required autofocus></div>
          <div class="mb-4"><label class="form-label"><?= t('password') ?></label><input type="password" name="password" class="form-control" autocomplete="current-password" required></div>
          <button class="btn btn-primary w-100 py-2"><i class="fa-solid fa-right-to-bracket me-2"></i><?= t('login') ?></button>
        </form>
        <?php if (getSetting('allow_registration', '1') === '1'): ?><p class="text-center mt-4 mb-0 small text-secondary"><?= t('no_account') ?> <a href="?page=register"><?= t('register') ?></a></p><?php endif; ?>
      </div>
    </div></div>
    <?php break;

case 'register':
    if ($auth->isLoggedIn()) redirectTo('?page=dashboard');
    if (getSetting('allow_registration', '1') !== '1') {   // v6.2
        echo '<div class="row justify-content-center py-5"><div class="col-md-6 col-lg-4"><div class="card p-4 text-center"><div class="auth-logo mb-3"><i class="fa-solid fa-lock"></i></div><p>'
            . h(t('registration_closed')) . '</p><a href="?page=login" class="btn btn-primary">' . t('login') . '</a></div></div></div>';
        break;
    }
    $error = '';
    if ($isPost) {
        $d = ['username' => trim($P['username'] ?? ''), 'email' => trim($P['email'] ?? ''), 'phone' => normalizePhone($P['phone'] ?? ''),
              'password' => (string)($P['password'] ?? ''), 'full_name' => trim($P['full_name'] ?? '')];
        if (in_array('', $d, true)) $error = t('all_fields_required');
        elseif (strlen($d['password']) < 6) $error = t('password_min');
        elseif (!filter_var($d['email'], FILTER_VALIDATE_EMAIL)) $error = 'Invalid email';
        elseif (!rateLimitCheck(clientIp(), 'register', 5, 3600)) $error = t('rate_limited');
        else { $r = $auth->register($d); if ($r['success']) redirectTo('?page=routers&add=1'); $error = $r['message']; }
    }
    ?>
    <div class="row justify-content-center py-4"><div class="col-md-8 col-lg-6">
      <div class="card p-4 p-md-5">
        <div class="text-center mb-4"><div class="auth-logo"><i class="fa-solid fa-wifi"></i></div><h3 class="mt-3 mb-0"><?= t('create_account') ?></h3></div>
        <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
        <form method="POST" class="row g-3"><?= csrf_field() ?>
          <div class="col-md-6"><label class="form-label"><?= t('full_name') ?></label><input name="full_name" class="form-control" autocomplete="name" value="<?= h($P['full_name'] ?? '') ?>" required></div>
          <div class="col-md-6"><label class="form-label"><?= t('username') ?></label><input name="username" class="form-control" autocomplete="username" value="<?= h($P['username'] ?? '') ?>" required></div>
          <div class="col-md-6"><label class="form-label"><?= t('email') ?></label><input type="email" name="email" class="form-control" autocomplete="email" value="<?= h($P['email'] ?? '') ?>" required></div>
          <div class="col-md-6"><label class="form-label"><?= t('phone') ?></label><input type="tel" name="phone" class="form-control" autocomplete="tel" placeholder="07XXXXXXXX" value="<?= h($P['phone'] ?? '') ?>" required></div>
          <div class="col-12"><label class="form-label"><?= t('password') ?></label><input type="password" name="password" class="form-control" autocomplete="new-password" required></div>
          <div class="col-12"><button class="btn btn-primary w-100 py-2"><i class="fa-solid fa-user-plus me-2"></i><?= t('create_account') ?></button></div>
        </form>
        <p class="text-center mt-4 mb-0 small text-secondary"><?= t('already_account') ?> <a href="?page=login"><?= t('login') ?></a></p>
      </div>
    </div></div>
    <?php break;

case 'dashboard':
    $auth->requireLogin();
    if ($user['user_type'] === 'customer') {
        echo '<div class="alert alert-info">Customers buy WiFi directly on the hotspot portal — no account needed.</div>';
        break;
    }
    $uid = (int)$user['id'];
    $st = SessionOps::stats($uid);
    $devs = Device::forSeller($uid);
    $pending = rows("SELECT o.*, p.name AS package_name FROM hs_orders o LEFT JOIN hs_packages p ON p.id=o.package_id WHERE o.seller_id=? AND o.status='pending' ORDER BY o.id DESC LIMIT 10", 'i', $uid);
    $recent = rows("SELECT o.*, p.name AS package_name, v.code FROM hs_orders o LEFT JOIN hs_packages p ON p.id=o.package_id LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.seller_id=? AND o.status='paid' ORDER BY o.paid_at DESC LIMIT 8", 'i', $uid);
    $pkgCount = (int)val("SELECT COUNT(*) FROM hs_packages WHERE seller_id=?", 'i', $uid);
    ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
      <div><h4 class="mb-0"><?= t('welcome_back') ?>, <?= h(explode(' ', $user['full_name'])[0]) ?> 👋</h4><div class="small text-secondary"><?= h(date('l, d M Y')) ?></div></div>
      <span class="badge text-bg-dark border fs-6 px-3 py-2"><i class="fa-solid fa-wallet me-2"></i><?= t('earn_available') ?>: <?= money($user['balance']) ?></span>
    </div>
    <?php $ern = Earnings::summary($uid); ?>
    <div class="row g-3 mb-3">
      <div class="col-6 col-lg"><div class="card stat s2 p-3"><h6><i class="fa-solid fa-mobile-screen me-1"></i><?= t('earn_mobile') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['mobile']) ?></h4><div class="earn-sub"><?= t('earn_today') ?>: <?= money($ern['mobile_today']) ?></div></div></div>
      <div class="col-6 col-lg"><div class="card stat s3 p-3"><h6><i class="fa-solid fa-ticket me-1"></i><?= t('earn_vouchers') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['vouchers']) ?></h4><div class="earn-sub"><?= t('earn_today') ?>: <?= money($ern['vouchers_today']) ?></div></div></div>
      <div class="col-6 col-lg"><div class="card stat s1 p-3"><h6><i class="fa-solid fa-sack-dollar me-1"></i><?= t('earn_total') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['total']) ?></h4><div class="earn-sub"><?= $ern['commission'] > 0 ? t('earn_commission') . ': −' . money($ern['commission']) : t('earn_today') . ': ' . money($ern['today']) ?></div></div></div>
      <div class="col-6 col-lg"><div class="card stat s5 p-3"><h6><i class="fa-solid fa-money-bill-transfer me-1"></i><?= t('earn_withdrawn') ?></h6><h4 class="mb-0 fw-bold">−<?= money($ern['withdrawn']) ?></h4><div class="earn-sub"><a href="?page=withdraw" class="text-white"><?= t('withdraw') ?> →</a></div></div></div>
      <div class="col-12 col-lg"><div class="card stat s6 p-3"><h6><i class="fa-solid fa-wallet me-1"></i><?= t('earn_available') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['balance']) ?></h4><div class="earn-sub"><?= t('earn_total') ?> − <?= t('earn_withdrawn') ?></div></div></div>
    </div>
    <?php if ($st['attention_orders'] > 0): ?>
      <div class="alert alert-warning d-flex justify-content-between align-items-center flex-wrap gap-2"><span><i class="fa-solid fa-triangle-exclamation me-2"></i><?= t('pay_attention') ?>: <b><?= (int)$st['attention_orders'] ?></b> — <?= t('pending') ?> / failed / expired</span>
        <a href="?page=transactions&status=attention" class="btn btn-sm btn-warning"><i class="fa-solid fa-receipt me-1"></i><?= t('payments') ?></a></div>
    <?php endif; ?>
    <?php if ($auth->isAdmin() && array_filter(securityIssues(), fn($x) => $x[0] === 'danger')): ?>
      <div class="alert alert-danger d-flex justify-content-between align-items-center flex-wrap gap-2"><span><i class="fa-solid fa-shield-halved me-2"></i>Security: some passwords / keys are still defaults.</span><a href="?page=admin" class="btn btn-sm btn-danger">Security check</a></div>
    <?php endif; ?>
    <?php
    // v6.2 — Quick start checklist
    $qsVouchers = (int)val("SELECT COUNT(*) FROM hs_vouchers WHERE seller_id=?", 'i', $uid);
    $qsProv = (bool)array_filter($devs, fn($x) => in_array((string)($x['prov_state'] ?? ''), ['done', 'ready'], true) || Device::omadaConnected($x));
    $qsLive = (bool)array_filter($devs, fn($x) => !empty($x['last_seen']) && time() - strtotime($x['last_seen']) < 86400);
    $qs = [['qs_router', (bool)$devs, '?page=routers&add=1'], ['qs_provision', $qsProv, $devs ? '?page=hotspot&id=' . (int)$devs[0]['id'] . '#setup' : '?page=routers&add=1'],
           ['qs_package', $pkgCount > 0, '?page=packages'], ['qs_vouchers', $qsVouchers > 0, '?page=vouchers'], ['qs_live', $qsLive, $devs ? '?page=hotspot&id=' . (int)$devs[0]['id'] . '#health' : '?page=hotspot']];
    $qsDone = count(array_filter($qs, fn($x) => $x[1]));
    if ($qsDone < count($qs)): ?>
      <div class="card mb-3"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="fa-solid fa-flag-checkered me-2"></i><?= t('quick_start') ?></span><span class="badge text-bg-primary"><?= $qsDone ?>/<?= count($qs) ?></span></div>
        <div class="card-body"><div class="progress mb-3" style="height:6px"><div class="progress-bar" style="width:<?= (int)round($qsDone * 100 / count($qs)) ?>%"></div></div>
          <div class="row g-2"><?php foreach ($qs as $i => [$qk, $qok, $ql]): ?>
            <div class="col-sm-6 col-xl"><a href="<?= h($ql) ?>" class="d-flex align-items-center gap-2 p-2 rounded-3 text-decoration-none" style="border:1px solid var(--line);background:var(--surface-2)">
              <i class="fa-solid fa-<?= $qok ? 'circle-check text-success' : 'circle text-secondary' ?>"></i><span class="small <?= $qok ? 'text-secondary text-decoration-line-through' : 'text-body-emphasis fw-semibold' ?>"><?= $i + 1 ?>. <?= t($qk) ?></span></a></div>
          <?php endforeach; ?></div></div></div>
    <?php endif; ?>
    <?php if (!$devs): ?>
      <div class="alert alert-primary d-flex justify-content-between align-items-center flex-wrap gap-2"><div><b>1.</b> <?= t('add_device') ?> → <b>2.</b> <?= t('create_package') ?> → <b>3.</b> <?= t('generate_vouchers') ?></div><a href="?page=routers&add=1" class="btn btn-primary btn-sm"><?= t('add_device') ?></a></div>
    <?php elseif (!$pkgCount): ?>
      <div class="alert alert-primary d-flex justify-content-between align-items-center"><span><?= t('create_package') ?></span><a href="?page=packages" class="btn btn-primary btn-sm"><?= t('create_package') ?></a></div>
    <?php elseif ($st['devices_online'] === 0): ?>
      <div class="alert alert-warning"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= t('no_radius_traffic') ?> <a href="?page=hotspot&id=<?= (int)$devs[0]['id'] ?>"><?= t('radius_settings_btn') ?></a></div>
    <?php endif; ?>
    <div class="row g-3 mb-3">
      <div class="col-6 col-xl-3"><div class="card stat s1 p-3"><h6><i class="fa-solid fa-calendar-day me-1"></i><?= t('today_revenue') ?></h6><h4 class="mb-0 fw-bold" id="lv_today"><?= money($st['today_revenue']) ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s2 p-3"><h6><i class="fa-solid fa-signal me-1"></i><?= t('active_sessions') ?></h6><h4 class="mb-0 fw-bold" id="lv_sessions"><?= $st['active_sessions'] ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s3 p-3"><h6><i class="fa-solid fa-bolt me-1"></i><?= t('used_today') ?></h6><h4 class="mb-0 fw-bold" id="lv_used"><?= $st['used_today'] ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s4 p-3"><h6><i class="fa-solid fa-ticket me-1"></i><?= t('available_vouchers') ?></h6><h4 class="mb-0 fw-bold"><?= $st['available'] ?></h4></div></div>
    </div>
    <div class="row g-3">
      <div class="col-lg-6">
        <div class="card h-100"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="fa-solid fa-tower-broadcast me-2"></i><?= t('devices') ?> (<?= $st['devices_online'] ?>/<?= $st['devices'] ?> <?= t('online') ?>)</span><a href="?page=routers" class="small fw-normal"><?= t('view_all') ?></a></div>
          <div class="card-body">
            <?php foreach ($devs as $d): $on = Device::isOnline($d); ?>
              <div class="d-flex justify-content-between align-items-center py-2 border-bottom border-secondary-subtle">
                <div class="min-w-0"><span class="dot <?= $on ? 'on' : 'off' ?>"></span><b><?= h($d['device_name']) ?></b> <small class="text-secondary mono"><?= h($d['ap_mac']) ?></small><div class="small text-secondary"><?= h($d['ssid']) ?></div></div>
                <div class="text-end small"><span class="badge text-bg-<?= $on ? 'success' : 'secondary' ?>"><?= $on ? t('online') : t('offline') ?></span><div class="text-secondary mt-1"><?= (int)$d['active_sessions'] ?> <i class="fa-solid fa-user"></i></div></div>
              </div>
            <?php endforeach; if (!$devs) echo '<p class="text-secondary mb-0">' . t('no_data') . '</p>'; ?>
          </div></div>
      </div>
      <div class="col-lg-6">
        <div class="card h-100"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="fa-solid fa-hourglass-half me-2"></i><?= t('pending_orders') ?> (<?= $st['pending_orders'] ?>)</span><a href="?page=orders&status=pending" class="small fw-normal"><?= t('view_all') ?></a></div>
          <div class="card-body">
            <?php foreach ($pending as $o): ?>
              <div class="d-flex justify-content-between align-items-center py-2 border-bottom border-secondary-subtle gap-2">
                <div class="small"><b><?= money($o['amount']) ?></b> • <?= h($o['package_name']) ?><div class="text-secondary"><?= h($o['phone']) ?> • <?= h($o['order_ref']) ?></div></div>
                <form method="POST" onsubmit="return confirm('<?= h(t('mark_paid')) ?>?')"><?= csrf_field() ?><input type="hidden" name="act" value="order_confirm"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="btn btn-sm btn-success"><i class="fa-solid fa-check"></i> <?= t('mark_paid') ?></button></form>
              </div>
            <?php endforeach; if (!$pending) echo '<p class="text-secondary mb-0">' . t('no_data') . '</p>'; ?>
          </div></div>
      </div>
      <div class="col-12">
        <div class="card"><div class="card-header"><i class="fa-solid fa-receipt me-2"></i><?= t('recent_orders') ?> <span class="text-secondary fw-normal ms-2 small"><?= t('month_revenue') ?>: <b class="text-body-emphasis"><?= money($st['month_revenue']) ?></b> • <?= t('total_revenue') ?>: <b class="text-body-emphasis"><?= money($st['total_revenue']) ?></b></span></div>
          <div class="card-body table-responsive">
            <?php if ($recent): ?><table class="table table-sm table-hover mcard mb-0"><thead><tr><th><?= t('order_ref') ?></th><th><?= t('package') ?></th><th><?= t('code') ?></th><th><?= t('phone') ?></th><th><?= t('amount') ?></th><th><?= t('date') ?></th></tr></thead><tbody>
            <?php foreach ($recent as $o): ?><tr><td data-label="<?= t('order_ref') ?>" class="small"><?= h($o['order_ref']) ?></td><td data-label="<?= t('package') ?>"><?= h($o['package_name']) ?></td><td data-label="<?= t('code') ?>" class="mono"><?= h($o['code']) ?></td><td data-label="<?= t('phone') ?>"><?= h($o['phone']) ?></td><td data-label="<?= t('amount') ?>" class="fw-semibold"><?= money($o['amount']) ?></td><td data-label="<?= t('date') ?>" class="small"><?= h(date('d M H:i', strtotime($o['paid_at']))) ?></td></tr><?php endforeach; ?>
            </tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
          </div></div>
      </div>
    </div>
    <script>
    (function(){let busy=false;function live(){if(document.hidden||busy)return;busy=true;
      fetch('?ajax=live',{credentials:'same-origin'}).then(r=>r.json()).then(d=>{if(!d.success)return;
        document.getElementById('lv_sessions').textContent=d.stats.active_sessions;document.getElementById('lv_used').textContent=d.stats.used_today;
        document.getElementById('lv_today').textContent='<?= CURRENCY ?> '+Math.round(d.stats.today_revenue).toLocaleString();}).catch(()=>{}).finally(()=>{busy=false})}
      setInterval(live,30000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)live()});})();
    </script>
    <?php break;

// ============================================================
// v5.5 — ROUTERS: list → "Add router" → choose the model (Omada EAP225) → enter all router data
// ============================================================
case 'routers':
    $auth->requireSeller();
    $uid = (int)$user['id'];
    $edit = isset($_GET['edit']) ? Device::get((int)$_GET['edit'], $uid) : null;
    $adding = !$edit && isset($_GET['add']);
    $model = $edit ? RouterModels::forDevice($edit) : ($adding ? RouterModels::byCode((string)($_GET['model'] ?? '')) : null);
    $radiusIp = getSetting('radius_server_ip');
    $allModels = RouterModels::all();
    ?>
    <?php if ($radiusIp === ''): ?><div class="alert alert-warning"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= t('radius_ip_missing') ?><?= $auth->isAdmin() ? ' <a href="?page=radius">' . t('radius_setup') . '</a>' : '' ?></div><?php endif; ?>
    <?php
    // ---------------- step 1: choose the router model ----------------
    if ($adding && !$model): ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <div><a href="?page=routers" class="small"><i class="fa-solid fa-arrow-left me-1"></i><?= t('routers') ?></a><h4 class="mb-0 mt-1"><i class="fa-solid fa-plus text-primary me-2"></i><?= t('add_router') ?></h4></div>
    </div>
    <div class="card"><div class="card-header d-flex align-items-center"><span class="step-n">1</span><?= t('choose_model') ?></div><div class="card-body">
      <p class="small text-secondary"><?= t('choose_model_help') ?></p>
      <div class="row g-3">
        <?php foreach ($allModels as $m): $act = (int)$m['is_active'] === 1; ?>
          <div class="col-sm-6 col-xl-4">
            <?php if ($act): ?><a href="?page=routers&add=1&model=<?= urlencode($m['code']) ?>" class="d-block h-100 text-decoration-none"><?php endif; ?>
            <div class="h-100 p-3 rounded-4 d-flex gap-3 align-items-start" style="border:1px solid <?= $act ? 'var(--brand)' : 'var(--line)' ?>;background:<?= $act ? 'var(--brand-soft)' : 'var(--surface-2)' ?>;<?= $act ? '' : 'opacity:.55' ?>">
              <span class="brand-logo flex-shrink-0"><i class="fa-solid fa-<?= h($m['icon'] ?: 'wifi') ?>"></i></span>
              <div class="min-w-0 flex-grow-1">
                <div class="small text-secondary"><?= h($m['brand']) ?></div>
                <div class="fw-bold text-body-emphasis fs-5"><?= h($m['model']) ?></div>
                <div class="small text-secondary"><?= h($m['description']) ?></div>
                <div class="mt-2"><?= $act ? '<span class="btn btn-sm btn-primary"><i class="fa-solid fa-check me-1"></i>' . t('select') . '</span>' : '<span class="badge text-bg-secondary">' . t('coming_soon') . '</span>' ?></div>
              </div>
            </div>
            <?php if ($act): ?></a><?php endif; ?>
          </div>
        <?php endforeach; ?>
        <?php if (!$allModels): ?><div class="col-12"><a class="btn btn-primary" href="?page=routers&add=1&model=<?= RouterModels::DEFAULT_CODE ?>"><i class="fa-solid fa-wifi me-1"></i>TP-Link Omada EAP225</a></div><?php endif; ?>
      </div>
    </div></div>
    <?php break; endif;

    // ---------------- step 2: the router data form (add or edit) ----------------
    if ($adding || $edit):
        if (!$model) $model = RouterModels::forDevice([]);
        $old = $_SESSION['router_form'] ?? [];
        unset($_SESSION['router_form']);
        $v = function (string $k, string $def = '') use ($old, $edit): string {
            if (array_key_exists($k, $old)) return (string)$old[$k];
            if ($edit && array_key_exists($k, $edit) && $edit[$k] !== null) return (string)$edit[$k];
            return $def;
        };
        $defCtlId = ensureDefaultController($uid);   // v5.8: the default Omada Inform URL is pre-selected for every new router
        $ctrls = rows("SELECT id, name, sites_json, client_id, client_secret, base_url, inform_url FROM hs_controllers WHERE user_id=? ORDER BY id", 'i', $uid);
        $anyApi = (bool)array_filter($ctrls, fn($c) => OmadaApi::canApi($c));
        $curLink = array_key_exists('omada_link', $old) ? (string)$old['omada_link']
            : ($edit ? ($edit['controller_id'] ? (int)$edit['controller_id'] . '|' . (string)$edit['omada_site_id'] : '') : ($defCtlId ? $defCtlId . '|' : (($fa = array_values(array_filter($ctrls, fn($c) => OmadaApi::canApi($c)))) ? (int)$fa[0]['id'] . '|' : 'new')));
        $myPkgs = rows("SELECT id, name, price FROM hs_packages WHERE seller_id=? AND is_active=1 ORDER BY sort_order, price", 'i', $uid);
        $vmode = $v('voucher_mode', 'radius');
        [$eu] = $edit ? OmadaProvision::deviceCreds($edit) : ['admin'];
        $macVal = array_key_exists('ap_mac', $old) ? (string)$old['ap_mac'] : ($edit ? dashMac($edit['ap_mac']) : '');
        $isActive = array_key_exists('device_name', $old) ? !empty($old['is_active']) : (bool)($edit['is_active'] ?? 1);
        $pkgSel = (string)($old['prov_pkg'] ?? (!$edit ? ($myPkgs ? (string)$myPkgs[0]['id'] : 'starter') : '0'));
    ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <div><a href="?page=routers<?= $adding ? '&add=1' : '' ?>" class="small"><i class="fa-solid fa-arrow-left me-1"></i><?= $adding ? t('choose_model') : t('routers') ?></a>
        <h4 class="mb-0 mt-1"><i class="fa-solid fa-<?= $edit ? 'pen' : 'plus' ?> text-primary me-2"></i><?= $edit ? t('edit_router') . ' — ' . h($edit['device_name']) : t('add_router') ?></h4></div>
      <span class="badge text-bg-primary fs-6 px-3 py-2"><i class="fa-solid fa-<?= h($model['icon'] ?: 'wifi') ?> me-2"></i><?= h(RouterModels::label($model)) ?><?php if ($adding): ?> <a href="?page=routers&add=1" class="ms-2 small fw-normal"><?= t('change_model') ?></a><?php endif; ?></span>
    </div>
    <form method="POST" id="routerForm" autocomplete="off"><?= csrf_field() ?>
      <input type="hidden" name="act" value="device_save"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>"><input type="hidden" name="router_model" value="<?= h($model['code']) ?>">
      <?php if (!$edit): ?><input type="hidden" name="omada_auto" value="1"><?php endif; ?>
      <div class="row g-3">
        <div class="col-xl-7">
          <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">1</span><?= t('router_details') ?></div><div class="card-body row g-3">
            <div class="col-md-6"><label class="form-label small"><?= t('device_name') ?> *</label><input name="device_name" class="form-control" maxlength="100" value="<?= h($v('device_name', $model['model'] . ' Main')) ?>" required></div>
            <div class="col-md-6"><label class="form-label small"><?= t('ap_mac') ?> * <span class="text-secondary fw-normal">(<?= t('ap_mac_where') ?>)</span></label><input name="ap_mac" class="form-control mono" placeholder="50-C7-BF-11-22-33" value="<?= h($macVal) ?>" required pattern="[0-9A-Fa-f:\-\. ]{12,17}"></div>
            <div class="col-md-6"><label class="form-label small"><?= t('omada_sn') ?></label><input name="omada_sn" class="form-control mono" maxlength="20" value="<?= h($v('omada_sn')) ?>" placeholder="2236XXXXXXXXX"><div class="form-text"><?= t('serial_help') ?></div></div>
            <div class="col-md-6"><label class="form-label small"><?= t('prov_creds') ?></label><div class="input-group"><input name="dev_user" class="form-control" value="<?= h($v('dev_user', $eu)) ?>" placeholder="<?= h(t('dev_user')) ?>"><input name="dev_pass" type="password" class="form-control" placeholder="<?= h(t('dev_pass')) ?> (admin)" autocomplete="new-password"></div><div class="form-text"><?= t('dev_default_hint') ?>: admin / admin</div></div>
            <div class="col-12"><label class="form-label small"><?= t('location') ?></label><input name="location" class="form-control" maxlength="255" value="<?= h($v('location')) ?>" placeholder="Kariakoo, Dar es Salaam"></div>
          </div></div>

          <?php if (!$auth->isAdmin()):   // v6.2 — sellers never pick or create an Omada Controller
              $sellerCtl = null;
              foreach ($ctrls as $c) if ((int)$c['id'] === (int)explode('|', $curLink . '|')[0]) $sellerCtl = $c;
              $sellerOk = OmadaApi::canApi($sellerCtl); ?>
          <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">2</span><?= t('cloud_link') ?></div><div class="card-body row g-3">
            <div class="col-12"><div class="alert alert-<?= $sellerOk ? 'success' : 'warning' ?> small mb-0"><i class="fa-solid fa-<?= $sellerOk ? 'circle-check' : 'hourglass-half' ?> me-2"></i><?= $sellerOk ? t('ctrl_managed_by_admin') : t('ctrl_admin_pending') ?>
              <?php if ($sellerOk && informUrlOf($sellerCtl) !== ''): ?><div class="mt-1"><?= t('inform_url') ?>: <span class="mono text-info"><?= h(informUrlOf($sellerCtl)) ?></span></div><?php endif; ?></div></div>
            <div class="col-12"><label class="form-label small"><?= t('site_name') ?></label><input name="site_name" class="form-control" maxlength="100" value="<?= h($v('site_name', 'Default')) ?>"><div class="form-text"><?= t('site_name_help') ?></div></div>
          </div></div>
          <?php else: ?>
          <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">2</span><?= t('cloud_link') ?></div><div class="card-body row g-3">
            <div class="col-12"><label class="form-label small"><?= t('ctrl_link') ?></label><select name="omada_link" class="form-select" id="rlink" onchange="routerForm()">
              <?php foreach ($ctrls as $c): $sites = json_decode((string)$c['sites_json'], true) ?: []; ?>
                <option value="<?= (int)$c['id'] ?>|" <?= $curLink === (int)$c['id'] . '|' ? 'selected' : '' ?> <?= OmadaApi::canApi($c) ? '' : 'disabled' ?>><?= h($c['name']) ?><?= OmadaApi::canApi($c) ? ' • ' . h(t('ctrl_api_mode')) : ' • ' . h(t('ctrl_no_keys_badge')) ?><?= informUrlOf($c) !== '' ? ' — ' . h(informUrlOf($c)) : '' ?></option>
                <?php foreach ($sites as $s): $sv = (int)$c['id'] . '|' . $s['id']; ?><option value="<?= h($sv) ?>" <?= $curLink === $sv ? 'selected' : '' ?>><?= h($c['name'] . ' / ' . $s['name']) ?></option><?php endforeach; ?>
              <?php endforeach; ?>
              <option value="new" <?= $curLink === 'new' ? 'selected' : '' ?>><?= t('ctrl_new_inline') ?></option></select>
              <div class="form-text"><?= t('ctrl_link_help') ?></div>
              <?php if (defaultInformUrl() !== ''): ?><div class="form-text"><i class="fa-solid fa-link me-1 text-primary"></i><?= t('default_inform') ?>: <span class="mono text-info"><?= h(informDeviceAddr(defaultInformUrl())) ?></span></div><?php endif; ?></div>
            <div class="col-12" data-show="new"><div class="p-3 rounded-3" style="border:1px dashed var(--line-2);background:var(--surface-2)"><div class="row g-2">
              <div class="col-12 small fw-semibold text-body-emphasis"><i class="fa-solid fa-server me-1 text-primary"></i><?= t('ctrl_add') ?> — <?= t('ctrl_keys_title') ?></div>
              <div class="col-md-6"><label class="form-label small"><?= t('ctrl_base') ?></label><input name="new_base_url" data-req="1" class="form-control form-control-sm mono" value="<?= h($v('new_base_url', OMADA_CONTROLLER_URL)) ?>" placeholder="<?= h(OMADA_CONTROLLER_URL) ?>"></div>
              <div class="col-md-6"><label class="form-label small"><?= t('ctrl_omadac') ?></label><input name="new_omadac_id" class="form-control form-control-sm mono" value="<?= h($v('new_omadac_id')) ?>" placeholder="<?= h(t('ctrl_omadac_ph')) ?>"></div>
              <div class="col-md-6"><label class="form-label small"><?= t('ctrl_client_id') ?> *</label><input name="new_client_id" data-req="1" class="form-control form-control-sm mono" value="<?= h($v('new_client_id')) ?>" autocomplete="off" spellcheck="false"></div>
              <div class="col-md-6"><label class="form-label small"><?= t('ctrl_client_secret') ?> *</label><input name="new_client_secret" data-req="1" type="password" class="form-control form-control-sm mono" autocomplete="new-password" spellcheck="false"></div>
              <div class="col-12"><label class="form-label small"><?= t('ctrl_inform_paste') ?></label><input name="new_inform_url" class="form-control form-control-sm mono" value="<?= h($v('new_inform_url')) ?>" placeholder="169.58.93.38"></div>
              <div class="col-12 form-text mt-0"><?= t('ctrl_keys_help') ?><br><?= t('ctrl_get_omadac') ?></div>
            </div></div></div>
            <div class="col-12"><label class="form-label small"><?= t('site_name') ?></label><input name="site_name" class="form-control" maxlength="100" value="<?= h($v('site_name', 'Default')) ?>"><div class="form-text"><?= t('site_name_help') ?></div></div>
          </div></div>
          <?php endif; ?>

          <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">3</span><?= t('wifi_details') ?></div><div class="card-body row g-3">
            <div class="col-md-6"><label class="form-label small"><?= t('ssid') ?></label><input name="ssid" class="form-control" maxlength="32" value="<?= h($v('ssid')) ?>" placeholder="SKY WIFI"></div>
            <div class="col-md-6"><label class="form-label small"><?= t('lipa_info') ?></label><input name="lipa_info" class="form-control" maxlength="255" value="<?= h($v('lipa_info')) ?>" placeholder="M-Pesa Lipa 123456 — SKY TANZANIA"><div class="form-text"><?= t('lipa_info_help') ?></div></div>
          </div></div>
        </div>

        <div class="col-xl-5">
          <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">4</span><?= t('vouchers_section') ?></div><div class="card-body row g-3">
            <?php if ($anyApi || $curLink === 'new' || !$auth->isAdmin()): ?>
              <div class="col-12"><label class="form-label small"><?= t('voucher_mode') ?></label>
                <div class="form-check"><input class="form-check-input" type="radio" name="voucher_mode" value="radius" id="rvr" <?= $vmode !== 'omada' ? 'checked' : '' ?>><label class="form-check-label small" for="rvr"><?= t('vm_radius') ?></label></div>
                <div class="form-check"><input class="form-check-input" type="radio" name="voucher_mode" value="omada" id="rvo" <?= $vmode === 'omada' ? 'checked' : '' ?>><label class="form-check-label small" for="rvo"><?= t('vm_omada') ?></label></div></div>
            <?php else: ?><input type="hidden" name="voucher_mode" value="radius"><div class="col-12 small text-secondary"><?= t('vm_radius') ?></div><?php endif; ?>
            <div class="col-8"><label class="form-label small"><?= t('prov_pkg') ?></label><select name="prov_pkg" class="form-select">
              <option value="0" <?= $pkgSel === '0' ? 'selected' : '' ?>><?= t('prov_pkg_none') ?></option>
              <option value="starter" <?= $pkgSel === 'starter' ? 'selected' : '' ?>><?= t('prov_pkg_starter') ?></option>
              <?php foreach ($myPkgs as $p): ?><option value="<?= (int)$p['id'] ?>" <?= $pkgSel === (string)$p['id'] ? 'selected' : '' ?>><?= h($p['name']) ?> — <?= money($p['price']) ?></option><?php endforeach; ?></select></div>
            <div class="col-4"><label class="form-label small"><?= t('prov_qty') ?></label><input type="number" name="prov_qty" min="0" max="500" value="<?= h((string)($old['prov_qty'] ?? ($edit ? 0 : 20))) ?>" class="form-control"></div>
          </div></div>

          <div class="card mb-3"><div class="card-body">
            <?php if ($auth->isAdmin()): ?><details><summary class="small text-secondary" style="cursor:pointer"><i class="fa-solid fa-sliders me-1"></i><?= t('advanced') ?></summary><div class="row g-3 mt-1">
              <div class="col-12"><label class="form-label small"><?= t('controller_url') ?></label><input name="controller_url" class="form-control" value="<?= h($v('controller_url')) ?>" placeholder="http://192.168.0.10:8088"><div class="form-text"><?= t('controller_url_help') ?></div></div>
              <div class="col-12"><label class="form-label small"><?= t('omada_nas_id') ?></label><input name="omada_nas_id" class="form-control mono" maxlength="64" value="<?= h($v('omada_nas_id')) ?>" placeholder="<?= h(t('nas_auto')) ?>"><div class="form-text"><?= t('omada_nas_help') ?></div></div>
              <div class="col-12"><label class="form-label small"><?= t('dae_target') ?></label><input name="dae_target" class="form-control mono" value="<?= h($v('dae_target')) ?>" placeholder="41.59.10.20:3799"><div class="form-text"><?= t('dae_target_help') ?></div></div>
            </div></details><?php endif; ?>
            <div class="form-check form-switch mt-3"><input class="form-check-input" type="checkbox" name="is_active" id="ract" <?= $isActive ? 'checked' : '' ?>><label class="form-check-label" for="ract"><?= t('active') ?></label></div>
            <?php if ($edit): ?><div class="form-check form-switch mt-2"><input class="form-check-input" type="checkbox" name="omada_auto" value="1" id="rrun"><label class="form-check-label small" for="rrun"><?= t('rerun_setup') ?></label></div><?php endif; ?>
            <div class="d-flex gap-2 mt-3 flex-wrap">
              <button class="btn btn-primary flex-grow-1" id="routerSave"><i class="fa-solid fa-floppy-disk me-1"></i><?= $edit ? t('save') : t('add_router') . ' → ' . t('hotspot') ?></button>
              <a href="?page=routers" class="btn btn-outline-secondary"><?= t('cancel') ?></a>
            </div>
            <div class="small text-secondary d-none mt-2" id="routerBusy"><span class="spinner-border spinner-border-sm me-2"></span><?= t('prov_busy') ?></div>
          </div></div>

          <div class="card"><div class="card-header"><i class="fa-solid fa-circle-info me-2"></i><?= t('how_it_works') ?></div><div class="card-body small">
            <?php foreach (['hiw_1', 'hiw_2', 'hiw_3'] as $i => $k): ?><div class="d-flex mb-3"><span class="step-n"><?= $i + 1 ?></span><span><?= t($k) ?></span></div><?php endforeach; ?>
            <div class="text-secondary"><?= t('auth_port') ?> <b class="mono">1812</b> • <?= t('acct_port') ?> <b class="mono">1813</b> (<?= t('fixed_port') ?>)</div>
          </div></div>
        </div>
      </div>
    </form>
    <script>
    function routerForm(){const r=document.getElementById('rlink');if(!r)return;const v=r.value,f=document.getElementById('routerForm');
      f.querySelectorAll('[data-show]').forEach(el=>el.classList.toggle('d-none',el.dataset.show==='new'?v!=='new':v===''));
      f.querySelectorAll('[data-req]').forEach(i=>i.required=(v==='new'));}
    routerForm();
    document.getElementById('routerForm').addEventListener('submit',()=>{document.getElementById('routerSave').disabled=true;document.getElementById('routerBusy').classList.remove('d-none')});
    </script>
    <?php break; endif;

    // ---------------- router list ----------------
    $devs = Device::forSeller($uid);
    $mm = [];
    foreach ($allModels as $m) $mm[(int)$m['id']] = $m;
    $cnames = [];
    foreach (rows("SELECT id, name FROM hs_controllers WHERE user_id=?", 'i', $uid) as $c) $cnames[(int)$c['id']] = $c['name'];
    ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <p class="text-secondary small mb-0" style="max-width:720px"><?= t('routers_intro') ?></p>
      <a href="?page=routers&add=1" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i><?= t('add_router') ?></a>
    </div>
    <?php if (!$devs): ?>
      <div class="card p-5 text-center"><i class="fa-solid fa-tower-broadcast fa-2x mb-3 text-primary"></i><p class="text-secondary"><?= t('no_data') ?></p>
        <div><a href="?page=routers&add=1" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i><?= t('add_router') ?></a></div></div>
    <?php else: ?>
    <div class="row g-3">
      <?php foreach ($devs as $d): $on = Device::isOnline($d); $m = $mm[(int)($d['router_model_id'] ?? 0)] ?? RouterModels::forDevice($d); $ps = (string)($d['prov_state'] ?? ''); ?>
        <div class="col-md-6 col-xxl-4"><div class="card h-100"><div class="card-body d-flex flex-column">
          <div class="d-flex gap-3 align-items-start">
            <span class="brand-logo flex-shrink-0"><i class="fa-solid fa-<?= h($m['icon'] ?: 'wifi') ?>"></i></span>
            <div class="min-w-0 flex-grow-1">
              <div class="d-flex justify-content-between gap-2"><b class="text-body-emphasis text-truncate"><span class="dot <?= $on ? 'on' : 'off' ?>"></span><?= h($d['device_name']) ?></b>
                <span class="badge text-bg-<?= $on ? 'success' : 'secondary' ?>"><?= $on ? t('hs_live') : t('hs_waiting') ?></span></div>
              <div class="small text-secondary"><?= h(RouterModels::label($m)) ?><?= $d['is_active'] ? '' : ' • <span class="text-warning">' . t('inactive') . '</span>' ?></div>
            </div>
          </div>
          <div class="small mt-3 flex-grow-1">
            <div><span class="text-secondary"><?= t('mac') ?>:</span> <span class="mono"><?= h(dashMac($d['ap_mac'])) ?></span><?= $d['omada_sn'] ? ' • S/N <span class="mono">' . h($d['omada_sn']) . '</span>' : '' ?></div>
            <div><span class="text-secondary"><?= t('ssid') ?>:</span> <?= h($d['ssid'] ?: '—') ?> • <span class="text-secondary"><?= t('site_name') ?>:</span> <?= h($d['site_name']) ?></div>
            <div><span class="text-secondary"><?= t('cloud_link') ?>:</span> <?= $d['controller_id'] && isset($cnames[(int)$d['controller_id']]) ? h($cnames[(int)$d['controller_id']]) : '<span class="text-warning">' . t('ctrl_not_linked_opt') . '</span>' ?></div>
            <div><span class="text-secondary"><?= t('nas_id') ?>:</span> <?= $d['omada_nas_id'] ? '<span class="mono text-info">' . h($d['omada_nas_id']) . '</span>' : '<span class="text-warning">' . t('nas_waiting') . '</span>' ?></div>
            <div class="text-secondary"><?= t('last_seen') ?>: <?= $d['last_seen'] ? h(date('d M H:i', strtotime($d['last_seen']))) : t('never') ?> • <?= (int)$d['active_sessions'] ?> <i class="fa-solid fa-user"></i></div>
            <?php if ($ps !== ''): ?><div class="mt-1"><span class="badge text-bg-<?= ['done' => 'success', 'ready' => 'primary', 'provisioning' => 'info', 'partial' => 'warning'][$ps] ?? 'secondary' ?>"><?= h(t('prov_state_' . $ps)) ?></span></div><?php endif; ?>
          </div>
          <div class="d-flex gap-1 flex-wrap mt-3">
            <a class="btn btn-sm btn-success" href="?page=hotspot&id=<?= (int)$d['id'] ?>#setup"><i class="fa-solid fa-plug me-1"></i><?= t('prov_start') ?></a>
            <a class="btn btn-sm btn-outline-primary" href="?page=routers&edit=<?= (int)$d['id'] ?>" title="<?= h(t('edit_router')) ?>"><i class="fa-solid fa-pen"></i></a>
            <a class="btn btn-sm btn-outline-info" href="?page=sessions&device=<?= (int)$d['id'] ?>" title="<?= h(t('sessions')) ?>"><i class="fa-solid fa-signal"></i></a>
            <form method="POST" <?= (int)$d['is_active'] ? 'onsubmit="return confirm(' . h(json_encode(t('hotspot_stop_confirm'))) . ')"' : '' ?>><?= csrf_field() ?><input type="hidden" name="act" value="device_toggle"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><input type="hidden" name="return" value="?page=routers"><button class="btn btn-sm btn-outline-<?= (int)$d['is_active'] ? 'warning' : 'success' ?>" title="<?= h((int)$d['is_active'] ? t('hotspot_stop') : t('hotspot_start')) ?>"><i class="fa-solid fa-<?= (int)$d['is_active'] ? 'stop' : 'play' ?>"></i></button></form>
            <form method="POST" class="ms-auto" onsubmit="return confirm('<?= h(t('confirm_delete')) ?>')"><?= csrf_field() ?><input type="hidden" name="act" value="device_delete"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-danger" title="<?= h(t('delete')) ?>"><i class="fa-solid fa-trash"></i></button></form>
          </div>
        </div></div></div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php break;

// ============================================================
// v5.5 — HOTSPOT: choose a router → provision & connect it (with an id this shows the full provisioning page below)
// ============================================================
case 'hotspot':
    if ((int)($_GET['id'] ?? 0) <= 0) {
        $auth->requireSeller();
        $uid = (int)$user['id'];
        $devs = Device::forSeller($uid);
        $cnames = [];
        foreach (rows("SELECT id, name FROM hs_controllers WHERE user_id=?", 'i', $uid) as $c) $cnames[(int)$c['id']] = $c['name'];
        $runs = ProvisionLog::forUser($uid, 15);
        $srvOnline = (int)getSetting('radius_server_seen', '0') > time() - 180;
        ?>
        <div class="alert alert-info small"><i class="fa-solid fa-circle-info me-2"></i><?= t('hs_intro') ?></div>
        <?php if (defaultInformUrl() !== ''): ?><div class="card mb-3"><div class="card-body"><div class="cfg"><?= cfgRow(t('default_inform'), informDeviceAddr(defaultInformUrl()), t('inform_hint')) ?><?= cfgFixed(t('inform_ports'), 'UDP 29810 • TCP 29811–29817', t('inform_ports_hint')) ?></div></div></div><?php endif; ?>
        <div class="d-flex flex-wrap gap-2 mb-3">
          <span class="badge text-bg-<?= $srvOnline ? 'success' : 'danger' ?> py-2 px-3"><i class="fa-solid fa-server me-1"></i><?= t('radius_server') ?>: <?= $srvOnline ? t('server_online') : t('server_offline') ?></span>
          <span class="badge text-bg-<?= getSetting('radius_server_ip') !== '' ? 'primary' : 'warning' ?> py-2 px-3"><i class="fa-solid fa-network-wired me-1"></i><?= t('radius_server_ip') ?>: <?= h(getSetting('radius_server_ip') ?: t('not_set')) ?></span>
          <?php if (OmadaClientOps::targets($uid)): ?><form method="POST" class="ms-auto" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="routers_sync_all"><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-arrows-rotate me-1"></i><?= t('sync_all') ?></button></form><?php endif; ?>
        </div>
        <div class="row g-3">
          <div class="col-lg-8">
            <?php if (!$devs): ?>
              <div class="card p-5 text-center"><i class="fa-solid fa-wifi fa-2x mb-3 text-primary"></i><p class="text-secondary"><?= t('hs_no_routers') ?></p>
                <div><a href="?page=routers&add=1" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i><?= t('add_router') ?></a></div></div>
            <?php else: ?>
            <div class="card"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="fa-solid fa-wifi me-2"></i><?= t('routers') ?> (<?= count($devs) ?>)</span><a href="?page=routers&add=1" class="small fw-normal"><i class="fa-solid fa-plus me-1"></i><?= t('add_router') ?></a></div>
              <div class="card-body table-responsive">
                <table class="table table-hover mcard align-middle mb-0"><thead><tr><th><?= t('device_name') ?></th><th><?= t('cloud_link') ?></th><th><?= t('status') ?></th><th><?= t('hs_health') ?></th><th><?= t('last_seen') ?></th><th></th></tr></thead><tbody>
                <?php foreach ($devs as $d): $on = Device::isOnline($d); $ps = (string)($d['prov_state'] ?? ''); ?>
                  <tr>
                    <td data-label="<?= t('device_name') ?>"><span class="dot <?= $on ? 'on' : 'off' ?>"></span><b class="text-body-emphasis"><?= h($d['device_name']) ?></b>
                      <div class="small text-secondary"><?= h(RouterModels::label(RouterModels::forDevice($d))) ?> • <span class="mono"><?= h(dashMac($d['ap_mac'])) ?></span> • <?= h($d['ssid'] ?: '—') ?></div></td>
                    <td data-label="<?= t('cloud_link') ?>" class="small"><?= $d['controller_id'] && isset($cnames[(int)$d['controller_id']]) ? h($cnames[(int)$d['controller_id']]) : '<span class="text-warning">' . t('ctrl_not_linked_opt') . '</span>' ?></td>
                    <td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $on ? 'success' : 'secondary' ?>"><?= $on ? t('hs_live') : t('hs_waiting') ?></span>
                      <?php if ($ps !== ''): ?><div class="small text-secondary mt-1"><?= h(t('prov_state_' . $ps)) ?></div><?php endif; ?></td>
                    <td data-label="<?= t('hs_health') ?>"><?php $hc = OmadaLink::counts(OmadaLink::saved($d)); if ($d['health_at'] ?? null): ?>
                      <a href="?page=hotspot&id=<?= (int)$d['id'] ?>#health" class="badge text-bg-<?= $hc['fail'] ? 'danger' : ($hc['warn'] ? 'warning' : 'success') ?> text-decoration-none"><?= $hc['ok'] ?> ✔ <?= $hc['warn'] ?> ⚠ <?= $hc['fail'] ?> ✘</a><?php else: ?><span class="text-secondary small">—</span><?php endif; ?></td>
                    <td data-label="<?= t('last_seen') ?>" class="small"><?= $d['last_seen'] ? h(date('d M H:i', strtotime($d['last_seen']))) : t('never') ?></td>
                    <td class="text-nowrap"><a class="btn btn-sm btn-success" href="?page=hotspot&id=<?= (int)$d['id'] ?>#setup"><i class="fa-solid fa-plug me-1"></i><?= t('prov_start') ?></a></td>
                  </tr>
                <?php endforeach; ?>
                </tbody></table>
              </div></div>
            <?php endif; ?>
          </div>
          <div class="col-lg-4">
            <div class="card mb-3"><div class="card-header"><i class="fa-solid fa-list-ol me-2"></i><?= t('how_it_works') ?></div><div class="card-body small">
              <?php foreach (['prov_step_power', 'prov_step_inform', 'prov_step_adopt', 'prov_step_press'] as $i => $k): ?><div class="d-flex mb-2"><span class="step-n"><?= $i + 1 ?></span><span><?= t($k) ?></span></div><?php endforeach; ?>
            </div></div>
            <div class="card"><div class="card-header"><i class="fa-solid fa-clock-rotate-left me-2"></i><?= t('prov_history') ?></div><div class="card-body p-2" style="max-height:420px;overflow:auto">
              <?php foreach ($runs as $r): ?>
                <a href="?page=hotspot&id=<?= (int)$r['device_id'] ?>" class="d-flex justify-content-between gap-2 border-bottom border-secondary-subtle py-2 px-1 small text-decoration-none">
                  <div class="min-w-0"><b class="text-body-emphasis"><?= h($r['device_name']) ?></b> • <?= h(t('pa_' . $r['action'])) ?><?= $r['phase'] !== null && $r['phase'] !== '' ? ' <span class="badge text-bg-secondary">' . h($r['phase']) . '</span>' : '' ?>
                    <div class="text-secondary text-truncate"><?= h($r['message']) ?></div></div>
                  <span class="text-secondary text-nowrap"><?= h(date('d M H:i', strtotime($r['created_at']))) ?></span></a>
              <?php endforeach; if (!$runs) echo '<p class="text-secondary m-2 small">' . t('no_data') . '</p>'; ?>
            </div></div>
          </div>
        </div>
        <?php
        break;
    }
    // a router was chosen: fall through to its provisioning page

case 'omada':
    $auth->requireSeller();
    $uid = (int)$user['id'];
    $d = Device::get((int)($_GET['id'] ?? 0), $uid);
    if (!$d && $auth->isAdmin() && ($d = Device::get((int)($_GET['id'] ?? 0)))) $uid = (int)$d['user_id'];   // v6.2: admin opens a seller's router
    $isAdm = $auth->isAdmin();
    $ownRouter = $d && (int)$d['user_id'] === (int)$user['id'];
    if (!$d) { echo '<div class="alert alert-warning">' . t('no_data') . ' — <a href="?page=routers">' . t('devices') . '</a></div>'; break; }
    if (!$d['nas_id'] || !$d['radius_secret'] || !$d['acct_secret']) { Device::ensureCredentials((int)$d['id']); $d = Device::get((int)$d['id'], $uid); }
    $c = Device::radiusConfig($d);
    $on = Device::isOnline($d);
    $host = (string)parse_url(appUrl(), PHP_URL_HOST);
    $hostIp = $host !== '' ? resolveHost($host) : '';
    $ctl = $d['controller_id'] ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', $d['controller_id'], $uid) : null;
    $myCtrls = rows("SELECT id, name, inform_url, base_url, ctype FROM hs_controllers WHERE user_id=? ORDER BY id", 'i', $uid);
    $inform = $ctl ? informUrlOf($ctl) : ($myCtrls ? informUrlOf($myCtrls[0]) : '');
    if ($inform === '') $inform = informDeviceAddr(defaultInformUrl());   // v5.8 (v6.1.2: controller IP)
    [$oLabel, $oColor] = Device::omadaBadge($d['omada_status']);
    if ($hostIp === $host || !filter_var($hostIp, FILTER_VALIDATE_IP)) $hostIp = '';
    $srvInfo = json_decode(getSetting('radius_server_info'), true) ?: [];
    $srvOnline = (int)getSetting('radius_server_seen', '0') > time() - 180;
    $badPw = array_filter((array)($srvInfo['badpw'] ?? []), fn($x) => is_array($x) && (($x['key'] ?? ($x['nas'] ?? '')) === $d['nas_id']));
    $logs = rows("SELECT * FROM hs_radius_log WHERE nas_id=? ORDER BY id DESC LIMIT 15", 's', $d['nas_id']);
    $na = t('not_set');
    $nasLine = $c['nas_id'] !== '' ? $c['nas_id'] . ' (' . t('nas_learned') . ')' : t('nas_auto');
    $sheet = implode("\n", [
        SITE_NAME . ' — Omada RADIUS settings', 'Hotspot: ' . $d['device_name'] . ' (' . dashMac($d['ap_mac']) . ')', '',
        '[RADIUS Profile]  Settings > Profiles > RADIUS Profile', 'Name: ' . $c['profile'], 'Authentication Server IP: ' . ($c['server_ip'] ?: $na),
        'Authentication Port: ' . $c['auth_port'], 'Authentication Password: ' . $c['auth_secret'], 'RADIUS Accounting: Enable',
        'Interim Update: Enable, ' . $c['interim'] . ' seconds', 'Accounting Server IP: ' . ($c['acct_ip'] ?: $na), 'Accounting Port: ' . $c['acct_port'],
        'Accounting Password: ' . $c['acct_secret'], '',
        '[Portal]  Settings > Authentication > Portal', 'Authentication Type: External RADIUS Server', 'RADIUS Profile: ' . $c['profile'],
        'NAS ID: ' . $nasLine, 'Authentication Mode: PAP', 'Disconnect Requests: Enable, Receiver Port ' . $c['dae_port'],
        'Portal Customization: External Web Portal', 'External Web Portal URL: ' . $c['portal_url'], '',
        '[Pre-Authentication Access]', 'URL: ' . $host . ($hostIp ? "\nIP: " . $hostIp : ''), '',
        '[EAP225 → Controller Inform URL]', 'Controller Inform URL: ' . ($inform ?: $na), 'Ports to the controller: UDP 29810, TCP 29811-29817',
    ]);
    ?>
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
      <div>
        <a href="?page=hotspot" class="small no-print"><i class="fa-solid fa-arrow-left me-1"></i><?= t('hotspot') ?></a>
        <h4 class="mb-1 mt-1"><i class="fa-solid fa-wifi text-primary me-2"></i><?= h($d['device_name']) ?> <span class="badge text-bg-primary align-middle"><?= h(RouterModels::label(RouterModels::forDevice($d))) ?></span></h4>
        <div class="small text-secondary mono"><?= h(dashMac($d['ap_mac'])) ?> • <?= h($d['ssid'] ?: '—') ?> • <?= h($d['site_name']) ?><?php if ($ownRouter): ?> <a class="ms-2 no-print" href="?page=routers&edit=<?= (int)$d['id'] ?>"><i class="fa-solid fa-pen"></i> <?= t('edit_router') ?></a><?php endif; ?></div>
        <?php if (!$ownRouter): ?><div class="small text-warning mt-1"><i class="fa-solid fa-user-shield me-1"></i><?= h(sprintf(t('owner_view'), (string)val("SELECT username FROM users WHERE id=?", 'i', $uid))) ?></div><?php endif; ?>
      </div>
      <div class="d-flex gap-2 flex-wrap">
        <form method="POST" class="no-print" <?= (int)$d['is_active'] ? 'onsubmit="return confirm(' . h(json_encode(t('hotspot_stop_confirm'))) . ')"' : '' ?>><?= csrf_field() ?><input type="hidden" name="act" value="device_toggle"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
          <button class="btn btn-sm btn-<?= (int)$d['is_active'] ? 'outline-danger' : 'success' ?>"><i class="fa-solid fa-<?= (int)$d['is_active'] ? 'stop' : 'play' ?> me-1"></i><?= (int)$d['is_active'] ? t('hotspot_stop') : t('hotspot_start') ?></button></form>
        <button type="button" class="btn btn-sm btn-primary" onclick="cp('sheet',this)"><i class="fa-regular fa-copy me-1"></i><?= t('copy_all') ?></button>
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()"><i class="fa-solid fa-print me-1"></i><?= t('print_sheet') ?></button>
      </div>
    </div>
    <textarea id="sheet" class="d-none" readonly><?= h($sheet) ?></textarea>
    <div class="d-flex flex-wrap gap-2 mb-3">
      <span class="badge text-bg-<?= $srvOnline ? 'success' : 'danger' ?> py-2 px-3"><i class="fa-solid fa-server me-1"></i><?= t('radius_server') ?>: <?= $srvOnline ? t('server_online') : t('server_offline') ?></span>
      <span class="badge text-bg-<?= $on ? 'success' : 'secondary' ?> py-2 px-3"><i class="fa-solid fa-tower-broadcast me-1"></i><?= $d['last_seen'] ? t('last_seen') . ': ' . h(date('d M H:i:s', strtotime($d['last_seen']))) . ($d['radius_src_ip'] ? ' ' . t('contact_from') . ' ' . h($d['radius_src_ip']) : '') : t('waiting_contact') ?></span>
      <?php if ($d['controller_id']): ?><span class="badge text-bg-<?= $oColor ?> py-2 px-3"><i class="fa-solid fa-wifi me-1"></i>Omada: <?= h($oLabel) ?><?= $d['omada_status_at'] ? ' • ' . h(date('H:i', strtotime($d['omada_status_at']))) : '' ?> • <?= (int)$d['omada_clients'] ?> <i class="fa-solid fa-users"></i></span><?php endif; ?>
      <span class="badge text-bg-<?= $c['nas_id'] !== '' ? 'info' : 'secondary' ?> py-2 px-3"><i class="fa-solid fa-id-badge me-1"></i><?= t('nas_id') ?>: <?= $c['nas_id'] !== '' ? h($c['nas_id']) : t('nas_waiting') ?></span>
    </div>
    <?php if ($c['server_ip'] === ''): ?><div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= t('radius_ip_missing') ?><?= $auth->isAdmin() ? ' <a href="?page=radius">' . t('radius_setup') . '</a>' : '' ?></div><?php endif; ?>
    <?php foreach ($badPw as $b): ?><div class="alert alert-danger"><i class="fa-solid fa-lock me-2"></i>The RADIUS server is rejecting packets from <span class="mono"><?= h($b['ip'] ?? '') ?></span>: <b><?= h($b['kind'] ?? '') ?></b> in Omada is wrong. Copy it again from below.</div><?php endforeach; ?>
    <?php
    // ---------------- v5.7 connection health: Phone → EAP225 → Omada → RADIUS server → Website ----------------
    if (empty($d['health_at'])) { OmadaLink::check((int)$d['id'], $uid, 15); $d = Device::get((int)$d['id'], $uid); }
    $hRows = OmadaLink::saved($d);
    $hCnt = OmadaLink::counts($hRows);
    $hops = [
        ['hl_phone', 'mobile-screen', OmadaLink::hop($hRows, ['portal_reach'])],
        ['hl_eap', 'wifi', OmadaLink::hop($hRows, ['device', 'radius_traffic'])],
        ['hl_omada', 'cloud', OmadaLink::hop($hRows, ['cloud', 'relay', 'api', 'site', 'ssid', 'radius_profile', 'portal', 'preauth'])],
        ['hl_radius', 'server', OmadaLink::hop($hRows, ['radius_ip', 'radius_box', 'router'])],
        ['hl_web', 'globe', OmadaLink::hop($hRows, ['website'])],
    ];
    $hIc = ['ok' => ['circle-check', 'success'], 'warn' => ['triangle-exclamation', 'warning'], 'fail' => ['circle-xmark', 'danger'], 'skip' => ['circle-minus', 'secondary']];
    $fixLink = ['admin' => $auth->isAdmin() ? '?page=radius' : '', 'link' => '?page=routers&edit=' . (int)$d['id'], 'keys' => $isAdm ? ($ctl ? '?page=controller&edit=' . (int)$ctl['id'] : '?page=controller') : '',
        'sheet' => '#sheetTop', 'adopt' => '#setup', 'setup' => ''];
    ?>
    <style>.hchain{display:flex;align-items:center;gap:.35rem;flex-wrap:wrap}.hnode{display:flex;flex-direction:column;align-items:center;gap:.3rem;min-width:70px;font-size:.72rem;font-weight:700;color:var(--muted)}
    .hnode i{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;font-size:1.1rem;border:1px solid var(--line-2);background:var(--surface-2)}
    .hnode.ok i{background:rgba(34,197,94,.14);color:var(--ok);border-color:rgba(34,197,94,.45)}.hnode.warn i{background:rgba(245,158,11,.14);color:var(--warn);border-color:rgba(245,158,11,.45)}
    .hnode.fail i{background:rgba(239,68,68,.14);color:var(--bad);border-color:rgba(239,68,68,.45)}.hline{flex:1;min-width:16px;height:2px;background:var(--line-2);margin-bottom:1.2rem}
    .hrow{display:flex;gap:.6rem;padding:.5rem 0;border-bottom:1px solid var(--line)}.hrow:last-child{border-bottom:0}</style>
    <div class="card mb-3" id="health"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
      <span><i class="fa-solid fa-heart-pulse me-2"></i><?= t('hl_title') ?></span>
      <span class="d-flex gap-2 align-items-center no-print">
        <?php if ($hRows): ?><span class="badge text-bg-<?= $hCnt['fail'] ? 'danger' : ($hCnt['warn'] ? 'warning' : 'success') ?>"><?= $hCnt['ok'] ?> ✔ • <?= $hCnt['warn'] ?> ⚠ • <?= $hCnt['fail'] ?> ✘</span><?php endif; ?>
        <form method="POST" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="link_check"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-stethoscope me-1"></i><?= t('hl_check') ?></button></form>
        <?php if (OmadaApi::canApi($ctl)): ?><form method="POST" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').innerHTML='<span class=&quot;spinner-border spinner-border-sm me-1&quot;></span><?= h(t('hl_fix')) ?>'"><?= csrf_field() ?><input type="hidden" name="act" value="link_fix"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-success"><i class="fa-solid fa-wrench me-1"></i><?= t('hl_fix') ?></button></form><?php endif; ?>
      </span></div>
      <div class="card-body">
        <div class="hchain mb-3">
          <?php foreach ($hops as $i => [$lk, $ic, $st]): ?><?= $i ? '<span class="hline"></span>' : '' ?><span class="hnode <?= $st ?>"><i class="fa-solid fa-<?= $ic ?>"></i><?= t($lk) ?></span><?php endforeach; ?>
        </div>
        <?php if (!$hCnt['fail'] && !$hCnt['warn'] && $hRows): ?><div class="alert alert-success small py-2"><?= t('hl_all_ok') ?></div><?php endif; ?>
        <div class="small">
          <?php foreach ($hRows as $r): [$ri, $rc] = $hIc[$r['status']] ?? $hIc['skip']; $fl = $fixLink[$r['fix'] ?? ''] ?? ''; ?>
            <div class="hrow"><i class="fa-solid fa-<?= $ri ?> text-<?= $rc ?> mt-1"></i><div class="min-w-0 flex-grow-1"><b class="text-body-emphasis"><?= h(t('hc_' . $r['key'])) ?></b>
              <div class="text-secondary" style="word-break:break-word"><?= h($r['msg']) ?></div></div>
              <?php if (in_array($r['status'], ['fail', 'warn'], true) && $fl !== ''): ?><a class="btn btn-sm btn-outline-secondary align-self-center no-print" href="<?= h($fl) ?>"><i class="fa-solid fa-arrow-right"></i></a><?php endif; ?></div>
          <?php endforeach; if (!$hRows) echo '<p class="text-secondary mb-0">' . t('hl_never') . '</p>'; ?>
        </div>
        <?php if ($d['health_at']): ?><div class="small text-secondary mt-2"><?= t('hl_checked') ?>: <?= h(date('d M H:i:s', strtotime($d['health_at']))) ?></div><?php endif; ?>
      </div></div>
    <?php
    // ---------------- Omada auto-setup + Start provisioning ----------------
    $pstate = (string)($d['prov_state'] ?? '');
    $plog = json_decode((string)($d['prov_log'] ?? ''), true) ?: [];
    $apiOn = OmadaApi::canApi($ctl);
    $stColor = ['done' => 'success', 'ready' => 'primary', 'provisioning' => 'info', 'partial' => 'warning', 'manual' => 'secondary'][$pstate] ?? 'secondary';
    $stIcon = ['ok' => ['circle-check', 'text-success'], 'fail' => ['circle-xmark', 'text-danger'], 'skip' => ['circle-minus', 'text-secondary'], 'warn' => ['triangle-exclamation', 'text-warning']];
    $pkgsAll = rows("SELECT id, name, price FROM hs_packages WHERE seller_id=? AND is_active=1 ORDER BY sort_order, price", 'i', $uid);
    $ctlRows = rows("SELECT id, name, sites_json, client_id, client_secret, base_url FROM hs_controllers WHERE user_id=? ORDER BY id", 'i', $uid);
    $curLink = $d['controller_id'] ? (int)$d['controller_id'] . '|' . (string)$d['omada_site_id'] : '';
    [$pu] = OmadaProvision::deviceCreds($d);
    $infP = parseInformUrl($inform);
    ?>
    <style>.pstep{display:flex;align-items:center;gap:.45rem;color:var(--muted);font-size:.78rem;font-weight:600}.pstep i{width:30px;height:30px;border-radius:50%;display:grid;place-items:center;border:1px solid var(--line-2);background:var(--surface);font-size:.8rem}
    .pstep.on{color:var(--heading)}.pstep.on i{background:var(--brand-soft);color:var(--brand);border-color:var(--brand)}.pstep.done i{background:var(--ok);color:#fff;border-color:var(--ok)}.pstep.cur i{animation:pulse 2s infinite}
    .psep{flex:1;height:2px;background:var(--line-2);min-width:12px}.plog li{display:flex;gap:.55rem;padding:.42rem 0;border-bottom:1px solid var(--line)}.plog li:last-child{border-bottom:0}</style>
    <div class="card mb-3 border-primary-subtle" id="setup"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
      <span><i class="fa-solid fa-cloud me-2"></i><?= t('prov_title') ?></span>
      <span class="badge text-bg-<?= $stColor ?> px-3 py-2"><?= h($pstate !== '' ? t('prov_state_' . $pstate) : t('prov_state_new')) ?><?= $d['prov_at'] ? ' • ' . h(date('d M H:i', strtotime($d['prov_at']))) : '' ?></span></div>
      <div class="card-body">
        <?php if (!$apiOn && $isAdm): ?><div class="alert alert-danger small d-flex justify-content-between align-items-center flex-wrap gap-2"><span><i class="fa-solid fa-key me-2"></i><?= t('prov_api_alert') ?> <?= t('prov_need_keys') ?></span>
          <a class="btn btn-sm btn-danger" href="<?= $ctl ? '?page=controller&edit=' . (int)$ctl['id'] : '?page=radius' ?>"><i class="fa-solid fa-pen me-1"></i><?= t('edit') ?></a></div>
        <?php elseif (!$apiOn): ?><div class="alert alert-warning small"><i class="fa-solid fa-hourglass-half me-2"></i><?= t('ctrl_admin_pending') ?></div><?php endif; ?>
        <div class="row g-4">
        <div class="col-lg-7">
          <h6 class="mb-2"><i class="fa-solid fa-rocket me-2 text-primary"></i><?= t('prov_start') ?></h6>
          <ol class="small ps-3 mb-3">
            <li class="mb-1"><?= t('prov_step_power') ?></li>
            <li class="mb-1"><?= t('prov_step_inform') ?> <span class="text-secondary">(<?= t('inform_path') ?>)</span></li>
            <?php if (!$apiOn): ?><li class="mb-1"><?= t('prov_step_adopt') ?></li><li class="mb-1"><?= t('prov_step_copy') ?></li><?php endif; ?>
            <li><?= t('prov_step_press') ?></li>
          </ol>
          <div class="cfg mb-2"><?= cfgRow(t('inform_url'), $inform, $infP && $infP['cloud'] ? 'Omada ID ' . $infP['omadac_id'] . ' • ' . strtoupper($infP['region']) : t('inform_hint')) ?></div>
          <?php if ($ctl && $isAdm): ?><form method="POST" class="mb-3 no-print"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_test"><input type="hidden" name="id" value="<?= (int)$ctl['id'] ?>"><input type="hidden" name="device_id" value="<?= (int)$d['id'] ?>"><input type="hidden" name="return" value="?page=hotspot&id=<?= (int)$d['id'] ?>#setup">
            <button class="btn btn-sm btn-outline-info"><i class="fa-solid fa-cloud me-1"></i><?= t('cloud_check') ?></button> <span class="small text-secondary"><?= h($ctl['name']) ?><?= $ctl['last_ok'] ? ' • ' . t('ctrl_last_ok') . ' ' . h(date('d M H:i', strtotime($ctl['last_ok']))) : '' ?></span></form>
          <?php elseif ($ctl): ?><div class="small text-secondary mb-3"><i class="fa-solid fa-shield-halved me-1"></i><?= t('ctrl_managed_by_admin') ?></div>
          <?php elseif ($isAdm): ?><div class="alert alert-warning small py-2 no-print"><?= t('ctrl_not_linked') ?> <a href="?page=routers&edit=<?= (int)$d['id'] ?>"><?= t('edit_router') ?> →</a></div><?php endif; ?>
          <div class="d-flex align-items-center gap-1 mb-3" id="provSteps">
            <?php foreach (['waiting' => 'satellite-dish', 'adopting' => 'hand-holding', 'provisioning' => 'gears', 'connected' => 'wifi'] as $ph => $ic): ?>
              <?= $ph !== 'waiting' ? '<span class="psep"></span>' : '' ?><span class="pstep <?= $pstate === 'done' ? 'on done' : '' ?>" data-ph="<?= $ph ?>"><i class="fa-solid fa-<?= $ic ?>"></i><span class="d-none d-sm-inline"><?= t('pph_' . $ph) ?></span></span>
            <?php endforeach; ?>
          </div>
          <div class="row g-2 align-items-end no-print">
            <div class="col-sm-4<?= $apiOn ? '' : ' d-none' ?>"><label class="form-label small"><?= t('dev_user') ?></label><input id="pvU" class="form-control form-control-sm" value="<?= h($pu) ?>" autocomplete="off"></div>
            <div class="col-sm-4<?= $apiOn ? '' : ' d-none' ?>"><label class="form-label small"><?= t('dev_pass') ?></label><input id="pvP" type="password" class="form-control form-control-sm" placeholder="admin" autocomplete="new-password"></div>
            <div class="<?= $apiOn ? 'col-sm-4' : 'col-12' ?>"><button type="button" class="btn btn-success w-100<?= $apiOn ? '' : ' py-2' ?>" id="provBtn"><i class="fa-solid fa-play me-1"></i><?= t('prov_start') ?></button></div>
          </div>
          <div class="small mt-2 text-secondary" id="provMsg" role="status" aria-live="polite"><?= $pstate === 'done' ? h($apiOn ? t('prov_done') : t('prov_done_radius')) : t('prov_start_help') ?></div>
        </div>
        <div class="col-lg-5">
          <h6 class="mb-2"><i class="fa-solid fa-list-check me-2 text-primary"></i><?= t('prov_log') ?></h6>
          <?php if ($plog): ?><ul class="list-unstyled plog small mb-3">
            <?php foreach ($plog as $l): [$li, $lc] = $stIcon[$l['status'] ?? 'skip'] ?? $stIcon['skip']; ?>
              <li><i class="fa-solid fa-<?= $li ?> <?= $lc ?> mt-1"></i><div class="min-w-0"><b class="text-body-emphasis"><?= h(t('pstep_' . ($l['step'] ?? ''))) ?></b><div class="text-secondary" style="word-break:break-word"><?= h($l['msg'] ?? '') ?></div></div></li>
            <?php endforeach; ?></ul>
          <?php else: ?><p class="small text-secondary"><?= t('prov_never') ?></p><?php endif; ?>
          <details class="no-print" <?= !$plog ? 'open' : '' ?>><summary class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-wand-magic-sparkles me-1"></i><?= t('prov_run_again') ?></summary>
            <form method="POST" class="row g-2 mt-2" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="prov_run"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
              <?php if ($isAdm): ?><div class="col-12"><select name="omada_link" class="form-select form-select-sm">
                <?php foreach ($ctlRows as $cr): $sites = json_decode((string)$cr['sites_json'], true) ?: []; ?>
                  <?php $mine = (int)$d['controller_id'] === (int)$cr['id'] && (string)$d['omada_site_id'] !== '';
                        $inList = $mine && in_array((string)$d['omada_site_id'], array_column($sites, 'id'), true); ?>
                  <option value="<?= (int)$cr['id'] ?>|" <?= ($mine && !$inList) || $curLink === (int)$cr['id'] . '|' ? 'selected' : '' ?>><?= h($cr['name']) ?> — <?= $mine ? h(t('omada_site_keep') . ' (' . ($d['site_name'] ?: $d['omada_site_id']) . ')') : (OmadaApi::canApi($cr) ? t('omada_site_new') : h(t('ctrl_inform_only_badge'))) ?></option>
                  <?php foreach ($sites as $s): $v = (int)$cr['id'] . '|' . $s['id']; ?><option value="<?= h($v) ?>" <?= $curLink === $v ? 'selected' : '' ?>><?= h($cr['name'] . ' / ' . $s['name']) ?></option><?php endforeach; ?>
                <?php endforeach; ?></select></div><?php endif; ?>
              <div class="col-7"><input name="omada_sn" class="form-control form-control-sm mono" value="<?= h($d['omada_sn'] ?? '') ?>" placeholder="S/N"></div>
              <div class="col-5"><input name="omada_site_name" class="form-control form-control-sm" placeholder="<?= h(t('omada_site_name')) ?>"></div>
              <div class="col-6"><input name="dev_user" class="form-control form-control-sm" value="<?= h($pu) ?>" placeholder="<?= h(t('dev_user')) ?>"></div>
              <div class="col-6"><input name="dev_pass" type="password" class="form-control form-control-sm" placeholder="<?= h(t('dev_pass')) ?>"></div>
              <div class="col-12"><select name="voucher_mode" class="form-select form-select-sm"><option value="radius"><?= t('vm_radius') ?></option><option value="omada" <?= ($d['voucher_mode'] ?? '') === 'omada' ? 'selected' : '' ?>><?= t('vm_omada') ?></option></select></div>
              <div class="col-8"><select name="prov_pkg" class="form-select form-select-sm"><option value="0"><?= t('prov_pkg_none') ?></option><option value="starter"><?= t('prov_pkg_starter') ?></option>
                <?php foreach ($pkgsAll as $p): ?><option value="<?= (int)$p['id'] ?>"><?= h($p['name']) ?> — <?= money($p['price']) ?></option><?php endforeach; ?></select></div>
              <div class="col-4"><input type="number" name="prov_qty" min="0" max="500" value="0" class="form-control form-control-sm" title="<?= h(t('prov_qty')) ?>"></div>
              <div class="col-12"><button class="btn btn-sm btn-primary w-100"><i class="fa-solid fa-wand-magic-sparkles me-1"></i><?= t('prov_run_again') ?></button></div>
            </form></details>
          <?php if (($d['voucher_mode'] ?? '') === 'omada' && $apiOn && $d['omada_site_id'] && $pkgsAll): ?>
            <form method="POST" class="row g-2 mt-3 no-print" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="omada_vouchers"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
              <div class="col-12 small fw-semibold text-body-emphasis"><i class="fa-solid fa-ticket me-1 text-primary"></i><?= t('omada_vouchers_gen') ?></div>
              <div class="col-7"><select name="package_id" class="form-select form-select-sm"><?php foreach ($pkgsAll as $p): ?><option value="<?= (int)$p['id'] ?>"><?= h($p['name']) ?></option><?php endforeach; ?></select></div>
              <div class="col-2"><input type="number" name="quantity" min="1" max="500" value="20" class="form-control form-control-sm"></div>
              <div class="col-3"><button class="btn btn-sm btn-success w-100"><?= t('generate') ?></button></div>
            </form>
          <?php endif; ?>
        </div>
      </div></div>
    </div>
    <script>
    (function(){
      const ID=<?= (int)$d['id'] ?>, CSRF=<?= json_encode(csrf_token()) ?>, PH=['waiting','adopting','provisioning','connected'];
      const L={start:<?= json_encode(t('prov_start')) ?>,stop:<?= json_encode(t('prov_stop')) ?>,stopped:<?= json_encode(t('prov_stopped')) ?>,net:<?= json_encode(t('prov_net_retry')) ?>};
      const B=document.getElementById('provBtn'),M=document.getElementById('provMsg'),U=document.getElementById('pvU'),P=document.getElementById('pvP');
      if(!B)return;let timer=null,n=0,running=false;
      function mark(ph){const j=PH.indexOf(ph);document.querySelectorAll('#provSteps [data-ph]').forEach(el=>{const i=PH.indexOf(el.dataset.ph);
        el.classList.toggle('on',j>=0&&i<=j);el.classList.toggle('cur',running&&i===j&&ph!=='connected');el.classList.toggle('done',ph==='connected')})}
      function stop(msg){running=false;clearTimeout(timer);B.innerHTML='<i class="fa-solid fa-play me-1"></i>'+L.start;B.classList.replace('btn-outline-danger','btn-success');
        document.querySelectorAll('#provSteps .cur').forEach(e=>e.classList.remove('cur'));if(msg)M.textContent=msg}
      function tick(){const fd=new FormData();fd.append('csrf',CSRF);fd.append('id',ID);
        if(n===0){fd.append('dev_user',U.value);fd.append('dev_pass',P.value)}
        fetch('?ajax=prov_step',{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).then(d=>{
          if(!running)return;M.textContent=d.msg||'';M.className='small mt-2 '+(d.phase==='connected'?'text-success fw-semibold':(['error','need_login','offline'].includes(d.phase)?'text-danger':'text-secondary'));
          mark(d.phase);n++;
          if(d.done){stop();if(d.phase==='connected')setTimeout(()=>location.reload(),3000);return}
          if(d.need_login){stop();P.focus();return}
          if(n>180){stop(L.stopped);return}
          timer=setTimeout(tick,d.phase==='waiting'?8000:5000)}).catch(()=>{if(!running)return;M.textContent=L.net;timer=setTimeout(tick,10000)})}
      B.addEventListener('click',()=>{if(running){stop(L.stopped);return}running=true;n=0;B.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>'+L.stop;
        B.classList.replace('btn-success','btn-outline-danger');mark('waiting');tick()});
      if(location.hash==='#setup')document.getElementById('setup').scrollIntoView({behavior:'smooth'});
      // v6.1: Add router → provisioning starts by itself (adopts the EAP225 as soon as it reports PENDING)
      if(<?= $apiOn && $pstate !== 'done' ? 'true' : 'false' ?>&&new URLSearchParams(location.search).get('autostart')==='1'){setTimeout(()=>{if(!running)B.click()},700);
        try{history.replaceState(null,'',location.href.replace(/&autostart=1/,''))}catch(e){}}
    })();
    </script>
    <?php if ($apiOn && (string)$d['omada_site_id'] !== ''):
        // v5.6 — phones on this EAP225, live from the Omada controller (Open API)
        $apApi = new OmadaApi($ctl);
        $prevDl = OmadaApi::$deadline; OmadaApi::$deadline = microtime(true) + 12;
        try { $apClients = $apApi->clientList((string)$d['omada_site_id'], (string)$d['ap_mac']); $apErr = $apApi->error; }
        catch (Throwable $ex) { $apClients = []; $apErr = $ex->getMessage(); }
        OmadaApi::$deadline = $prevDl; ?>
    <div class="card mb-3 no-print"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="fa-solid fa-users me-2"></i><?= t('omada_ap_clients') ?> (<?= count($apClients) ?>)</span>
      <a href="?page=hotspot&id=<?= (int)$d['id'] ?>" class="small" aria-label="Refresh"><i class="fa-solid fa-rotate"></i></a></div><div class="card-body">
      <?php if ($apErr !== '' && !$apClients): ?><div class="alert alert-warning small mb-0"><?= h($apErr) ?></div>
      <?php else: echo omadaClientTable($apClients, (int)$ctl['id'], (string)$d['omada_site_id'], '?page=hotspot&id=' . (int)$d['id'], (int)$uid); endif; ?>
    </div></div>
    <?php endif; ?>
    <?php // v6.3 — seller: several WiFi names (SSIDs) for this router
        $xs = json_decode((string)($d['extra_ssids'] ?? ''), true) ?: [];
        $xsIds = []; foreach ($xs as $x) if (is_array($x)) $xsIds[(string)($x['id'] ?? '')] = $x;
        $siteSsids = []; $ssErr = '';
        if ($apiOn && (string)$d['omada_site_id'] !== '') {
            $prevDl = OmadaApi::$deadline; OmadaApi::$deadline = microtime(true) + 12;
            try { $ssApi = new OmadaApi($ctl); $siteSsids = $ssApi->allSsids((string)$d['omada_site_id']); $ssErr = $ssApi->error; }
            catch (Throwable $ex) { $ssErr = $ex->getMessage(); }
            OmadaApi::$deadline = $prevDl;
        } ?>
    <div class="card mb-3 no-print" id="ssids"><div class="card-header"><i class="fa-solid fa-wifi me-2"></i><?= t('my_ssids') ?> (<?= count($siteSsids) ?>)</div><div class="card-body">
      <p class="small text-secondary"><?= t('ssid_add_help') ?></p>
      <?php if (!$apiOn || (string)$d['omada_site_id'] === ''): ?><div class="alert alert-warning small mb-0"><?= t('ssid_need_setup') ?></div>
      <?php else: ?>
        <?php if ($ssErr !== '' && !$siteSsids): ?><div class="alert alert-warning small"><?= h($ssErr) ?></div><?php endif; ?>
        <?php foreach ($siteSsids as $x): $isMain = $x['ssid_id'] === (string)$d['omada_ssid_id'] || (!$d['omada_ssid_id'] && $x['name'] === $d['ssid']); $xx = $xsIds[$x['ssid_id']] ?? null; ?>
          <div class="d-flex justify-content-between align-items-center gap-2 border-bottom border-secondary-subtle py-2 small">
            <div class="min-w-0"><i class="fa-solid fa-<?= $x['security'] === 0 ? 'wifi' : 'lock' ?> me-2 text-<?= $x['security'] === 0 ? 'info' : 'primary' ?>"></i><b class="text-body-emphasis"><?= h($x['name']) ?></b>
              <?= $isMain ? '<span class="badge text-bg-success ms-1">' . t('ssid_main') . '</span>' : ($xx ? '<span class="badge text-bg-primary ms-1">' . t('ssid_extra') . '</span>' : '') ?>
              <span class="badge text-bg-<?= $x['security'] === 0 ? 'info' : 'secondary' ?> ms-1"><?= $x['security'] === 0 ? t('ssid_type_hotspot') : t('ssid_type_private') ?></span>
              <span class="text-secondary ms-1"><?= h([1 => '2.4 GHz', 2 => '5 GHz', 3 => '2.4 + 5 GHz'][$x['band']] ?? '') ?></span></div>
            <?php if (!$isMain): ?><form method="POST" onsubmit="return confirm('<?= h(t('delete')) ?> SSID <?= h(addslashes($x['name'])) ?>?')"><?= csrf_field() ?><input type="hidden" name="act" value="router_ssid_delete"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><input type="hidden" name="ssid" value="<?= h($x['ssid_id']) ?>"><button class="btn btn-sm btn-outline-danger" aria-label="<?= t('delete') ?>"><i class="fa-solid fa-trash"></i></button></form><?php endif; ?>
          </div>
        <?php endforeach; if (!$siteSsids && $ssErr === '') echo '<p class="text-secondary small">' . t('ssid_none') . '</p>'; ?>
        <form method="POST" class="row g-2 align-items-end mt-2" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="router_ssid_create"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
          <div class="col-12 small fw-semibold text-body-emphasis"><i class="fa-solid fa-plus me-1 text-primary"></i><?= t('ssid_new') ?></div>
          <div class="col-md-4"><label class="form-label small">SSID</label><input name="name" class="form-control form-control-sm" maxlength="32" required placeholder="SKY WIFI 2"></div>
          <div class="col-md-3"><label class="form-label small"><?= t('ssid_type') ?></label><select name="type" class="form-select form-select-sm" onchange="this.form.psk.closest('div').classList.toggle('d-none',this.value!=='private');this.form.psk.required=this.value==='private'">
            <option value="hotspot"><?= t('ssid_type_hotspot') ?></option><option value="private"><?= t('ssid_type_private') ?></option></select></div>
          <div class="col-md-2 d-none"><label class="form-label small"><?= t('ssid_pass') ?></label><input name="psk" type="password" class="form-control form-control-sm" minlength="8" maxlength="63" autocomplete="new-password"></div>
          <div class="col-md-2"><label class="form-label small"><?= t('ssid_band') ?></label><select name="band" class="form-select form-select-sm"><option value="3">2.4 + 5 GHz</option><option value="1">2.4 GHz</option><option value="2">5 GHz</option></select></div>
          <div class="col-md-3"><button class="btn btn-sm btn-primary w-100"><i class="fa-solid fa-plus me-1"></i><?= t('save') ?></button></div>
        </form>
      <?php endif; ?>
    </div></div>
    <div id="sheetTop"></div>
    <div class="alert alert-info small"><i class="fa-solid fa-circle-info me-2"></i><?= $apiOn && !in_array($pstate, ['', 'manual', 'failed'], true) ? t('omada_intro_auto') : t('omada_intro') ?></div>

    <div class="row g-3">
      <div class="col-xl-7">
        <div class="card mb-3"><div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2"><span class="d-flex align-items-center"><span class="step-n">0</span><?= t('step_adopt') ?></span>
          <?php if ($ctl): ?><span class="d-flex gap-1 no-print">
            <form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_sync"><input type="hidden" name="id" value="<?= (int)$ctl['id'] ?>"><input type="hidden" name="return" value="?page=hotspot&id=<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-rotate me-1"></i><?= t('ctrl_check_now') ?></button></form>
            <?php if ($d['omada_site_id']): ?>
            <form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="device_omada_cmd"><input type="hidden" name="cmd" value="locate"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-info" title="Locate (LED)"><i class="fa-solid fa-lightbulb"></i></button></form>
            <form method="POST" onsubmit="return confirm('Reboot <?= h($d['device_name']) ?>?')"><?= csrf_field() ?><input type="hidden" name="act" value="device_omada_cmd"><input type="hidden" name="cmd" value="reboot"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-warning" title="Reboot"><i class="fa-solid fa-power-off"></i></button></form>
            <?php endif; ?></span><?php endif; ?></div><div class="card-body">
          <?php if (!$myCtrls): ?>
            <div class="alert alert-warning small mb-3"><?= $isAdm ? t('ctrl_connect_first') . ' <a href="?page=controller">' . t('omada_controller') . ' →</a>' : t('ctrl_admin_pending') ?></div>
          <?php elseif (!$ctl): ?>
            <div class="alert alert-warning small mb-3"><?= $isAdm ? t('ctrl_not_linked') . ' <a href="?page=routers&edit=' . (int)$d['id'] . '">' . t('edit') . ' →</a>' : t('ctrl_admin_pending') ?></div>
          <?php else: ?>
            <div class="small mb-3"><span class="text-secondary"><?= t('omada_controller') ?>:</span> <?php if ($isAdm): ?><a href="?page=controller&id=<?= (int)$ctl['id'] ?><?= $d['omada_site_id'] ? '&site=' . urlencode($d['omada_site_id']) : '' ?>"><b><?= h($ctl['name']) ?></b></a> • <span class="mono"><?= h($ctl['base_url']) ?></span><?php else: ?><b><?= t('ctrl_linked_auto') ?></b><?php endif; ?>
              <?php if ($d['omada_model'] || $d['omada_ip']): ?><br><span class="text-secondary">AP:</span> <?= h($d['omada_model']) ?> • <span class="mono"><?= h($d['omada_ip']) ?></span> • FW <?= h($d['omada_fw']) ?><?= $d['omada_uptime'] ? ' • up ' . h($d['omada_uptime']) : '' ?><?php endif; ?>
              <?php if ($ctl['last_error'] && $isAdm): ?><br><span class="text-danger"><i class="fa-solid fa-triangle-exclamation me-1"></i><?= h($ctl['last_error']) ?></span><?php endif; ?></div>
            <?php if (in_array($d['omada_status'], ['pending', 'adopt_failed', 'managed_by_others'], true) && $d['omada_site_id']): ?>
              <form method="POST" class="row g-2 align-items-end mb-3 no-print"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_adopt"><input type="hidden" name="id" value="<?= (int)$ctl['id'] ?>"><input type="hidden" name="site" value="<?= h($d['omada_site_id']) ?>"><input type="hidden" name="mac" value="<?= h($d['ap_mac']) ?>"><input type="hidden" name="return" value="?page=hotspot&id=<?= (int)$d['id'] ?>">
                <div class="col-5"><label class="form-label small"><?= t('dev_user') ?></label><input name="dev_user" class="form-control form-control-sm" value="admin"></div>
                <div class="col-4"><label class="form-label small"><?= t('dev_pass') ?></label><input name="dev_pass" type="password" class="form-control form-control-sm" placeholder="admin"></div>
                <div class="col-3"><button class="btn btn-sm btn-success w-100"><i class="fa-solid fa-hand-holding me-1"></i><?= t('ctrl_adopt') ?></button></div>
              </form>
            <?php endif; ?>
          <?php endif; ?>
          <div class="cfg-path"><i class="fa-solid fa-route me-1"></i><?= t('inform_path') ?></div>
          <div class="cfg">
            <?= cfgRow(t('inform_url'), $inform, t('inform_hint')) ?>
            <?= cfgFixed(t('inform_ports'), 'UDP 29810 • TCP 29811–29817', t('inform_ports_hint')) ?>
            <?= cfgFixed(t('dev_user') . ' / ' . t('dev_pass'), 'admin / admin', t('dev_default_hint')) ?>
          </div>
        </div></div>

        <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">1</span><?= t('step_profile') ?></div><div class="card-body">
          <div class="cfg-path"><i class="fa-solid fa-route me-1"></i>Omada → Settings → Profiles → RADIUS Profile → + Create New RADIUS Profile</div>
          <div class="cfg">
            <?= cfgRow('Name', $c['profile']) ?>
            <?= cfgFixed('VLAN Assignment', 'Off') ?>
            <?= cfgRow(t('radius_server_ip'), $c['server_ip'], 'Authentication Server IP') ?>
            <?= cfgRow(t('auth_port'), $c['auth_port'], t('fixed_port')) ?>
            <?= cfgRow(t('auth_password'), $c['auth_secret'], '', true) ?>
            <?= cfgFixed('RADIUS Accounting', 'Enable') ?>
            <?= cfgFixed('Interim Update', 'Enable — ' . $c['interim'] . ' s') ?>
            <?= cfgRow(t('acct_server_ip'), $c['acct_ip']) ?>
            <?= cfgRow(t('acct_port'), $c['acct_port'], t('fixed_port')) ?>
            <?= cfgRow(t('acct_password'), $c['acct_secret'], '', true) ?>
          </div>
        </div></div>

        <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">2</span><?= t('step_portal') ?></div><div class="card-body">
          <div class="cfg-path"><i class="fa-solid fa-route me-1"></i>Omada → Settings → Authentication → Portal → + Create New Portal</div>
          <div class="cfg">
            <?= cfgRow('Portal Name', $c['portal_name']) ?>
            <?= cfgFixed('SSID & Network', $d['ssid'] ?: 'your hotspot SSID') ?>
            <?= cfgFixed('Authentication Type', 'External RADIUS Server') ?>
            <?= cfgFixed('RADIUS Profile', $c['profile']) ?>
            <?php if ($c['nas_id'] !== ''): ?>
              <?= cfgRow(t('nas_id'), $c['nas_id'], t('nas_learned') . ($d['nas_learned_at'] ? ' • ' . date('d M H:i', strtotime($d['nas_learned_at'])) : '') . ' — ' . t('nas_keep_hint')) ?>
            <?php else: ?>
              <?= cfgFixed(t('nas_id'), t('nas_auto'), t('nas_auto_hint')) ?>
            <?php endif; ?>
            <?= cfgFixed('Authentication Mode', 'PAP', 'CHAP also works') ?>
            <?= cfgFixed('Disconnect Requests', 'Enable — Receiver Port ' . $c['dae_port'], 'Optional: lets you kick a user instantly') ?>
            <?= cfgFixed('Authentication Timeout', 'Custom — at least your longest package', 'RADIUS Session-Timeout still ends each session on time') ?>
            <?= cfgFixed('Portal Customization', 'External Web Portal') ?>
            <?= cfgRow('External Web Portal URL', $c['portal_url']) ?>
            <?= cfgFixed('Landing Page', 'The Original URL') ?>
          </div>
        </div></div>

        <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">3</span><?= t('step_preauth') ?></div><div class="card-body">
          <div class="cfg-path"><i class="fa-solid fa-route me-1"></i>Portal → Access Control → Pre-Authentication Access → Enable → + Add</div>
          <div class="cfg">
            <?= cfgRow('URL', $host, 'Type: URL') ?>
            <?php if ($hostIp): ?><?= cfgRow('IP Range', $hostIp . '/32', 'Type: IP Range') ?><?php endif; ?>
          </div>
        </div></div>

        <div class="card mb-3"><div class="card-header d-flex align-items-center"><span class="step-n">4</span><?= t('step_test') ?></div><div class="card-body small">
          <ol class="mb-0 ps-3">
            <li class="mb-2">Connect a phone to <b><?= h($d['ssid'] ?: 'SSID') ?></b> — the portal opens (if not, open <span class="mono">http://neverssl.com</span>).</li>
            <li class="mb-2">Enter a voucher (make one under <a href="?page=vouchers"><?= t('vouchers') ?></a>) → <?= t('p_connect') ?>.</li>
            <li class="mb-1">The request appears under "<?= t('radius_activity') ?>", the NAS ID from Omada is saved, and the phone shows under <a href="?page=sessions&device=<?= (int)$d['id'] ?>"><?= t('sessions') ?></a>.</li>
          </ol>
          <?php if ($auth->isAdmin() && $c['server_ip'] !== ''): $rt = 'echo "User-Name=VOUCHER,User-Password=VOUCHER,NAS-Identifier=' . ($c['nas_id'] !== '' ? $c['nas_id'] : $c['key']) . '" | radclient -x ' . $c['server_ip'] . ':' . $c['auth_port'] . ' auth ' . $c['auth_secret']; ?>
            <div class="mt-3 text-secondary">Admin — test from any Linux box (<span class="mono">apt install freeradius-utils</span>):</div>
            <div class="input-group input-group-sm mt-1"><input id="rtest" class="form-control mono" value="<?= h($rt) ?>" readonly><button type="button" class="btn btn-outline-primary" onclick="cp('rtest',this)"><i class="fa-regular fa-copy"></i></button></div>
          <?php endif; ?>
        </div></div>
      </div>

      <div class="col-xl-5">
        <?php $pruns = ProvisionLog::forDevice((int)$d['id'], 12); ?>
        <div class="card mb-3"><div class="card-header"><i class="fa-solid fa-clock-rotate-left me-2"></i><?= t('prov_history') ?></div><div class="card-body p-2" style="max-height:320px;overflow:auto">
          <?php foreach ($pruns as $pr): $pbad = in_array($pr['phase'], ['error', 'fail', 'failed', 'need_login', 'offline', 'partial'], true); $pgood = in_array($pr['phase'], ['connected', 'ok', 'ready', 'done'], true); ?>
            <div class="d-flex justify-content-between gap-2 border-bottom border-secondary-subtle py-2 px-1 small">
              <div class="min-w-0"><b class="text-body-emphasis"><?= h(t('pa_' . $pr['action'])) ?></b><?php if ($pr['phase'] !== null && $pr['phase'] !== ''): ?> <span class="badge text-bg-<?= $pbad ? 'danger' : ($pgood ? 'success' : 'secondary') ?>"><?= h($pr['phase']) ?></span><?php endif; ?>
                <div class="text-secondary" style="word-break:break-word"><?= h($pr['message']) ?></div></div>
              <span class="text-secondary text-nowrap"><?= h(date('d M H:i', strtotime($pr['created_at']))) ?></span></div>
          <?php endforeach; if (!$pruns) echo '<p class="text-secondary m-2 small">' . t('no_data') . '</p>'; ?>
        </div></div>

        <div class="card mb-3"><div class="card-header"><i class="fa-solid fa-list me-2"></i><?= t('radius_activity') ?></div><div class="card-body p-2" style="max-height:420px;overflow:auto">
          <?php foreach ($logs as $l): ?><div class="d-flex justify-content-between gap-2 border-bottom border-secondary-subtle py-2 px-1 small">
            <div style="min-width:0"><span class="badge text-bg-<?= $l['result'] === 'accept' || $l['result'] === 'ok' ? 'success' : 'danger' ?>"><?= h($l['kind'] . ' ' . $l['result']) ?></span> <span class="mono"><?= h($l['username']) ?></span>
              <div class="text-secondary text-truncate"><?= h($l['message']) ?></div></div>
            <span class="text-secondary text-nowrap"><?= h(date('d M H:i', strtotime($l['created_at']))) ?></span></div>
          <?php endforeach; if (!$logs) echo '<p class="text-secondary m-2 small">' . t('waiting_contact') . '</p>'; ?>
        </div></div>

        <div class="card mb-3 no-print"><div class="card-header"><i class="fa-solid fa-screwdriver-wrench me-2"></i><?= t('troubleshoot') ?></div><div class="card-body small">
          <?php $tips = [
              ['Portal does not open', 'Check step 3 (Pre-Authentication Access) and that the External Web Portal URL is exact.'],
              ['"Portal is not linked to the controller"', 'Set the Controller Portal URL on the device form (e.g. http://192.168.0.10:8088).'],
              ['Login spins then fails, nothing in RADIUS activity', 'Omada cannot reach the RADIUS server: check RADIUS Server IP, UDP 1812/1813 in the firewall, and the server status above.'],
              ['"Hotspot not registered" or NAS ID never appears', 'The NAS ID does not need to match — it is read from Omada. If nothing arrives, the Authentication Password or RADIUS Server IP is wrong.'],
              ['"Password unreadable" or a red warning above', 'The Authentication/Accounting Password in the RADIUS Profile is wrong — copy it again.'],
              ['Time/data not counting', 'Enable RADIUS Accounting + Interim Update in the RADIUS Profile.'],
          ];
          foreach ($tips as [$q, $a]): ?><div class="mb-3"><b class="text-body-emphasis"><?= h($q) ?></b><div class="text-secondary"><?= h($a) ?></div></div><?php endforeach; ?>
        </div></div>

        <div class="card border-warning-subtle no-print"><div class="card-header"><i class="fa-solid fa-rotate me-2"></i><?= t('regen_secrets') ?></div><div class="card-body small">
          <p class="text-secondary"><?= t('regen_help') ?><?= $d['secrets_rotated_at'] ? '<br>' . t('date') . ': ' . h(date('d M Y H:i', strtotime($d['secrets_rotated_at']))) : '' ?></p>
          <form method="POST" onsubmit="return confirm(<?= h(json_encode(t('regen_confirm'))) ?>)"><?= csrf_field() ?><input type="hidden" name="act" value="device_regen"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="btn btn-sm btn-outline-warning"><i class="fa-solid fa-rotate me-1"></i><?= t('regen_secrets') ?></button></form>
        </div></div>
      </div>
    </div>
    <script>window.addEventListener('beforeprint',()=>document.querySelectorAll('.cfg input[type=password]').forEach(i=>i.type='text'))</script>
    <?php break;

case 'controller':
    $auth->requireAdmin();   // v6.2: admin only
    $uid = (int)$user['id'];
    $ctrls = rows("SELECT c.*, (SELECT COUNT(*) FROM hs_devices d WHERE d.controller_id=c.id) AS hotspots,
                          (SELECT COUNT(*) FROM hs_devices d WHERE d.controller_id=c.id AND d.omada_status='connected') AS connected
                   FROM hs_controllers c WHERE c.user_id=? ORDER BY c.id", 'i', $uid);
    $editC = isset($_GET['edit']) ? row("SELECT * FROM hs_controllers WHERE id=? AND user_id=?", 'ii', (int)$_GET['edit'], $uid) : null;
    $cur = isset($_GET['id']) ? OmadaApi::load((int)$_GET['id'], $uid) : null;
    $e = $editC ?? ['id' => 0, 'name' => '', 'ctype' => 'local', 'base_url' => '', 'omadac_id' => '', 'client_id' => '', 'inform_url' => '', 'verify_ssl' => 0, 'conn_mode' => 'auto', 'shared_keys' => 0];
    if ($editC && (parseInformUrl((string)$e['inform_url'])['cloud'] ?? false)) $e['inform_url'] = '';   // v6.1: no Omada Cloud
    $relayOn = OmadaRelay::alive();
    $routeBadge = function (array $c) use ($relayOn): string {   // v5.9 — how the website reaches this controller
        $r = OmadaRelay::routeOf($c);
        $mode = (string)($c['conn_mode'] ?? 'auto');
        if ($r === 'relay') return ' <span class="badge text-bg-' . ($relayOn ? 'info' : 'danger') . '" title="' . h(t('route_' . $mode)) . '"><i class="fa-solid fa-server me-1"></i>' . h(t('route_relay')) . ($relayOn ? '' : ' • ' . h(t('server_offline'))) . '</span>';
        return ' <span class="badge text-bg-secondary" title="' . h(t('route_' . $mode)) . '"><i class="fa-solid fa-arrow-right me-1"></i>' . h(t('route_direct')) . '</span>';
    };
    $myDevs = [];
    foreach (rows("SELECT id, ap_mac, device_name, controller_id FROM hs_devices WHERE user_id=?", 'i', $uid) as $r) $myDevs[$r['ap_mac']] = $r;
    ?>
    <div class="alert alert-info small"><i class="fa-solid fa-circle-info me-2"></i><?= t('ctrl_intro') ?></div>
    <?php $cloudRows = array_values(array_filter($ctrls, fn($c) => OmadaRelay::isCloudHost((string)parse_url((string)$c['base_url'], PHP_URL_HOST)))); ?>
    <?php if ($cloudRows): ?><div class="alert alert-danger small"><i class="fa-solid fa-cloud-arrow-down me-2"></i><b><?= h(implode(', ', array_column($cloudRows, 'name'))) ?>:</b> <?= t('ctrl_cloud_unsupported') ?></div><?php endif; ?>
    <?php $needRelay = (bool)array_filter($ctrls, fn($c) => !OmadaRelay::isCloudHost((string)parse_url((string)$c['base_url'], PHP_URL_HOST)) && ($c['conn_mode'] ?? 'auto') !== 'direct'); ?>
    <?php if ($needRelay && !$relayOn): ?><div class="alert alert-warning small"><i class="fa-solid fa-server me-2"></i><b><?= t('relay_title') ?>: <?= t('server_offline') ?>.</b> <?= t('relay_off_help') ?><?= $auth->isAdmin() ? ' <a href="?page=radius">' . t('radius_setup') . ' →</a>' : '' ?></div><?php endif; ?>
    <?php $noKeyLocal = array_values(array_filter($ctrls, fn($c) => !OmadaApi::canApi($c) && !OmadaRelay::isCloudHost((string)parse_url((string)$c['base_url'], PHP_URL_HOST)))); ?>
    <?php if ($noKeyLocal): $c = $noKeyLocal[0]; ?>
      <div class="alert alert-primary small"><i class="fa-solid fa-key me-2"></i><b><?= h($c['name']) ?>:</b> <?= h(sprintf(t('ctrl_local_keys_steps'), rtrim((string)$c['base_url'], '/'))) ?></div>
    <?php endif; ?>
    <div class="row g-3">
      <div class="col-lg-5">
        <div class="card mb-3"><div class="card-header"><i class="fa-solid fa-plug me-2"></i><?= $editC ? t('ctrl_edit') : t('ctrl_add') ?></div><div class="card-body">
          <form method="POST" class="row g-3" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_save"><input type="hidden" name="id" value="<?= (int)$e['id'] ?>"><input type="hidden" name="ctype" value="local">
            <?php $hasKeys = $editC && OmadaApi::canApi($editC); ?>
            <div class="col-12"><label class="form-label small"><?= t('ctrl_name') ?></label><input name="name" class="form-control" value="<?= h($e['name']) ?>" placeholder="Omada Controller VPS"></div>
            <div class="col-12"><label class="form-label small fw-semibold"><?= t('ctrl_base') ?></label><input name="base_url" class="form-control mono" value="<?= h(OmadaRelay::isCloudHost((string)parse_url((string)$e['base_url'], PHP_URL_HOST)) ? '' : ($e['base_url'] !== '' ? omadaControllerBase((string)$e['base_url']) : (!$editC ? OMADA_CONTROLLER_URL : ''))) ?>" placeholder="<?= h(OMADA_CONTROLLER_URL) ?>" required><div class="form-text"><?= t('ctrl_base_help') ?></div></div>
            <div class="col-12"><label class="form-label small fw-semibold"><?= t('ctrl_omadac') ?></label><input name="omadac_id" class="form-control mono" value="<?= h($e['omadac_id']) ?>" placeholder="<?= h(t('ctrl_omadac_ph')) ?>"><div class="form-text"><?= t('ctrl_get_omadac') ?></div></div>
            <div class="col-12"><div class="p-3 rounded-3" style="border:1px dashed var(--line-2);background:var(--surface-2)">
              <div class="small fw-semibold text-body-emphasis mb-1"><i class="fa-solid fa-key me-1 text-primary"></i><?= t('ctrl_keys_title') ?><?= $hasKeys ? ' <span class="badge text-bg-success">' . h(t('ctrl_api_mode')) . '</span>' : '' ?></div>
              <div class="form-text mt-0 mb-2"><?= t('ctrl_keys_help') ?></div>
              <?php if (!empty($e['shared_keys'])): ?><div class="alert alert-success small py-2 mb-2"><i class="fa-solid fa-key me-1"></i><?= t('ctrl_shared_keys_note') ?></div><?php endif; ?>
              <div class="row g-2">
                <div class="col-md-6"><label class="form-label small"><?= t('ctrl_client_id') ?> *</label><input name="client_id" class="form-control form-control-sm mono" value="<?= empty($e['shared_keys']) ? h($e['client_id'] ?? '') : '' ?>" placeholder="<?= !empty($e['shared_keys']) ? h(t('ctrl_secret_keep')) : '' ?>" <?= !empty($e['shared_keys']) ? '' : 'required' ?> autocomplete="off" spellcheck="false"></div>
                <div class="col-md-6"><label class="form-label small"><?= t('ctrl_client_secret') ?> *</label><input name="client_secret" type="password" class="form-control form-control-sm mono" placeholder="<?= $hasKeys ? h(t('ctrl_secret_keep')) : '' ?>" <?= $hasKeys ? '' : 'required' ?> autocomplete="new-password" spellcheck="false"></div>
              </div>
            </div></div>
            <div class="col-12"><label class="form-label small"><?= t('ctrl_inform_paste') ?></label><input name="inform_url" class="form-control mono" value="<?= h($e['inform_url']) ?>" placeholder="169.58.93.38" oninput="informPreview(this,'cprev',true)"><div class="form-text" id="cprev"><?= t('ctrl_inform_paste_help') ?></div></div>
            <div class="col-12"><label class="form-label small fw-semibold"><?= t('route_label') ?></label><select name="conn_mode" class="form-select">
              <?php foreach (['auto', 'relay', 'direct'] as $cm): ?><option value="<?= $cm ?>" <?= ($e['conn_mode'] ?? 'auto') === $cm ? 'selected' : '' ?>><?= h(t('route_' . $cm)) ?></option><?php endforeach; ?></select>
              <div class="form-text"><?= t('route_help') ?> <?= $relayOn ? '<span class="text-success">' . h(t('relay_title')) . ': ' . h(t('server_online')) . '</span>' : '<span class="text-danger">' . h(t('relay_title')) . ': ' . h(t('server_offline')) . '</span>' ?></div></div>
            <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="verify_ssl" id="vs" <?= $e['verify_ssl'] ? 'checked' : '' ?>><label class="form-check-label small" for="vs"><?= t('ctrl_verify_ssl') ?></label></div></div>
            <div class="col-12 d-flex gap-2"><button class="btn btn-primary"><i class="fa-solid fa-floppy-disk me-1"></i><?= t('ctrl_save_test') ?></button><?php if ($editC): ?><a href="?page=controller" class="btn btn-outline-secondary"><?= t('cancel') ?></a><?php endif; ?></div>
          </form>
        </div></div>
        <div class="card"><div class="card-header"><i class="fa-solid fa-list-check me-2"></i><?= t('ctrl_howto') ?></div><div class="card-body small">
          <?php foreach (([
              'Install the <b>Omada Software Controller</b> (or OC200/OC300) on a VPS/PC with a public IP; open TCP 8043, UDP 29810 and TCP 29811-29817' . ($auth->isAdmin() ? ' (<a href="?page=omada_manager#vpskit">VPS kit</a>)' : '') . '.',
              'Omada → Global View → Settings → <b>Platform Integration → Open API</b> → Add New App (mode <b>Client</b>, role Administrator) → copy the <b>Client ID</b> + <b>Client Secret</b>.',
              '<b>Omada ID</b>: open <span class="mono">https://IP:8043/api/info</span> → <span class="mono">omadacId</span>.',
              'Paste the Controller URL, Omada ID, Client ID and Client Secret above → <b>Save & test</b>. On shared hosting the calls go through your RADIUS server (Omada relay).',
              'Menu <b>Routers → Add router</b>: site, SSID, RADIUS profile, portal, Pre-Authentication Access and vouchers are created in Omada automatically.',
              'On the EAP225 set <b>Controller Inform URL = controller IP</b>; <b>Provision & connect</b> adopts it automatically until Connected.',
          ]) as $i => $txt): ?><div class="d-flex mb-2"><span class="step-n"><?= $i + 1 ?></span><span><?= $txt ?></span></div><?php endforeach; ?>
        </div></div>
      </div>

      <div class="col-lg-7">
        <div class="card mb-3"><div class="card-header"><i class="fa-solid fa-server me-2"></i><?= t('omada_controller') ?> (<?= count($ctrls) ?>)</div><div class="card-body">
          <?php foreach ($ctrls as $c): $okc = $c['last_ok'] && (!$c['last_error'] || strtotime($c['last_ok']) > time() - 900); ?>
            <div class="border border-secondary-subtle rounded-4 p-3 mb-2" style="background:var(--surface-2)">
              <div class="d-flex justify-content-between flex-wrap gap-2">
                <div class="min-w-0"><span class="dot <?= $okc ? 'on' : 'off' ?>"></span><b class="text-body-emphasis"><?= h($c['name']) ?></b> <span class="badge text-bg-<?= $c['ctype'] === 'cloud' ? 'info' : 'primary' ?>"><?= $c['ctype'] === 'cloud' ? 'CLOUD' : 'LOCAL' ?></span><?= $c['controller_ver'] ? ' <span class="badge text-bg-secondary">v' . h($c['controller_ver']) . '</span>' : '' ?>
                  <?= OmadaApi::canApi($c) ? ' <span class="badge text-bg-success">Open API' . (!empty($c['shared_keys']) ? ' • ' . h(t('ctrl_shared_badge')) : '') . '</span>'
                      : ' <span class="badge text-bg-warning">' . h(OmadaRelay::isCloudHost((string)parse_url((string)$c['base_url'], PHP_URL_HOST)) ? t('ctrl_inform_only_badge') : t('ctrl_no_keys_badge')) . '</span>' ?><?= $routeBadge($c) ?>
                  <div class="small text-secondary mono mt-1 text-truncate"><?= h($c['base_url']) ?> • ID <?= h($c['omadac_id'] ?: '—') ?></div>
                  <div class="small mt-1"><?= t('inform_url') ?>: <span class="mono text-info"><?= h(informUrlOf($c) ?: '—') ?></span></div>
                  <div class="small text-secondary"><?= t('routers') ?>: <b class="text-body-emphasis"><?= OmadaApi::canApi($c) ? (int)$c['connected'] . '/' . (int)$c['hotspots'] . '</b> CONNECTED' : (int)$c['hotspots'] . '</b>' ?> • <?= t('ctrl_last_ok') ?>: <?= $c['last_ok'] ? h(date('d M H:i', strtotime($c['last_ok']))) : t('never') ?></div>
                  <?php if ($c['last_error']): ?><div class="small text-danger mt-1"><i class="fa-solid fa-triangle-exclamation me-1"></i><?= h($c['last_error']) ?></div><?php endif; ?>
                </div>
                <div class="d-flex gap-1 align-items-start flex-wrap">
                  <a class="btn btn-sm btn-primary" href="?page=controller&id=<?= (int)$c['id'] ?>"><i class="fa-solid fa-tower-broadcast me-1"></i><?= OmadaApi::canApi($c) ? t('ctrl_open') : t('routers') ?></a>
                  <form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_test"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><button class="btn btn-sm btn-outline-success" title="<?= h(t('cloud_check')) ?>"><i class="fa-solid fa-stethoscope"></i></button></form>
                  <?php if (OmadaApi::canApi($c)): ?><form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_sync"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><input type="hidden" name="return" value="?page=controller"><button class="btn btn-sm btn-outline-info" title="<?= h(t('ctrl_check_now')) ?>"><i class="fa-solid fa-rotate"></i></button></form>
                  <form method="POST" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_apicheck"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><input type="hidden" name="return" value="?page=controller"><button class="btn btn-sm btn-outline-warning" title="<?= h(t('ctrl_api_check')) ?>"><i class="fa-solid fa-list-check"></i></button></form><?php endif; ?>
                  <a class="btn btn-sm btn-outline-primary" href="?page=controller&edit=<?= (int)$c['id'] ?>" aria-label="<?= t('edit') ?>"><i class="fa-solid fa-pen"></i></a>
                  <form method="POST" onsubmit="return confirm('<?= h(t('confirm_delete')) ?>')"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><button class="btn btn-sm btn-outline-danger" aria-label="<?= t('delete') ?>"><i class="fa-solid fa-trash"></i></button></form>
                </div>
              </div>
            </div>
          <?php endforeach; if (!$ctrls) echo '<p class="text-secondary mb-0">' . t('no_data') . '</p>'; ?>
        </div></div>
      </div>
    </div>

    <?php if ($cur && !OmadaApi::canApi($cur->row())):
        // v5.5 — Omada Cloud linked by Inform URL only: show its Inform URL and the routers that use it
        $cr = $cur->row();
        $linked = rows("SELECT * FROM hs_devices WHERE user_id=? AND controller_id=? ORDER BY device_name", 'ii', $uid, (int)$cr['id']);
    ?>
    <div class="card mt-3"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
      <span><i class="fa-solid fa-cloud me-2"></i><?= h($cr['name']) ?> — <?= t('routers_linked') ?> (<?= count($linked) ?>)</span>
      <a href="?page=routers&add=1" class="btn btn-sm btn-primary"><i class="fa-solid fa-plus me-1"></i><?= t('add_router') ?></a></div><div class="card-body">
      <div class="alert alert-danger small d-flex justify-content-between align-items-center flex-wrap gap-2"><span><i class="fa-solid fa-key me-2"></i><?= t('ctrl_inform_only') ?></span><a class="btn btn-sm btn-danger" href="?page=controller&edit=<?= (int)$cr['id'] ?>"><?= t('edit') ?></a></div>
      <div class="cfg mb-3"><?= cfgRow(t('inform_url'), informUrlOf($cr), t('inform_hint')) ?><?= cfgFixed(t('inform_ports'), 'UDP 29810 • TCP 29811–29817', t('inform_ports_hint')) ?></div>
      <?php foreach ($linked as $ld): $lon = Device::isOnline($ld); ?>
        <div class="d-flex justify-content-between align-items-center gap-2 border-bottom border-secondary-subtle py-2 small">
          <div class="min-w-0"><span class="dot <?= $lon ? 'on' : 'off' ?>"></span><b class="text-body-emphasis"><?= h($ld['device_name']) ?></b> <span class="mono text-secondary"><?= h(dashMac($ld['ap_mac'])) ?></span> • <?= h($ld['site_name']) ?></div>
          <a class="btn btn-sm btn-success" href="?page=hotspot&id=<?= (int)$ld['id'] ?>#setup"><i class="fa-solid fa-plug me-1"></i><?= t('prov_start') ?></a></div>
      <?php endforeach; if (!$linked) echo '<p class="text-secondary mb-0">' . t('no_data') . '</p>'; ?>
    </div></div>
    <?php elseif ($cur):
        $cr = $cur->row();
        $sites = $cur->cachedSites() ?: $cur->sites();
        $siteSel = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($_GET['site'] ?? '')) ?: ($sites[0]['id'] ?? '');
        if (!$cur->siteAllowed($siteSel)) $siteSel = $sites[0]['id'] ?? '';   // v5.9: shared keys → own sites only
        $apList = $siteSel !== '' ? $cur->devices($siteSel) : [];
        $apErr = $cur->error;
        $aps = array_values(array_filter($apList, fn($x) => in_array($x['type'], ['ap', 'eap', ''], true)));
        $ret = '?page=controller&id=' . (int)$cr['id'] . '&site=' . urlencode($siteSel);
    ?>
    <div class="card mt-3"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
      <span><i class="fa-solid fa-tower-broadcast me-2"></i><?= h($cr['name']) ?> — <?= t('ctrl_aps') ?></span>
      <form method="GET" class="d-flex gap-2"><input type="hidden" name="page" value="controller"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>">
        <select name="site" class="form-select form-select-sm" onchange="this.form.submit()"><?php foreach ($sites as $s): ?><option value="<?= h($s['id']) ?>" <?= $s['id'] === $siteSel ? 'selected' : '' ?>><?= h($s['name']) ?></option><?php endforeach; if (!$sites) echo '<option value="">—</option>'; ?></select>
        <a href="<?= h($ret) ?>" class="btn btn-sm btn-outline-secondary" aria-label="Refresh"><i class="fa-solid fa-rotate"></i></a></form>
    </div><div class="card-body">
      <?php if ($apErr !== '' && !$apList): ?><div class="alert alert-danger small"><?= h($apErr) ?></div><?php endif; ?>
      <?php if ($aps): ?><div class="table-responsive"><table class="table table-sm table-hover mcard align-middle"><thead><tr><th><?= t('device_name') ?></th><th>MAC</th><th><?= t('status') ?></th><th>IP</th><th><i class="fa-solid fa-users"></i></th><th>FW</th><th></th></tr></thead><tbody>
      <?php foreach ($aps as $a): [$bl, $bc] = Device::omadaBadge($a['status']); $mine = $myDevs[$a['mac']] ?? null; $canAdopt = in_array($a['status'], ['pending', 'adopt_failed', 'managed_by_others'], true); ?>
        <tr><td data-label="<?= t('device_name') ?>"><b class="text-body-emphasis"><?= h($a['name'] ?: '—') ?></b><div class="small text-secondary"><?= h($a['model']) ?></div></td>
          <td data-label="MAC" class="mono small"><?= h(dashMac($a['mac'])) ?></td>
          <td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $bc ?>"><?= h($bl) ?></span></td>
          <td data-label="IP" class="mono small"><?= h($a['ip']) ?></td>
          <td data-label="Clients"><?= (int)$a['clients'] ?></td>
          <td data-label="FW" class="small"><?= h($a['fw']) ?></td>
          <td class="text-nowrap">
            <?php if ($canAdopt): ?>
              <details class="d-inline-block text-start"><summary class="btn btn-sm btn-success"><i class="fa-solid fa-hand-holding me-1"></i><?= t('ctrl_adopt') ?></summary>
                <form method="POST" class="p-2 mt-1 rounded-3" style="background:var(--surface-3);min-width:220px"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_adopt"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>">
                  <input name="dev_user" class="form-control form-control-sm mb-1" value="admin" placeholder="<?= h(t('dev_user')) ?>"><input name="dev_pass" type="password" class="form-control form-control-sm mb-1" placeholder="<?= h(t('dev_pass')) ?> (admin)">
                  <button class="btn btn-sm btn-success w-100"><?= t('ctrl_adopt') ?></button></form></details>
            <?php else: ?>
              <form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_locate"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>"><button class="btn btn-sm btn-outline-info" title="Locate (LED)"><i class="fa-solid fa-lightbulb"></i></button></form>
              <form method="POST" class="d-inline" onsubmit="return confirm('Reboot?')"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_reboot"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>"><button class="btn btn-sm btn-outline-warning" title="Reboot"><i class="fa-solid fa-power-off"></i></button></form>
            <?php endif; ?>
            <?php if ($mine && (int)$mine['controller_id'] === (int)$cr['id']): ?>
              <a class="btn btn-sm btn-primary" href="?page=hotspot&id=<?= (int)$mine['id'] ?>"><i class="fa-solid fa-key me-1"></i><?= t('radius_settings_btn') ?></a>
            <?php else: ?>
              <form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_import"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="name" value="<?= h($a['name']) ?>"><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-plus me-1"></i><?= $mine ? t('ctrl_link_hotspot') : t('ctrl_import') ?></button></form>
            <?php endif; ?>
          </td></tr>
      <?php endforeach; ?></tbody></table></div>
      <?php elseif ($apErr === ''): ?><p class="text-secondary mb-3"><?= t('ctrl_no_aps') ?></p><?php endif; ?>

      <div class="row g-3 mt-1">
        <div class="col-lg-6"><div class="p-3 rounded-4 h-100" style="border:1px solid var(--line);background:var(--surface-2)">
          <b class="text-body-emphasis small"><i class="fa-solid fa-link me-1 text-primary"></i><?= t('inform_url') ?></b>
          <div class="cfg mt-2"><?= cfgRow(t('inform_url'), informUrlOf($cr), t('inform_hint')) ?><?= cfgFixed(t('inform_ports'), 'UDP 29810 • TCP 29811–29817', t('inform_ports_hint')) ?></div>
          <div class="small text-secondary mt-2"><?= t('inform_path') ?></div>
        </div></div>
        <div class="col-lg-6"><div class="p-3 rounded-4 h-100" style="border:1px solid var(--line);background:var(--surface-2)">
          <b class="text-body-emphasis small"><i class="fa-solid fa-barcode me-1 text-primary"></i><?= t('ctrl_claim') ?></b>
          <div class="small text-secondary mb-2"><?= t('ctrl_claim_help') ?></div>
          <form method="POST" class="row g-2"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_claim"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>">
            <div class="col-6"><input name="sn" class="form-control form-control-sm mono" placeholder="Serial (S/N)" required></div>
            <div class="col-6"><input name="device_key" class="form-control form-control-sm mono" placeholder="Device key (optional)"></div>
            <div class="col-8"><input name="dname" class="form-control form-control-sm" placeholder="<?= h(t('device_name')) ?>"></div>
            <div class="col-4"><button class="btn btn-sm btn-primary w-100"><?= t('ctrl_claim_btn') ?></button></div>
          </form>
        </div></div>
      </div>
      <div class="row g-3 mt-1">
        <div class="col-lg-6"><div class="p-3 rounded-4 h-100" style="border:1px solid var(--line);background:var(--surface-2)">
          <b class="text-body-emphasis small"><i class="fa-solid fa-sitemap me-1 text-primary"></i><?= t('ctrl_site_create') ?></b>
          <form method="POST" class="row g-2 mt-1" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_site_create"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>">
            <div class="col-8"><input name="site_name" class="form-control form-control-sm" maxlength="64" placeholder="<?= h(t('site_name')) ?>" required></div>
            <div class="col-4"><button class="btn btn-sm btn-primary w-100"><i class="fa-solid fa-plus me-1"></i><?= t('save') ?></button></div>
          </form>
        </div></div>
        <div class="col-lg-6"><div class="p-3 rounded-4 h-100" style="border:1px solid var(--line);background:var(--surface-2)">
          <b class="text-body-emphasis small"><i class="fa-solid fa-list-check me-1 text-primary"></i><?= t('ctrl_api_check') ?></b>
          <form method="POST" class="mt-2" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_apicheck"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>">
            <button class="btn btn-sm btn-outline-warning"><i class="fa-solid fa-stethoscope me-1"></i><?= t('ctrl_api_check') ?></button></form>
        </div></div>
      </div>
    </div></div>
    <?php if ($siteSel !== ''):
        // v5.7 — SSID management for this Omada site (Open API)
        $prevDl = OmadaApi::$deadline; OmadaApi::$deadline = microtime(true) + 15;
        $ssids = $cur->allSsids($siteSel); $ssErr = $cur->error;
        OmadaApi::$deadline = $prevDl;
        $usedBy = [];
        foreach (rows("SELECT device_name, omada_ssid_id, ssid FROM hs_devices WHERE user_id=? AND omada_site_id=?", 'is', $uid, $siteSel) as $ur) {
            if ($ur['omada_ssid_id']) $usedBy[$ur['omada_ssid_id']][] = $ur['device_name'];
            elseif ($ur['ssid']) $usedBy['n:' . $ur['ssid']][] = $ur['device_name'];
        } ?>
    <div class="card mt-3" id="ssids"><div class="card-header"><i class="fa-solid fa-wifi me-2"></i><?= t('ssid_manage') ?> (<?= count($ssids) ?>)</div><div class="card-body">
      <?php if ($ssErr !== '' && !$ssids): ?><div class="alert alert-warning small"><?= h($ssErr) ?></div><?php endif; ?>
      <?php if ($ssids): ?><div class="table-responsive"><table class="table table-sm table-hover mcard align-middle"><thead><tr><th>SSID</th><th><?= t('ssid_type') ?></th><th><?= t('ssid_band') ?></th><th>WLAN</th><th><?= t('ssid_used_by') ?></th><th></th></tr></thead><tbody>
        <?php foreach ($ssids as $x): $ub = array_merge($usedBy[$x['ssid_id']] ?? [], $usedBy['n:' . $x['name']] ?? []); ?>
          <tr><td data-label="SSID"><b class="text-body-emphasis"><?= h($x['name']) ?></b><?= $x['broadcast'] ? '' : ' <span class="badge text-bg-secondary">hidden</span>' ?></td>
            <td data-label="<?= t('ssid_type') ?>"><span class="badge text-bg-<?= $x['security'] === 0 ? 'info' : 'primary' ?>"><?= $x['security'] === 0 ? t('ssid_open') : t('ssid_wpa') ?></span><?= $x['guest'] ? ' <span class="badge text-bg-secondary">' . t('ssid_guest') . '</span>' : '' ?></td>
            <td data-label="<?= t('ssid_band') ?>" class="small"><?= h([1 => '2.4 GHz', 2 => '5 GHz', 3 => '2.4 + 5 GHz'][$x['band']] ?? (string)$x['band']) ?></td>
            <td data-label="WLAN" class="small"><?= h($x['wlan_name']) ?></td>
            <td data-label="<?= t('ssid_used_by') ?>" class="small"><?= h(implode(', ', array_unique($ub)) ?: '—') ?></td>
            <td class="text-nowrap"><form method="POST" class="d-inline" onsubmit="return confirm('<?= h(t('delete')) ?> SSID <?= h($x['name']) ?>?')"><?= csrf_field() ?><input type="hidden" name="act" value="ssid_delete"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>"><input type="hidden" name="wlan" value="<?= h($x['wlan_id']) ?>"><input type="hidden" name="ssid" value="<?= h($x['ssid_id']) ?>"><button class="btn btn-sm btn-outline-danger" aria-label="<?= t('delete') ?>"><i class="fa-solid fa-trash"></i></button></form></td></tr>
        <?php endforeach; ?></tbody></table></div>
      <?php elseif ($ssErr === ''): ?><p class="text-secondary"><?= t('ssid_none') ?></p><?php endif; ?>
      <form method="POST" class="row g-2 align-items-end mt-1" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="ssid_create"><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>"><input type="hidden" name="site" value="<?= h($siteSel) ?>">
        <div class="col-12 small fw-semibold text-body-emphasis"><i class="fa-solid fa-plus me-1 text-primary"></i><?= t('ssid_new') ?></div>
        <div class="col-md-3"><label class="form-label small">SSID</label><input name="name" class="form-control form-control-sm" maxlength="32" required placeholder="SKY WIFI"></div>
        <div class="col-md-3"><label class="form-label small"><?= t('ssid_type') ?></label><select name="type" class="form-select form-select-sm" onchange="this.form.psk.closest('div').classList.toggle('d-none',this.value!=='private')">
          <option value="hotspot"><?= t('ssid_type_hotspot') ?></option><option value="private"><?= t('ssid_type_private') ?></option></select></div>
        <div class="col-md-2 d-none"><label class="form-label small"><?= t('ssid_pass') ?></label><input name="psk" type="password" class="form-control form-control-sm" minlength="8" maxlength="63" autocomplete="new-password"></div>
        <div class="col-md-2"><label class="form-label small"><?= t('ssid_band') ?></label><select name="band" class="form-select form-select-sm"><option value="3">2.4 + 5 GHz</option><option value="1">2.4 GHz</option><option value="2">5 GHz</option></select></div>
        <div class="col-md-2"><button class="btn btn-sm btn-primary w-100"><i class="fa-solid fa-plus me-1"></i><?= t('save') ?></button></div>
      </form>
    </div></div>
    <?php endif; ?>
    <?php if ($siteSel !== ''):
        $prevDl = OmadaApi::$deadline; OmadaApi::$deadline = microtime(true) + 15;
        $cliList = $cur->clientList($siteSel); $cliErr = $cur->error;
        OmadaApi::$deadline = $prevDl; ?>
    <div class="card mt-3"><div class="card-header"><i class="fa-solid fa-users me-2"></i><?= t('omada_clients') ?> (<?= count($cliList) ?>)</div><div class="card-body">
      <?php if ($cliErr !== '' && !$cliList): ?><div class="alert alert-warning small mb-0"><?= h($cliErr) ?></div>
      <?php else: echo omadaClientTable($cliList, (int)$cr['id'], $siteSel, $ret, (int)$uid); endif; ?>
    </div></div>
    <?php endif; ?>
    <?php endif; ?>
    <?php break;

case 'packages':
    $auth->requireSeller();
    $uid = (int)$user['id'];
    $devs = Device::forSeller($uid);
    $edit = isset($_GET['edit']) ? row("SELECT * FROM hs_packages WHERE id=? AND seller_id=?", 'ii', (int)$_GET['edit'], $uid) : null;
    $pkgs = rows("SELECT p.*, d.device_name, (SELECT COUNT(*) FROM hs_vouchers v WHERE v.package_id=p.id AND v.status IN ('available','sold')) AS unused
                  FROM hs_packages p LEFT JOIN hs_devices d ON d.id=p.device_id WHERE p.seller_id=? ORDER BY p.sort_order, p.price", 'i', $uid);
    $e = $edit ?? ['name' => '', 'description' => '', 'price' => '', 'duration_minutes' => 60, 'time_mode' => 'continuous', 'data_limit_mb' => 0, 'speed_down_mbps' => 5,
                   'speed_up_mbps' => 2, 'max_devices' => 1, 'validity_days' => 30, 'show_on_portal' => 1, 'is_active' => 1, 'sort_order' => 0, 'device_id' => null];
    ?>
    <div class="row g-3">
      <div class="col-lg-5">
        <div class="card"><div class="card-header"><i class="fa-solid fa-box me-2"></i><?= $edit ? t('edit_package') : t('create_package') ?></div>
          <div class="card-body">
            <form method="POST" class="row g-3"><?= csrf_field() ?><input type="hidden" name="act" value="package_save"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
              <div class="col-12"><label class="form-label small"><?= t('package_name') ?> *</label><input name="name" class="form-control" value="<?= h($e['name']) ?>" placeholder="1 Hour" required></div>
              <div class="col-12"><label class="form-label small"><?= t('description') ?></label><input name="description" class="form-control" value="<?= h($e['description']) ?>"></div>
              <div class="col-6"><label class="form-label small"><?= t('price') ?> (<?= CURRENCY ?>)</label><input type="number" step="1" min="0" name="price" class="form-control" value="<?= h($e['price']) ?>" required></div>
              <div class="col-6"><label class="form-label small"><?= t('duration_minutes') ?></label><input type="number" min="1" name="duration_minutes" class="form-control" value="<?= (int)$e['duration_minutes'] ?>" list="durs" required>
                <datalist id="durs"><option value="30"><option value="60"><option value="180"><option value="360"><option value="1440"><option value="10080"><option value="43200"></datalist></div>
              <div class="col-12"><label class="form-label small"><?= t('time_mode') ?></label><select name="time_mode" class="form-select">
                <option value="continuous" <?= $e['time_mode'] === 'continuous' ? 'selected' : '' ?>><?= t('continuous') ?></option>
                <option value="online" <?= $e['time_mode'] === 'online' ? 'selected' : '' ?>><?= t('online_time') ?></option></select></div>
              <div class="col-6"><label class="form-label small"><?= t('speed_down') ?></label><input type="number" step="0.5" min="0" name="speed_down_mbps" class="form-control" value="<?= h($e['speed_down_mbps']) ?>"></div>
              <div class="col-6"><label class="form-label small"><?= t('speed_up') ?></label><input type="number" step="0.5" min="0" name="speed_up_mbps" class="form-control" value="<?= h($e['speed_up_mbps']) ?>"></div>
              <div class="col-6"><label class="form-label small"><?= t('data_limit_mb') ?></label><input type="number" min="0" name="data_limit_mb" class="form-control" value="<?= (int)$e['data_limit_mb'] ?>"></div>
              <div class="col-6"><label class="form-label small"><?= t('max_devices') ?></label><input type="number" min="1" max="10" name="max_devices" class="form-control" value="<?= (int)$e['max_devices'] ?>"></div>
              <div class="col-6"><label class="form-label small"><?= t('validity_days') ?></label><input type="number" min="0" name="validity_days" class="form-control" value="<?= (int)$e['validity_days'] ?>"></div>
              <div class="col-6"><label class="form-label small">Sort</label><input type="number" name="sort_order" class="form-control" value="<?= (int)$e['sort_order'] ?>"></div>
              <div class="col-12"><label class="form-label small">EAP225</label><select name="device_id" class="form-select"><option value="0"><?= t('all_my_aps') ?></option>
                <?php foreach ($devs as $d): ?><option value="<?= (int)$d['id'] ?>" <?= (int)$e['device_id'] === (int)$d['id'] ? 'selected' : '' ?>><?= h($d['device_name']) ?></option><?php endforeach; ?></select></div>
              <div class="col-6"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="show_on_portal" id="sp" <?= $e['show_on_portal'] ? 'checked' : '' ?>><label class="form-check-label small" for="sp"><?= t('show_on_portal') ?></label></div></div>
              <div class="col-6"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="is_active" id="ia" <?= $e['is_active'] ? 'checked' : '' ?>><label class="form-check-label small" for="ia"><?= t('active') ?></label></div></div>
              <div class="col-12 d-flex gap-2"><button class="btn btn-primary"><i class="fa-solid fa-floppy-disk me-1"></i> <?= t('save') ?></button><?php if ($edit): ?><a href="?page=packages" class="btn btn-outline-secondary"><?= t('cancel') ?></a><?php endif; ?></div>
            </form>
          </div></div>
      </div>
      <div class="col-lg-7">
        <div class="card"><div class="card-header"><i class="fa-solid fa-layer-group me-2"></i><?= t('packages') ?> (<?= count($pkgs) ?>)</div>
          <div class="card-body table-responsive">
            <?php if ($pkgs): ?><table class="table table-hover mcard align-middle"><thead><tr><th><?= t('package_name') ?></th><th><?= t('price') ?></th><th><?= t('duration') ?></th><th>Mbps</th><th><?= t('p_data') ?></th><th><?= t('available_vouchers') ?></th><th></th></tr></thead><tbody>
            <?php foreach ($pkgs as $p): ?>
              <tr><td data-label="<?= t('package_name') ?>"><b class="text-body-emphasis"><?= h($p['name']) ?></b><?= $p['is_active'] ? '' : ' <span class="badge text-bg-secondary">' . t('inactive') . '</span>' ?><?= $p['show_on_portal'] ? ' <i class="fa-solid fa-globe text-info" title="portal"></i>' : '' ?><div class="small text-secondary"><?= h($p['device_name'] ?: t('all_my_aps')) ?></div></td>
                <td data-label="<?= t('price') ?>" class="fw-semibold"><?= money($p['price']) ?></td>
                <td data-label="<?= t('duration') ?>"><?= fmtDur((int)$p['duration_minutes']) ?><?= $p['time_mode'] === 'online' ? ' <span class="badge text-bg-info">online</span>' : '' ?></td>
                <td data-label="Mbps"><?= (float)$p['speed_down_mbps'] ?: '∞' ?>/<?= (float)$p['speed_up_mbps'] ?: '∞' ?></td>
                <td data-label="<?= t('p_data') ?>"><?= (int)$p['data_limit_mb'] ? fmtBytes($p['data_limit_mb'] * 1048576) : t('unlimited') ?></td>
                <td data-label="<?= t('available_vouchers') ?>"><?= (int)$p['unused'] ?></td>
                <td class="text-nowrap"><a class="btn btn-sm btn-outline-success" href="?page=vouchers&package=<?= (int)$p['id'] ?>" title="<?= t('generate') ?>"><i class="fa-solid fa-ticket"></i></a>
                  <a class="btn btn-sm btn-outline-primary" href="?page=packages&edit=<?= (int)$p['id'] ?>"><i class="fa-solid fa-pen"></i></a>
                  <form method="POST" class="d-inline" onsubmit="return confirm('<?= h(t('confirm_delete')) ?>')"><?= csrf_field() ?><input type="hidden" name="act" value="package_delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button></form></td></tr>
            <?php endforeach; ?></tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
          </div></div>
      </div>
    </div>
    <?php break;

case 'vouchers':
    $auth->requireSeller();
    $uid = (int)$user['id'];
    $pkgs = rows("SELECT id, name, price FROM hs_packages WHERE seller_id=? AND is_active=1 ORDER BY sort_order, price", 'i', $uid);
    $fStatus = in_array($_GET['status'] ?? '', ['available', 'sold', 'active', 'expired', 'exhausted', 'blocked', 'cancelled'], true) ? $_GET['status'] : '';
    $fBatch = preg_replace('/[^A-Z0-9]/', '', strtoupper((string)($_GET['batch'] ?? '')));
    $fQ = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)($_GET['q'] ?? '')));
    $where = "v.seller_id=?"; $types = 'i'; $args = [$uid];
    if ($fStatus) { $where .= " AND v.status=?"; $types .= 's'; $args[] = $fStatus; }
    if ($fBatch) { $where .= " AND v.batch=?"; $types .= 's'; $args[] = $fBatch; }
    if ($fQ) { $where .= " AND v.code LIKE ?"; $types .= 's'; $args[] = "%$fQ%"; }
    $list = rows("SELECT v.*, p.name AS package_name, (SELECT COUNT(*) FROM hs_voucher_macs m WHERE m.voucher_id=v.id) AS macs FROM hs_vouchers v LEFT JOIN hs_packages p ON p.id=v.package_id WHERE $where ORDER BY v.id DESC LIMIT 300", $types, ...$args);
    $batches = rows("SELECT batch, COUNT(*) n, MIN(created_at) c, SUM(status IN ('available','sold')) unused FROM hs_vouchers WHERE seller_id=? AND batch IS NOT NULL GROUP BY batch ORDER BY c DESC LIMIT 10", 'i', $uid);
    $badge = ['available' => 'success', 'sold' => 'info', 'active' => 'primary', 'expired' => 'secondary', 'exhausted' => 'warning', 'blocked' => 'danger', 'cancelled' => 'dark'];
    ?>
    <div class="row g-3 mb-3">
      <div class="col-lg-5"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-ticket me-2"></i><?= t('generate_vouchers') ?></div><div class="card-body">
        <?php if (!$pkgs): ?><p class="text-secondary"><a href="?page=packages"><?= t('create_package') ?></a></p><?php else: ?>
        <form method="POST" class="row g-2"><?= csrf_field() ?><input type="hidden" name="act" value="vouchers_generate">
          <div class="col-8"><label class="form-label small"><?= t('package') ?></label><select name="package_id" class="form-select"><?php foreach ($pkgs as $p): ?><option value="<?= (int)$p['id'] ?>" <?= (int)($_GET['package'] ?? 0) === (int)$p['id'] ? 'selected' : '' ?>><?= h($p['name']) ?> — <?= money($p['price']) ?></option><?php endforeach; ?></select></div>
          <div class="col-4"><label class="form-label small"><?= t('quantity') ?></label><input type="number" name="quantity" min="1" max="1000" value="20" class="form-control"></div>
          <div class="col-12 mt-3"><button class="btn btn-success w-100"><i class="fa-solid fa-wand-magic-sparkles me-1"></i> <?= t('generate') ?></button></div>
        </form><?php endif; ?>
      </div></div></div>
      <div class="col-lg-7"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-boxes-stacked me-2"></i><?= t('batch') ?></div><div class="card-body p-2">
        <?php foreach ($batches as $b): ?><div class="d-flex justify-content-between align-items-center gap-2 px-2 py-2 border-bottom border-secondary-subtle small">
          <a href="?page=vouchers&batch=<?= h($b['batch']) ?>" class="mono"><?= h($b['batch']) ?></a><span class="text-secondary"><?= (int)$b['unused'] ?>/<?= (int)$b['n'] ?> • <?= h(date('d M H:i', strtotime($b['c']))) ?></span>
          <span class="text-nowrap"><a class="btn btn-sm btn-outline-secondary" target="_blank" href="?page=print&batch=<?= h($b['batch']) ?>" title="<?= t('print') ?>"><i class="fa-solid fa-print"></i></a> <a class="btn btn-sm btn-outline-secondary" href="?export=vouchers&batch=<?= h($b['batch']) ?>" title="<?= t('export_csv') ?>"><i class="fa-solid fa-file-csv"></i></a></span></div>
        <?php endforeach; if (!$batches) echo '<p class="text-secondary m-2">' . t('no_data') . '</p>'; ?>
      </div></div></div>
    </div>
    <div class="card"><div class="card-header">
      <form class="row g-2 align-items-center" method="GET"><input type="hidden" name="page" value="vouchers">
        <div class="col-6 col-md-3"><input name="q" class="form-control form-control-sm" placeholder="<?= t('search') ?>" value="<?= h($fQ) ?>"></div>
        <div class="col-6 col-md-3"><select name="status" class="form-select form-select-sm"><option value=""><?= t('all') ?></option><?php foreach (array_keys($badge) as $s): ?><option <?= $fStatus === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?></select></div>
        <div class="col-6 col-md-3"><input name="batch" class="form-control form-control-sm" placeholder="<?= t('batch') ?>" value="<?= h($fBatch) ?>"></div>
        <div class="col-6 col-md-3"><button class="btn btn-sm btn-primary w-100"><i class="fa-solid fa-filter me-1"></i><?= t('filter') ?></button></div>
      </form></div>
      <div class="card-body table-responsive">
        <?php if ($list): ?><table class="table table-sm table-hover mcard align-middle"><thead><tr><th><?= t('code') ?></th><th><?= t('package') ?></th><th><?= t('status') ?></th><th><?= t('remaining') ?></th><th><?= t('data_used') ?></th><th><?= t('mac') ?></th><th></th></tr></thead><tbody>
        <?php foreach ($list as $v): $rem = in_array($v['status'], ['active', 'available', 'sold'], true) ? Vouchers::remainingSeconds($v) : 0; ?>
          <tr><td data-label="<?= t('code') ?>" class="mono fw-bold text-body-emphasis"><?= h($v['code']) ?></td>
            <td data-label="<?= t('package') ?>"><?= h($v['package_name'] ?? '—') ?> <small class="text-secondary"><?= money($v['price']) ?></small></td>
            <td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $badge[$v['status']] ?? 'secondary' ?>"><?= h($v['status']) ?></span><?= $v['source'] === 'online' ? ' <i class="fa-solid fa-mobile-screen text-info" title="online"></i>' : '' ?></td>
            <td data-label="<?= t('remaining') ?>"><?= $rem ? fmtSecs($rem) : '—' ?></td>
            <td data-label="<?= t('data_used') ?>"><?= fmtBytes($v['data_used_bytes']) ?><?= (int)$v['data_limit_mb'] ? ' / ' . fmtBytes($v['data_limit_mb'] * 1048576) : '' ?></td>
            <td data-label="<?= t('mac') ?>"><?= (int)$v['macs'] ?>/<?= (int)$v['max_devices'] ?></td>
            <td class="text-nowrap">
              <?php if (in_array($v['status'], ['blocked'], true)): ?>
                <form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="voucher_status"><input type="hidden" name="id" value="<?= (int)$v['id'] ?>"><input type="hidden" name="to" value="unblock"><button class="btn btn-sm btn-outline-success"><?= t('unblock') ?></button></form>
              <?php elseif (!in_array($v['status'], ['cancelled'], true)): ?>
                <button class="btn btn-sm btn-outline-info" onclick="adj(<?= (int)$v['id'] ?>,'<?= h($v['code']) ?>')" title="<?= t('adjust_time') ?>"><i class="fa-solid fa-clock"></i></button>
                <form method="POST" class="d-inline" onsubmit="return confirm('<?= h(t('block')) ?> <?= h($v['code']) ?>?')"><?= csrf_field() ?><input type="hidden" name="act" value="voucher_status"><input type="hidden" name="id" value="<?= (int)$v['id'] ?>"><input type="hidden" name="to" value="blocked"><button class="btn btn-sm btn-outline-danger" title="<?= t('block') ?>"><i class="fa-solid fa-ban"></i></button></form>
              <?php endif; ?></td></tr>
        <?php endforeach; ?></tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
      </div></div>
    <form method="POST" id="adjForm" class="d-none"><?= csrf_field() ?><input type="hidden" name="act" value="adjust"><input type="hidden" name="voucher_id"><input type="hidden" name="minutes"><input type="hidden" name="reason"><input type="hidden" name="return" value="<?= h($_SERVER['REQUEST_URI']) ?>"></form>
    <script>function adj(id,code){const m=prompt(code+' — <?= h(t('adjust_time')) ?> (+/- <?= h(t('minutes')) ?>)','30');if(!m||isNaN(parseInt(m)))return;const r=prompt('<?= h(t('reason')) ?>','')||'';const f=document.getElementById('adjForm');f.voucher_id.value=id;f.minutes.value=parseInt(m);f.reason.value=r;f.submit()}</script>
    <?php break;

case 'sessions':
    $auth->requireSeller();
    $uid = (int)$user['id'];
    $devFilter = (int)($_GET['device'] ?? 0);
    $sess = SessionOps::active($uid, $devFilter);
    $blocked = rows("SELECT * FROM hs_blocked_macs WHERE seller_id=? ORDER BY id DESC", 'i', $uid);
    $devs = Device::forSeller($uid);
    ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <form method="GET" class="d-flex gap-2"><input type="hidden" name="page" value="sessions"><select name="device" class="form-select form-select-sm" onchange="this.form.submit()"><option value="0"><?= t('all_my_aps') ?></option>
        <?php foreach ($devs as $d): ?><option value="<?= (int)$d['id'] ?>" <?= $devFilter === (int)$d['id'] ? 'selected' : '' ?>><?= h($d['device_name']) ?></option><?php endforeach; ?></select></form>
      <div class="d-flex gap-2 align-items-center"><span class="badge text-bg-success py-2 px-3"><span class="dot on"></span><?= count($sess) ?> <?= t('active_sessions') ?></span><a href="?page=sessions&device=<?= $devFilter ?>" class="btn btn-sm btn-outline-secondary" aria-label="Refresh"><i class="fa-solid fa-rotate"></i></a></div>
    </div>
    <form method="POST" id="bulk"><?= csrf_field() ?><input type="hidden" name="act" value="bulk_adjust"><input type="hidden" name="minutes" id="bulkMin" value="30"><input type="hidden" name="reason" value="Bulk adjustment">
    <div class="row g-3">
    <?php foreach ($sess as $s):
        $rem = $s['code'] ? Vouchers::remainingSeconds($s) : 0;
        $cls = $rem <= 300 ? 'danger' : ($rem <= 900 ? 'warning' : 'success'); ?>
      <div class="col-md-6 col-xxl-4"><div class="card p-3 h-100">
        <div class="d-flex justify-content-between gap-2">
          <div class="min-w-0"><input type="checkbox" class="form-check-input me-2 sc" name="voucher_ids[]" value="<?= (int)$s['voucher_id'] ?>" onchange="bulkBar()"><span class="mono fw-bold text-body-emphasis"><?= h($s['code'] ?: $s['username']) ?></span>
            <div class="small text-secondary"><?= h($s['package_name'] ?? '') ?> • <?= h($s['device_name'] ?? '') ?></div></div>
          <div class="text-end"><div class="fw-bold fs-5 text-<?= $cls ?>"><?= fmtSecs($rem) ?></div><small class="text-secondary"><?= t('remaining') ?></small></div>
        </div>
        <div class="small text-secondary mt-2 pt-2 border-top border-secondary-subtle">
          <i class="fa-solid fa-mobile-screen fa-fw"></i><span class="mono"><?= h(dashMac((string)$s['mac'])) ?></span> • <?= h($s['ip']) ?><br>
          <i class="fa-solid fa-play fa-fw"></i><?= h(date('H:i', strtotime($s['started_at']))) ?> • <?= fmtSecs((int)$s['session_time']) ?> •
          <i class="fa-solid fa-arrow-down text-success"></i> <?= fmtBytes($s['bytes_out']) ?> <i class="fa-solid fa-arrow-up text-info"></i> <?= fmtBytes($s['bytes_in']) ?>
        </div>
        <div class="d-flex flex-wrap gap-1 mt-3">
          <?php if ($s['voucher_id']): foreach ([15, 30, 60, -15] as $m): ?>
            <button type="button" class="btn btn-sm btn-outline-<?= $m > 0 ? 'success' : 'danger' ?>" onclick="quick(<?= (int)$s['voucher_id'] ?>,<?= $m ?>)"><?= $m > 0 ? '+' : '' ?><?= $m ?>m</button>
          <?php endforeach; endif; ?>
          <span class="ms-auto"></span>
          <button type="button" class="btn btn-sm btn-outline-warning" title="<?= t('disconnect') ?>" onclick="act('disconnect',{session_id:<?= (int)$s['id'] ?>})"><i class="fa-solid fa-plug-circle-xmark"></i></button>
          <button type="button" class="btn btn-sm btn-outline-danger" title="<?= t('block_device') ?>" onclick="if(confirm('<?= h(t('block_device')) ?>?'))act('block_mac',{mac:'<?= h($s['mac']) ?>'})"><i class="fa-solid fa-ban"></i></button>
        </div>
      </div></div>
    <?php endforeach; ?>
    </div>
    <?php if (!$sess): ?><div class="card p-5 text-center text-secondary"><i class="fa-solid fa-signal fa-2x mb-3 opacity-50"></i><?= t('no_data') ?></div><?php endif; ?>
    <div id="bulkBar" class="card p-2 mt-3 d-none position-sticky" style="bottom:90px;z-index:5"><div class="d-flex flex-wrap gap-2 align-items-center"><span class="badge text-bg-primary" id="selN">0</span>
      <?php foreach ([15, 30, 60, 120] as $m): ?><button type="button" class="btn btn-sm btn-outline-success" onclick="document.getElementById('bulkMin').value=<?= $m ?>;document.getElementById('bulk').submit()">+<?= $m ?>m <?= t('apply_to_selected') ?></button><?php endforeach; ?></div></div>
    </form>

    <div class="card mt-3"><div class="card-header"><i class="fa-solid fa-ban me-2"></i><?= t('blocked_devices') ?> (<?= count($blocked) ?>)</div><div class="card-body">
      <form method="POST" class="row g-2 mb-3"><?= csrf_field() ?><input type="hidden" name="act" value="block_mac">
        <div class="col-7"><input name="mac" class="form-control form-control-sm mono" placeholder="AA-BB-CC-DD-EE-FF" required></div><div class="col-5"><button class="btn btn-sm btn-outline-danger w-100"><?= t('block') ?></button></div></form>
      <?php foreach ($blocked as $b): ?><div class="d-flex justify-content-between align-items-center border-bottom border-secondary-subtle py-2 small"><span class="mono"><?= h(dashMac($b['mac'])) ?></span><span class="text-secondary"><?= h($b['reason']) ?></span>
        <form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="unblock_mac"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><button class="btn btn-sm btn-link text-success"><?= t('unblock') ?></button></form></div><?php endforeach; ?>
    </div></div>
    <form method="POST" id="actForm" class="d-none"><?= csrf_field() ?><input type="hidden" name="act"><input type="hidden" name="voucher_id"><input type="hidden" name="minutes"><input type="hidden" name="reason"><input type="hidden" name="session_id"><input type="hidden" name="mac"></form>
    <script>
    function act(a,data){const f=document.getElementById('actForm');f.act.value=a;for(const k in data)f[k].value=data[k];f.submit()}
    function quick(vid,m){act('adjust',{voucher_id:vid,minutes:m,reason:'Quick '+(m>0?'+':'')+m+'m'})}
    function bulkBar(){const n=document.querySelectorAll('.sc:checked').length;document.getElementById('bulkBar').classList.toggle('d-none',!n);document.getElementById('selN').textContent=n}
    </script>
    <?php break;

case 'orders':
    $auth->requireSeller();
    $uid = (int)$user['id'];
    $fs = in_array($_GET['status'] ?? '', ['pending', 'paid', 'failed', 'expired', 'cancelled'], true) ? $_GET['status'] : '';
    $orders = $fs ? rows("SELECT o.*, p.name AS package_name, v.code FROM hs_orders o LEFT JOIN hs_packages p ON p.id=o.package_id LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.seller_id=? AND o.status=? ORDER BY o.id DESC LIMIT 300", 'is', $uid, $fs)
                  : rows("SELECT o.*, p.name AS package_name, v.code FROM hs_orders o LEFT JOIN hs_packages p ON p.id=o.package_id LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.seller_id=? ORDER BY o.id DESC LIMIT 300", 'i', $uid);
    $badge = ['pending' => 'warning', 'paid' => 'success', 'failed' => 'danger', 'expired' => 'secondary', 'cancelled' => 'dark'];
    ?>
    <div class="mb-3 d-flex gap-1 flex-wrap"><a class="btn btn-sm btn-<?= $fs === '' ? 'primary' : 'outline-secondary' ?>" href="?page=orders"><?= t('all') ?></a>
      <?php foreach ($badge as $s => $c): ?><a class="btn btn-sm btn-<?= $fs === $s ? 'primary' : 'outline-secondary' ?>" href="?page=orders&status=<?= $s ?>"><?= $s ?></a><?php endforeach; ?></div>
    <div class="card"><div class="card-body table-responsive">
      <?php if ($orders): ?><table class="table table-sm table-hover mcard align-middle"><thead><tr><th><?= t('order_ref') ?></th><th><?= t('package') ?></th><th><?= t('phone') ?></th><th><?= t('amount') ?></th><th><?= t('status') ?></th><th><?= t('code') ?></th><th><?= t('date') ?></th><th></th></tr></thead><tbody>
      <?php foreach ($orders as $o): ?><tr>
        <td data-label="<?= t('order_ref') ?>" class="small mono"><?= h($o['order_ref']) ?></td><td data-label="<?= t('package') ?>"><?= h($o['package_name']) ?></td><td data-label="<?= t('phone') ?>"><?= h($o['phone']) ?></td>
        <td data-label="<?= t('amount') ?>" class="fw-semibold"><?= money($o['amount']) ?></td><td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $badge[$o['status']] ?>"><?= h($o['status']) ?></span></td>
        <td data-label="<?= t('code') ?>" class="mono"><?= h($o['code'] ?? '') ?></td><td data-label="<?= t('date') ?>" class="small"><?= h(date('d M H:i', strtotime($o['created_at']))) ?></td>
        <td class="text-nowrap"><?php if (in_array($o['status'], ['pending', 'expired', 'failed'], true)): ?>
          <form method="POST" class="d-inline" onsubmit="return confirm('<?= h(t('mark_paid')) ?>: <?= h(money($o['amount'])) ?> — <?= h($o['phone']) ?>?')"><?= csrf_field() ?><input type="hidden" name="act" value="order_confirm"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="btn btn-sm btn-success" title="<?= t('mark_paid') ?>"><i class="fa-solid fa-check"></i></button></form>
          <?php if ($o['status'] === 'pending'): ?><form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="order_cancel"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="btn btn-sm btn-outline-secondary" title="<?= t('cancel') ?>"><i class="fa-solid fa-xmark"></i></button></form><?php endif; ?>
        <?php endif; ?></td></tr><?php endforeach; ?>
      </tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
    </div></div>
    <?php break;

case 'adjustments':
    $auth->requireSeller();
    $list = rows("SELECT a.*, v.code FROM hs_adjustments a JOIN hs_vouchers v ON v.id=a.voucher_id WHERE a.seller_id=? ORDER BY a.id DESC LIMIT 200", 'i', $user['id']);
    ?>
    <div class="card"><div class="card-body table-responsive">
      <?php if ($list): ?><table class="table table-sm table-hover mcard"><thead><tr><th><?= t('code') ?></th><th><?= t('minutes') ?></th><th>Old → New</th><th><?= t('reason') ?></th><th><?= t('date') ?></th></tr></thead><tbody>
      <?php foreach ($list as $a): ?><tr><td data-label="<?= t('code') ?>" class="mono"><?= h($a['code']) ?></td><td data-label="<?= t('minutes') ?>" class="fw-bold text-<?= $a['minutes'] > 0 ? 'success' : 'danger' ?>"><?= $a['minutes'] > 0 ? '+' : '' ?><?= (int)$a['minutes'] ?>m</td>
        <td data-label="Old → New" class="small"><?= h($a['old_value']) ?> → <?= h($a['new_value']) ?></td><td data-label="<?= t('reason') ?>"><?= h($a['reason']) ?></td><td data-label="<?= t('date') ?>" class="small"><?= h(date('d M Y H:i', strtotime($a['created_at']))) ?></td></tr><?php endforeach; ?>
      </tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
    </div></div>
    <?php break;

case 'transactions':
    // v6.4 — Payments (manage pending / failed / expired portal payments) + earnings + ledger. Admin sees every seller.
    $auth->requireLogin();
    if ($user['user_type'] === 'customer') redirectTo('?page=dashboard');
    $uid = (int)$user['id'];
    $isAdm = $auth->isAdmin();
    $fs = (string)($_GET['status'] ?? 'attention');
    if (!in_array($fs, ['attention', 'all', 'pending', 'failed', 'expired', 'paid', 'cancelled'], true)) $fs = 'attention';
    $fq = trim(substr(preg_replace('/[^A-Za-z0-9 +\-_.]/', '', (string)($_GET['q'] ?? '')), 0, 40));
    $fSeller = $isAdm ? (int)($_GET['seller'] ?? 0) : $uid;
    $w = []; $types = ''; $args = [];
    if ($fSeller) { $w[] = 'o.seller_id=?'; $types .= 'i'; $args[] = $fSeller; }
    if ($fs === 'attention') $w[] = "o.status IN ('pending','failed','expired')";
    elseif ($fs !== 'all') { $w[] = 'o.status=?'; $types .= 's'; $args[] = $fs; }
    if ($fq !== '') { $w[] = '(o.order_ref LIKE ? OR o.phone LIKE ? OR o.gateway_ref LIKE ? OR v.code LIKE ?)'; $types .= 'ssss'; $lk = '%' . $fq . '%'; array_push($args, $lk, $lk, $lk, $lk); }
    $pays = rows("SELECT o.*, p.name AS package_name, v.code, v.first_used_at AS v_used, d.device_name, u.username AS seller_name, cb.username AS confirmed_name
                  FROM hs_orders o LEFT JOIN hs_packages p ON p.id=o.package_id LEFT JOIN hs_vouchers v ON v.id=o.voucher_id LEFT JOIN hs_devices d ON d.id=o.device_id
                  LEFT JOIN users u ON u.id=o.seller_id LEFT JOIN users cb ON cb.id=o.confirmed_by
                  WHERE " . ($w ? implode(' AND ', $w) : '1=1') . " ORDER BY o.id DESC LIMIT 300", $types, ...$args);
    $cnt = ['pending' => 0, 'failed' => 0, 'expired' => 0, 'paid' => 0, 'cancelled' => 0];
    foreach (rows("SELECT status, COUNT(*) n FROM hs_orders" . ($fSeller ? ' WHERE seller_id=' . (int)$fSeller : '') . " GROUP BY status") as $r) $cnt[$r['status']] = (int)$r['n'];
    $cnt['attention'] = $cnt['pending'] + $cnt['failed'] + $cnt['expired'];
    $cnt['all'] = array_sum(array_intersect_key($cnt, array_flip(['pending', 'failed', 'expired', 'paid', 'cancelled'])));
    $ern = Earnings::summary($fSeller);
    $ledger = $fSeller
        ? rows("SELECT t.*, v.code, u.username FROM transactions t LEFT JOIN hs_vouchers v ON v.id=t.voucher_id LEFT JOIN users u ON u.id=COALESCE(t.seller_id,t.user_id)
                WHERE t.seller_id=? OR t.user_id=? ORDER BY t.id DESC LIMIT 300", 'ii', $fSeller, $fSeller)
        : rows("SELECT t.*, v.code, u.username FROM transactions t LEFT JOIN hs_vouchers v ON v.id=t.voucher_id LEFT JOIN users u ON u.id=COALESCE(t.seller_id,t.user_id)
                ORDER BY t.id DESC LIMIT 300");
    $sellers = $isAdm ? rows("SELECT DISTINCT u.id, u.username FROM users u WHERE u.user_type IN ('seller','admin') ORDER BY u.username") : [];
    $ret = '?page=transactions&status=' . urlencode($fs) . ($isAdm && $fSeller ? '&seller=' . $fSeller : '') . ($fq !== '' ? '&q=' . urlencode($fq) : '');
    $badge = ['pending' => 'warning', 'paid' => 'success', 'failed' => 'danger', 'expired' => 'secondary', 'cancelled' => 'dark'];
    $tab = ($_GET['tab'] ?? '') === 'ledger' ? 'ledger' : 'payments';
    $hidden = function (array $o, string $op) use ($ret): string {
        return csrf_field() . '<input type="hidden" name="act" value="pay_manage"><input type="hidden" name="id" value="' . (int)$o['id'] . '">'
            . '<input type="hidden" name="op" value="' . h($op) . '"><input type="hidden" name="return" value="' . h($ret) . '">';
    };
    ?>
    <div class="row g-3 mb-3">
      <div class="col-6 col-lg"><div class="card stat s2 p-3"><h6><i class="fa-solid fa-mobile-screen me-1"></i><?= t('earn_mobile') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['mobile']) ?></h4><div class="earn-sub"><?= t('earn_today') ?>: <?= money($ern['mobile_today']) ?></div></div></div>
      <div class="col-6 col-lg"><div class="card stat s3 p-3"><h6><i class="fa-solid fa-ticket me-1"></i><?= t('earn_vouchers') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['vouchers']) ?></h4><div class="earn-sub"><?= t('earn_today') ?>: <?= money($ern['vouchers_today']) ?></div></div></div>
      <div class="col-6 col-lg"><div class="card stat s1 p-3"><h6><i class="fa-solid fa-sack-dollar me-1"></i><?= t('earn_total') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['total']) ?></h4><div class="earn-sub"><?= $ern['commission'] > 0 ? t('earn_commission') . ': −' . money($ern['commission']) : '&nbsp;' ?></div></div></div>
      <div class="col-6 col-lg"><div class="card stat s5 p-3"><h6><i class="fa-solid fa-money-bill-transfer me-1"></i><?= t('earn_withdrawn') ?></h6><h4 class="mb-0 fw-bold">−<?= money($ern['withdrawn']) ?></h4><div class="earn-sub">&nbsp;</div></div></div>
      <div class="col-12 col-lg"><div class="card stat s6 p-3"><h6><i class="fa-solid fa-wallet me-1"></i><?= t('earn_available') ?></h6><h4 class="mb-0 fw-bold"><?= money($ern['balance']) ?></h4><div class="earn-sub"><?= $isAdm && !$fSeller ? t('earn_all_sellers') : t('earn_total') . ' − ' . t('earn_withdrawn') ?></div></div></div>
    </div>
    <p class="small text-secondary"><i class="fa-solid fa-circle-info me-1"></i><?= t('earn_note') ?></p>

    <ul class="nav nav-pills gap-1 mb-3">
      <li class="nav-item"><a class="nav-link py-1 px-3 <?= $tab === 'payments' ? 'active' : '' ?>" href="<?= h($ret) ?>"><i class="fa-solid fa-receipt me-1"></i><?= t('payments') ?><?= $cnt['attention'] ? ' <span class="badge text-bg-warning ms-1">' . $cnt['attention'] . '</span>' : '' ?></a></li>
      <li class="nav-item"><a class="nav-link py-1 px-3 <?= $tab === 'ledger' ? 'active' : '' ?>" href="<?= h($ret . '&tab=ledger') ?>"><i class="fa-solid fa-book me-1"></i><?= t('ledger') ?></a></li>
    </ul>

    <?php if ($tab === 'payments'): ?>
    <div class="alert alert-info small d-flex justify-content-between align-items-center flex-wrap gap-2"><span><i class="fa-solid fa-circle-info me-2"></i><?= t('pay_intro') ?></span>
      <?php if (Payments::sonicConfigured()): ?><form method="POST" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').innerHTML='<span class=&quot;spinner-border spinner-border-sm me-1&quot;></span><?= h(t('pay_recheck_all')) ?>'"><?= csrf_field() ?><input type="hidden" name="act" value="pay_recheck_all"><input type="hidden" name="return" value="<?= h($ret) ?>"><button class="btn btn-sm btn-primary"><i class="fa-solid fa-rotate me-1"></i><?= t('pay_recheck_all') ?></button></form><?php endif; ?></div>
    <div class="card"><div class="card-header">
      <div class="d-flex gap-1 flex-wrap mb-2">
        <?php foreach (['attention' => t('pay_attention'), 'pending' => 'pending', 'failed' => 'failed', 'expired' => 'expired', 'paid' => 'paid', 'cancelled' => 'cancelled', 'all' => t('all')] as $sk => $sl): ?>
          <a class="btn btn-sm btn-<?= $fs === $sk ? 'primary' : 'outline-secondary' ?>" href="?page=transactions&status=<?= $sk ?><?= $isAdm && $fSeller ? '&seller=' . $fSeller : '' ?>"><?= h($sl) ?> <span class="opacity-75">(<?= (int)($cnt[$sk] ?? 0) ?>)</span></a>
        <?php endforeach; ?>
      </div>
      <form method="GET" class="row g-2"><input type="hidden" name="page" value="transactions"><input type="hidden" name="status" value="<?= h($fs) ?>">
        <?php if ($isAdm): ?><div class="col-md-4"><select name="seller" class="form-select form-select-sm"><option value="0"><?= t('earn_all_sellers') ?></option>
          <?php foreach ($sellers as $se): ?><option value="<?= (int)$se['id'] ?>" <?= $fSeller === (int)$se['id'] ? 'selected' : '' ?>><?= h($se['username']) ?></option><?php endforeach; ?></select></div><?php endif; ?>
        <div class="col"><input name="q" class="form-control form-control-sm" value="<?= h($fq) ?>" placeholder="<?= t('search') ?>: <?= t('order_ref') ?> / <?= t('phone') ?> / <?= t('code') ?>"></div>
        <div class="col-auto"><button class="btn btn-sm btn-primary"><i class="fa-solid fa-filter me-1"></i><?= t('filter') ?></button></div>
      </form></div>
      <div class="card-body table-responsive">
        <?php if ($pays): ?><table class="table table-sm table-hover mcard align-middle"><thead><tr><th><?= t('order_ref') ?></th><?php if ($isAdm): ?><th><?= t('seller') ?></th><?php endif; ?><th><?= t('pay_customer') ?></th><th><?= t('package') ?></th><th><?= t('amount') ?></th><th><?= t('status') ?></th><th><?= t('pay_gateway') ?></th><th><?= t('code') ?></th><th></th></tr></thead><tbody>
        <?php foreach ($pays as $o): $open = in_array($o['status'], ['pending', 'failed', 'expired', 'cancelled'], true);
            $gwTxt = trim(preg_replace('/\s+/', ' ', strip_tags((string)$o['gateway_response']))); ?>
          <tr>
            <td data-label="<?= t('order_ref') ?>"><span class="mono small"><?= h($o['order_ref']) ?></span><div class="small text-secondary"><?= h(date('d M Y H:i', strtotime($o['created_at']))) ?></div></td>
            <?php if ($isAdm): ?><td data-label="<?= t('seller') ?>"><?= h($o['seller_name'] ?? '—') ?></td><?php endif; ?>
            <td data-label="<?= t('pay_customer') ?>"><b class="text-body-emphasis"><?= h($o['phone']) ?></b>
              <div class="small text-secondary"><?= $o['client_mac'] ? '<span class="mono">' . h(dashMac($o['client_mac'])) . '</span>' : '' ?><?= ($o['ssid'] ?? '') !== '' && $o['ssid'] !== null ? ' • 📶 ' . h($o['ssid']) : '' ?><?= $o['device_name'] ? ' • ' . h($o['device_name']) : '' ?></div></td>
            <td data-label="<?= t('package') ?>"><?= h($o['package_name'] ?? ($o['pkg_name'] ?? '—')) ?></td>
            <td data-label="<?= t('amount') ?>" class="fw-semibold"><?= money($o['amount']) ?></td>
            <td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $badge[$o['status']] ?? 'secondary' ?>"><?= h($o['status']) ?></span>
              <?php if ($o['status'] === 'paid' && $o['paid_at']): ?><div class="small text-secondary"><?= h(date('d M H:i', strtotime($o['paid_at']))) ?></div><?php endif; ?>
              <?php if (!empty($o['confirmed_name'])): ?><div class="small text-secondary"><?= t('pay_confirmed_by') ?>: <?= h($o['confirmed_name']) ?></div><?php endif; ?>
              <?php if (($o['admin_note'] ?? '') !== '' && $o['admin_note'] !== null): ?><div class="small text-info" style="max-width:220px;word-break:break-word"><i class="fa-regular fa-note-sticky me-1"></i><?= h($o['admin_note']) ?></div><?php endif; ?></td>
            <td data-label="<?= t('pay_gateway') ?>" class="small"><?= $o['gateway_ref'] ? '<span class="mono">' . h($o['gateway_ref']) . '</span>' : '<span class="text-secondary">Lipa Namba</span>' ?>
              <?php $sps = (string)($o['sp_status'] ?? ''); if ($sps !== ''):
                  $spc = in_array($sps, ['SUCCESS', 'SUCCESSFUL', 'COMPLETED', 'PAID', 'CONFIRMED'], true) ? 'success' : (preg_match('/FAIL|CANCEL|REJECT|ERROR|UNDERPAID|EXPIRED/', $sps) ? 'danger' : 'warning'); ?>
                <div><span class="badge text-bg-<?= $spc ?>"><?= t('pay_sp_status') ?>: <?= h($sps) ?></span></div><?php endif; ?>
              <?php if (!empty($o['sp_transid'])): ?><div class="text-secondary">TxID <span class="mono"><?= h($o['sp_transid']) ?></span><?= !empty($o['sp_channel']) ? ' • ' . h($o['sp_channel']) : '' ?></div><?php endif; ?>
              <?php if (!empty($o['sp_checked_at'])): ?><div class="text-secondary"><?= h(date('d M H:i:s', strtotime($o['sp_checked_at']))) ?> • <?= (int)($o['sp_check_count'] ?? 0) ?>×</div><?php endif; ?>
              <?php if ($o['status'] !== 'paid' && (string)($o['fulfill_error'] ?? '') !== ''): ?><div class="text-danger" style="max-width:240px;word-break:break-word"><i class="fa-solid fa-triangle-exclamation me-1"></i><?= t('pay_error') ?>: <?= h($o['fulfill_error']) ?></div><?php endif; ?>
              <?php if ($gwTxt !== ''): ?><div class="text-secondary text-truncate" style="max-width:200px" title="<?= h(substr($gwTxt, 0, 600)) ?>"><?= h(substr($gwTxt, 0, 80)) ?></div><?php endif; ?>
              <?php $evs = Payments::events((int)$o['id'], 8); if ($evs): ?>
                <details class="mt-1"><summary class="text-primary" style="cursor:pointer"><i class="fa-solid fa-list me-1"></i><?= t('pay_log') ?> (<?= count($evs) ?>)</summary>
                  <div class="p-2 mt-1 rounded-3" style="background:var(--surface-3);max-width:320px">
                  <?php foreach ($evs as $ev): ?><div class="border-bottom border-secondary-subtle py-1"><b><?= h($ev['source']) ?></b> <span class="badge text-bg-secondary"><?= h((string)$ev['state']) ?></span>
                    <?= (int)$ev['http_code'] ? '<span class="text-secondary">HTTP ' . (int)$ev['http_code'] . '</span>' : '' ?> <span class="text-secondary"><?= h(date('d M H:i:s', strtotime($ev['created_at']))) ?></span>
                    <?php if ((string)$ev['message'] !== ''): ?><div style="word-break:break-word"><?= h($ev['message']) ?></div><?php endif; ?>
                    <?php if ((string)$ev['body'] !== ''): ?><div class="mono text-secondary" style="font-size:.7rem;word-break:break-all;max-height:80px;overflow:auto"><?= h(substr((string)$ev['body'], 0, 600)) ?></div><?php endif; ?></div>
                  <?php endforeach; ?></div></details>
              <?php endif; ?></td>
            <td data-label="<?= t('code') ?>"><?php if ($o['code']): ?><span class="mono fw-bold text-body-emphasis"><?= h($o['code']) ?></span>
              <div class="small"><?= $o['v_used'] ? '<span class="text-success">' . t('pay_voucher_used') . '</span>' : '<span class="text-warning">' . t('pay_voucher_waiting') . '</span>' ?></div><?php else: ?>—<?php endif; ?></td>
            <td class="text-nowrap">
              <?php if ($open): ?>
                <details class="d-inline-block text-start"><summary class="btn btn-sm btn-success"><i class="fa-solid fa-check me-1"></i><?= t('pay_confirm') ?></summary>
                  <form method="POST" class="p-2 mt-1 rounded-3" style="background:var(--surface-3);min-width:250px" onsubmit="return confirm(<?= h(json_encode(t('pay_confirm_q') . ' ' . money($o['amount']) . ' — ' . $o['phone'])) ?>)">
                    <?= $hidden($o, 'confirm') ?>
                    <input name="gateway_ref" class="form-control form-control-sm mono mb-1" maxlength="100" placeholder="<?= h(t('pay_gw_ref')) ?>">
                    <input name="note" class="form-control form-control-sm mb-1" maxlength="500" placeholder="<?= h(t('pay_note')) ?>">
                    <button class="btn btn-sm btn-success w-100"><i class="fa-solid fa-wifi me-1"></i><?= t('pay_confirm_btn') ?></button></form></details>
                <?php if ($o['gateway_ref']): ?><form method="POST" class="d-inline" onsubmit="this.querySelector('button').disabled=true"><?= $hidden($o, 'recheck') ?><button class="btn btn-sm btn-outline-info" title="<?= h(t('pay_recheck')) ?>"><i class="fa-solid fa-rotate"></i></button></form><?php endif; ?>
                <?php if (in_array($o['status'], ['pending', 'expired'], true)): ?><form method="POST" class="d-inline" onsubmit="return confirm(<?= h(json_encode(t('pay_mark_failed') . '?')) ?>)"><?= $hidden($o, 'fail') ?><button class="btn btn-sm btn-outline-danger" title="<?= h(t('pay_mark_failed')) ?>"><i class="fa-solid fa-xmark"></i></button></form><?php endif; ?>
                <?php if ($o['status'] !== 'cancelled'): ?><form method="POST" class="d-inline" onsubmit="return confirm(<?= h(json_encode(t('pay_cancel') . '?')) ?>)"><?= $hidden($o, 'cancel') ?><button class="btn btn-sm btn-outline-secondary" title="<?= h(t('pay_cancel')) ?>"><i class="fa-solid fa-ban"></i></button></form><?php endif; ?>
              <?php elseif ($o['status'] === 'paid'): ?>
                <?php if ($o['client_mac']): ?><form method="POST" class="d-inline" onsubmit="this.querySelector('button').disabled=true"><?= $hidden($o, 'reconnect') ?><button class="btn btn-sm btn-outline-primary" title="<?= h(t('pay_reconnect')) ?>"><i class="fa-solid fa-wifi me-1"></i><?= t('pay_reconnect') ?></button></form><?php endif; ?>
              <?php endif; ?>
              <?php if ($o['status'] !== 'paid'): ?>
              <details class="d-inline-block text-start"><summary class="btn btn-sm btn-outline-primary" title="<?= h(t('pay_set_status')) ?>"><i class="fa-solid fa-pen-to-square"></i></summary>
                <form method="POST" class="p-2 mt-1 rounded-3" style="background:var(--surface-3);min-width:250px" onsubmit="return this.to.value!=='paid'||confirm(<?= h(json_encode(t('pay_confirm_q') . ' ' . money($o['amount']) . ' — ' . $o['phone'])) ?>)"><?= $hidden($o, 'set_status') ?>
                  <div class="small text-secondary mb-1"><?= t('pay_set_status_help') ?></div>
                  <select name="to" class="form-select form-select-sm mb-1"><?php foreach (['paid', 'pending', 'failed', 'cancelled', 'expired'] as $stOpt): ?><option value="<?= $stOpt ?>" <?= $stOpt === $o['status'] ? 'selected' : '' ?>><?= $stOpt ?></option><?php endforeach; ?></select>
                  <input name="gateway_ref" class="form-control form-control-sm mono mb-1" maxlength="100" placeholder="<?= h(t('pay_gw_ref')) ?>">
                  <button class="btn btn-sm btn-primary w-100"><?= t('pay_set_status') ?></button></form></details>
              <?php endif; ?>
              <details class="d-inline-block text-start"><summary class="btn btn-sm btn-outline-secondary" title="<?= h(t('pay_note')) ?>"><i class="fa-regular fa-note-sticky"></i></summary>
                <form method="POST" class="p-2 mt-1 rounded-3 d-flex gap-1" style="background:var(--surface-3);min-width:240px"><?= $hidden($o, 'note') ?>
                  <input name="note" class="form-control form-control-sm" maxlength="500" value="<?= h((string)($o['admin_note'] ?? '')) ?>"><button class="btn btn-sm btn-primary"><?= t('save') ?></button></form></details>
            </td></tr>
        <?php endforeach; ?></tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
      </div></div>
    <?php else: ?>
    <div class="card"><div class="card-body table-responsive">
      <?php if ($ledger): ?><table class="table table-sm table-hover mcard"><thead><tr><th><?= t('reference') ?></th><?php if ($isAdm): ?><th><?= t('seller') ?></th><?php endif; ?><th><?= t('type') ?></th><th><?= t('amount') ?></th><th><?= t('method') ?></th><th><?= t('code') ?></th><th><?= t('status') ?></th><th><?= t('date') ?></th></tr></thead><tbody>
      <?php foreach ($ledger as $tx): $neg = in_array($tx['type'], ['withdrawal', 'commission'], true);
          $src = $tx['type'] === 'purchase' ? ($tx['payment_method'] === 'voucher' ? '<span class="badge text-bg-info"><i class="fa-solid fa-ticket me-1"></i>voucher</span>' : '<span class="badge text-bg-success"><i class="fa-solid fa-mobile-screen me-1"></i>' . h($tx['payment_method'] === 'manual' ? 'mobile money (confirmed)' : 'mobile money') . '</span>') : h($tx['payment_method']); ?>
        <tr><td data-label="<?= t('reference') ?>" class="small mono"><?= h($tx['transaction_ref']) ?></td><?php if ($isAdm): ?><td data-label="<?= t('seller') ?>"><?= h($tx['username'] ?? '—') ?></td><?php endif; ?>
          <td data-label="<?= t('type') ?>"><?= h($tx['type']) ?></td>
          <td data-label="<?= t('amount') ?>" class="fw-semibold <?= $neg ? 'text-danger' : 'text-success' ?>"><?= $neg ? '−' : '+' ?><?= money($tx['amount']) ?></td>
          <td data-label="<?= t('method') ?>"><?= $src ?></td><td data-label="<?= t('code') ?>" class="mono small"><?= h($tx['code'] ?? '') ?></td>
          <td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $tx['status'] === 'completed' ? 'success' : ($tx['status'] === 'pending' ? 'warning' : 'danger') ?>"><?= h($tx['status']) ?></span></td>
          <td data-label="<?= t('date') ?>" class="small"><?= h(date('d M Y H:i', strtotime($tx['created_at']))) ?></td></tr><?php endforeach; ?>
      </tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
    </div></div>
    <?php endif; ?>
    <?php break;

case 'withdraw':
    $auth->requireSeller();
    $error = ''; $okMsg = '';
    $pf = (float)WITHDRAWAL_FEE_PERCENT; $sf = (float)SONIC_PESA_FEE_PERCENT;
    $minW = max((float)getSetting('min_withdrawal', '5000'), ceil((float)SONIC_PESA_MIN_PAYOUT / (1 - $pf / 100)));
    $methods = ['mpesa' => 'M-Pesa', 'tigopesa' => 'Tigo Pesa / Mixx', 'airtelmoney' => 'Airtel Money', 'halopesa' => 'HaloPesa', 'crdb' => 'CRDB Bank', 'nmb' => 'NMB Bank', 'selcom' => 'Selcom'];
    if ($isPost && ($P['act'] ?? '') === 'withdraw') {
        $amount = round((float)($P['amount'] ?? 0), 2); $method = (string)($P['method'] ?? ''); $acc = trim((string)($P['account_number'] ?? '')); $accName = trim((string)($P['account_name'] ?? ''));
        if (!isset($methods[$method])) $error = t('invalid_method');
        elseif ($acc === '') $error = t('all_fields_required');
        elseif ($amount > (float)$user['balance']) $error = t('insufficient_balance');
        elseif ($amount < $minW) $error = t('below_minimum') . ' (' . money($minW) . ')';
        elseif (!SonicPesaPayout::configured()) $error = t('withdrawal_failed') . ' Sonic Pesa — not configured.';
        elseif (!rateLimitCheck('wd' . $user['id'], 'withdraw', 3, 600)) $error = t('rate_limited');
        else {
            $platformFee = round($amount * $pf / 100, 2); $toSonic = round($amount - $platformFee, 2);
            $sonicFee = round($toSonic * $sf / 100, 2); $net = round($toSonic - $sonicFee, 2);
            if ($toSonic < (float)SONIC_PESA_MIN_PAYOUT) $error = t('sonic_pesa_minimum');
            else {
                try {
                    db()->begin_transaction();
                    if (run("UPDATE users SET balance=balance-? WHERE id=? AND balance>=?", 'did', $amount, $user['id'], $amount) !== 1) throw new RuntimeException(t('insufficient_balance'));
                    q("INSERT INTO withdrawals (user_id,amount,fee,net_amount,method,account_number,account_name,status,sonic_pesa_fee,sonic_pesa_net_amount) VALUES (?,?,?,?,?,?,?,'pending',?,?)",
                        'idddsssdd', $user['id'], $amount, $platformFee + $sonicFee, $net, $method, $acc, $accName, $sonicFee, $net);
                    $wid = db()->insert_id;
                    q("INSERT INTO transactions (user_id,seller_id,transaction_ref,amount,payment_method,payment_phone,type,status) VALUES (?,?,?,?,?,?,'withdrawal','pending')",
                        'iisdss', $user['id'], $user['id'], 'WD' . $wid, $amount, $method, $acc);
                    db()->commit();
                    $po = (new SonicPesaPayout())->createPayout($toSonic, $method, $acc, $accName);
                    if (!empty($po['success'])) {
                        $sid = (string)($po['data']['withdrawal_id'] ?? $po['data']['id'] ?? '');
                        run("UPDATE withdrawals SET status='processing', sonic_pesa_withdrawal_id=?, sonic_pesa_response=? WHERE id=?", 'ssi', $sid ?: null, json_encode($po['data']), $wid);
                        $okMsg = t('withdrawal_pending_desc');
                    } else {
                        run("UPDATE withdrawals SET status='rejected', admin_notes=? WHERE id=?", 'si', (string)$po['message'], $wid);
                        run("UPDATE users SET balance=balance+? WHERE id=?", 'di', $amount, $user['id']);
                        run("UPDATE transactions SET status='failed' WHERE transaction_ref=?", 's', 'WD' . $wid);
                        $error = t('withdrawal_failed') . ' ' . $po['message'];
                    }
                    $user = $auth->user();
                } catch (Throwable $e) { db()->rollback(); $error = t('withdrawal_failed') . ' ' . $e->getMessage(); }
            }
        }
    }
    $hist = rows("SELECT * FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 100", 'i', $user['id']);
    ?>
    <?php if ($okMsg): ?><div class="alert alert-warning"><b><?= t('withdrawal_pending') ?></b><br><?= h($okMsg) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
    <div class="row g-3">
      <div class="col-lg-5"><div class="card"><div class="card-header"><i class="fa-solid fa-money-bill-wave me-2"></i><?= t('request_withdrawal') ?></div><div class="card-body">
        <div class="card stat s1 p-3 mb-3"><h6><?= t('earn_available') ?></h6><h4 class="mb-0 fw-bold"><?= money($user['balance']) ?></h4></div>
        <?php $wern = Earnings::summary((int)$user['id']); ?>
        <div class="small mb-3 p-3 rounded-3" style="background:var(--surface-2);border:1px solid var(--line)">
          <div class="d-flex justify-content-between"><span class="text-secondary"><?= t('earn_mobile') ?></span><b class="text-body-emphasis"><?= money($wern['mobile']) ?></b></div>
          <div class="d-flex justify-content-between mt-1"><span class="text-secondary"><?= t('earn_vouchers') ?></span><b class="text-body-emphasis"><?= money($wern['vouchers']) ?></b></div>
          <?php if ($wern['commission'] > 0): ?><div class="d-flex justify-content-between mt-1"><span class="text-secondary"><?= t('earn_commission') ?></span><b class="text-danger">−<?= money($wern['commission']) ?></b></div><?php endif; ?>
          <div class="d-flex justify-content-between mt-1 pt-1 border-top border-secondary-subtle"><span class="text-secondary"><?= t('earn_total') ?></span><b class="text-body-emphasis"><?= money($wern['total']) ?></b></div>
          <div class="d-flex justify-content-between mt-1"><span class="text-secondary"><?= t('earn_withdrawn') ?></span><b class="text-danger">−<?= money($wern['withdrawn']) ?></b></div>
          <div class="d-flex justify-content-between mt-1 pt-1 border-top border-secondary-subtle"><span class="text-body-emphasis fw-semibold"><?= t('earn_available') ?></span><b class="text-success"><?= money($wern['balance']) ?></b></div>
        </div>
        <div class="small mb-3 p-3 rounded-3" style="background:var(--surface-2);border:1px solid var(--line)">
          <div class="d-flex justify-content-between"><span class="text-secondary"><?= t('minimum_withdrawal') ?></span><b class="text-body-emphasis"><?= money($minW) ?></b></div>
          <div class="d-flex justify-content-between mt-1"><span class="text-secondary"><?= t('withdraw_fee') ?></span><b class="text-body-emphasis"><?= rtrim(rtrim(number_format(withdrawalFeePercent(), 2), '0'), '.') ?>%</b></div>
          <div class="text-secondary mt-1" style="font-size:.74rem"><?= t('withdraw_fee_note') ?></div>
        </div>
        <form method="POST" class="row g-3"><?= csrf_field() ?><input type="hidden" name="act" value="withdraw">
          <div class="col-12"><label class="form-label small"><?= t('amount') ?></label><input type="number" step="1" name="amount" id="wa" class="form-control form-control-lg" min="<?= $minW ?>" max="<?= (float)$user['balance'] ?>" required oninput="calc()"></div>
          <div class="col-12"><div class="rounded-3 p-3 small" style="border:1.5px dashed var(--brand);background:var(--brand-soft)">
            <div class="d-flex justify-content-between"><span><?= t('withdraw_fee') ?> (<?= rtrim(rtrim(number_format(withdrawalFeePercent(), 2), '0'), '.') ?>%)</span><span id="w1">0</span></div>
            <div class="d-flex justify-content-between fw-bold text-success border-top border-secondary-subtle mt-2 pt-2"><span><?= t('you_receive') ?></span><span id="w3">0</span></div></div></div>
          <div class="col-12"><label class="form-label small"><?= t('method') ?></label><select name="method" class="form-select"><?php foreach ($methods as $k => $n): ?><option value="<?= $k ?>"><?= $n ?></option><?php endforeach; ?></select></div>
          <div class="col-12"><label class="form-label small"><?= t('account_number') ?></label><input name="account_number" class="form-control" value="<?= h($user['phone']) ?>" required></div>
          <div class="col-12"><label class="form-label small"><?= t('account_name') ?></label><input name="account_name" class="form-control" value="<?= h($user['full_name']) ?>"></div>
          <div class="col-12"><button class="btn btn-primary w-100 py-2"><i class="fa-solid fa-paper-plane me-1"></i><?= t('submit_request') ?></button></div>
        </form></div></div></div>
      <div class="col-lg-7"><div class="card"><div class="card-header"><i class="fa-solid fa-clock-rotate-left me-2"></i><?= t('withdrawal_history') ?></div><div class="card-body table-responsive">
        <?php if ($hist): ?><table class="table table-sm table-hover mcard"><thead><tr><th><?= t('amount') ?></th><th><?= t('fee') ?></th><th><?= t('net_amount') ?></th><th><?= t('status') ?></th><th><?= t('date') ?></th></tr></thead><tbody>
        <?php foreach ($hist as $w): ?><tr><td data-label="<?= t('amount') ?>" class="fw-semibold"><?= money($w['amount']) ?></td><td data-label="<?= t('fee') ?>"><?= money($w['fee']) ?></td><td data-label="<?= t('net_amount') ?>"><?= money($w['net_amount']) ?></td>
          <td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= ['completed' => 'success', 'pending' => 'warning', 'processing' => 'info'][$w['status']] ?? 'danger' ?>"><?= h($w['status']) ?></span></td><td data-label="<?= t('date') ?>" class="small"><?= h(date('d M Y', strtotime($w['created_at']))) ?></td></tr><?php endforeach; ?>
        </tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
      </div></div></div>
    </div>
    <script>function calc(){const v=parseFloat(document.getElementById('wa').value)||0,pf=v*<?= $pf ?>/100,ts=v-pf,sf=ts*<?= $sf ?>/100,n=ts-sf,f=x=>'<?= CURRENCY ?> '+Math.round(x).toLocaleString();
      document.getElementById('w1').textContent='− '+f(v-n);document.getElementById('w3').textContent=f(n)}</script>
    <?php break;

case 'profile':
    $auth->requireLogin();
    ?>
    <div class="row g-3">
      <div class="col-lg-6"><div class="card"><div class="card-header"><i class="fa-solid fa-user me-2"></i><?= t('profile') ?></div><div class="card-body">
        <form method="POST" class="row g-3"><?= csrf_field() ?><input type="hidden" name="act" value="profile">
          <div class="col-12"><label class="form-label small"><?= t('full_name') ?></label><input name="full_name" class="form-control" value="<?= h($user['full_name']) ?>" required></div>
          <div class="col-12"><label class="form-label small"><?= t('username') ?></label><input class="form-control" value="<?= h($user['username']) ?>" disabled></div>
          <div class="col-md-6"><label class="form-label small"><?= t('email') ?></label><input type="email" name="email" class="form-control" value="<?= h($user['email']) ?>" required></div>
          <div class="col-md-6"><label class="form-label small"><?= t('phone') ?></label><input name="phone" class="form-control" value="<?= h($user['phone']) ?>" required></div>
          <div class="col-12"><button class="btn btn-primary"><i class="fa-solid fa-floppy-disk me-1"></i><?= t('update') ?></button></div>
        </form></div></div></div>
      <div class="col-lg-6"><div class="card"><div class="card-header"><i class="fa-solid fa-lock me-2"></i><?= t('change_password') ?></div><div class="card-body">
        <form method="POST" class="row g-3"><?= csrf_field() ?><input type="hidden" name="act" value="password">
          <div class="col-12"><label class="form-label small"><?= t('current_password') ?></label><input type="password" name="current" class="form-control" autocomplete="current-password" required></div>
          <div class="col-12"><label class="form-label small"><?= t('new_password') ?></label><input type="password" name="new" class="form-control" minlength="6" autocomplete="new-password" required></div>
          <div class="col-12"><button class="btn btn-warning"><i class="fa-solid fa-key me-1"></i><?= t('change_password') ?></button></div>
        </form></div></div></div>
    </div>
    <?php break;

case 'settings':
    $auth->requireLogin();
    ?>
    <div class="row g-3">
      <div class="col-md-6"><div class="card"><div class="card-header"><i class="fa-solid fa-bell me-2"></i><?= t('notifications') ?></div><div class="card-body">
        <form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="prefs">
          <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="sms_enabled" id="s1" <?= $user['sms_enabled'] ? 'checked' : '' ?>><label class="form-check-label" for="s1">SMS</label></div>
          <div class="form-check form-switch mb-4"><input class="form-check-input" type="checkbox" name="email_enabled" id="s2" <?= $user['email_enabled'] ? 'checked' : '' ?>><label class="form-check-label" for="s2">Email</label></div>
          <button class="btn btn-primary"><?= t('save') ?></button></form></div></div></div>
      <div class="col-md-6"><div class="card"><div class="card-header"><i class="fa-solid fa-display me-2"></i>Appearance</div><div class="card-body d-grid gap-2">
        <button type="button" class="btn btn-outline-secondary" onclick="toggleTheme()"><i class="fa-solid fa-circle-half-stroke me-1"></i> Light / Dark</button>
        <button class="btn btn-outline-success d-none" id="installBtn"><i class="fa-solid fa-download"></i> Install app</button>
      </div></div></div>
    </div>
    <?php break;

case 'notifications':
    $auth->requireLogin();
    $list = Notify::list((int)$user['id'], 100);
    ?>
    <div class="d-flex justify-content-end mb-3"><form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="notif_read_all"><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-check-double me-1"></i><?= t('mark_all_read') ?></button></form></div>
    <div class="card overflow-hidden"><div class="card-body p-0">
      <?php foreach ($list as $n): ?><a href="<?= h($n['link'] ?: '#') ?>" class="notif-item <?= $n['is_read'] ? 'text-secondary' : 'unread text-body-emphasis' ?>">
        <div class="notif-ic"><i class="fa-solid fa-<?= h($n['icon'] ?: 'bell') ?>"></i></div>
        <div class="min-w-0"><div class="fw-semibold"><?= h($n['title']) ?></div><div class="small"><?= h($n['message']) ?></div><div class="small text-secondary"><?= h(date('d M Y H:i', strtotime($n['created_at']))) ?></div></div></a>
      <?php endforeach; if (!$list) echo '<p class="text-secondary p-5 mb-0 text-center"><i class="fa-regular fa-bell-slash fa-2x d-block mb-3 opacity-50"></i>' . t('no_notifications') . '</p>'; ?>
    </div></div>
    <?php break;

case 'admin':
    $auth->requireAdmin();
    $c = fn($sql) => val($sql);
    $users = rows("SELECT u.*, (SELECT COUNT(*) FROM hs_devices d WHERE d.user_id=u.id) devs,
                        (SELECT COUNT(*) FROM hs_controllers c WHERE c.user_id=u.id) ctrls,
                        (SELECT COUNT(*) FROM hs_controllers c WHERE c.user_id=u.id AND c.client_id IS NOT NULL AND c.client_id<>'' AND c.client_secret IS NOT NULL AND c.client_secret<>'') api_ctrls,
                        (SELECT COUNT(*) FROM hs_devices d WHERE d.user_id=u.id AND d.omada_status='connected') omada_on
                   FROM users u ORDER BY u.id DESC LIMIT 100");
    $wds = rows("SELECT w.*, u.username FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.id DESC LIMIT 30");
    ?>
    <?= securityPanel(securityIssues()) ?>
    <div class="row g-3 mb-3">
      <div class="col-6 col-xl-3"><div class="card stat s1 p-3"><h6>Sellers</h6><h4 class="mb-0"><?= (int)$c("SELECT COUNT(*) FROM users WHERE user_type='seller'") ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s2 p-3"><h6>EAP225 online</h6><h4 class="mb-0"><?= (int)$c("SELECT COUNT(*) FROM hs_devices WHERE last_seen > DATE_SUB(NOW(), INTERVAL 10 MINUTE) OR (omada_status='connected' AND omada_status_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE))") ?>/<?= (int)$c("SELECT COUNT(*) FROM hs_devices") ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s3 p-3"><h6><?= t('active_sessions') ?></h6><h4 class="mb-0"><?= (int)$c("SELECT COUNT(*) FROM hs_sessions WHERE status='active'") ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s4 p-3"><h6>Online sales today</h6><h4 class="mb-0"><?= money($c("SELECT COALESCE(SUM(amount),0) FROM hs_orders WHERE status='paid' AND DATE(paid_at)=CURDATE()")) ?></h4></div></div>
    </div>
    <div class="row g-3">
      <div class="col-lg-5"><div class="card"><div class="card-header"><i class="fa-solid fa-sliders me-2"></i>Platform settings</div><div class="card-body">
        <form method="POST" class="row g-3"><?= csrf_field() ?><input type="hidden" name="act" value="admin_settings"><input type="hidden" name="form" value="platform">
          <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="allow_registration" value="1" id="areg" <?= getSetting('allow_registration', '1') === '1' ? 'checked' : '' ?>><label class="form-check-label small" for="areg"><?= t('allow_registration') ?></label></div></div>
          <div class="col-6"><label class="form-label small">Commission % on portal sales</label><input name="platform_commission_percent" type="number" step="0.1" min="0" max="100" class="form-control" value="<?= h(getSetting('platform_commission_percent', '0')) ?>"></div>
          <div class="col-6"><label class="form-label small">Min withdrawal (<?= CURRENCY ?>)</label><input name="min_withdrawal" type="number" class="form-control" value="<?= h(getSetting('min_withdrawal', '5000')) ?>"></div>
          <div class="col-6"><label class="form-label small">Voucher code length</label><input name="voucher_length" type="number" min="6" max="12" class="form-control" value="<?= h(getSetting('voucher_length', '8')) ?>"></div>
          <div class="col-6"><label class="form-label small"><?= t('sales_contact') ?></label><input name="sales_contact_phone" class="form-control mono" value="<?= h(salesContactPhone()) ?>" placeholder="0612710364"></div>
          <div class="col-12"><label class="form-label small">Sonic Pesa addresses (fixed, same as MIKEKA APP)</label>
            <input class="form-control mono" value="<?= h(SONIC_PESA_MIKEKA_URL . sonicCollectEndpoint()) ?>" readonly>
            <input class="form-control mono mt-1" value="<?= h(SONIC_PESA_MIKEKA_URL . sonicStatusEndpoint()) ?>" readonly>
            <div class="form-text">Callback: <?= h(machineUrl() . (strpos(machineUrl(), '?') === false ? '?' : '&') . 'webhook=sonicpesa&secret=…') ?>
              • API key: <?= Payments::sonicConfigured() ? '<span class="text-success">OK</span>' : '<span class="text-danger">missing — the portal uses manual Lipa Namba</span>' ?></div></div>
          <?php $spFromCfg = (string)SONIC_PESA_API_KEY !== ''; $spSaved = openSecret(getSetting('sonic_api_key')) !== ''; ?>
          <div class="col-12"><div class="p-3 rounded-3" style="border:1px dashed var(--line-2);background:var(--surface-2)">
            <div class="small fw-semibold text-body-emphasis mb-1"><i class="fa-solid fa-mobile-screen me-1 text-primary"></i>Sonic Pesa (mobile money push on the captive portal)
              <?= Payments::sonicConfigured() ? '<span class="badge text-bg-success ms-1">connected</span>' : '<span class="badge text-bg-danger ms-1">not set</span>' ?></div>
            <?php if ($spFromCfg): ?><div class="form-text mt-0 mb-2">The API key comes from config.local.php (SONIC_PESA_API_KEY) and overrides the fields below.</div><?php endif; ?>
            <div class="row g-2">
              <div class="col-md-6"><label class="form-label small">API key (X-API-KEY) *</label><input name="sonic_api_key_in" type="password" class="form-control form-control-sm mono" autocomplete="new-password" spellcheck="false" placeholder="<?= $spSaved ? h(t('ctrl_secret_keep')) : 'sk_live_…' ?>"></div>
              <div class="col-md-6"><label class="form-label small">API secret (optional)</label><input name="sonic_api_secret_in" type="password" class="form-control form-control-sm mono" autocomplete="new-password" spellcheck="false" placeholder="<?= openSecret(getSetting('sonic_api_secret')) !== '' ? h(t('ctrl_secret_keep')) : '' ?>"></div>
              <div class="col-12 form-text mt-0">Callback URL (sent automatically with every push): <span class="mono"><?= h(preg_replace('/secret=[^&]+/', 'secret=…', sonicCallbackUrl())) ?></span></div>
              <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="sonic_test" value="1" id="spt" checked><label class="form-check-label small" for="spt">Test the key after saving</label></div></div>
              <?php if ($spSaved): ?><div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="sonic_keys_remove" value="1" id="spr"><label class="form-check-label small text-danger" for="spr">Remove the saved keys</label></div></div><?php endif; ?>
            </div></div></div>
          <?php $baUrl = omadaPortalAuthUrl(); $baWarn = browserAuthUrlWarning($baUrl); ?>
          <div class="col-12"><div class="p-3 rounded-3" style="border:1px dashed var(--line-2);background:var(--surface-2)">
            <div class="small fw-semibold text-body-emphasis mb-1"><i class="fa-solid fa-lock me-1 text-primary"></i>Omada browserauth URL (captive portal login, HTTPS)
              <?= $baWarn === '' ? '<span class="badge text-bg-success ms-1">HTTPS domain</span>' : '<span class="badge text-bg-danger ms-1">certificate risk</span>' ?></div>
            <input name="omada_portal_auth_url" class="form-control form-control-sm mono" value="<?= h(getSetting('omada_portal_auth_url')) ?>" placeholder="<?= h((string)OMADA_PORTAL_AUTH_URL) ?>" spellcheck="false">
            <div class="form-text">Phones post the voucher here after "Connect". Empty = <span class="mono"><?= h(normalizeBrowserAuthUrl((string)OMADA_PORTAL_AUTH_URL)) ?></span>.
              In use now: <span class="mono"><?= h($baUrl ?: '—') ?></span><?= $baWarn !== '' ? '<br><span class="text-danger">' . h($baWarn) . '</span>' : '' ?></div>
            <div class="form-check mt-1"><input class="form-check-input" type="checkbox" name="browserauth_test" value="1" id="bat"><label class="form-check-label small" for="bat">Test the SSL certificate after saving</label></div>
          </div></div>
          <div class="col-6 d-flex align-items-end"><a href="?page=radius" class="small"><i class="fa-solid fa-network-wired me-1"></i>RADIUS server settings →</a></div>
          <div class="col-12"><button class="btn btn-primary"><?= t('save') ?></button></div>
        </form>
        <?php $spLastErr = getSetting('sp_last_push_error'); ?>
        <form method="POST" class="row g-2 mt-3 pt-3 border-top border-secondary-subtle" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="admin_sonic_push_test">
          <div class="col-12 small fw-semibold text-body-emphasis"><i class="fa-solid fa-mobile-screen-button me-1 text-primary"></i>Send a test USSD push (real Sonic Pesa request)</div>
          <div class="col-7"><input name="phone" class="form-control form-control-sm mono" placeholder="07XXXXXXXX" required></div>
          <div class="col-5"><input name="amount" type="number" min="100" class="form-control form-control-sm" value="1000"></div>
          <div class="col-12"><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-paper-plane me-1"></i>Send test push</button>
            <span class="small text-secondary ms-2">Key: <?= Payments::sonicConfigured() ? '<span class="text-success">OK</span>' : '<span class="text-danger">missing</span>' ?> • v<?= h(APP_VERSION) ?></span></div>
          <?php if ($spLastErr !== ''): ?><div class="col-12"><div class="alert alert-danger small py-2 mb-0" style="word-break:break-word"><b>Last USSD push error:</b> <?= h($spLastErr) ?></div></div><?php endif; ?>
        </form></div></div></div>
      <div class="col-lg-7"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-bullhorn me-2"></i><?= t('broadcast') ?></div><div class="card-body">
        <form method="POST" class="row g-2"><?= csrf_field() ?><input type="hidden" name="act" value="admin_broadcast">
          <div class="col-12"><label class="form-label small"><?= t('broadcast_title') ?></label><input name="title" class="form-control" maxlength="200" required></div>
          <div class="col-12"><label class="form-label small"><?= t('broadcast_msg') ?></label><textarea name="message" class="form-control" rows="3" maxlength="2000" required></textarea></div>
          <div class="col-12"><button class="btn btn-primary"><i class="fa-solid fa-paper-plane me-1"></i><?= t('broadcast') ?></button> <a href="?page=all_routers" class="btn btn-outline-secondary"><i class="fa-solid fa-server me-1"></i><?= t('all_routers') ?></a></div>
        </form></div></div></div>
      <div class="col-12"><div class="card"><div class="card-header"><i class="fa-solid fa-users me-2"></i>Users</div><div class="card-body table-responsive">
        <table class="table table-sm table-hover mcard align-middle"><thead><tr><th>User</th><th>Type</th><th>APs</th><th>Omada</th><th><?= t('balance') ?></th><th><?= t('status') ?></th><th></th></tr></thead><tbody>
        <?php foreach ($users as $u): ?><tr><td data-label="User"><b class="text-body-emphasis"><?= h($u['username']) ?></b><div class="small text-secondary"><?= h($u['phone']) ?></div></td><td data-label="Type"><?= h($u['user_type']) ?></td><td data-label="APs"><?= (int)$u['devs'] ?></td>
          <td data-label="Omada" class="small"><?php if ((int)$u['ctrls']): ?><?= (int)$u['ctrls'] ?> <i class="fa-solid fa-cloud"></i><?= (int)$u['api_ctrls'] ? ' <span class="badge text-bg-success">API ' . (int)$u['api_ctrls'] . '</span>' : ' <span class="badge text-bg-secondary">Inform URL</span>' ?><div class="text-secondary"><?= (int)$u['omada_on'] ?> CONNECTED</div><?php else: ?>—<?php endif; ?></td>
          <td data-label="<?= t('balance') ?>"><?= money($u['balance']) ?></td><td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $u['status'] === 'active' ? 'success' : 'danger' ?>"><?= h($u['status']) ?></span></td>
          <td><?php if ($u['user_type'] !== 'admin'): ?><form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="admin_user_status"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><input type="hidden" name="status" value="<?= $u['status'] === 'active' ? 'suspended' : 'active' ?>"><button class="btn btn-sm btn-outline-<?= $u['status'] === 'active' ? 'danger' : 'success' ?>"><?= $u['status'] === 'active' ? 'Suspend' : 'Activate' ?></button></form><?php endif; ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div></div>
      <div class="col-12"><div class="card"><div class="card-header"><i class="fa-solid fa-money-bill-transfer me-2"></i>Withdrawals</div><div class="card-body table-responsive">
        <table class="table table-sm table-hover mcard"><thead><tr><th>User</th><th><?= t('amount') ?></th><th><?= t('net_amount') ?></th><th><?= t('method') ?></th><th>Sonic ID</th><th><?= t('status') ?></th><th><?= t('date') ?></th></tr></thead><tbody>
        <?php foreach ($wds as $w): ?><tr><td data-label="User"><?= h($w['username']) ?></td><td data-label="<?= t('amount') ?>"><?= money($w['amount']) ?></td><td data-label="<?= t('net_amount') ?>"><?= money($w['net_amount']) ?></td><td data-label="<?= t('method') ?>"><?= h($w['method']) ?> <?= h($w['account_number']) ?></td><td data-label="Sonic ID" class="small mono"><?= h($w['sonic_pesa_withdrawal_id']) ?></td><td data-label="<?= t('status') ?>"><?= h($w['status']) ?></td><td data-label="<?= t('date') ?>" class="small"><?= h(date('d M H:i', strtotime($w['created_at']))) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div></div>
    </div>
    <?php break;

case 'radius':
    $auth->requireAdmin();
    $info = json_decode(getSetting('radius_server_info'), true) ?: [];
    $seen = (int)getSetting('radius_server_seen', '0');
    $srvOnline = $seen > time() - 180;
    $last = row("SELECT * FROM hs_radius_log ORDER BY id DESC LIMIT 1");
    $logs = rows("SELECT * FROM hs_radius_log ORDER BY id DESC LIMIT 100");
    $dae = rows("SELECT status, COUNT(*) n FROM hs_dae_queue GROUP BY status");
    $allDevs = rows("SELECT d.id, d.device_name, d.nas_id, d.omada_nas_id, d.nas_learned_at, d.last_seen, d.radius_src_ip, d.radius_last_auth, d.is_active, u.username
                     FROM hs_devices d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC LIMIT 300");
    $weakKey = radiusApiKeyWeak();
    $kitKey = $weakKey ? bin2hex(random_bytes(24)) : (string)RADIUS_API_KEY;
    $probe = probeApiEndpoint();
    $apiUrl = machineUrl();
    $radiusIp = getSetting('radius_server_ip');
    $htKit = "# SkyTanza WiFi v5.7.2 — let the RADIUS box, payment callbacks and cron reach index.php WITHOUT a redirect.\n"
           . "# Put these lines at the TOP of public_html/.htaccess (above the rule that removes .php / forces https):\n"
           . "RewriteEngine On\n"
           . "RewriteCond %{QUERY_STRING} (^|&)(radius|webhook|cron|pwa)= [NC]\n"
           . "RewriteRule ^ - [L]\n";
    $cfgSite = "<?php\n// WEBSITE (cPanel): add to config.local.php next to index.php\ndefine('RADIUS_API_KEY', '$kitKey');\n";
    $cfgBox = "<?php\n// RADIUS SERVER BOX: /opt/skyradius/config.local.php  (no database needed here)\ndefine('RADIUS_API_URL', '$apiUrl');\ndefine('RADIUS_API_KEY', '$kitKey');\n";
    $unit = "[Unit]\nDescription=SkyTanza WiFi external RADIUS server (UDP 1812/1813)\nAfter=network-online.target\nWants=network-online.target\n\n[Service]\nUser=skyradius\nWorkingDirectory=/opt/skyradius\nExecStart=/usr/bin/php /opt/skyradius/index.php radius-server\nRestart=always\nRestartSec=3\n\n[Install]\nWantedBy=multi-user.target\n";
    $cmds = "# Ubuntu / Debian VPS with a PUBLIC IP (or a PC / Raspberry Pi at the hotspot site)\n"
          . "sudo apt update && sudo apt install -y php-cli php-curl\n"
          . "sudo useradd -r -s /usr/sbin/nologin skyradius 2>/dev/null || true\n"
          . "sudo mkdir -p /opt/skyradius\n"
          . "# upload index.php (Download button) to /opt/skyradius/index.php, then:\n"
          . "sudo nano /opt/skyradius/config.local.php            # paste box config\n"
          . "sudo chown -R skyradius:skyradius /opt/skyradius\n"
          . "sudo -u skyradius php /opt/skyradius/index.php radius-server --test\n"
          . "sudo ufw allow 1812/udp && sudo ufw allow 1813/udp   # also open them in the VPS provider firewall\n"
          . "sudo nano /etc/systemd/system/skyradius.service       # paste the service\n"
          . "sudo systemctl daemon-reload && sudo systemctl enable --now skyradius\n"
          . "sudo journalctl -u skyradius -f                       # live log\n"
          . "# v5.9 Omada relay: starts with skyradius (needs php pcntl — included in Ubuntu php-cli). Check it:\n"
          . "php -m | grep -i pcntl                                 # empty? then also install skyradius-relay.service below\n"
          . "# Omada controller on THIS VPS? EAP225s must reach it:  sudo ufw allow 29810/udp && sudo ufw allow 29811:29817/tcp && sudo ufw allow 8043/tcp\n";
    $unitRelay = "[Unit]\nDescription=SkyTanza WiFi Omada relay (website -> this box -> Omada controller)\nAfter=network-online.target\nWants=network-online.target\n\n[Service]\nUser=skyradius\nWorkingDirectory=/opt/skyradius\nEnvironment=SKY_OMADA_RELAY=1\nExecStart=/usr/bin/php /opt/skyradius/index.php omada-relay\nRestart=always\nRestartSec=3\n\n[Install]\nWantedBy=multi-user.target\n";
    $st = (array)($info['stats'] ?? []);
    ?>
    <?php $secIss = securityIssues(); if ($secIss): ?><div class="alert alert-warning small"><i class="fa-solid fa-shield-halved me-2"></i><?= count($secIss) ?> security item(s) need attention — <a href="?page=admin">Admin Panel → Security check</a>.</div><?php endif; ?>
    <?php if ($weakKey): ?><div class="alert alert-danger"><b>Step 0 — security key.</b> RADIUS_API_KEY is still the default, so the RADIUS API is switched off. Add the website line below to <code>config.local.php</code> on cPanel, and use the same key on the RADIUS box. (A new key is suggested on every page load — copy both boxes from the same view.)</div><?php endif; ?>
    <?php if (getSetting('omada_push_needed', '0') === '1'): ?><div class="alert alert-warning d-flex justify-content-between align-items-center flex-wrap gap-2"><span><i class="fa-solid fa-arrows-rotate me-2"></i><?= t('push_needed') ?></span>
      <form method="POST" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="admin_push_all"><button class="btn btn-sm btn-warning"><i class="fa-solid fa-cloud-arrow-up me-1"></i><?= t('push_all') ?></button></form></div><?php endif; ?>
    <div class="card mb-3 <?= $probe['ok'] === false ? 'border-danger-subtle' : '' ?>" id="apiProbe"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
      <span><i class="fa-solid fa-route me-2"></i>Website API endpoint (what the RADIUS box calls)</span>
      <form method="POST" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="admin_probe_api"><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-stethoscope me-1"></i>Check again</button></form></div>
      <div class="card-body small">
        <div class="d-flex align-items-center gap-2 mb-2"><i class="fa-solid fa-<?= $probe['ok'] === true ? 'circle-check text-success' : ($probe['ok'] === false ? 'circle-xmark text-danger' : 'circle-minus text-secondary') ?>"></i>
          <b class="text-body-emphasis mono"><?= h($apiUrl) ?></b><?= $probe['ok'] === true ? ' <span class="badge text-bg-success">index.php answers here</span>' : '' ?></div>
        <?php if ($probe['redirects']): ?>
          <div class="alert alert-warning py-2 mb-2">Your hosting redirects <span class="mono"><?= h($probe['start']) ?></span>: <?= h(implode(' ; ', $probe['redirects'])) ?>.
            RADIUS box v5.7.2 follows this by itself, and the config below already uses the final address. To remove the redirect completely, add the .htaccess lines below.</div>
        <?php endif; ?>
        <?php if ($probe['msg'] !== ''): ?><div class="text-secondary mb-2"><?= h($probe['msg']) ?></div><?php endif; ?>
        <div class="d-flex justify-content-between align-items-center mb-1"><b class="text-body-emphasis">Optional — public_html/.htaccess (stops the redirect for machine calls)</b><button type="button" class="btn btn-sm btn-outline-primary" onclick="cp('kHt',this)"><i class="fa-regular fa-copy"></i></button></div>
        <pre class="kit mb-0" id="kHt"><?= h($htKit) ?></pre>
        <div class="text-secondary mt-2">Checked <?= h(date('d M H:i', (int)($probe['at'] ?? time()))) ?> • External Web Portal URL for Omada: <span class="mono"><?= h(portalUrl()) ?></span></div>
      </div></div>
    <?php if ($radiusIp === ''): ?><div class="alert alert-warning"><b>Set the RADIUS Server IP</b> (public IP of the VPS/PC running <code>php index.php radius-server</code>). Sellers see "not set" in their Omada settings until you do.</div><?php endif; ?>
    <?php if ($info && version_compare((string)($info['version'] ?? '0'), '5.1.0', '<')): ?><div class="alert alert-warning"><b>Update the RADIUS box.</b> It runs v<?= h($info['version'] ?? '?') ?>. Download index.php below and replace <code>/opt/skyradius/index.php</code>, then <code>sudo systemctl restart skyradius</code> — v5.1 accepts the NAS ID exactly as Omada sends it.</div><?php endif; ?>
    <div class="row g-3">
      <div class="col-lg-6"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-heart-pulse me-2"></i>RADIUS server status</div><div class="card-body small">
        <div class="d-flex align-items-center gap-2 mb-3"><span class="dot <?= $srvOnline ? 'on' : 'off' ?>"></span><b class="fs-6 text-body-emphasis"><?= $srvOnline ? 'Running' : 'Not running / not reaching the website' ?></b></div>
        <p class="mb-1">Last heartbeat: <b><?= $seen ? h(date('d M Y H:i:s', $seen)) . ' (' . fmtSecs(time() - $seen) . ' ago)' : t('never') ?></b></p>
        <?php $rlInfo = OmadaRelay::info(); $rlSeen = (int)getSetting('omada_relay_seen', '0'); $rlOn = OmadaRelay::alive(); $rlSt = (array)($rlInfo['stats'] ?? []); ?>
        <div class="p-2 rounded-3 my-2" style="border:1px solid var(--line);background:var(--surface-2)">
          <div class="d-flex align-items-center gap-2"><span class="dot <?= $rlOn ? 'on' : 'off' ?>"></span><b class="text-body-emphasis"><?= t('relay_title') ?>: <?= $rlOn ? t('server_online') : t('server_offline') ?></b></div>
          <?php if ($rlInfo): ?><div class="mt-1">v<?= h($rlInfo['version'] ?? '?') ?> • <?= h($rlInfo['host'] ?? '?') ?> • pid <?= (int)($rlInfo['pid'] ?? 0) ?> • <?= t('last_seen') ?>: <?= $rlSeen ? h(date('d M H:i:s', $rlSeen)) : t('never') ?>
            • jobs <?= (int)($rlSt['jobs'] ?? 0) ?> (<span class="text-success"><?= (int)($rlSt['ok'] ?? 0) ?> ok</span> / <span class="text-danger"><?= (int)($rlSt['fail'] ?? 0) ?> fail</span>)<?= ($rlSt['last_ms'] ?? 0) ? ' • ' . (int)$rlSt['last_ms'] . ' ms' : '' ?>
            <?php if (($rlSt['last_error'] ?? '') !== ''): ?><div class="text-danger"><?= h($rlSt['last_error']) ?></div><?php endif; ?></div><?php endif; ?>
          <?php if (!$rlOn): ?><div class="text-secondary mt-1"><?= t('relay_off_help') ?><?= (($info['relay_mode'] ?? '') === 'separate') ? ' ' . t('relay_needs_service') : '' ?></div><?php endif; ?>
          <div class="text-secondary mt-1"><?= t('relay_explain') ?></div>
        </div>
        <?php if ($info): ?>
          <p class="mb-1">Server: <b><?= h($info['host'] ?? '?') ?></b> • v<?= h($info['version'] ?? '?') ?> • seen from IP <span class="mono"><?= h($info['ip'] ?? '?') ?></span> • up <?= fmtSecs((int)($info['uptime'] ?? 0)) ?></p>
          <p class="mb-1">Since start: <span class="text-success"><?= (int)($st['accept'] ?? 0) ?> accept</span> • <span class="text-danger"><?= (int)($st['reject'] ?? 0) ?> reject</span> • <?= (int)($st['acct'] ?? 0) ?> accounting • <?= (int)($st['dropped'] ?? 0) ?> dropped • NAS IDs learned <?= (int)($st['learned'] ?? 0) ?> • disconnect <?= (int)($st['dae_ok'] ?? 0) ?>/<?= (int)($st['dae_fail'] ?? 0) ?> • API errors <?= (int)($st['api_errors'] ?? 0) ?> • queue <?= (int)($info['queue'] ?? 0) ?></p>
        <?php endif; ?>
        <p class="mb-1">Last request reaching the website: <b><?= $last ? h($last['created_at']) . ' (' . h($last['kind']) . ' ' . h($last['result']) . ', ' . h($last['nas_id']) . ')' : t('never') ?></b></p>
        <p class="mb-1">Housekeeping: <span class="text-secondary"><?= h(getSetting('hk_last_result') ?: '—') ?></span></p>
        <p class="mb-2">Disconnect queue: <?php foreach ($dae as $q) echo '<span class="badge text-bg-secondary me-1">' . h($q['status']) . ' ' . (int)$q['n'] . '</span>'; if (!$dae) echo '—'; ?></p>
        <?php foreach ((array)($info['unknown'] ?? []) as $u): if (!is_array($u)) continue; ?>
          <div class="alert alert-warning py-2 px-3 mb-2">Packets from <span class="mono"><?= h($u['ip'] ?? '') ?></span> with NAS ID <b class="mono"><?= h($u['nas'] ?? '') ?></b> (<?= (int)($u['count'] ?? 0) ?>×) match no hotspot's RADIUS password — check the Authentication/Accounting Password in that Omada RADIUS profile.</div>
        <?php endforeach; foreach ((array)($info['badpw'] ?? []) as $u): if (!is_array($u)) continue; ?>
          <div class="alert alert-danger py-2 px-3 mb-2">Wrong <?= h($u['kind'] ?? '') ?> for hotspot <b class="mono"><?= h($u['key'] ?? '') ?></b> (NAS ID <span class="mono"><?= h($u['nas'] ?? '') ?></span>) from <span class="mono"><?= h($u['ip'] ?? '') ?></span> (<?= (int)($u['count'] ?? 0) ?>×)</div>
        <?php endforeach; ?>
        <form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="admin_run_hk"><button class="btn btn-sm btn-outline-info mt-2"><i class="fa-solid fa-broom me-1"></i>Run housekeeping now</button></form>
        <?php $srvErr = json_decode(getSetting('server_errors', '[]'), true) ?: []; ?>
        <div class="mt-3 pt-3 border-top border-secondary-subtle"><b class="text-body-emphasis"><i class="fa-solid fa-bug me-1 text-danger"></i><?= t('server_errors') ?></b>
          <?php foreach (array_slice($srvErr, 0, 8) as $se): if (!is_array($se)) continue; ?>
            <div class="mt-2"><span class="badge text-bg-danger mono"><?= h($se['ref'] ?? '') ?></span> <span class="text-secondary"><?= h($se['at'] ?? '') ?> • <?= h($se['url'] ?? '') ?></span>
              <div class="mono" style="word-break:break-word"><?= h($se['msg'] ?? '') ?> <span class="text-secondary">(<?= h($se['where'] ?? '') ?>)</span></div></div>
          <?php endforeach; if (!$srvErr) echo '<div class="text-secondary mt-1">' . t('server_errors_none') . '</div>'; ?>
        </div>
      </div></div></div>

      <div class="col-lg-6"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-sliders me-2"></i>RADIUS settings (shown to every seller)</div><div class="card-body">
        <form method="POST" class="row g-3"><?= csrf_field() ?><input type="hidden" name="act" value="admin_settings"><input type="hidden" name="form" value="radius">
          <div class="col-md-6"><label class="form-label small fw-semibold">RADIUS Server IP *</label><input name="radius_server_ip" class="form-control mono" value="<?= h($radiusIp) ?>" placeholder="102.214.50.10"><div class="form-text">Public IP of the RADIUS box (LAN IP if it sits at the site).</div></div>
          <div class="col-md-6"><label class="form-label small fw-semibold">Accounting Server IP</label><input name="acct_server_ip" class="form-control mono" value="<?= h(getSetting('acct_server_ip')) ?>" placeholder="same as RADIUS"><div class="form-text">Empty = same as RADIUS Server IP.</div></div>
          <div class="col-6"><label class="form-label small">Authentication Port</label><input class="form-control mono" value="<?= RADIUS_AUTH_PORT ?>" disabled></div>
          <div class="col-6"><label class="form-label small">Accounting Port</label><input class="form-control mono" value="<?= RADIUS_ACCT_PORT ?>" disabled></div>
          <div class="col-6"><label class="form-label small">Idle-Timeout (s, 0 = off)</label><input name="radius_idle_timeout" type="number" min="0" class="form-control" value="<?= h(getSetting('radius_idle_timeout', '900')) ?>"></div>
          <div class="col-6"><label class="form-label small">Reply language</label><input class="form-control" value="English" disabled></div>
          <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="dae_enabled" value="1" id="dae" <?= getSetting('dae_enabled', '1') === '1' ? 'checked' : '' ?>><label class="form-check-label small" for="dae">Send Disconnect-Request (UDP <?= RADIUS_DAE_PORT ?>) when a seller kicks/blocks a user</label></div></div>
          <div class="col-12"><label class="form-label small fw-semibold">Public website URL</label><input name="site_url" class="form-control mono" value="<?= h(getSetting('site_url') ?: appUrl()) ?>" placeholder="https://wifi.example.co.tz"><div class="form-text">Used for the External Web Portal URL (<span class="mono"><?= h(portalUrl()) ?></span>), payment callbacks and the RADIUS box. Empty = detect automatically.<?= SITE_URL !== '' ? ' Locked by SITE_URL in config.local.php.' : '' ?></div></div>
          <div class="col-12"><label class="form-label small">Default controller portal URL (fallback for all APs)</label><input name="controller_url" class="form-control" value="<?= h(getSetting('controller_url')) ?>" placeholder="http://169.58.93.38:8088"></div>
          <div class="col-12"><label class="form-label small fw-semibold"><?= t('default_inform_admin') ?></label><input name="omada_default_inform" class="form-control mono" value="<?= h(getSetting('omada_default_inform') ?: OMADA_DEFAULT_INFORM_URL) ?>" placeholder="omada://169.58.93.38?dPort=29810&amp;mPort=29814"><div class="form-text"><?= t('default_inform_help') ?> <?= t('inform_url') ?>: <span class="mono"><?= h(informDeviceAddr(defaultInformUrl()) ?: t('not_set')) ?></span></div></div>
          <?php [$dKeyId] = defaultOmadaKeys(); $dSecSet = openSecret(getSetting('omada_default_client_secret')) !== '' || (string)OMADA_DEFAULT_CLIENT_SECRET !== ''; ?>
          <div class="col-12"><div class="p-3 rounded-3" style="border:1px dashed var(--line-2);background:var(--surface-2)">
            <div class="small fw-semibold text-body-emphasis mb-1"><i class="fa-solid fa-key me-1 text-primary"></i><?= t('default_keys_title') ?><?= $dKeyId !== '' ? ' <span class="badge text-bg-success">' . h(t('ctrl_api_mode')) . '</span>' : '' ?></div>
            <div class="form-text mt-0 mb-2"><?= t('default_keys_help') ?></div>
            <div class="row g-2">
              <div class="col-md-6"><label class="form-label small"><?= t('ctrl_client_id') ?></label><input name="omada_default_client_id" class="form-control form-control-sm mono" value="<?= h(getSetting('omada_default_client_id') ?: (string)OMADA_DEFAULT_CLIENT_ID) ?>" autocomplete="off" spellcheck="false"></div>
              <div class="col-md-6"><label class="form-label small"><?= t('ctrl_client_secret') ?></label><input name="omada_default_client_secret" type="password" class="form-control form-control-sm mono" placeholder="<?= $dSecSet ? h(t('ctrl_secret_keep')) : '' ?>" autocomplete="new-password" spellcheck="false"></div>
              <div class="col-md-6"><label class="form-label small"><?= t('site_region') ?></label><input name="omada_site_region" class="form-control form-control-sm" value="<?= h(getSetting('omada_site_region', 'Tanzania')) ?>"></div>
              <div class="col-md-6"><label class="form-label small"><?= t('site_timezone') ?></label><input name="omada_site_timezone" class="form-control form-control-sm mono" value="<?= h(getSetting('omada_site_timezone', 'Africa/Nairobi')) ?>"></div>
              <?php if ($dKeyId !== ''): ?><div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="omada_default_keys_remove" value="1" id="dkr"><label class="form-check-label small text-danger" for="dkr"><?= t('ctrl_remove_keys') ?></label></div></div><?php endif; ?>
            </div></div></div>
          <div class="col-12"><label class="form-label small">Only accept API calls from these IPs (comma-separated; the "seen from IP" above). Empty = any caller with the key.</label><input name="radius_allowed_ips" class="form-control mono" value="<?= h(getSetting('radius_allowed_ips')) ?>"></div>
          <div class="col-12"><button class="btn btn-primary"><?= t('save') ?></button></div>
        </form>
      </div></div></div>

      <div class="col-12"><div class="card"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2"><span><i class="fa-solid fa-server me-2"></i>Install the RADIUS server (same index.php, ~5 minutes)</span>
        <a class="btn btn-sm btn-primary" href="?export=source"><i class="fa-solid fa-download me-1"></i>Download index.php</a></div><div class="card-body">
        <p class="small text-secondary mb-3">Shared hosting cannot receive UDP 1812/1813, so the RADIUS server runs on any Linux machine with PHP 8 — a small VPS with a public IP (one server for all sellers) or a PC/Raspberry Pi at the site. It needs no database: it learns every router's passwords from this website, recognises each Omada hotspot by those passwords, saves the NAS ID Omada sends, and asks the website for each decision.</p>
        <div class="row g-3">
          <div class="col-lg-6">
            <div class="d-flex justify-content-between align-items-center mb-1"><b class="small text-body-emphasis">1. Website — config.local.php</b><button type="button" class="btn btn-sm btn-outline-primary" onclick="cp('kSite',this)"><i class="fa-regular fa-copy"></i></button></div>
            <pre class="kit mb-3" id="kSite"><?= h($cfgSite) ?></pre>
            <div class="d-flex justify-content-between align-items-center mb-1"><b class="small text-body-emphasis">2. RADIUS box — /opt/skyradius/config.local.php</b><button type="button" class="btn btn-sm btn-outline-primary" onclick="cp('kBox',this)"><i class="fa-regular fa-copy"></i></button></div>
            <pre class="kit mb-3" id="kBox"><?= h($cfgBox) ?></pre>
            <div class="d-flex justify-content-between align-items-center mb-1"><b class="small text-body-emphasis">3. Service — /etc/systemd/system/skyradius.service</b><button type="button" class="btn btn-sm btn-outline-primary" onclick="cp('kUnit',this)"><i class="fa-regular fa-copy"></i></button></div>
            <pre class="kit" id="kUnit"><?= h($unit) ?></pre>
            <div class="d-flex justify-content-between align-items-center mb-1 mt-3"><b class="small text-body-emphasis">3b. <?= t('relay_unit_title') ?> — /etc/systemd/system/skyradius-relay.service</b><button type="button" class="btn btn-sm btn-outline-primary" onclick="cp('kUnitR',this)"><i class="fa-regular fa-copy"></i></button></div>
            <div class="small text-secondary mb-1"><?= t('relay_unit_help') ?></div>
            <pre class="kit" id="kUnitR"><?= h($unitRelay) ?></pre>
          </div>
          <div class="col-lg-6">
            <div class="d-flex justify-content-between align-items-center mb-1"><b class="small text-body-emphasis">4. Commands on the RADIUS box</b><button type="button" class="btn btn-sm btn-outline-primary" onclick="cp('kCmd',this)"><i class="fa-regular fa-copy"></i></button></div>
            <pre class="kit mb-3" id="kCmd"><?= h($cmds) ?></pre>
            <div class="small text-secondary">
              <div class="mb-2"><b>5.</b> Put the VPS public IP in <b>RADIUS Server IP</b> above and save. Status turns <span class="text-success">Running</span> within a minute.</div>
              <div class="mb-2"><b>6.</b> Sellers open Devices → <b><?= t('radius_settings_btn') ?></b> and copy their own passwords into Omada. The NAS ID in the Omada portal can stay as Omada sets it — it is read from the first request.</div>
              <div class="mb-2"><b>Kick users instantly (optional):</b> the RADIUS box sends Disconnect-Request to the router on UDP <?= RADIUS_DAE_PORT ?>, with the NAS ID Omada reported. With a cloud VPS the site router must port-forward UDP <?= RADIUS_DAE_PORT ?> to the Omada controller, or set a target per device. Without it, Session-Timeout still ends every session on time.</div>
              <div class="mb-2"><b>Website API check:</b> <span class="mono">php /opt/skyradius/index.php radius-server --test</span></div>
              <div><b>Updating the box:</b> copy the new index.php to <span class="mono">/opt/skyradius/index.php</span>, run the test, then <span class="mono">sudo systemctl restart skyradius</span>. Redirects from the hosting (/index.php → /index, http → https) are followed automatically.</div>
            </div>
          </div>
        </div>
      </div></div></div>

      <div class="col-lg-5"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-flask me-2"></i>Voucher decision simulator (read-only)</div><div class="card-body">
        <div class="row g-2">
          <div class="col-12"><select id="simNas" class="form-select"><option value="">— hotspot —</option><?php foreach ($allDevs as $d): ?><option value="<?= h($d['nas_id']) ?>"><?= h($d['username'] . ' • ' . $d['device_name'] . ' • NAS ID ' . ($d['omada_nas_id'] ?: '—')) ?></option><?php endforeach; ?></select></div>
          <div class="col-7"><input id="simCode" class="form-control mono" placeholder="Voucher code"></div>
          <div class="col-5"><input id="simMac" class="form-control mono" placeholder="Client MAC"></div>
          <div class="col-12"><button type="button" class="btn btn-primary w-100" onclick="sim()"><i class="fa-solid fa-play me-1"></i>Simulate Access-Request</button></div></div>
        <pre id="simOut" class="kit mt-3" style="min-height:90px"></pre>
      </div></div></div>

      <div class="col-lg-7"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-tower-broadcast me-2"></i>Hotspots (<?= count($allDevs) ?>)</div><div class="card-body table-responsive" style="max-height:420px">
        <?php if ($allDevs): ?><table class="table table-sm table-hover mcard small align-middle"><thead><tr><th>Seller</th><th>Device</th><th>NAS ID (Omada)</th><th>Last contact</th><th>From IP</th><th>Last login</th></tr></thead><tbody>
        <?php foreach ($allDevs as $d): $on = Device::isOnline($d); ?><tr>
          <td data-label="Seller"><?= h($d['username']) ?></td><td data-label="Device"><span class="dot <?= $on ? 'on' : 'off' ?>"></span><?= h($d['device_name']) ?><?= $d['is_active'] ? '' : ' <span class="badge text-bg-secondary">off</span>' ?><div class="text-secondary mono" style="font-size:.7rem"><?= h($d['nas_id']) ?></div></td>
          <td data-label="NAS ID (Omada)" class="mono"><?= $d['omada_nas_id'] ? h($d['omada_nas_id']) : '<span class="text-warning">' . t('nas_waiting') . '</span>' ?></td><td data-label="Last contact"><?= $d['last_seen'] ? h(date('d M H:i', strtotime($d['last_seen']))) : t('never') ?></td>
          <td data-label="From IP" class="mono"><?= h($d['radius_src_ip'] ?: '—') ?></td><td data-label="Last login"><?= $d['radius_last_auth'] ? h(date('d M H:i', strtotime($d['radius_last_auth']))) : '—' ?></td></tr><?php endforeach; ?>
        </tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
      </div></div></div>

      <div class="col-12"><div class="card"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="fa-solid fa-list me-2"></i>Live RADIUS log</span><a href="?page=radius" class="small" aria-label="Refresh"><i class="fa-solid fa-rotate"></i></a></div><div class="card-body table-responsive" style="max-height:480px">
        <?php if ($logs): ?><table class="table table-sm table-hover mcard small"><thead><tr><th>Time</th><th>Kind</th><th>Hotspot</th><th>User</th><th>Client</th><th>From</th><th>Result</th><th>Message</th></tr></thead><tbody>
        <?php foreach ($logs as $l): ?><tr><td data-label="Time"><?= h(date('d M H:i:s', strtotime($l['created_at']))) ?></td><td data-label="Kind"><?= h($l['kind']) ?></td><td data-label="Hotspot" class="mono"><?= h($l['nas_id']) ?></td><td data-label="User" class="mono"><?= h($l['username']) ?></td>
          <td data-label="Client" class="mono"><?= h($l['mac']) ?></td><td data-label="From" class="mono"><?= h($l['src_ip']) ?></td>
          <td data-label="Result"><span class="badge text-bg-<?= in_array($l['result'], ['reject', 'drop'], true) ? 'danger' : 'success' ?>"><?= h($l['result']) ?></span></td><td data-label="Message"><?= h($l['message']) ?></td></tr><?php endforeach; ?>
        </tbody></table><?php else: ?><p class="text-secondary mb-0">No RADIUS traffic yet.</p><?php endif; ?>
      </div></div></div>
    </div>
    <script>
    function sim(){const fd=new FormData();fd.append('csrf',<?= json_encode(csrf_token()) ?>);fd.append('nas',document.getElementById('simNas').value);fd.append('code',document.getElementById('simCode').value);fd.append('mac',document.getElementById('simMac').value);
      fetch('?ajax=simulate',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{document.getElementById('simOut').textContent=d.decision+'  •  '+d.hotspot+'\n'+JSON.stringify(d.reply,null,2)})}
    </script>
    <?php break;

// ============================================================
// v6.2 — ADMIN → ALL ROUTERS: every seller's router, managed by the admin
// ============================================================
case 'all_routers':
    $auth->requireAdmin();
    $fSeller = (int)($_GET['seller'] ?? 0);
    $fQ = trim(substr((string)($_GET['q'] ?? ''), 0, 60));
    $fState = in_array($_GET['state'] ?? '', ['online', 'offline', 'unlinked', 'stopped', 'problems'], true) ? (string)$_GET['state'] : '';
    $where = '1=1'; $types = ''; $args = [];
    if ($fSeller) { $where .= ' AND d.user_id=?'; $types .= 'i'; $args[] = $fSeller; }
    if ($fQ !== '') { $where .= ' AND (d.device_name LIKE ? OR d.ap_mac LIKE ? OR d.ssid LIKE ? OR d.site_name LIKE ? OR u.username LIKE ?)'; $types .= 'sssss';
        $like = '%' . $fQ . '%'; $mq = '%' . normMac($fQ) . '%'; array_push($args, $like, normMac($fQ) !== '' ? $mq : $like, $like, $like, $like); }
    if ($fState === 'unlinked') $where .= ' AND d.controller_id IS NULL';
    if ($fState === 'stopped') $where .= ' AND d.is_active=0';
    $arList = rows("SELECT d.*, u.username, u.full_name, c.name AS ctrl_name,
                    (SELECT COUNT(*) FROM hs_sessions s WHERE s.device_id=d.id AND s.status='active') AS active_sessions
                    FROM hs_devices d JOIN users u ON u.id=d.user_id LEFT JOIN hs_controllers c ON c.id=d.controller_id
                    WHERE $where ORDER BY d.id DESC LIMIT 500", $types, ...$args);
    if ($fState === 'online') $arList = array_values(array_filter($arList, fn($d) => Device::isOnline($d)));
    if ($fState === 'offline') $arList = array_values(array_filter($arList, fn($d) => !Device::isOnline($d)));
    if ($fState === 'problems') $arList = array_values(array_filter($arList, fn($d) => OmadaLink::counts(OmadaLink::saved($d))['fail'] > 0));
    $arAll = rows("SELECT d.*, (d.controller_id IS NULL) AS unlinked FROM hs_devices d");
    $arStat = ['total' => count($arAll), 'online' => 0, 'prov' => 0, 'unlinked' => 0];
    foreach ($arAll as $d) { if (Device::isOnline($d)) $arStat['online']++; if (($d['prov_state'] ?? '') === 'done') $arStat['prov']++; if ((int)$d['unlinked']) $arStat['unlinked']++; }
    $sellers = rows("SELECT u.id, u.username, COUNT(d.id) n FROM users u JOIN hs_devices d ON d.user_id=u.id GROUP BY u.id, u.username ORDER BY u.username");
    $mm = [];
    foreach (RouterModels::all() as $m) $mm[(int)$m['id']] = $m;
    ?>
    <p class="text-secondary small"><?= t('ar_intro') ?></p>
    <div class="row g-3 mb-3">
      <div class="col-6 col-xl-3"><div class="card stat s1 p-3"><h6><i class="fa-solid fa-tower-broadcast me-1"></i><?= t('ar_total') ?></h6><h4 class="mb-0"><?= $arStat['total'] ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s2 p-3"><h6><i class="fa-solid fa-signal me-1"></i><?= t('ar_online') ?></h6><h4 class="mb-0"><?= $arStat['online'] ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s3 p-3"><h6><i class="fa-solid fa-circle-check me-1"></i><?= t('ar_provisioned') ?></h6><h4 class="mb-0"><?= $arStat['prov'] ?></h4></div></div>
      <div class="col-6 col-xl-3"><div class="card stat s4 p-3"><h6><i class="fa-solid fa-link-slash me-1"></i><?= t('ar_unlinked') ?></h6><h4 class="mb-0"><?= $arStat['unlinked'] ?></h4></div></div>
    </div>
    <div class="card mb-3"><div class="card-header">
      <form class="row g-2 align-items-center" method="GET"><input type="hidden" name="page" value="all_routers">
        <div class="col-md-3"><select name="seller" class="form-select form-select-sm"><option value="0"><?= t('all') ?> — <?= t('seller') ?></option>
          <?php foreach ($sellers as $se): ?><option value="<?= (int)$se['id'] ?>" <?= $fSeller === (int)$se['id'] ? 'selected' : '' ?>><?= h($se['username']) ?> (<?= (int)$se['n'] ?>)</option><?php endforeach; ?></select></div>
        <div class="col-md-3"><select name="state" class="form-select form-select-sm"><option value=""><?= t('all') ?> — <?= t('status') ?></option>
          <?php foreach (['online' => t('ar_online'), 'offline' => t('offline'), 'unlinked' => t('ar_unlinked'), 'stopped' => t('inactive'), 'problems' => t('hs_health') . ' ✘'] as $sk => $sl): ?><option value="<?= $sk ?>" <?= $fState === $sk ? 'selected' : '' ?>><?= h($sl) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3"><input name="q" class="form-control form-control-sm" value="<?= h($fQ) ?>" placeholder="<?= t('search') ?>"></div>
        <div class="col-md-3"><button class="btn btn-sm btn-primary w-100"><i class="fa-solid fa-filter me-1"></i><?= t('filter') ?></button></div>
      </form>
      <?php if ($arStat['unlinked']): ?><form method="POST" class="mt-2" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="admin_link_unlinked"><button class="btn btn-sm btn-outline-warning"><i class="fa-solid fa-link me-1"></i><?= t('link_unlinked') ?> (<?= $arStat['unlinked'] ?>)</button></form><?php endif; ?>
      </div>
      <div class="card-body table-responsive">
        <?php if ($arList): ?><table class="table table-sm table-hover mcard align-middle"><thead><tr><th><?= t('device_name') ?></th><th><?= t('seller') ?></th><th><?= t('cloud_link') ?></th><th><?= t('status') ?></th><th><?= t('hs_health') ?></th><th><?= t('last_seen') ?></th><th></th></tr></thead><tbody>
        <?php foreach ($arList as $d): $on = Device::isOnline($d); $ps = (string)($d['prov_state'] ?? ''); [$bl, $bc] = Device::omadaBadge($d['omada_status']); $hc = OmadaLink::counts(OmadaLink::saved($d)); $m = $mm[(int)($d['router_model_id'] ?? 0)] ?? RouterModels::forDevice($d); ?>
          <tr><td data-label="<?= t('device_name') ?>"><span class="dot <?= $on ? 'on' : 'off' ?>"></span><b class="text-body-emphasis"><?= h($d['device_name']) ?></b><?= (int)$d['is_active'] ? '' : ' <span class="badge text-bg-secondary">' . t('inactive') . '</span>' ?>
              <div class="small text-secondary"><?= h(RouterModels::label($m)) ?> • <span class="mono"><?= h(dashMac($d['ap_mac'])) ?></span> • <?= h($d['ssid'] ?: '—') ?> • <?= h($d['site_name']) ?></div></td>
            <td data-label="<?= t('seller') ?>"><b><?= h($d['username']) ?></b><div class="small text-secondary"><?= h($d['full_name']) ?></div></td>
            <td data-label="<?= t('cloud_link') ?>" class="small"><?= $d['ctrl_name'] ? h($d['ctrl_name']) : '<span class="text-warning">' . t('ar_unlinked') . '</span>' ?></td>
            <td data-label="<?= t('status') ?>"><?php if ($d['controller_id']): ?><span class="badge text-bg-<?= $bc ?>"><?= h($bl) ?></span><?php endif; ?><?php if ($ps !== ''): ?><div class="small text-secondary"><?= h(t('prov_state_' . $ps)) ?></div><?php endif; ?></td>
            <td data-label="<?= t('hs_health') ?>"><?php if ($d['health_at'] ?? null): ?><span class="badge text-bg-<?= $hc['fail'] ? 'danger' : ($hc['warn'] ? 'warning' : 'success') ?>"><?= $hc['ok'] ?> ✔ <?= $hc['warn'] ?> ⚠ <?= $hc['fail'] ?> ✘</span><?php else: ?><span class="text-secondary small">—</span><?php endif; ?></td>
            <td data-label="<?= t('last_seen') ?>" class="small"><?= $d['last_seen'] ? h(date('d M H:i', strtotime($d['last_seen']))) : t('never') ?> • <?= (int)$d['active_sessions'] ?> <i class="fa-solid fa-user"></i></td>
            <td class="text-nowrap">
              <a class="btn btn-sm btn-primary" href="?page=hotspot&id=<?= (int)$d['id'] ?>" title="<?= h(t('open')) ?>"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
              <form method="POST" class="d-inline" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="admin_router_setup"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-success" title="<?= h(t('run_setup')) ?>"><i class="fa-solid fa-wand-magic-sparkles"></i></button></form>
              <form method="POST" class="d-inline" onsubmit="this.querySelector('button').disabled=true"><?= csrf_field() ?><input type="hidden" name="act" value="admin_router_check"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-info" title="<?= h(t('check_health')) ?>"><i class="fa-solid fa-stethoscope"></i></button></form>
              <form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="device_toggle"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><input type="hidden" name="return" value="?page=all_routers"><button class="btn btn-sm btn-outline-<?= (int)$d['is_active'] ? 'warning' : 'success' ?>" title="<?= h((int)$d['is_active'] ? t('hotspot_stop') : t('hotspot_start')) ?>"><i class="fa-solid fa-<?= (int)$d['is_active'] ? 'stop' : 'play' ?>"></i></button></form>
              <form method="POST" class="d-inline" onsubmit="return confirm('<?= h(t('confirm_delete')) ?>')"><?= csrf_field() ?><input type="hidden" name="act" value="admin_router_delete"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-danger" title="<?= h(t('delete')) ?>"><i class="fa-solid fa-trash"></i></button></form>
            </td></tr>
        <?php endforeach; ?></tbody></table><?php else: ?><p class="text-secondary mb-0"><?= t('no_data') ?></p><?php endif; ?>
      </div></div>
    <?php break;

// ============================================================
// v6.0 — OMADA MANAGER page: sites, EAP225 devices, Omada vouchers and clients through the Omada Open API
// ============================================================
case 'omada_manager':
    $auth->requireAdmin();   // v6.2: admin only
    $uid = (int)$user['id'];
    ensureDefaultController($uid);
    $omCtrls = OmadaManager::controllers($uid);
    $omAll = rows("SELECT id, name FROM hs_controllers WHERE user_id=? ORDER BY id", 'i', $uid);
    $omKit = OmadaManager::vpsKit();
    $omKitHtml = function () use ($omKit, $auth): string {
        if (!$auth->isAdmin()) return '';
        $o = '<div class="card mt-3" id="vpskit"><div class="card-header"><i class="fa-solid fa-server me-2"></i>' . h(t('om_vps_title')) . '</div><div class="card-body">'
           . '<p class="small text-secondary">' . h(t('om_vps_help')) . '</p><div class="row g-3">';
        foreach ($omKit as $i => [$k, $txt]) $o .= '<div class="col-lg-6"><div class="d-flex justify-content-between align-items-center mb-1"><b class="small text-body-emphasis">' . h(t($k))
           . '</b><button type="button" class="btn btn-sm btn-outline-primary" onclick="cp(\'omk' . $i . '\',this)"><i class="fa-regular fa-copy"></i></button></div><pre class="kit" id="omk' . $i . '">' . h($txt) . '</pre></div>';
        return $o . '</div><div class="small mt-3"><a href="?page=radius">' . h(t('radius_setup')) . ' →</a></div></div></div>';
    };
    if (!$omCtrls) { ?>
      <div class="card p-4 text-center"><i class="fa-solid fa-key fa-2x text-primary mb-3"></i><h5><?= t('om_no_api') ?></h5>
        <p class="text-secondary small mb-3" style="max-width:720px;margin:0 auto"><?= t('ctrl_keys_help') ?></p>
        <div class="d-flex gap-2 justify-content-center flex-wrap">
          <?php foreach ($omAll as $c): ?><a class="btn btn-primary" href="?page=controller&edit=<?= (int)$c['id'] ?>"><i class="fa-solid fa-key me-1"></i><?= h($c['name']) ?></a><?php endforeach; ?>
          <a class="btn btn-outline-primary" href="?page=controller"><i class="fa-solid fa-cloud me-1"></i><?= t('omada_controller') ?></a>
          <?php if ($auth->isAdmin()): ?><a class="btn btn-outline-secondary" href="?page=radius"><?= t('radius_setup') ?></a><?php endif; ?>
        </div></div>
      <?= $omKitHtml() ?>
    <?php break; }
    $cid = (int)($_GET['c'] ?? 0);
    $omCtl = null;
    foreach ($omCtrls as $c) if ((int)$c['id'] === $cid) $omCtl = $c;
    if (!$omCtl) $omCtl = $omCtrls[0];
    $cid = (int)$omCtl['id'];
    $api = new OmadaApi($omCtl);
    $prevDl = OmadaApi::$deadline;
    OmadaApi::$deadline = microtime(true) + workBudget(28);
    $sites = $api->sites();
    $omErr = $api->error;
    if (!$sites && $omErr !== '') $sites = $api->cachedSites();
    $site = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($_GET['site'] ?? ''));
    if (!in_array($site, array_column($sites, 'id'), true)) $site = (string)($sites[0]['id'] ?? '');
    $siteName = '';
    foreach ($sites as $s) if ($s['id'] === $site) $siteName = $s['name'];
    $tab = in_array($_GET['tab'] ?? '', ['overview', 'devices', 'vouchers', 'clients'], true) ? (string)$_GET['tab'] : 'overview';
    $base = '?page=omada_manager&c=' . $cid . '&site=' . urlencode($site);
    $ret = $base . '&tab=' . $tab;
    $hid = function (array $extra = []) use ($cid, $site, $ret): string {
        $o = csrf_field() . '<input type="hidden" name="c" value="' . $cid . '"><input type="hidden" name="site" value="' . h($site) . '"><input type="hidden" name="return" value="' . h($ret) . '">';
        foreach ($extra as $k => $v) $o .= '<input type="hidden" name="' . h($k) . '" value="' . h($v) . '">';
        return $o;
    };
    $devs = []; $clients = []; $devErr = ''; $cliErr = '';
    if ($site !== '' && in_array($tab, ['overview', 'devices'], true)) { $devs = $api->devices($site); $devErr = $api->error; }
    if ($site !== '' && in_array($tab, ['overview', 'clients'], true)) { $clients = $api->clientList($site); $cliErr = $api->error; }
    $myDevs = [];
    foreach (rows("SELECT * FROM hs_devices WHERE user_id=?", 'i', $uid) as $r) $myDevs[$r['ap_mac']] = $r;
    $localSite = $site !== '' ? rows("SELECT * FROM hs_devices WHERE user_id=? AND controller_id=? AND omada_site_id=? ORDER BY device_name", 'iis', $uid, $cid, $site) : [];
    $pkgs = rows("SELECT * FROM hs_packages WHERE seller_id=? AND is_active=1 ORDER BY sort_order, price", 'i', $uid);
    ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <form method="GET" class="d-flex gap-2 flex-wrap"><input type="hidden" name="page" value="omada_manager"><input type="hidden" name="tab" value="<?= h($tab) ?>">
        <select name="c" class="form-select form-select-sm" style="width:auto" onchange="this.form.site.value='';this.form.submit()" aria-label="<?= h(t('omada_controller')) ?>">
          <?php foreach ($omCtrls as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$c['id'] === $cid ? 'selected' : '' ?>><?= h($c['name']) ?></option><?php endforeach; ?></select>
        <select name="site" class="form-select form-select-sm" style="width:auto" onchange="this.form.submit()" aria-label="<?= h(t('om_site')) ?>">
          <?php foreach ($sites as $s): ?><option value="<?= h($s['id']) ?>" <?= $s['id'] === $site ? 'selected' : '' ?>><?= h($s['name']) ?></option><?php endforeach; if (!$sites) echo '<option value="">—</option>'; ?></select>
      </form>
      <div class="d-flex gap-1 flex-wrap">
        <form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_test"><input type="hidden" name="id" value="<?= $cid ?>"><input type="hidden" name="return" value="<?= h($ret) ?>"><button class="btn btn-sm btn-outline-success"><i class="fa-solid fa-stethoscope me-1"></i><?= t('ctrl_test') ?></button></form>
        <form method="POST"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_sync"><input type="hidden" name="id" value="<?= $cid ?>"><input type="hidden" name="return" value="<?= h($ret) ?>"><button class="btn btn-sm btn-outline-info"><i class="fa-solid fa-rotate me-1"></i><?= t('ctrl_check_now') ?></button></form>
        <form method="POST" onsubmit="this.querySelector('button').disabled=true"><?= $hid(['act' => 'om_vsync']) ?><button class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-ticket me-1"></i><?= t('om_vsync') ?></button></form>
        <a class="btn btn-sm btn-outline-secondary" href="?page=controller&id=<?= $cid ?>&site=<?= urlencode($site) ?>#ssids"><i class="fa-solid fa-wifi me-1"></i>SSID</a>
      </div>
    </div>
    <?php if ($omErr !== '' && !$sites): ?><div class="alert alert-danger small"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= h($omErr) ?><?= $api->essentialsHint() !== '' ? '<br>' . h($api->essentialsHint()) : '' ?></div><?php endif; ?>
    <div class="alert alert-info small"><i class="fa-solid fa-circle-info me-2"></i><?= t('om_intro') ?> • <span class="mono"><?= h($omCtl['base_url']) ?></span> • <?= h(OmadaRelay::routeOf($omCtl) === 'relay' ? OmadaRelay::labelFor((string)parse_url((string)$omCtl['base_url'], PHP_URL_HOST)) : t('route_direct')) ?></div>

    <div class="row g-3 mb-3">
      <div class="col-lg-7"><div class="card h-100"><div class="card-header"><i class="fa-solid fa-sitemap me-2"></i><?= t('om_sites') ?> (<?= count($sites) ?>)</div><div class="card-body p-2" style="max-height:260px;overflow:auto">
        <?php foreach ($sites as $s): $n = count(array_filter($myDevs, fn($d) => (string)$d['omada_site_id'] === $s['id'])); ?>
          <a href="?page=omada_manager&c=<?= $cid ?>&site=<?= urlencode($s['id']) ?>&tab=<?= h($tab) ?>" class="d-flex justify-content-between align-items-center px-2 py-2 border-bottom border-secondary-subtle small text-decoration-none <?= $s['id'] === $site ? 'fw-bold' : '' ?>">
            <span class="text-body-emphasis"><i class="fa-solid fa-<?= $s['id'] === $site ? 'circle-dot text-primary' : 'circle text-secondary' ?> me-2"></i><?= h($s['name']) ?></span>
            <span class="text-secondary"><?= $n ?> <i class="fa-solid fa-tower-broadcast"></i></span></a>
        <?php endforeach; if (!$sites) echo '<p class="text-secondary m-2 small">' . ($api->sharedScope() ? t('ctrl_shared_sites') : t('no_data')) . '</p>'; ?>
      </div></div></div>
      <div class="col-lg-5"><div class="card h-100"><div class="card-body">
        <form method="POST" class="row g-2" onsubmit="this.querySelector('button').disabled=true"><?= $hid(['act' => 'om_site_create']) ?>
          <div class="col-12 small fw-semibold text-body-emphasis"><i class="fa-solid fa-plus me-1 text-primary"></i><?= t('om_site_new') ?></div>
          <div class="col-8"><input name="site_name" class="form-control form-control-sm" maxlength="60" required placeholder="<?= h(t('site_name')) ?>"></div>
          <div class="col-4"><button class="btn btn-sm btn-primary w-100"><?= t('save') ?></button></div>
        </form>
        <?php if ($site !== ''): ?>
        <form method="POST" class="row g-2 mt-3" onsubmit="return confirm(<?= h(json_encode(t('om_site_delete') . ': ' . $siteName . '?')) ?>)"><?= $hid(['act' => 'om_site_delete']) ?>
          <div class="col-12 small fw-semibold text-danger"><i class="fa-solid fa-trash me-1"></i><?= t('om_site_delete') ?>: <?= h($siteName) ?></div>
          <div class="col-8"><input name="confirm_name" class="form-control form-control-sm" required placeholder="<?= h(t('om_site_delete_confirm')) ?>" autocomplete="off"></div>
          <div class="col-4"><button class="btn btn-sm btn-outline-danger w-100"><?= t('delete') ?></button></div>
        </form>
        <?php endif; ?>
      </div></div></div>
    </div>

    <?php if ($site !== ''): ?>
    <ul class="nav nav-pills gap-1 mb-3 flex-wrap">
      <?php foreach (['overview' => 'gauge-high', 'devices' => 'tower-broadcast', 'vouchers' => 'ticket', 'clients' => 'users'] as $tk => $ti): ?>
        <li class="nav-item"><a class="nav-link py-1 px-3 <?= $tab === $tk ? 'active' : '' ?>" href="<?= h($base . '&tab=' . $tk) ?>"><i class="fa-solid fa-<?= $ti ?> me-1"></i><?= t('om_tab_' . $tk) ?></a></li>
      <?php endforeach; ?>
    </ul>

    <?php if ($tab === 'overview'): $stt = OmadaManager::siteStats($devs, $clients);
        $vOpen = (int)val("SELECT COUNT(*) FROM hs_vouchers v JOIN hs_omada_vgroups g ON g.group_id=v.ext_ref AND g.user_id=v.seller_id WHERE g.user_id=? AND g.site_id=? AND v.status IN ('available','sold')", 'is', $uid, $site); ?>
      <?php if ($devErr !== ''): ?><div class="alert alert-warning small"><?= h($devErr) ?></div><?php endif; ?>
      <div class="row g-3 mb-3">
        <div class="col-6 col-xl-3"><div class="card stat s1 p-3"><h6><i class="fa-solid fa-tower-broadcast me-1"></i><?= t('om_stat_devices') ?></h6><h4 class="mb-0"><?= $stt['connected'] ?>/<?= $stt['devices'] ?></h4></div></div>
        <div class="col-6 col-xl-3"><div class="card stat s4 p-3"><h6><i class="fa-solid fa-hourglass-half me-1"></i><?= t('om_stat_pending') ?></h6><h4 class="mb-0"><?= $stt['pending'] ?></h4></div></div>
        <div class="col-6 col-xl-3"><div class="card stat s2 p-3"><h6><i class="fa-solid fa-users me-1"></i><?= t('om_stat_clients') ?></h6><h4 class="mb-0"><?= $stt['clients'] ?></h4></div></div>
        <div class="col-6 col-xl-3"><div class="card stat s3 p-3"><h6><i class="fa-solid fa-ticket me-1"></i><?= t('om_stat_vouchers') ?></h6><h4 class="mb-0"><?= $vOpen ?></h4></div></div>
      </div>
      <div class="card"><div class="card-header"><i class="fa-solid fa-wifi me-2"></i><?= t('om_local_routers') ?> (<?= count($localSite) ?>)</div><div class="card-body">
        <?php foreach ($localSite as $d): [$bl, $bc] = Device::omadaBadge($d['omada_status']); ?>
          <div class="d-flex justify-content-between align-items-center gap-2 border-bottom border-secondary-subtle py-2 small">
            <div class="min-w-0"><span class="dot <?= Device::isOnline($d) ? 'on' : 'off' ?>"></span><b class="text-body-emphasis"><?= h($d['device_name']) ?></b> <span class="mono text-secondary"><?= h(dashMac($d['ap_mac'])) ?></span> • <?= h($d['ssid'] ?: '—') ?> <span class="badge text-bg-<?= $bc ?>"><?= h($bl) ?></span></div>
            <a class="btn btn-sm btn-success" href="?page=hotspot&id=<?= (int)$d['id'] ?>#setup"><i class="fa-solid fa-plug me-1"></i><?= t('prov_start') ?></a></div>
        <?php endforeach; if (!$localSite) echo '<p class="text-secondary mb-0 small">' . t('om_none_local') . ' <a href="' . h($base . '&tab=devices') . '">' . t('om_dev_add') . ' →</a></p>'; ?>
      </div></div>

    <?php elseif ($tab === 'devices'): ?>
      <div class="row g-3">
        <div class="col-xl-8"><div class="card"><div class="card-header"><i class="fa-solid fa-tower-broadcast me-2"></i><?= t('ctrl_aps') ?> (<?= count($devs) ?>)</div><div class="card-body">
          <?php if ($devErr !== '' && !$devs): ?><div class="alert alert-warning small"><?= h($devErr) ?></div><?php endif; ?>
          <?php if ($devs): ?><div class="table-responsive"><table class="table table-sm table-hover mcard align-middle"><thead><tr><th><?= t('device_name') ?></th><th>MAC / S/N</th><th><?= t('status') ?></th><th>IP</th><th><i class="fa-solid fa-users"></i></th><th></th></tr></thead><tbody>
          <?php foreach ($devs as $a): [$bl, $bc] = Device::omadaBadge($a['status']); $mine = $myDevs[$a['mac']] ?? null; $canAdopt = in_array($a['status'], ['pending', 'adopt_failed', 'managed_by_others'], true); ?>
            <tr><td data-label="<?= t('device_name') ?>"><b class="text-body-emphasis"><?= h($a['name'] ?: '—') ?></b><div class="small text-secondary"><?= h($a['model']) ?><?= $a['fw'] !== '' ? ' • FW ' . h($a['fw']) : '' ?></div></td>
              <td data-label="MAC / S/N" class="mono small"><?= h(dashMac($a['mac'])) ?><div class="text-secondary"><?= h($a['sn']) ?></div></td>
              <td data-label="<?= t('status') ?>"><span class="badge text-bg-<?= $bc ?>"><?= h($bl) ?></span></td>
              <td data-label="IP" class="mono small"><?= h($a['ip']) ?></td><td data-label="Clients"><?= (int)$a['clients'] ?></td>
              <td class="text-nowrap">
                <?php if ($canAdopt): ?>
                  <details class="d-inline-block text-start"><summary class="btn btn-sm btn-success"><i class="fa-solid fa-hand-holding me-1"></i><?= t('ctrl_adopt') ?></summary>
                    <form method="POST" class="p-2 mt-1 rounded-3" style="background:var(--surface-3);min-width:220px"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_adopt"><input type="hidden" name="id" value="<?= $cid ?>"><input type="hidden" name="site" value="<?= h($site) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>">
                      <input name="dev_user" class="form-control form-control-sm mb-1" value="admin"><input name="dev_pass" type="password" class="form-control form-control-sm mb-1" placeholder="<?= h(t('dev_pass')) ?> (admin)">
                      <button class="btn btn-sm btn-success w-100"><?= t('ctrl_adopt') ?></button></form></details>
                <?php else: ?>
                  <form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_locate"><input type="hidden" name="id" value="<?= $cid ?>"><input type="hidden" name="site" value="<?= h($site) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>"><button class="btn btn-sm btn-outline-info" title="Locate (LED)"><i class="fa-solid fa-lightbulb"></i></button></form>
                  <form method="POST" class="d-inline" onsubmit="return confirm('Reboot?')"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_reboot"><input type="hidden" name="id" value="<?= $cid ?>"><input type="hidden" name="site" value="<?= h($site) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="return" value="<?= h($ret) ?>"><button class="btn btn-sm btn-outline-warning" title="Reboot"><i class="fa-solid fa-power-off"></i></button></form>
                <?php endif; ?>
                <details class="d-inline-block text-start"><summary class="btn btn-sm btn-outline-primary" title="<?= h(t('om_dev_rename')) ?>"><i class="fa-solid fa-pen"></i></summary>
                  <form method="POST" class="p-2 mt-1 rounded-3 d-flex gap-1" style="background:var(--surface-3);min-width:240px"><?= $hid(['act' => 'om_device_rename', 'mac' => $a['mac']]) ?>
                    <input name="name" class="form-control form-control-sm" maxlength="60" value="<?= h($a['name']) ?>" required><button class="btn btn-sm btn-primary"><?= t('save') ?></button></form></details>
                <form method="POST" class="d-inline" onsubmit="return confirm(<?= h(json_encode(t('om_dev_forget_confirm') . ' ' . dashMac($a['mac']))) ?>)"><?= $hid(['act' => 'om_device_forget', 'mac' => $a['mac']]) ?><button class="btn btn-sm btn-outline-danger" title="<?= h(t('om_dev_forget')) ?>"><i class="fa-solid fa-link-slash"></i></button></form>
                <?php if ($mine && (int)$mine['controller_id'] === $cid): ?>
                  <a class="btn btn-sm btn-primary" href="?page=hotspot&id=<?= (int)$mine['id'] ?>"><i class="fa-solid fa-key"></i></a>
                <?php else: ?>
                  <form method="POST" class="d-inline"><?= csrf_field() ?><input type="hidden" name="act" value="ctrl_import"><input type="hidden" name="id" value="<?= $cid ?>"><input type="hidden" name="site" value="<?= h($site) ?>"><input type="hidden" name="mac" value="<?= h($a['mac']) ?>"><input type="hidden" name="name" value="<?= h($a['name']) ?>"><button class="btn btn-sm btn-outline-primary" title="<?= h(t('ctrl_import')) ?>"><i class="fa-solid fa-plus"></i></button></form>
                <?php endif; ?></td></tr>
          <?php endforeach; ?></tbody></table></div>
          <?php elseif ($devErr === ''): ?><p class="text-secondary mb-0"><?= t('ctrl_no_aps') ?></p><?php endif; ?>
        </div></div></div>
        <div class="col-xl-4"><div class="card"><div class="card-header"><i class="fa-solid fa-plus me-2"></i><?= t('om_dev_add') ?></div><div class="card-body">
          <p class="small text-secondary"><?= t('om_dev_add_help') ?></p>
          <form method="POST" class="row g-2" onsubmit="this.querySelector('button[type=submit]').disabled=true"><?= $hid(['act' => 'om_device_add']) ?>
            <div class="col-12"><label class="form-label small"><?= t('device_name') ?></label><input name="name" class="form-control form-control-sm" maxlength="60" value="EAP225 <?= h($siteName) ?>"></div>
            <div class="col-12"><label class="form-label small"><?= t('omada_sn') ?></label><input name="sn" class="form-control form-control-sm mono" maxlength="20" placeholder="2236XXXXXXXXX"></div>
            <div class="col-12"><label class="form-label small"><?= t('ap_mac') ?></label><input name="mac" class="form-control form-control-sm mono" placeholder="50-C7-BF-11-22-33"></div>
            <div class="col-6"><input name="dev_user" class="form-control form-control-sm" value="admin" placeholder="<?= h(t('dev_user')) ?>"></div>
            <div class="col-6"><input name="dev_pass" type="password" class="form-control form-control-sm" placeholder="<?= h(t('dev_pass')) ?> (admin)" autocomplete="new-password"></div>
            <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="as_hotspot" value="1" id="omh" checked><label class="form-check-label small" for="omh"><?= t('om_as_hotspot') ?></label></div></div>
            <div class="col-12"><input name="ssid" class="form-control form-control-sm" maxlength="32" placeholder="SSID (SKY WIFI)"></div>
            <div class="col-12"><select name="voucher_mode" class="form-select form-select-sm"><option value="radius"><?= t('vm_radius') ?></option><option value="omada"><?= t('vm_omada') ?></option></select></div>
            <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="run_setup" value="1" id="omr" checked><label class="form-check-label small" for="omr"><?= t('om_run_setup') ?></label></div></div>
            <div class="col-12"><button type="submit" class="btn btn-sm btn-primary w-100"><i class="fa-solid fa-plus me-1"></i><?= t('om_dev_add') ?></button></div>
          </form>
        </div></div></div>
      </div>

    <?php elseif ($tab === 'vouchers'):
        $vg = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($_GET['vgroup'] ?? ''));
        $groups = OmadaManager::groups($api, $site);
        $gErr = $api->error;
        $known = [];
        foreach (rows("SELECT * FROM hs_omada_vgroups WHERE user_id=? AND site_id=?", 'is', $uid, $site) as $r) $known[$r['group_id']] = $r; ?>
      <div class="alert alert-warning small"><i class="fa-solid fa-circle-info me-2"></i><?= t('om_vg_hint') ?></div>
      <?php if ($vg !== ''): $det = OmadaManager::groupDetail($api, $site, $vg); $gm = OmadaManager::mapGroup($det['group']);
          if ($det['ok']) OmadaManager::applyStatuses($uid, $det['vouchers']);
          $cnt = ['unused' => 0, 'in_use' => 0, 'expired' => 0]; foreach ($det['vouchers'] as $v) $cnt[$v['status']]++; ?>
        <div class="card mb-3"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
          <span><i class="fa-solid fa-ticket me-2"></i><?= h($gm['name'] ?: $vg) ?> — <?= t('om_vg_codes') ?> (<?= count($det['vouchers']) ?>)</span>
          <span class="d-flex gap-1"><?php if (isset($known[$vg]) && $known[$vg]['batch']): ?><a class="btn btn-sm btn-outline-secondary" target="_blank" href="?page=print&batch=<?= urlencode($known[$vg]['batch']) ?>"><i class="fa-solid fa-print me-1"></i><?= t('print') ?></a><?php endif; ?>
            <a class="btn btn-sm btn-outline-secondary" href="<?= h($base . '&tab=vouchers') ?>"><i class="fa-solid fa-arrow-left me-1"></i><?= t('om_vg_back') ?></a></span></div><div class="card-body">
          <?php if (!$det['ok']): ?><div class="alert alert-danger small"><?= h($det['msg']) ?></div><?php endif; ?>
          <div class="d-flex gap-2 flex-wrap mb-2"><span class="badge text-bg-success"><?= t('om_v_unused') ?>: <?= $cnt['unused'] ?></span><span class="badge text-bg-primary"><?= t('om_v_inuse') ?>: <?= $cnt['in_use'] ?></span><span class="badge text-bg-secondary"><?= t('om_v_expired') ?>: <?= $cnt['expired'] ?></span></div>
          <div class="row g-2">
          <?php foreach ($det['vouchers'] as $v): ?>
            <div class="col-6 col-md-4 col-xl-3"><div class="d-flex justify-content-between align-items-center p-2 rounded-3" style="border:1px solid var(--line);background:var(--surface-2)">
              <div><span class="mono fw-bold text-body-emphasis"><?= h($v['code']) ?></span><div class="small"><span class="badge text-bg-<?= ['unused' => 'success', 'in_use' => 'primary', 'expired' => 'secondary'][$v['status']] ?>"><?= h(t(['unused' => 'om_v_unused', 'in_use' => 'om_v_inuse', 'expired' => 'om_v_expired'][$v['status']])) ?></span></div></div>
              <?php if ($v['id'] !== ''): ?><form method="POST" onsubmit="return confirm(<?= h(json_encode(t('om_v_delete') . ' ' . $v['code'] . '?')) ?>)"><?= $hid(['act' => 'om_voucher_delete', 'vid' => $v['id'], 'code' => $v['code'], 'return' => $ret . '&vgroup=' . $vg]) ?><button class="btn btn-sm btn-link text-danger p-0" title="<?= h(t('om_v_delete')) ?>"><i class="fa-solid fa-trash"></i></button></form><?php endif; ?>
            </div></div>
          <?php endforeach; ?></div>
        </div></div>
      <?php endif; ?>
      <div class="row g-3">
        <div class="col-xl-4"><div class="card"><div class="card-header"><i class="fa-solid fa-wand-magic-sparkles me-2"></i><?= t('om_vg_create') ?></div><div class="card-body">
          <?php if (!$pkgs): ?><p class="small text-secondary mb-0"><a href="?page=packages"><?= t('create_package') ?> →</a></p><?php else: ?>
          <form method="POST" class="row g-2" onsubmit="this.querySelector('button').disabled=true"><?= $hid(['act' => 'om_vgroup_create']) ?>
            <div class="col-12"><label class="form-label small"><?= t('package') ?></label><select name="package_id" class="form-select form-select-sm"><?php foreach ($pkgs as $p): ?><option value="<?= (int)$p['id'] ?>"><?= h($p['name']) ?> — <?= money($p['price']) ?> • <?= fmtDur((int)$p['duration_minutes']) ?></option><?php endforeach; ?></select></div>
            <div class="col-6"><label class="form-label small"><?= t('quantity') ?></label><input type="number" name="quantity" min="1" max="500" value="20" class="form-control form-control-sm"></div>
            <div class="col-6 d-flex align-items-end"><button class="btn btn-sm btn-success w-100"><?= t('generate') ?></button></div>
          </form><?php endif; ?>
        </div></div></div>
        <div class="col-xl-8"><div class="card"><div class="card-header"><i class="fa-solid fa-layer-group me-2"></i><?= t('om_vg_groups') ?> (<?= count($groups) ?>)</div><div class="card-body">
          <?php if ($gErr !== '' && !$groups): ?><div class="alert alert-warning small"><?= h($gErr) ?></div><?php endif; ?>
          <?php if ($groups): ?><div class="table-responsive"><table class="table table-sm table-hover mcard align-middle"><thead><tr><th><?= t('batch') ?></th><th><?= t('om_total') ?></th><th><?= t('om_v_unused') ?></th><th><?= t('om_duration') ?></th><th><?= t('om_created') ?></th><th></th></tr></thead><tbody>
          <?php foreach ($groups as $g): $k = $known[$g['id']] ?? null; ?>
            <tr><td data-label="<?= t('batch') ?>"><a href="<?= h($base . '&tab=vouchers&vgroup=' . urlencode($g['id'])) ?>" class="fw-semibold"><?= h($g['name'] ?: $g['id']) ?></a><?= $k ? ' <span class="badge text-bg-success">' . h($k['batch']) . '</span>' : '' ?></td>
              <td data-label="<?= t('om_total') ?>"><?= (int)$g['total'] ?></td><td data-label="<?= t('om_v_unused') ?>"><?= (int)$g['unused'] ?></td>
              <td data-label="<?= t('om_duration') ?>"><?= $g['duration'] ? fmtDur((int)$g['duration']) : '—' ?> • <?= (int)$g['limit'] ?> <i class="fa-solid fa-mobile-screen"></i></td>
              <td data-label="<?= t('om_created') ?>" class="small"><?= h($g['created']) ?></td>
              <td class="text-nowrap">
                <a class="btn btn-sm btn-outline-primary" href="<?= h($base . '&tab=vouchers&vgroup=' . urlencode($g['id'])) ?>" title="<?= h(t('om_vg_codes')) ?>"><i class="fa-solid fa-eye"></i></a>
                <?php if ($k && $k['batch']): ?><a class="btn btn-sm btn-outline-secondary" target="_blank" href="?page=print&batch=<?= urlencode($k['batch']) ?>" title="<?= h(t('print')) ?>"><i class="fa-solid fa-print"></i></a>
                <?php else: ?><form method="POST" class="d-inline" onsubmit="this.querySelector('button').disabled=true"><?= $hid(['act' => 'om_vgroup_import', 'gid' => $g['id']]) ?><button class="btn btn-sm btn-outline-success" title="<?= h(t('om_vg_import')) ?>"><i class="fa-solid fa-file-import"></i></button></form><?php endif; ?>
                <form method="POST" class="d-inline" onsubmit="return confirm(<?= h(json_encode(t('om_vg_delete_confirm'))) ?>)"><?= $hid(['act' => 'om_vgroup_delete', 'gid' => $g['id']]) ?><button class="btn btn-sm btn-outline-danger" title="<?= h(t('om_vg_delete')) ?>"><i class="fa-solid fa-trash"></i></button></form></td></tr>
          <?php endforeach; ?></tbody></table></div>
          <?php elseif ($gErr === ''): ?><p class="text-secondary mb-0"><?= t('om_vg_none') ?></p><?php endif; ?>
        </div></div></div>
      </div>

    <?php else: ?>
      <div class="card"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="fa-solid fa-users me-2"></i><?= t('omada_clients') ?> (<?= count($clients) ?>)</span><a href="<?= h($ret) ?>" class="small" aria-label="Refresh"><i class="fa-solid fa-rotate"></i></a></div><div class="card-body">
        <?php if ($cliErr !== '' && !$clients): ?><div class="alert alert-warning small mb-0"><?= h($cliErr) ?></div>
        <?php else: echo omadaClientTable($clients, $cid, $site, $ret, $uid); endif; ?>
      </div></div>
    <?php endif; ?>
    <?php endif; ?>
    <?= $omKitHtml() ?>
    <?php OmadaApi::$deadline = $prevDl; break;

default:
    redirectTo($auth->isLoggedIn() ? '?page=dashboard' : '?page=login');
}
?>
</main>
</div>

<?php if ($inApp): ?>
<nav class="bottom-nav" aria-label="Quick navigation">
  <?php foreach ([['dashboard', 'gauge-high'], ['sessions', 'signal'], ['vouchers', 'ticket'], ['orders', 'cart-shopping'], ['withdraw', 'money-bill-wave']] as [$k, $i]): ?>
    <a href="?page=<?= $k ?>" class="<?= $page === $k ? 'active' : '' ?>"><i class="fa-solid fa-<?= $i ?>"></i><span><?= h(t($k)) ?></span></a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" defer></script>
<script>
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register(<?= json_encode(selfPath() . '?pwa=sw') ?>).catch(()=>{}))}
function toggleTheme(){const r=document.documentElement,n=r.getAttribute('data-bs-theme')==='light'?'dark':'light';r.setAttribute('data-bs-theme',n);
  try{localStorage.setItem('sky_theme',n)}catch(e){}const m=document.querySelector('meta[name=theme-color]');if(m)m.content=n==='light'?'#f3f5fa':'#060a13'}
function cpText(v,btn){const done=()=>{if(!btn)return;const o=btn.innerHTML;btn.innerHTML='<i class="fa-solid fa-check"></i>';btn.classList.add('btn-success');setTimeout(()=>{btn.innerHTML=o;btn.classList.remove('btn-success')},1300)};
  const fb=()=>{const t=document.createElement('textarea');t.value=v;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();try{document.execCommand('copy');done()}catch(e){}document.body.removeChild(t)};
  if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(v).then(done).catch(fb);else fb()}
function cp(id,btn){const el=document.getElementById(id);if(el)cpText(el.tagName==='INPUT'||el.tagName==='TEXTAREA'?el.value:el.textContent,btn)}
function tg(id){const el=document.getElementById(id);if(el)el.type=el.type==='password'?'text':'password'}
// Omada Inform URL → Omada ID + regional Open API address (same rules as parseInformUrl() in PHP); fill=true also fills the controller form
function informPreview(el,outId,fill){const o=document.getElementById(outId);if(!o)return;if(o.dataset.def===undefined)o.dataset.def=o.innerHTML;
  const v=el.value.trim();if(!v){o.innerHTML=o.dataset.def;return}
  const m=v.match(/^(?:[a-z][a-z0-9+.\-]*:\/\/)?([^\/?#:\s]+)(?::\d+)?[^?\s]*(?:\?(\S*))?$/i);if(!m){o.textContent='✘ omada://…';return}
  const host=m[1].toLowerCase(),qs=new URLSearchParams(m[2]||'');let id='';qs.forEach((val,k)=>{if(k.toLowerCase()==='omadacid')id=val.replace(/[^A-Za-z0-9]/g,'')});
  const cloud=/(^|\.)tplinkcloud\.com$/.test(host),api=cloud?'':'https://'+host+':8043';
  const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  if(cloud){o.innerHTML='<span class="text-danger">✘</span> '+esc(<?= json_encode(t('ctrl_cloud_unsupported')) ?>);return}
  o.innerHTML='<span class="text-success">✔</span> Omada Controller <span class="mono">'+esc(host)+'</span> • Omada ID <b class="mono">'+esc(id||'?')+'</b> • API <span class="mono">'+esc(api)+'</span>';
  if(fill&&el.form){const f=el.form;if(f.omadac_id&&id)f.omadac_id.value=id;if(f.base_url&&api&&!f.base_url.value)f.base_url.value=api}}
let deferredPrompt;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;const b=document.getElementById('installBtn');if(b){b.classList.remove('d-none');b.onclick=async()=>{deferredPrompt.prompt();await deferredPrompt.userChoice;b.classList.add('d-none')}}});
</script>
</body>
</html>
<?php
ob_end_flush();