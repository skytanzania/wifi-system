<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Time Adjustment Log Page - Loaded from external file
 * 
 * Sellers can view complete history of all session time adjustments,
 * filter by date, router, reason, and export records
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE EXPORT TO CSV
// ============================================
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $filterRouter = intval($_GET['router'] ?? 0);
    $filterDateFrom = $_GET['from'] ?? '';
    $filterDateTo = $_GET['to'] ?? '';
    $filterType = $_GET['type'] ?? 'all';

    $sql = "SELECT sta.*, 
                   ws.mac_address,
                   ws.device_name,
                   ws.ip_address,
                   v.voucher_code,
                   r.device_name as router_name,
                   u.full_name as adjusted_by_name,
                   u.username as adjusted_by_username
            FROM session_time_adjustments sta
            JOIN wifi_sessions ws ON sta.session_id = ws.id
            JOIN routers r ON ws.router_id = r.id
            LEFT JOIN vouchers v ON ws.voucher_id = v.id
            LEFT JOIN users u ON sta.seller_id = u.id
            WHERE sta.seller_id = ?";
    $params = [$userId];
    $types = "i";

    if ($filterRouter) {
        $sql .= " AND ws.router_id = ?";
        $params[] = $filterRouter;
        $types .= "i";
    }

    if ($filterDateFrom) {
        $sql .= " AND DATE(sta.created_at) >= ?";
        $params[] = $filterDateFrom;
        $types .= "s";
    }

    if ($filterDateTo) {
        $sql .= " AND DATE(sta.created_at) <= ?";
        $params[] = $filterDateTo;
        $types .= "s";
    }

    if ($filterType === 'extend') {
        $sql .= " AND sta.adjustment_minutes > 0";
    } elseif ($filterType === 'reduce') {
        $sql .= " AND sta.adjustment_minutes < 0";
    } elseif ($filterType === 'offline') {
        $sql .= " AND sta.router_was_offline = 1";
    }

    $sql .= " ORDER BY sta.created_at DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $exportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Clear output
    while (ob_get_level() > 0) ob_end_clean();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="adjustments_' . date('Y-m-d_His') . '.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, [
        'ID', 'Date', 'Device', 'MAC', 'IP', 'Router', 'Voucher',
        'Old Expiry', 'New Expiry', 'Adjustment (min)', 'Type',
        'Router Was Offline', 'Reason', 'Adjusted By'
    ]);

    foreach ($exportData as $row) {
        fputcsv($output, [
            $row['id'],
            $row['created_at'],
            $row['device_name'] ?? 'Unknown',
            $row['mac_address'] ?? '',
            $row['ip_address'] ?? '',
            $row['router_name'] ?? '',
            $row['voucher_code'] ?? '',
            $row['old_expiry'] ?? '',
            $row['new_expiry'] ?? '',
            $row['adjustment_minutes'],
            $row['adjustment_minutes'] > 0 ? 'Extend' : 'Reduce',
            $row['router_was_offline'] ? 'Yes' : 'No',
            $row['reason'] ?? '',
            $row['adjusted_by_name'] ?? 'System'
        ]);
    }
    fclose($output);
    exit;
}

// ============================================
// FETCH FILTERS
// ============================================
$filterRouter = intval($_GET['router'] ?? 0);
$filterDateFrom = $_GET['from'] ?? '';
$filterDateTo = $_GET['to'] ?? '';
$filterType = $_GET['type'] ?? 'all';
$searchTerm = trim($_GET['search'] ?? '');
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 50;
$offset = ($pageNum - 1) * $perPage;

// ============================================
// BUILD QUERY
// ============================================
$whereClause = "WHERE sta.seller_id = ?";
$params = [$userId];
$types = "i";

if ($filterRouter) {
    $whereClause .= " AND ws.router_id = ?";
    $params[] = $filterRouter;
    $types .= "i";
}

if ($filterDateFrom) {
    $whereClause .= " AND DATE(sta.created_at) >= ?";
    $params[] = $filterDateFrom;
    $types .= "s";
}

if ($filterDateTo) {
    $whereClause .= " AND DATE(sta.created_at) <= ?";
    $params[] = $filterDateTo;
    $types .= "s";
}

if ($filterType === 'extend') {
    $whereClause .= " AND sta.adjustment_minutes > 0";
} elseif ($filterType === 'reduce') {
    $whereClause .= " AND sta.adjustment_minutes < 0";
} elseif ($filterType === 'offline') {
    $whereClause .= " AND sta.router_was_offline = 1";
}

if ($searchTerm) {
    $whereClause .= " AND (
        ws.mac_address LIKE ? 
        OR ws.device_name LIKE ? 
        OR v.voucher_code LIKE ? 
        OR sta.reason LIKE ?
    )";
    $searchLike = "%$searchTerm%";
    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;
    $types .= "ssss";
}

// Count total
$countSql = "SELECT COUNT(*) as total 
             FROM session_time_adjustments sta
             JOIN wifi_sessions ws ON sta.session_id = ws.id
             JOIN routers r ON ws.router_id = r.id
             LEFT JOIN vouchers v ON ws.voucher_id = v.id
             $whereClause";
$countStmt = $conn->prepare($countSql);
$countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalAdjustments = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = max(1, ceil($totalAdjustments / $perPage));

// Fetch adjustments
$sql = "SELECT sta.*, 
               ws.mac_address,
               ws.device_name,
               ws.ip_address,
               ws.session_start,
               ws.session_end,
               v.voucher_code,
               p.name as package_name,
               r.device_name as router_name,
               r.status as router_status,
               u.full_name as adjusted_by_name,
               u.username as adjusted_by_username
        FROM session_time_adjustments sta
        JOIN wifi_sessions ws ON sta.session_id = ws.id
        JOIN routers r ON ws.router_id = r.id
        LEFT JOIN vouchers v ON ws.voucher_id = v.id
        LEFT JOIN packages p ON v.package_id = p.id
        LEFT JOIN users u ON sta.seller_id = u.id
        $whereClause
        ORDER BY sta.created_at DESC
        LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;
$types .= "ii";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$adjustments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ============================================
// STATS
// ============================================
$stats = [
    'total' => 0,
    'today' => 0,
    'week' => 0,
    'month' => 0,
    'extend' => 0,
    'reduce' => 0,
    'offline' => 0,
    'extended_minutes' => 0,
    'reduced_minutes' => 0
];

try {
    $res = $conn->query("SELECT COUNT(*) as c FROM session_time_adjustments WHERE seller_id = $userId");
    if ($res) $stats['total'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM session_time_adjustments WHERE seller_id = $userId AND DATE(created_at) = CURDATE()");
    if ($res) $stats['today'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM session_time_adjustments WHERE seller_id = $userId AND YEARWEEK(created_at) = YEARWEEK(CURDATE())");
    if ($res) $stats['week'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM session_time_adjustments WHERE seller_id = $userId AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())");
    if ($res) $stats['month'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM session_time_adjustments WHERE seller_id = $userId AND adjustment_minutes > 0");
    if ($res) $stats['extend'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM session_time_adjustments WHERE seller_id = $userId AND adjustment_minutes < 0");
    if ($res) $stats['reduce'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM session_time_adjustments WHERE seller_id = $userId AND router_was_offline = 1");
    if ($res) $stats['offline'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COALESCE(SUM(adjustment_minutes), 0) as total FROM session_time_adjustments WHERE seller_id = $userId AND adjustment_minutes > 0");
    if ($res) $stats['extended_minutes'] = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COALESCE(SUM(ABS(adjustment_minutes)), 0) as total FROM session_time_adjustments WHERE seller_id = $userId AND adjustment_minutes < 0");
    if ($res) $stats['reduced_minutes'] = $res->fetch_assoc()['total'];
} catch (Throwable $e) {}

// ============================================
// FETCH ROUTERS FOR FILTER
// ============================================
$routers = $router->getRouters($userId);

// ============================================
// FETCH TOP REASONS
// ============================================
$topReasons = [];
try {
    $stmt = $conn->prepare("
        SELECT reason, COUNT(*) as count 
        FROM session_time_adjustments 
        WHERE seller_id = ? AND reason IS NOT NULL AND reason != ''
        GROUP BY reason 
        ORDER BY count DESC 
        LIMIT 5
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $topReasons = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// Format duration helper
function formatDuration($minutes) {
    $minutes = abs(intval($minutes));
    if ($minutes < 60) return $minutes . 'm';
    if ($minutes < 1440) {
        $h = floor($minutes / 60);
        $m = $minutes % 60;
        return $h . 'h' . ($m > 0 ? ' ' . $m . 'm' : '');
    }
    $d = floor($minutes / 1440);
    $h = floor(($minutes % 1440) / 60);
    return $d . 'd' . ($h > 0 ? ' ' . $h . 'h' : '');
}
?>

<!-- ============================================ -->
<!-- ADJUSTMENT LOG HEADER                       -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-history"></i> <?php echo t('time_adjustment_log'); ?></h2>
        <small class="text-muted">Complete history of all session time adjustments</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a href="?page=adjustments&export=csv&router=<?php echo $filterRouter; ?>&from=<?php echo $filterDateFrom; ?>&to=<?php echo $filterDateTo; ?>&type=<?php echo $filterType; ?>" 
           class="btn btn-outline-success btn-sm">
            <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
        </a>
        <a href="?page=sessions" class="btn btn-outline-warning btn-sm">
            <i class="fas fa-clock"></i> <?php echo t('session_manager'); ?>
        </a>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- STATS OVERVIEW                              -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-history text-primary"></i> <?php echo t('total'); ?></div>
            <div class="metric-value"><?php echo number_format($stats['total']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-calendar-day text-info"></i> <?php echo t('today'); ?></div>
            <div class="metric-value text-info"><?php echo number_format($stats['today']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-calendar-week text-warning"></i> <?php echo t('this_week'); ?></div>
            <div class="metric-value text-warning"><?php echo number_format($stats['week']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-calendar-alt text-success"></i> <?php echo t('this_month'); ?></div>
            <div class="metric-value text-success"><?php echo number_format($stats['month']); ?></div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- SECONDARY STATS                             -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card success">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('extend'); ?></h6>
                    <h4 class="fw-bold mb-0"><?php echo number_format($stats['extend']); ?></h4>
                    <small style="opacity:0.85;">
                        Total: +<?php echo formatDuration($stats['extended_minutes']); ?>
                    </small>
                </div>
                <i class="fas fa-arrow-up" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card danger">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('reduce'); ?></h6>
                    <h4 class="fw-bold mb-0"><?php echo number_format($stats['reduce']); ?></h4>
                    <small style="opacity:0.85;">
                        Total: -<?php echo formatDuration($stats['reduced_minutes']); ?>
                    </small>
                </div>
                <i class="fas fa-arrow-down" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card warning">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('offline'); ?> Router</h6>
                    <h4 class="fw-bold mb-0"><?php echo number_format($stats['offline']); ?></h4>
                    <small style="opacity:0.85;">
                        <?php 
                        $offlinePercent = $stats['total'] > 0 ? round(($stats['offline'] / $stats['total']) * 100) : 0;
                        echo $offlinePercent; ?>% of all adjustments
                    </small>
                </div>
                <i class="fas fa-wifi-slash" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card info">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1">Net Effect</h6>
                    <h4 class="fw-bold mb-0">
                        <?php 
                        $net = $stats['extended_minutes'] - $stats['reduced_minutes'];
                        echo ($net >= 0 ? '+' : '-') . formatDuration($net); 
                        ?>
                    </h4>
                    <small style="opacity:0.85;">Total minutes added</small>
                </div>
                <i class="fas fa-balance-scale" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- TOP REASONS CHART                           -->
<!-- ============================================ -->
<?php if (count($topReasons) > 0): ?>
<div class="card mb-4">
    <div class="card-header bg-white">
        <h6 class="mb-0"><i class="fas fa-chart-bar text-info"></i> Top Adjustment Reasons</h6>
    </div>
    <div class="card-body">
        <?php 
        $maxReasonCount = max(array_column($topReasons, 'count'));
        foreach ($topReasons as $tr):
            $pct = $maxReasonCount > 0 ? round(($tr['count'] / $maxReasonCount) * 100) : 0;
        ?>
        <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="text-truncate" style="max-width:70%;">
                    <i class="fas fa-quote-left text-muted small"></i> 
                    <?php echo htmlspecialchars($tr['reason']); ?>
                </span>
                <span class="badge bg-primary"><?php echo $tr['count']; ?>x</span>
            </div>
            <div class="progress" style="height:6px;">
                <div class="progress-bar bg-primary" style="width: <?php echo $pct; ?>%"></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- FILTERS                                     -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h6 class="mb-0"><i class="fas fa-filter"></i> <?php echo t('filter'); ?></h6>
    </div>
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-end">
            <input type="hidden" name="page" value="adjustments">
            
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-search"></i> <?php echo t('search'); ?></label>
                <input type="text" name="search" class="form-control form-control-sm" 
                       placeholder="MAC, voucher, reason..." value="<?php echo htmlspecialchars($searchTerm); ?>">
            </div>
            
            <div class="col-md-2 col-6">
                <label class="form-label small mb-1"><i class="fas fa-wifi"></i> <?php echo t('router'); ?></label>
                <select name="router" class="form-select form-select-sm">
                    <option value="0"><?php echo t('all_routers'); ?></option>
                    <?php foreach ($routers as $r): ?>
                    <option value="<?php echo $r['id']; ?>" <?php echo $filterRouter == $r['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($r['device_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2 col-6">
                <label class="form-label small mb-1"><i class="fas fa-tag"></i> <?php echo t('type'); ?></label>
                <select name="type" class="form-select form-select-sm">
                    <option value="all" <?php echo $filterType === 'all' ? 'selected' : ''; ?>>All Types</option>
                    <option value="extend" <?php echo $filterType === 'extend' ? 'selected' : ''; ?>>
                        <i class="fas fa-arrow-up"></i> <?php echo t('extend'); ?>
                    </option>
                    <option value="reduce" <?php echo $filterType === 'reduce' ? 'selected' : ''; ?>>
                        <i class="fas fa-arrow-down"></i> <?php echo t('reduce'); ?>
                    </option>
                    <option value="offline" <?php echo $filterType === 'offline' ? 'selected' : ''; ?>>
                        <i class="fas fa-wifi-slash"></i> Offline Router
                    </option>
                </select>
            </div>
            
            <div class="col-md-2 col-6">
                <label class="form-label small mb-1"><i class="fas fa-calendar"></i> <?php echo t('from'); ?></label>
                <input type="date" name="from" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filterDateFrom); ?>">
            </div>
            
            <div class="col-md-2 col-6">
                <label class="form-label small mb-1"><i class="fas fa-calendar"></i> <?php echo t('to'); ?></label>
                <input type="date" name="to" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filterDateTo); ?>">
            </div>
            
            <div class="col-md-1 col-6 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1" title="Filter">
                    <i class="fas fa-filter"></i>
                </button>
                <a href="?page=adjustments" class="btn btn-outline-secondary btn-sm" title="Clear">
                    <i class="fas fa-times"></i>
                </a>
            </div>
        </form>
        
        <!-- Quick Date Filters -->
        <div class="mt-2 d-flex gap-2 flex-wrap">
            <span class="small text-muted align-self-center">Quick:</span>
            <a href="?page=adjustments&from=<?php echo date('Y-m-d'); ?>&to=<?php echo date('Y-m-d'); ?>" 
               class="btn btn-sm btn-outline-info <?php echo ($filterDateFrom === date('Y-m-d') && $filterDateTo === date('Y-m-d')) ? 'active' : ''; ?>">
                <?php echo t('today'); ?>
            </a>
            <a href="?page=adjustments&from=<?php echo date('Y-m-d', strtotime('-7 days')); ?>&to=<?php echo date('Y-m-d'); ?>" 
               class="btn btn-sm btn-outline-info">
                Last 7 Days
            </a>
            <a href="?page=adjustments&from=<?php echo date('Y-m-d', strtotime('-30 days')); ?>&to=<?php echo date('Y-m-d'); ?>" 
               class="btn btn-sm btn-outline-info">
                Last 30 Days
            </a>
            <a href="?page=adjustments&from=<?php echo date('Y-m-01'); ?>&to=<?php echo date('Y-m-t'); ?>" 
               class="btn btn-sm btn-outline-info">
                This Month
            </a>
            <a href="?page=adjustments&type=offline" 
               class="btn btn-sm btn-outline-warning <?php echo $filterType === 'offline' ? 'active' : ''; ?>">
                <i class="fas fa-wifi-slash"></i> Offline Only
            </a>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- ADJUSTMENTS TABLE                           -->
<!-- ============================================ -->
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="mb-0">
            <i class="fas fa-list"></i> <?php echo t('time_adjustment_log'); ?>
            <small class="text-muted ms-2">(<?php echo number_format($totalAdjustments); ?> results)</small>
        </h5>
        <small class="text-muted">
            <?php echo t('showing'); ?> <?php echo $totalAdjustments > 0 ? $offset + 1 : 0; ?>-<?php echo min($offset + $perPage, $totalAdjustments); ?>
        </small>
    </div>
    <div class="card-body p-0">
        <?php if (count($adjustments) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mobile-card-table mb-0">
                    <thead>
                        <tr>
                            <th style="width:60px;">#</th>
                            <th><?php echo t('date'); ?></th>
                            <th><?php echo t('device'); ?></th>
                            <th><?php echo t('router'); ?></th>
                            <th><?php echo t('adjustment'); ?></th>
                            <th><?php echo t('old_expiry'); ?></th>
                            <th><?php echo t('new_expiry'); ?></th>
                            <th><?php echo t('reason'); ?></th>
                            <th><?php echo t('adjusted_by'); ?></th>
                            <th><?php echo t('actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($adjustments as $adj): 
                            $isExtend = $adj['adjustment_minutes'] > 0;
                            $minutesAbs = abs($adj['adjustment_minutes']);
                            $durationText = formatDuration($minutesAbs);
                            $wasOffline = !empty($adj['router_was_offline']);
                        ?>
                        <tr>
                            <td data-label="#">
                                <strong>#<?php echo $adj['id']; ?></strong>
                            </td>
                            <td data-label="<?php echo t('date'); ?>">
                                <div><?php echo date('d M Y', strtotime($adj['created_at'])); ?></div>
                                <small class="text-muted"><?php echo date('H:i:s', strtotime($adj['created_at'])); ?></small>
                            </td>
                            <td data-label="<?php echo t('device'); ?>">
                                <div class="fw-semibold"><?php echo htmlspecialchars($adj['device_name'] ?? 'Unknown'); ?></div>
                                <small class="text-muted">
                                    <i class="fas fa-network-wired"></i> 
                                    <code style="font-size:0.7rem;"><?php echo htmlspecialchars($adj['mac_address']); ?></code>
                                </small>
                                <?php if (!empty($adj['voucher_code'])): ?>
                                <br><small class="text-muted">
                                    <i class="fas fa-ticket-alt"></i> 
                                    <code style="font-size:0.7rem;"><?php echo htmlspecialchars($adj['voucher_code']); ?></code>
                                </small>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo t('router'); ?>">
                                <div>
                                    <i class="fas fa-wifi text-primary"></i>
                                    <?php echo htmlspecialchars($adj['router_name']); ?>
                                </div>
                                <?php if ($wasOffline): ?>
                                <span class="offline-badge mt-1">
                                    <i class="fas fa-wifi-slash"></i> Was Offline
                                </span>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo t('adjustment'); ?>">
                                <div class="fw-bold <?php echo $isExtend ? 'adjustment-positive' : 'adjustment-negative'; ?>">
                                    <i class="fas fa-<?php echo $isExtend ? 'arrow-up' : 'arrow-down'; ?>"></i>
                                    <?php echo $isExtend ? '+' : '-'; ?><?php echo $durationText; ?>
                                </div>
                                <small class="text-muted">
                                    <?php echo $isExtend ? 'Extended' : 'Reduced'; ?>
                                </small>
                            </td>
                            <td data-label="<?php echo t('old_expiry'); ?>">
                                <?php if (!empty($adj['old_expiry'])): ?>
                                <div><?php echo date('d M', strtotime($adj['old_expiry'])); ?></div>
                                <small class="text-muted"><?php echo date('H:i', strtotime($adj['old_expiry'])); ?></small>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo t('new_expiry'); ?>">
                                <?php if (!empty($adj['new_expiry'])): ?>
                                <div class="text-success"><?php echo date('d M', strtotime($adj['new_expiry'])); ?></div>
                                <small class="text-muted"><?php echo date('H:i', strtotime($adj['new_expiry'])); ?></small>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo t('reason'); ?>">
                                <?php if (!empty($adj['reason'])): ?>
                                <span class="text-truncate d-inline-block" style="max-width:150px;" 
                                      title="<?php echo htmlspecialchars($adj['reason']); ?>">
                                    <?php echo htmlspecialchars($adj['reason']); ?>
                                </span>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo t('adjusted_by'); ?>">
                                <div class="d-flex align-items-center gap-1">
                                    <div class="avatar" style="width:24px;height:24px;font-size:0.7rem;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;">
                                        <?php echo strtoupper(substr($adj['adjusted_by_name'] ?? 'S', 0, 1)); ?>
                                    </div>
                                    <small><?php echo htmlspecialchars($adj['adjusted_by_name'] ?? 'System'); ?></small>
                                </div>
                            </td>
                            <td data-label="<?php echo t('actions'); ?>">
                                <button type="button" class="btn btn-sm btn-outline-primary" 
                                        data-bs-toggle="modal" data-bs-target="#detailModal<?php echo $adj['id']; ?>">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                        
                        <!-- ============================================ -->
                        <!-- DETAIL MODAL                                 -->
                        <!-- ============================================ -->
                        <div class="modal fade" id="detailModal<?php echo $adj['id']; ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title"><i class="fas fa-history"></i> Adjustment #<?php echo $adj['id']; ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Type Banner -->
                                        <div class="alert alert-<?php echo $isExtend ? 'success' : 'danger'; ?> text-center">
                                            <i class="fas fa-<?php echo $isExtend ? 'arrow-up' : 'arrow-down'; ?> fa-2x mb-2"></i>
                                            <h4 class="mb-0">
                                                <?php echo $isExtend ? '+' : '-'; ?><?php echo $durationText; ?>
                                            </h4>
                                            <small><?php echo $isExtend ? 'Time Extended' : 'Time Reduced'; ?></small>
                                        </div>
                                        
                                        <?php if ($wasOffline): ?>
                                        <div class="alert alert-warning small">
                                            <i class="fas fa-wifi-slash"></i> 
                                            This adjustment was made while the router was <strong>offline</strong>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <!-- Time Comparison -->
                                        <div class="card mb-3" style="background:var(--bg-body);">
                                            <div class="card-body">
                                                <div class="row text-center">
                                                    <div class="col-6">
                                                        <div class="text-muted small mb-1"><?php echo t('old_expiry'); ?></div>
                                                        <div class="fw-bold">
                                                            <?php echo !empty($adj['old_expiry']) ? date('d M H:i', strtotime($adj['old_expiry'])) : '-'; ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 border-start" style="border-color:var(--border-color) !important;">
                                                        <div class="text-muted small mb-1"><?php echo t('new_expiry'); ?></div>
                                                        <div class="fw-bold text-success">
                                                            <?php echo !empty($adj['new_expiry']) ? date('d M H:i', strtotime($adj['new_expiry'])) : '-'; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Details -->
                                        <div class="stat-row">
                                            <span><?php echo t('date'); ?>:</span>
                                            <strong><?php echo date('d M Y H:i:s', strtotime($adj['created_at'])); ?></strong>
                                        </div>
                                        <div class="stat-row">
                                            <span><?php echo t('device'); ?>:</span>
                                            <strong><?php echo htmlspecialchars($adj['device_name'] ?? 'Unknown'); ?></strong>
                                        </div>
                                        <div class="stat-row">
                                            <span>MAC:</span>
                                            <code><?php echo htmlspecialchars($adj['mac_address']); ?></code>
                                        </div>
                                        <?php if (!empty($adj['ip_address'])): ?>
                                        <div class="stat-row">
                                            <span>IP:</span>
                                            <code><?php echo htmlspecialchars($adj['ip_address']); ?></code>
                                        </div>
                                        <?php endif; ?>
                                        <div class="stat-row">
                                            <span><?php echo t('router'); ?>:</span>
                                            <strong><?php echo htmlspecialchars($adj['router_name']); ?></strong>
                                        </div>
                                        <?php if (!empty($adj['voucher_code'])): ?>
                                        <div class="stat-row">
                                            <span>Voucher:</span>
                                            <code><?php echo htmlspecialchars($adj['voucher_code']); ?></code>
                                        </div>
                                        <?php endif; ?>
                                        <?php if (!empty($adj['package_name'])): ?>
                                        <div class="stat-row">
                                            <span>Package:</span>
                                            <strong><?php echo htmlspecialchars($adj['package_name']); ?></strong>
                                        </div>
                                        <?php endif; ?>
                                        <div class="stat-row">
                                            <span><?php echo t('adjustment'); ?>:</span>
                                            <strong class="<?php echo $isExtend ? 'text-success' : 'text-danger'; ?>">
                                                <?php echo $isExtend ? '+' : '-'; ?><?php echo $adj['adjustment_minutes']; ?> min
                                            </strong>
                                        </div>
                                        <div class="stat-row">
                                            <span><?php echo t('adjusted_by'); ?>:</span>
                                            <strong><?php echo htmlspecialchars($adj['adjusted_by_name'] ?? 'System'); ?></strong>
                                        </div>
                                        
                                        <?php if (!empty($adj['reason'])): ?>
                                        <div class="mt-3">
                                            <div class="text-muted small mb-1"><?php echo t('reason'); ?>:</div>
                                            <div class="p-2 rounded" style="background:var(--bg-body);">
                                                <i class="fas fa-quote-left text-muted"></i>
                                                <?php echo htmlspecialchars($adj['reason']); ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- ============================================ -->
            <!-- PAGINATION                                   -->
            <!-- ============================================ -->
            <?php if ($totalPages > 1): ?>
            <div class="d-flex justify-content-between align-items-center p-3 border-top flex-wrap gap-2" 
                 style="border-color:var(--border-color) !important;">
                <div class="text-muted small">
                    <?php echo t('page'); ?> <?php echo $pageNum; ?> <?php echo t('of'); ?> <?php echo $totalPages; ?>
                </div>
                <nav>
                    <ul class="pagination pagination-sm mb-0">
                        <?php if ($pageNum > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=adjustments&p=1&router=<?php echo $filterRouter; ?>&type=<?php echo $filterType; ?>&from=<?php echo $filterDateFrom; ?>&to=<?php echo $filterDateTo; ?>&search=<?php echo urlencode($searchTerm); ?>">
                                <i class="fas fa-angle-double-left"></i>
                            </a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="?page=adjustments&p=<?php echo $pageNum - 1; ?>&router=<?php echo $filterRouter; ?>&type=<?php echo $filterType; ?>&from=<?php echo $filterDateFrom; ?>&to=<?php echo $filterDateTo; ?>&search=<?php echo urlencode($searchTerm); ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php
                        $startPage = max(1, $pageNum - 2);
                        $endPage = min($totalPages, $pageNum + 2);
                        for ($i = $startPage; $i <= $endPage; $i++):
                        ?>
                        <li class="page-item <?php echo $i == $pageNum ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=adjustments&p=<?php echo $i; ?>&router=<?php echo $filterRouter; ?>&type=<?php echo $filterType; ?>&from=<?php echo $filterDateFrom; ?>&to=<?php echo $filterDateTo; ?>&search=<?php echo urlencode($searchTerm); ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                        <?php endfor; ?>
                        
                        <?php if ($pageNum < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=adjustments&p=<?php echo $pageNum + 1; ?>&router=<?php echo $filterRouter; ?>&type=<?php echo $filterType; ?>&from=<?php echo $filterDateFrom; ?>&to=<?php echo $filterDateTo; ?>&search=<?php echo urlencode($searchTerm); ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="?page=adjustments&p=<?php echo $totalPages; ?>&router=<?php echo $filterRouter; ?>&type=<?php echo $filterType; ?>&from=<?php echo $filterDateFrom; ?>&to=<?php echo $filterDateTo; ?>&search=<?php echo urlencode($searchTerm); ?>">
                                <i class="fas fa-angle-double-right"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
            
        <?php else: ?>
            <!-- Empty State -->
            <div class="empty-state py-5">
                <i class="fas fa-history"></i>
                <h5><?php echo t('no_data'); ?></h5>
                <p>
                    <?php if ($searchTerm || $filterRouter || $filterType !== 'all' || $filterDateFrom || $filterDateTo): ?>
                        No adjustments match your filters.
                        <a href="?page=adjustments">Clear all filters</a>
                    <?php else: ?>
                        No session time adjustments have been made yet.
                        <br>
                        <small>Adjustments are recorded when you manually change a session's expiry time.</small>
                    <?php endif; ?>
                </p>
                <?php if (!$searchTerm && !$filterRouter && $filterType === 'all'): ?>
                <a href="?page=sessions" class="btn btn-primary mt-3">
                    <i class="fas fa-clock"></i> Go to Session Manager
                </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================ -->
<!-- SUMMARY FOOTER                              -->
<!-- ============================================ -->
<?php if (count($adjustments) > 0): ?>
<div class="row mt-4">
    <div class="col-md-6 mb-3">
        <div class="card">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-info-circle text-info"></i> About Adjustments</h6>
                <p class="text-muted small mb-2">
                    <strong>Adjustments</strong> are recorded whenever you manually change a WiFi session's expiry time 
                    from the Session Manager or Device Manager.
                </p>
                <ul class="text-muted small mb-0">
                    <li><i class="fas fa-check text-success"></i> Every change is logged with old & new expiry</li>
                    <li><i class="fas fa-check text-success"></i> Reasons are tracked for auditing</li>
                    <li><i class="fas fa-check text-success"></i> Offline router adjustments are highlighted</li>
                    <li><i class="fas fa-check text-success"></i> CSV export respects all filters</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="card">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-lightbulb text-warning"></i> Tips</h6>
                <ul class="text-muted small mb-0">
                    <li class="mb-1">
                        <i class="fas fa-arrow-right text-primary"></i>
                        Use <strong>quick date filters</strong> to see today's, this week's, or this month's adjustments
                    </li>
                    <li class="mb-1">
                        <i class="fas fa-arrow-right text-primary"></i>
                        Filter by <strong>"Offline Only"</strong> to see adjustments made during router outages
                    </li>
                    <li class="mb-1">
                        <i class="fas fa-arrow-right text-primary"></i>
                        Click the <strong>eye icon</strong> on any row to see full details
                    </li>
                    <li class="mb-0">
                        <i class="fas fa-arrow-right text-primary"></i>
                        Export to CSV for record-keeping or reporting
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Auto-set "to" date when "from" date is selected
document.addEventListener('DOMContentLoaded', function() {
    const fromInput = document.querySelector('input[name="from"]');
    const toInput = document.querySelector('input[name="to"]');
    
    if (fromInput && toInput) {
        fromInput.addEventListener('change', function() {
            if (this.value && !toInput.value) {
                toInput.value = this.value;
            } else if (this.value && toInput.value && this.value > toInput.value) {
                toInput.value = this.value;
            }
        });
    }
    
    // Auto-submit when quick filter clicked (handled by anchor)
    // Copy-to-clipboard for MAC addresses
    document.querySelectorAll('code').forEach(code => {
        code.style.cursor = 'pointer';
        code.title = 'Click to copy';
        code.addEventListener('click', function() {
            navigator.clipboard.writeText(this.textContent.trim()).then(() => {
                const originalBg = this.style.background;
                this.style.background = 'rgba(16, 185, 129, 0.3)';
                setTimeout(() => {
                    this.style.background = originalBg;
                }, 300);
            });
        });
    });
});
</script>