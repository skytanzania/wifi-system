<?php
/**
 * ============================================================================
 *  SKYTANZA WIFI — config.local.php
 *  Copy this file next to index.php on BOTH:
 *    1) the cPanel website
 *    2) the RADIUS server box
 *
 *  Every value here overrides the built-in default in index.php.
 *  Delete any line you do not want to change.
 *
 *  SECURITY: never commit this file to git. chmod 600 config.local.php
 * ============================================================================
 */

// ---------------------------------------------------------------------------
// 1. DATABASE — website (cPanel) only. The RADIUS box does NOT need a database.
// ---------------------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_USER', 'skytanza_wifi');
define('DB_PASS', 'sky@75199919');
define('DB_NAME', 'skytanza_wifi');

// ---------------------------------------------------------------------------
// 2. SITE
// ---------------------------------------------------------------------------
define('SITE_NAME', 'SkyTanza WiFi');
define('SITE_URL', 'https://wifi.skytanzania.co.tz');
define('CURRENCY', 'TZS');
define('APP_VERSION', '5.0.0');

// ---------------------------------------------------------------------------
// 3. SECRETS — CHANGE ALL OF THESE. Use long random strings (32+ chars).
//    Generate one with:  php -r "echo bin2hex(random_bytes(32));"
// ---------------------------------------------------------------------------

// Used for general app signing / sessions.
define('APP_SECRET', 'a7f3c9e2b8d4615f0a2e7c3b9d8f1a4e6c2b5d8f0a3e7c1b9d4f6a2e8c5b7d0f');

// Shared key between the website and the RADIUS server.
// MUST be identical in the config.local.php on BOTH machines.
// This is sent as the X-API-KEY header on every RADIUS API call.
define('RADIUS_API_KEY', 'fd076edc1d1813f75d605151aaa3e6b1d842466e0bd765a42f15ccb3a0f35292');

// Secret for the optional cPanel cron job:  ?cron=run&secret=THIS
define('CRON_SECRET', 'c1f5a9e3b7d2f6a0c4e8b1d5f9a3c7e0b4d8f2a6c1e5b9d3f7a0c4e8b2d6f1a5');

// Secret for the mobile-money payment webhook:  ?webhook=payment&secret=THIS
define('PAYMENT_WEBHOOK_SECRET', 'd2a6e0c4f8b3d7a1c5e9b2d6f0a4c8e1b5d9f3a7c2e6b0d4f8a3c7e1b5d9f2a6');

// ---------------------------------------------------------------------------
// 4. PAYOUTS — Sonic Pesa (withdrawals). Move to a secret manager if possible.
// ---------------------------------------------------------------------------
define('WITHDRAWAL_FEE_PERCENT', 4);   // platform fee % taken from the seller
define('SONIC_PESA_FEE_PERCENT', 6);   // Sonic Pesa fee % on the remaining amount

define('SONIC_PESA_API_KEY', 'sk_live_7j16qyGqFqoUi2hY0r6a2ODxCcEkojeNU2jyjMMT');
define('SONIC_PESA_API_SECRET', 'BD4zOb9oFAUfpGzm2yzFb7Sdh6abdPIybrEwGiQyWANm3d1ldgQ2Z6u15kpNjVDK');
define('SONIC_PESA_API_BASE', 'https://api.sonicpesa.com/api/v1');
define('SONIC_PESA_MIN_PAYOUT', 30000); // TZS — Sonic Pesa minimum payout

// Mobile-money COLLECTION (customer pays on the portal).
// Leave '' to use the "Lipa Namba" manual confirmation flow.
// When Sonic Pesa gives you the collection path, put it here, e.g. '/payments/create'.
define('SONIC_PESA_COLLECT_ENDPOINT', '');

// ---------------------------------------------------------------------------
// 5. SESSIONS / RADIUS TIMING
// ---------------------------------------------------------------------------
define('SESSION_TIMEOUT', 3600);   // seconds of inactivity before a seller is logged out
define('RADIUS_INTERIM', 60);      // Accounting Interim-Update interval (seconds)

// ---------------------------------------------------------------------------
// 6. EXTERNAL RADIUS SERVER (the box running:  php index.php radius-server)
// ---------------------------------------------------------------------------
// Ports 1812 / 1813 are fixed by Omada. Disconnect/CoA goes to the NAS on 3799.
// define('RADIUS_AUTH_PORT', 1812);   // already fixed in index.php
// define('RADIUS_ACCT_PORT', 1813);   // already fixed in index.php
// define('RADIUS_DAE_PORT',  3799);   // already fixed in index.php

// Interface the RADIUS server listens on. '0.0.0.0' = all interfaces.
define('RADIUS_BIND_IP', '0.0.0.0');

// Where the website lives — the RADIUS server calls this URL for every
// authorize / accounting / dae_queue request.
define('RADIUS_API_URL', 'https://wifi.skytanzania.co.tz/index.php');

// How often the RADIUS server polls the website for Disconnect-Request jobs (seconds).
define('RADIUS_DAE_POLL', 15);

// Optional — defaults are shown
define('SKY_CTRL_VERIFY_SSL', false); // server→controller TLS verify (server-to-server, safe to disable for self-signed)
define('SKY_CTRL_TIMEOUT', 15);       // seconds
define('SKY_CTRL_USE_PROXY', true);   // use the server-side browserauth proxy (mobile fix)
define('SKY_CTRL_FORCE_HTTP', false); // force http:// for the controller browserauth URL


define('SONIC_PESA_KEY', 'sk_live_7j16qyGqFqoUi2hY0r6a2ODxCcEkojeNU2jyjMMT');
define('SONIC_PESA_ACTIVE', true);
define('PAYMENT_WEBHOOK_SECRET', 'a-very-long-random-string-here');