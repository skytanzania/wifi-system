<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Dashboard Page - Loaded from external file
 * 
 * This file is included by index.php with the following context variables available:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require login
$auth->requireLogin();

// Get current user
$user = $auth->getUser();

// Admin redirects to admin panel
if ($user['user_type'] === 'admin') {
    redirectTo('?page=admin');
    exit;
}

// ============================================
// CUSTOMER DASHBOARD
// ============================================
if ($user['user_type'] !== 'seller') {
    $transactions = $transaction->getByUser($_SESSION['user_id']);
    
    // Get active sessions for this customer
    $customerSessions = [];
    try {
        $stmt = $conn->prepare("
            SELECT ws.*, r.device_name as router_name, r.ssid,
                   p.name as package_name, v.voucher_code
            FROM wifi_sessions ws
            LEFT JOIN routers r ON ws.router_id = r.id
            LEFT JOIN vouchers v ON ws.voucher_id = v.id
            LEFT JOIN packages p ON v.package_id = p.id
            WHERE ws.user_id = ? AND ws.status = 'active'
            ORDER BY ws.session_end ASC
        ");
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        $customerSessions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Throwable $e) {
        $customerSessions = [];
    }
    
    // Get total stats
    $totalSpent = 0;
    $totalSessions = 0;
    try {
        $res = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE user_id = {$user['id']} AND payment_status = 'completed'");
        if ($res) $totalSpent = $res->fetch_assoc()['total'];
        
        $res = $conn->query("SELECT COUNT(*) as total FROM wifi_sessions WHERE user_id = {$user['id']}");
        if ($res) $totalSessions = $res->fetch_assoc()['total'];
    } catch (Throwable $e) {}
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h2 class="mb-0"><i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?></h2>
            <small class="text-muted"><?php echo t('welcome_back'); ?>, <?php echo htmlspecialchars($user['full_name']); ?>!</small>
        </div>
        <span class="badge bg-info"><i class="fas fa-user"></i> <?php echo t('customer'); ?></span>
    </div>
    
    <!-- Customer Stats -->
    <div class="row mb-4">
        <div class="col-6 col-md-3 mb-3">
            <div class="card p-3 stat-card">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="mb-1"><?php echo t('account_balance'); ?></h6>
                        <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($user['balance'], 0); ?></h4>
                    </div>
                    <i class="fas fa-wallet" style="font-size:1.5rem;opacity:0.7;"></i>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card p-3 stat-card success">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="mb-1"><?php echo t('total_spent'); ?></h6>
                        <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($totalSpent, 0); ?></h4>
                    </div>
                    <i class="fas fa-shopping-bag" style="font-size:1.5rem;opacity:0.7;"></i>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card p-3 stat-card info">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="mb-1"><?php echo t('total_sessions'); ?></h6>
                        <h4 class="fw-bold mb-0"><?php echo number_format($totalSessions); ?></h4>
                    </div>
                    <i class="fas fa-clock" style="font-size:1.5rem;opacity:0.7;"></i>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card p-3 stat-card warning">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="mb-1"><?php echo t('active_sessions'); ?></h6>
                        <h4 class="fw-bold mb-0"><?php echo count($customerSessions); ?></h4>
                    </div>
                    <i class="fas fa-wifi" style="font-size:1.5rem;opacity:0.7;"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Active Sessions -->
    <?php if (count($customerSessions) > 0): ?>
    <div class="card mb-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-wifi text-success"></i> <?php echo t('active_sessions'); ?></h5>
            <span class="badge bg-success"><?php echo count($customerSessions); ?> <?php echo t('active'); ?></span>
        </div>
        <div class="card-body">
            <?php foreach ($customerSessions as $cs): 
                $minutesRemaining = intval($cs['minutes_remaining'] ?? 0);
                $timeClass = $minutesRemaining <= 0 ? 'critical' : ($minutesRemaining <= 5 ? 'critical' : ($minutesRemaining <= 15 ? 'warning' : 'good'));
            ?>
            <div class="session-card mb-2">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <div class="fw-semibold">
                            <i class="fas fa-wifi text-success"></i>
                            <?php echo htmlspecialchars($cs['router_name'] ?? 'WiFi'); ?>
                            <?php if ($cs['ssid']): ?>
                            <small class="text-muted">(<?php echo htmlspecialchars($cs['ssid']); ?>)</small>
                            <?php endif; ?>
                        </div>
                        <div class="text-muted small mt-1">
                            <?php if ($cs['voucher_code']): ?>
                            <i class="fas fa-ticket-alt"></i> <?php echo htmlspecialchars($cs['voucher_code']); ?> |
                            <?php endif; ?>
                            <?php if ($cs['package_name']): ?>
                            <i class="fas fa-box"></i> <?php echo htmlspecialchars($cs['package_name']); ?>
                            <?php endif; ?>
                        </div>
                        <div class="text-muted small mt-1">
                            <i class="fas fa-play"></i> <?php echo date('H:i', strtotime($cs['session_start'])); ?>
                            &rarr;
                            <i class="fas fa-stop"></i> <?php echo date('H:i', strtotime($cs['session_end'])); ?>
                        </div>
                    </div>
                    <div class="text-end">
                        <div class="time-remaining <?php echo $timeClass; ?>">
                            <?php if ($minutesRemaining <= 0): ?>
                                <i class="fas fa-hourglass-end"></i> <?php echo t('expired'); ?>
                            <?php else: ?>
                                <i class="fas fa-hourglass-half"></i> <?php echo $minutesRemaining; ?>m
                            <?php endif; ?>
                        </div>
                        <small class="text-muted"><?php echo t('time_remaining'); ?></small>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Quick Actions -->
    <h5 class="mb-3"><?php echo t('quick_actions'); ?></h5>
    <div class="row mb-4">
        <div class="col-6 col-md-3 mb-3">
            <a href="?page=packages" class="text-decoration-none">
                <div class="card p-3 text-center quick-action-card h-100">
                    <i class="fas fa-box text-primary mb-2"></i>
                    <h6 class="mb-0"><?php echo t('packages'); ?></h6>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <a href="?page=voucher" class="text-decoration-none">
                <div class="card p-3 text-center quick-action-card h-100">
                    <i class="fas fa-ticket-alt text-success mb-2"></i>
                    <h6 class="mb-0"><?php echo t('buy_voucher'); ?></h6>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <a href="?page=connect" class="text-decoration-none">
                <div class="card p-3 text-center quick-action-card h-100">
                    <i class="fas fa-wifi text-warning mb-2"></i>
                    <h6 class="mb-0"><?php echo t('connect'); ?></h6>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <a href="?page=profile" class="text-decoration-none">
                <div class="card p-3 text-center quick-action-card h-100">
                    <i class="fas fa-user text-danger mb-2"></i>
                    <h6 class="mb-0"><?php echo t('profile'); ?></h6>
                </div>
            </a>
        </div>
    </div>
    
    <!-- Recent Transactions -->
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-clock-rotate-left"></i> <?php echo t('recent_transactions'); ?></h5>
            <a href="?page=transactions" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
        </div>
        <div class="card-body">
            <?php if (count($transactions) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mobile-card-table mb-0">
                        <thead>
                            <tr>
                                <th><?php echo t('reference'); ?></th>
                                <th><?php echo t('type'); ?></th>
                                <th><?php echo t('amount'); ?></th>
                                <th><?php echo t('status'); ?></th>
                                <th><?php echo t('date'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($transactions, 0, 10) as $txn): ?>
                            <tr>
                                <td data-label="<?php echo t('reference'); ?>"><code><?php echo htmlspecialchars($txn['transaction_ref']); ?></code></td>
                                <td data-label="<?php echo t('type'); ?>" class="text-capitalize"><?php echo $txn['type']; ?></td>
                                <td data-label="<?php echo t('amount'); ?>"><?php echo CURRENCY . ' ' . number_format($txn['amount'], 2); ?></td>
                                <td data-label="<?php echo t('status'); ?>">
                                    <span class="badge bg-<?php echo $txn['status'] === 'completed' ? 'success' : ($txn['status'] === 'pending' ? 'warning' : 'danger'); ?>">
                                        <?php echo $txn['status']; ?>
                                    </span>
                                </td>
                                <td data-label="<?php echo t('date'); ?>"><?php echo date('d M Y H:i', strtotime($txn['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-receipt"></i>
                    <p><?php echo t('no_transactions'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php
    return; // End customer dashboard
}

// ============================================
// SELLER DASHBOARD
// ============================================

$userId = $_SESSION['user_id'];

// Get seller statistics
$stats = $transaction->getSellerStats($userId);

// Get routers
$routers = $router->getRouters($userId);
$onlineRouters = 0;
$offlineRouters = 0;
foreach ($routers as $r) {
    if ($r['status'] === 'online') $onlineRouters++;
    else $offlineRouters++;
}

// Get voucher counts
$totalVouchers = 0;
$availableVouchers = 0;
$usedVouchers = 0;
$soldVouchers = 0;
try {
    $res = $conn->query("SELECT COUNT(*) as total FROM vouchers WHERE seller_id = $userId");
    if ($res) $totalVouchers = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM vouchers WHERE seller_id = $userId AND status = 'available'");
    if ($res) $availableVouchers = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM vouchers WHERE seller_id = $userId AND status = 'used'");
    if ($res) $usedVouchers = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM vouchers WHERE seller_id = $userId AND status = 'sold'");
    if ($res) $soldVouchers = $res->fetch_assoc()['total'];
} catch (Throwable $e) {}

// Get recent sales from payments table
$recentSales = [];
try {
    $res = $conn->query("
        SELECT p.*, v.voucher_code, pkg.name as package_name, r.device_name as router_name
        FROM payments p 
        LEFT JOIN vouchers v ON p.voucher_id = v.id 
        LEFT JOIN packages pkg ON v.package_id = pkg.id
        LEFT JOIN routers r ON pkg.router_id = r.id
        WHERE p.seller_id = $userId AND p.payment_status = 'completed' 
        ORDER BY p.created_at DESC 
        LIMIT 5
    ");
    if ($res) $recentSales = $res->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// Get recent activity
$activities = [];
try {
    $res = $conn->query("SELECT * FROM activity_logs WHERE user_id = $userId ORDER BY created_at DESC LIMIT 5");
    if ($res) $activities = $res->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// Get session stats
$sessionStats = $sessionManager->getSessionStats($userId);

// Get today's revenue breakdown
$todayRevenue = 0;
$todayCount = 0;
try {
    $res = $conn->query("SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as cnt FROM payments WHERE seller_id = $userId AND payment_status = 'completed' AND DATE(created_at) = CURDATE()");
    if ($res) {
        $row = $res->fetch_assoc();
        $todayRevenue = $row['total'];
        $todayCount = $row['cnt'];
    }
} catch (Throwable $e) {}

// Get this week's revenue
$weekRevenue = 0;
try {
    $res = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE seller_id = $userId AND payment_status = 'completed' AND YEARWEEK(created_at) = YEARWEEK(CURDATE())");
    if ($res) $weekRevenue = $res->fetch_assoc()['total'];
} catch (Throwable $e) {}

// Get pending withdrawals count
$pendingWithdrawals = 0;
try {
    $res = $conn->query("SELECT COUNT(*) as total FROM withdrawals WHERE user_id = $userId AND status IN ('pending', 'processing')");
    if ($res) $pendingWithdrawals = $res->fetch_assoc()['total'];
} catch (Throwable $e) {}

// Get last 7 days revenue for chart
$chartData = [];
$chartLabels = [];
$salesMap = [];
try {
    $res = $conn->query("
        SELECT DATE(created_at) as sale_date, COALESCE(SUM(amount), 0) as revenue
        FROM payments
        WHERE seller_id = $userId AND payment_status = 'completed'
        AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
    ");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $salesMap[$row['sale_date']] = $row['revenue'];
        }
    }
} catch (Throwable $e) {}

for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chartLabels[] = date('D', strtotime($date));
    $chartData[] = $salesMap[$date] ?? 0;
}
$maxChartValue = max(max($chartData), 1);

// Get top selling packages
$topPackages = [];
try {
    $res = $conn->query("
        SELECT p.id, p.name, p.price, COUNT(pay.id) as sales_count, COALESCE(SUM(pay.amount), 0) as revenue
        FROM packages p
        LEFT JOIN vouchers v ON v.package_id = p.id
        LEFT JOIN payments pay ON pay.voucher_id = v.id AND pay.payment_status = 'completed'
        WHERE p.seller_id = $userId
        GROUP BY p.id
        ORDER BY revenue DESC
        LIMIT 5
    ");
    if ($res) $topPackages = $res->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// Get total customers (unique phone numbers)
$totalCustomers = 0;
try {
    $res = $conn->query("SELECT COUNT(DISTINCT phone_number) as total FROM payments WHERE seller_id = $userId AND phone_number IS NOT NULL AND payment_status = 'completed'");
    if ($res) $totalCustomers = $res->fetch_assoc()['total'];
} catch (Throwable $e) {}

// Get unread notifications and messages
$unreadNotifs = $notificationManager->getUnreadCount($userId);
$unreadMsgs = $messageManager->getUnreadCount($userId);

?>

<!-- ============================================ -->
<!-- SELLER DASHBOARD HEADER                     -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-tachometer-alt"></i> <?php echo t('seller_dashboard'); ?></h2>
        <small class="text-muted"><?php echo t('welcome_back'); ?>, <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>!</small>
    </div>
    <div class="d-flex gap-2">
        <span class="badge bg-primary"><i class="fas fa-store"></i> <?php echo t('seller'); ?></span>
        <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'warning'; ?>">
            <i class="fas fa-circle"></i> <?php echo t($user['status']); ?>
        </span>
    </div>
</div>

<!-- ============================================ -->
<!-- OFFLINE ROUTER ALERT                        -->
<!-- ============================================ -->
<?php if ($sessionStats['offline_router_sessions'] > 0): ?>
<div class="alert alert-warning d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">
    <div>
        <i class="fas fa-exclamation-triangle"></i>
        <strong><?php echo $sessionStats['offline_router_sessions']; ?> session(s) on offline routers</strong>
        <br><small><?php echo t('offline_router_notice'); ?></small>
    </div>
    <a href="?page=sessions&filter=offline" class="btn btn-warning btn-sm">
        <i class="fas fa-clock"></i> <?php echo t('adjust_time'); ?>
    </a>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- MAIN STATS CARDS                            -->
<!-- ============================================ -->
<div class="dashboard-grid mb-4">
    <!-- Total Earnings -->
    <div class="card p-3 stat-card">
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <h6 class="mb-1"><?php echo t('total_earnings'); ?></h6>
                <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($stats['total_earnings'], 0); ?></h4>
                <small style="opacity:0.85;">
                    <?php echo number_format($stats['total_sales']); ?> <?php echo t('sales'); ?>
                </small>
            </div>
            <i class="fas fa-money-bill-wave" style="font-size:1.5rem;opacity:0.7;"></i>
        </div>
    </div>
    
    <!-- Today's Earnings -->
    <div class="card p-3 stat-card success">
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <h6 class="mb-1"><?php echo t('today_earnings'); ?></h6>
                <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($todayRevenue, 0); ?></h4>
                <small style="opacity:0.85;"><?php echo $todayCount; ?> <?php echo t('sales'); ?></small>
            </div>
            <i class="fas fa-chart-line" style="font-size:1.5rem;opacity:0.7;"></i>
        </div>
    </div>
    
    <!-- This Week -->
    <div class="card p-3 stat-card info">
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <h6 class="mb-1"><?php echo t('this_week'); ?></h6>
                <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($weekRevenue, 0); ?></h4>
                <small style="opacity:0.85;"><?php echo t('week'); ?> <?php echo t('revenue'); ?></small>
            </div>
            <i class="fas fa-calendar-week" style="font-size:1.5rem;opacity:0.7;"></i>
        </div>
    </div>
    
    <!-- Active Sessions -->
    <div class="card p-3 stat-card warning">
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <h6 class="mb-1"><?php echo t('active_sessions'); ?></h6>
                <h4 class="fw-bold mb-0"><?php echo number_format($sessionStats['active_sessions']); ?></h4>
                <small style="opacity:0.85;">
                    <?php echo $sessionStats['today_sessions']; ?> <?php echo t('today'); ?>
                </small>
            </div>
            <i class="fas fa-clock" style="font-size:1.5rem;opacity:0.7;"></i>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- SECONDARY STATS                             -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-users text-primary"></i> <?php echo t('total_customers'); ?></div>
            <div class="metric-value"><?php echo number_format($totalCustomers); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-wifi text-success"></i> <?php echo t('total_routers'); ?></div>
            <div class="metric-value"><?php echo count($routers); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-ticket-alt text-warning"></i> <?php echo t('total_vouchers'); ?></div>
            <div class="metric-value"><?php echo number_format($totalVouchers); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-money-bill-wave text-info"></i> <?php echo t('available_balance'); ?></div>
            <div class="metric-value"><?php echo CURRENCY . ' ' . number_format($user['balance'], 0); ?></div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- PENDING WITHDRAWALS ALERT                   -->
<!-- ============================================ -->
<?php if ($pendingWithdrawals > 0): ?>
<div class="alert alert-info d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">
    <div>
        <i class="fas fa-clock"></i>
        <strong><?php echo $pendingWithdrawals; ?> <?php echo t('pending_withdrawals'); ?></strong>
        <br><small><?php echo t('withdrawal_pending_desc'); ?></small>
    </div>
    <a href="?page=withdraw" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i> <?php echo t('view_details'); ?>
    </a>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- REVENUE CHART & ROUTER STATUS               -->
<!-- ============================================ -->
<div class="row mb-4">
    <!-- Revenue Chart -->
    <div class="col-lg-7 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-chart-line text-primary"></i> <?php echo t('revenue_chart'); ?> (<?php echo t('last_7_days'); ?>)</h6>
                <span class="badge bg-success"><?php echo CURRENCY . ' ' . number_format(array_sum($chartData), 0); ?></span>
            </div>
            <div class="card-body">
                <?php if (array_sum($chartData) > 0): ?>
                    <div class="chart-bar" style="height: 150px;">
                        <?php foreach ($chartData as $i => $val): ?>
                            <div class="bar" style="height: <?php echo max(($val / $maxChartValue) * 100, 2); ?>%;" 
                                 title="<?php echo $chartLabels[$i] . ': ' . CURRENCY . ' ' . number_format($val, 0); ?>">
                                <span class="bar-label"><?php echo $chartLabels[$i]; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="text-center mt-4 text-muted small"><?php echo t('revenue'); ?> (<?php echo CURRENCY; ?>)</div>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <i class="fas fa-chart-line"></i>
                        <p><?php echo t('no_analytics_data'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Router Status -->
    <div class="col-lg-5 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-network-wired text-success"></i> <?php echo t('router_status'); ?></h6>
                <a href="?page=connect" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
            </div>
            <div class="card-body" id="routerStatusContainer">
                <!-- Online -->
                <div class="d-flex justify-content-between mb-2">
                    <span><span class="router-status-indicator online"></span><?php echo t('online'); ?></span>
                    <span class="text-success fw-bold" id="onlineRouterCount"><?php echo $onlineRouters; ?></span>
                </div>
                <div class="progress mb-3">
                    <?php $total = max(count($routers), 1); ?>
                    <div class="progress-bar bg-success" id="onlineRouterBar" style="width: <?php echo ($onlineRouters / $total) * 100; ?>%"></div>
                </div>
                
                <!-- Offline -->
                <div class="d-flex justify-content-between mb-2">
                    <span><span class="router-status-indicator offline"></span><?php echo t('offline'); ?></span>
                    <span class="text-danger fw-bold" id="offlineRouterCount"><?php echo $offlineRouters; ?></span>
                </div>
                <div class="progress mb-3">
                    <div class="progress-bar bg-danger" id="offlineRouterBar" style="width: <?php echo ($offlineRouters / $total) * 100; ?>%"></div>
                </div>
                
                <!-- Total -->
                <div class="d-flex justify-content-between">
                    <span><i class="fas fa-wifi text-primary"></i> <?php echo t('total_routers'); ?></span>
                    <span class="fw-bold" id="totalRouterCount"><?php echo count($routers); ?></span>
                </div>
                
                <hr style="border-color:var(--border-color);">
                
                <!-- Voucher Breakdown -->
                <div class="d-flex justify-content-between mb-2">
                    <span><i class="fas fa-ticket-alt text-success"></i> <?php echo t('available_vouchers'); ?></span>
                    <span class="text-success fw-bold"><?php echo $availableVouchers; ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span><i class="fas fa-ticket-alt text-warning"></i> <?php echo t('sold_vouchers'); ?></span>
                    <span class="text-warning fw-bold"><?php echo $soldVouchers; ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span><i class="fas fa-check-circle text-info"></i> <?php echo t('used_vouchers'); ?></span>
                    <span class="text-info fw-bold"><?php echo $usedVouchers; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- QUICK ACTIONS                               -->
<!-- ============================================ -->
<h5 class="mb-3"><i class="fas fa-bolt text-warning"></i> <?php echo t('quick_actions'); ?></h5>
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=connect" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-plus-circle text-primary mb-2"></i>
                <h6 class="mb-0"><?php echo t('add_new_router'); ?></h6>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=packages" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-box text-success mb-2"></i>
                <h6 class="mb-0"><?php echo t('add_new_package'); ?></h6>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=sessions" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-clock text-warning mb-2"></i>
                <h6 class="mb-0"><?php echo t('session_manager'); ?></h6>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=withdraw" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-money-bill-wave text-danger mb-2"></i>
                <h6 class="mb-0"><?php echo t('withdraw'); ?></h6>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=analytics" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-chart-bar text-info mb-2"></i>
                <h6 class="mb-0"><?php echo t('analytics'); ?></h6>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=customers" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-users text-primary mb-2"></i>
                <h6 class="mb-0"><?php echo t('customers'); ?></h6>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=transactions" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-receipt text-success mb-2"></i>
                <h6 class="mb-0"><?php echo t('transactions'); ?></h6>
            </div>
        </a>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <a href="?page=reports" class="text-decoration-none">
            <div class="card p-3 text-center quick-action-card h-100">
                <i class="fas fa-file-alt text-warning mb-2"></i>
                <h6 class="mb-0"><?php echo t('reports'); ?></h6>
            </div>
        </a>
    </div>
</div>

<!-- ============================================ -->
<!-- RECENT SALES & TOP PACKAGES                 -->
<!-- ============================================ -->
<div class="row mb-4">
    <!-- Recent Sales -->
    <div class="col-lg-7 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-shopping-cart text-success"></i> <?php echo t('recent_sales'); ?></h6>
                <a href="?page=transactions" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
            </div>
            <div class="card-body p-0">
                <?php if (count($recentSales) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mobile-card-table mb-0">
                            <thead>
                                <tr>
                                    <th><?php echo t('voucher_code'); ?></th>
                                    <th><?php echo t('package'); ?></th>
                                    <th><?php echo t('amount'); ?></th>
                                    <th><?php echo t('date'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentSales as $s): ?>
                                <tr>
                                    <td data-label="<?php echo t('voucher_code'); ?>">
                                        <?php if ($s['voucher_code']): ?>
                                            <code style="font-size:0.85rem;"><?php echo htmlspecialchars($s['voucher_code']); ?></code>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('package'); ?>">
                                        <?php echo htmlspecialchars($s['package_name'] ?? 'WiFi'); ?>
                                        <?php if (!empty($s['router_name'])): ?>
                                        <br><small class="text-muted"><i class="fas fa-wifi"></i> <?php echo htmlspecialchars($s['router_name']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('amount'); ?>">
                                        <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($s['amount'], 0); ?></strong>
                                    </td>
                                    <td data-label="<?php echo t('date'); ?>">
                                        <small><?php echo date('d M H:i', strtotime($s['created_at'])); ?></small>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <i class="fas fa-shopping-cart"></i>
                        <p><?php echo t('no_sales'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Top Packages -->
    <div class="col-lg-5 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-crown text-warning"></i> <?php echo t('top_packages'); ?></h6>
                <a href="?page=packages" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
            </div>
            <div class="card-body">
                <?php if (count($topPackages) > 0): ?>
                    <?php foreach ($topPackages as $tp): ?>
                    <div class="stat-row">
                        <div>
                            <div class="fw-semibold"><?php echo htmlspecialchars($tp['name']); ?></div>
                            <small class="text-muted"><?php echo $tp['sales_count']; ?> <?php echo t('sales'); ?></small>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold text-success"><?php echo CURRENCY . ' ' . number_format($tp['revenue'], 0); ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <i class="fas fa-crown"></i>
                        <p><?php echo t('no_data'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- RECENT ACTIVITY                             -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h6 class="mb-0"><i class="fas fa-history text-info"></i> <?php echo t('recent_activity'); ?></h6>
        <a href="?page=audit-log" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
    </div>
    <div class="card-body">
        <?php if (count($activities) > 0): ?>
            <?php foreach ($activities as $a): ?>
            <div class="activity-item">
                <div class="activity-icon bg-<?php echo $a['action'] === 'login' ? 'success' : 'primary'; ?> bg-opacity-10 text-<?php echo $a['action'] === 'login' ? 'success' : 'primary'; ?>">
                    <i class="fas fa-<?php 
                        echo $a['action'] === 'login' ? 'sign-in-alt' : 
                            ($a['action'] === 'register' ? 'user-plus' : 
                            ($a['action'] === 'logout' ? 'sign-out-alt' : 'bolt')); 
                    ?>"></i>
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold"><?php echo htmlspecialchars($a['description']); ?></div>
                    <small class="text-muted">
                        <?php 
                        $diff = time() - strtotime($a['created_at']);
                        if ($diff < 60) echo t('just_now');
                        elseif ($diff < 3600) echo floor($diff / 60) . ' ' . t('minutes_ago');
                        elseif ($diff < 86400) echo floor($diff / 3600) . ' ' . t('hours_ago');
                        else echo floor($diff / 86400) . ' ' . t('days_ago');
                        ?>
                    </small>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state py-4">
                <i class="fas fa-bolt"></i>
                <p><?php echo t('no_activity'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================ -->
<!-- USEFUL LINKS                                -->
<!-- ============================================ -->
<div class="card">
    <div class="card-header bg-white">
        <h6 class="mb-0"><i class="fas fa-th-large text-primary"></i> <?php echo t('quick_links'); ?></h6>
    </div>
    <div class="card-body">
        <div class="row g-2">
            <div class="col-6 col-md-3">
                <a href="?page=messages" class="btn btn-outline-primary w-100 position-relative">
                    <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    <?php if ($unreadMsgs > 0): ?>
                    <span class="badge bg-danger position-absolute" style="top:-5px;right:-5px;"><?php echo $unreadMsgs; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="?page=notifications" class="btn btn-outline-info w-100 position-relative">
                    <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    <?php if ($unreadNotifs > 0): ?>
                    <span class="badge bg-danger position-absolute" style="top:-5px;right:-5px;"><?php echo $unreadNotifs; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="?page=support" class="btn btn-outline-warning w-100">
                    <i class="fas fa-headset"></i> <?php echo t('support'); ?>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="?page=help" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-question-circle"></i> <?php echo t('help_center'); ?>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="?page=referrals" class="btn btn-outline-success w-100">
                    <i class="fas fa-user-plus"></i> <?php echo t('referrals'); ?>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="?page=promo-codes" class="btn btn-outline-info w-100">
                    <i class="fas fa-tags"></i> <?php echo t('promo_codes'); ?>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="?page=invoices" class="btn btn-outline-primary w-100">
                    <i class="fas fa-file-invoice"></i> <?php echo t('invoices'); ?>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="?page=profile" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- AUTO-REFRESH SCRIPT                         -->
<!-- ============================================ -->
<script>
// Refresh router status every 30 seconds
(function() {
    if (window.routerPolling) {
        // Already set up by main index.php
        return;
    }
    
    function refreshRouterStatus() {
        fetch('?ajax=get_router_status&page=dashboard')
            .then(res => res.json())
            .then(data => {
                if (data.success && data.summary) {
                    const onlineCount = document.getElementById('onlineRouterCount');
                    const offlineCount = document.getElementById('offlineRouterCount');
                    const totalCount = document.getElementById('totalRouterCount');
                    const onlineBar = document.getElementById('onlineRouterBar');
                    const offlineBar = document.getElementById('offlineRouterBar');
                    
                    if (onlineCount) onlineCount.textContent = data.summary.online;
                    if (offlineCount) offlineCount.textContent = data.summary.offline;
                    if (totalCount) totalCount.textContent = data.summary.total;
                    if (onlineBar && data.summary.total > 0) 
                        onlineBar.style.width = (data.summary.online / data.summary.total) * 100 + '%';
                    if (offlineBar && data.summary.total > 0) 
                        offlineBar.style.width = (data.summary.offline / data.summary.total) * 100 + '%';
                }
            })
            .catch(() => {});
    }
    
    setInterval(refreshRouterStatus, 30000);
})();
</script>