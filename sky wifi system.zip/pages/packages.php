<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Packages Management Page - Loaded from external file
 * 
 * Seller Packages Management: Create, edit, delete, generate vouchers
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE ADD PACKAGE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_package'])) {
    $routerId = intval($_POST['router_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $duration = intval($_POST['duration_minutes'] ?? 0);
    $dataLimit = intval($_POST['data_limit_mb'] ?? 0);
    $speedLimit = intval($_POST['speed_limit_mbps'] ?? 5);
    $maxDevices = intval($_POST['max_devices'] ?? 1);
    $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
    $tags = trim($_POST['tags'] ?? '');

    // Validate router belongs to this seller
    $routerCheck = $conn->prepare("SELECT id FROM routers WHERE id = ? AND user_id = ?");
    $routerCheck->bind_param("ii", $routerId, $userId);
    $routerCheck->execute();
    $routerValid = $routerCheck->get_result()->num_rows > 0;

    if (!$routerValid) {
        $msg = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Invalid router selected</div>';
    } elseif (!$routerId || !$name || $price <= 0 || $duration <= 0) {
        $msg = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Please fill in all required fields</div>';
    } else {
        $stmt = $conn->prepare("INSERT INTO packages (router_id, seller_id, name, description, price, duration_minutes, data_limit_mb, speed_limit_mbps, max_devices, is_featured, tags) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iissdiiiiis", $routerId, $userId, $name, $description, $price, $duration, $dataLimit, $speedLimit, $maxDevices, $isFeatured, $tags);
        if ($stmt->execute()) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Package created successfully!</div>';
            redirectTo('?page=packages');
        } else {
            $msg = '<div class="alert alert-danger">Failed to create package: ' . htmlspecialchars($conn->error) . '</div>';
        }
    }
}

// ============================================
// HANDLE EDIT PACKAGE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_package'])) {
    $packageId = intval($_POST['package_id'] ?? 0);
    $routerId = intval($_POST['router_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $duration = intval($_POST['duration_minutes'] ?? 0);
    $dataLimit = intval($_POST['data_limit_mb'] ?? 0);
    $speedLimit = intval($_POST['speed_limit_mbps'] ?? 5);
    $maxDevices = intval($_POST['max_devices'] ?? 1);
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
    $tags = trim($_POST['tags'] ?? '');

    if ($packageId && $name && $price > 0 && $duration > 0) {
        $stmt = $conn->prepare("UPDATE packages SET router_id = ?, name = ?, description = ?, price = ?, duration_minutes = ?, data_limit_mb = ?, speed_limit_mbps = ?, max_devices = ?, is_active = ?, is_featured = ?, tags = ? WHERE id = ? AND seller_id = ?");
        $stmt->bind_param("issdiiiiiisii", $routerId, $name, $description, $price, $duration, $dataLimit, $speedLimit, $maxDevices, $isActive, $isFeatured, $tags, $packageId, $userId);
        if ($stmt->execute()) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Package updated successfully!</div>';
            redirectTo('?page=packages');
        } else {
            $msg = '<div class="alert alert-danger">Failed to update package: ' . htmlspecialchars($conn->error) . '</div>';
        }
    } else {
        $msg = '<div class="alert alert-warning">Please fill in all required fields</div>';
    }
}

// ============================================
// HANDLE TOGGLE PACKAGE STATUS
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_package'])) {
    $packageId = intval($_POST['package_id'] ?? 0);
    if ($packageId) {
        $stmt = $conn->prepare("UPDATE packages SET is_active = NOT is_active WHERE id = ? AND seller_id = ?");
        $stmt->bind_param("ii", $packageId, $userId);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Package status updated!</div>';
        }
    }
}

// ============================================
// HANDLE DELETE PACKAGE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_package'])) {
    $deleteId = intval($_POST['package_id'] ?? 0);
    if ($deleteId) {
        $stmt = $conn->prepare("DELETE FROM packages WHERE id = ? AND seller_id = ?");
        $stmt->bind_param("ii", $deleteId, $userId);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Package deleted successfully!</div>';
            redirectTo('?page=packages');
        } else {
            $msg = '<div class="alert alert-danger">Failed to delete package</div>';
        }
    }
}

// ============================================
// HANDLE DUPLICATE PACKAGE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['duplicate_package'])) {
    $packageId = intval($_POST['package_id'] ?? 0);
    if ($packageId) {
        $stmt = $conn->prepare("SELECT * FROM packages WHERE id = ? AND seller_id = ?");
        $stmt->bind_param("ii", $packageId, $userId);
        $stmt->execute();
        $orig = $stmt->get_result()->fetch_assoc();
        
        if ($orig) {
            $newName = $orig['name'] . ' (Copy)';
            $stmt = $conn->prepare("INSERT INTO packages (router_id, seller_id, name, description, price, duration_minutes, data_limit_mb, speed_limit_mbps, max_devices, is_active, is_featured, tags) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?)");
            $stmt->bind_param("iissdiiii s", $orig['router_id'], $userId, $newName, $orig['description'], $orig['price'], $orig['duration_minutes'], $orig['data_limit_mb'], $orig['speed_limit_mbps'], $orig['max_devices'], $orig['tags']);
            if ($stmt->execute()) {
                $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Package duplicated successfully!</div>';
                redirectTo('?page=packages');
            }
        }
    }
}

// ============================================
// HANDLE GENERATE VOUCHERS
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_vouchers'])) {
    $packageId = intval($_POST['package_id'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 10);
    
    if ($packageId && $quantity > 0 && $quantity <= 1000) {
        $result = $voucher->createVouchers($packageId, $userId, $quantity);
        if ($result['success']) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Generated ' . count($result['vouchers']) . ' vouchers successfully!</div>';
            redirectTo('?page=packages');
        } else {
            $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
        }
    } else {
        $msg = '<div class="alert alert-warning">Invalid quantity (1-1000)</div>';
    }
}

// ============================================
// FETCH DATA
// ============================================

// Get routers for this seller
$routers = $router->getRouters($userId);

// Get all packages
$packages = [];
try {
    $stmt = $conn->prepare("
        SELECT p.*, 
               r.device_name as router_name, 
               r.ssid,
               (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id) as voucher_count,
               (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = 'available') as available_vouchers,
               (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = 'used') as used_vouchers,
               (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = 'sold') as sold_vouchers,
               (SELECT COALESCE(SUM(amount), 0) FROM payments WHERE voucher_id IN (SELECT id FROM vouchers WHERE package_id = p.id) AND payment_status = 'completed') as total_revenue
        FROM packages p 
        JOIN routers r ON p.router_id = r.id 
        WHERE p.seller_id = ? 
        ORDER BY p.created_at DESC
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $packages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {
    $packages = [];
}

// Package statistics
$totalPackages = count($packages);
$activePackages = 0;
$totalVouchers = 0;
$totalRevenue = 0;
foreach ($packages as $p) {
    if ($p['is_active']) $activePackages++;
    $totalVouchers += intval($p['voucher_count']);
    $totalRevenue += floatval($p['total_revenue']);
}

// Filter by router if requested
$filterRouterId = isset($_GET['router']) ? intval($_GET['router']) : 0;
if ($filterRouterId) {
    $packages = array_filter($packages, function($p) use ($filterRouterId) {
        return $p['router_id'] == $filterRouterId;
    });
    $packages = array_values($packages);
}

?>

<!-- ============================================ -->
<!-- PACKAGES PAGE HEADER                        -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-box"></i> <?php echo t('manage_packages'); ?></h2>
        <small class="text-muted">Create and manage your WiFi packages & vouchers</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <?php if (count($routers) > 0): ?>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addPackageModal">
            <i class="fas fa-plus-circle"></i> <?php echo t('create_package'); ?>
        </button>
        <?php endif; ?>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- NO ROUTERS WARNING                          -->
<!-- ============================================ -->
<?php if (count($routers) === 0): ?>
<div class="alert alert-warning mb-4">
    <i class="fas fa-exclamation-triangle"></i>
    <strong>You need to add a router first!</strong>
    <p class="mb-2 mt-1">Packages are tied to specific routers. Add a router before creating packages.</p>
    <a href="?page=connect" class="btn btn-warning btn-sm">
        <i class="fas fa-plus-circle"></i> <?php echo t('add_router'); ?>
    </a>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- STATS OVERVIEW                              -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-box text-primary"></i> <?php echo t('total_packages'); ?></div>
            <div class="metric-value"><?php echo number_format($totalPackages); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-check-circle text-success"></i> <?php echo t('active'); ?></div>
            <div class="metric-value text-success"><?php echo number_format($activePackages); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-ticket-alt text-warning"></i> <?php echo t('total_vouchers'); ?></div>
            <div class="metric-value text-warning"><?php echo number_format($totalVouchers); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-money-bill-wave text-info"></i> <?php echo t('total_revenue'); ?></div>
            <div class="metric-value text-info" style="font-size:1.3rem;"><?php echo CURRENCY . ' ' . number_format($totalRevenue, 0); ?></div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- FILTER BY ROUTER                            -->
<!-- ============================================ -->
<?php if (count($routers) > 1): ?>
<div class="card mb-4">
    <div class="card-body py-2">
        <form method="GET" class="row g-2 align-items-center">
            <input type="hidden" name="page" value="packages">
            <div class="col-md-6">
                <label class="form-label small mb-1"><i class="fas fa-filter"></i> <?php echo t('filter_by'); ?> <?php echo t('router'); ?></label>
                <select name="router" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="0"><?php echo t('all_routers'); ?> (<?php echo count($packages); ?>)</option>
                    <?php foreach ($routers as $r): 
                        // Count packages for this router
                        $routerPkgCount = 0;
                        foreach ($packages as $p) if ($p['router_id'] == $r['id']) $routerPkgCount++;
                    ?>
                    <option value="<?php echo $r['id']; ?>" <?php echo $filterRouterId == $r['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($r['device_name']); ?> 
                        <?php if ($r['ssid']): ?>(<?php echo htmlspecialchars($r['ssid']); ?>)<?php endif; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($filterRouterId): ?>
            <div class="col-md-3">
                <a href="?page=packages" class="btn btn-sm btn-outline-secondary mt-3">
                    <i class="fas fa-times"></i> <?php echo t('clear_filters'); ?>
                </a>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- PACKAGES LIST                               -->
<!-- ============================================ -->
<?php if (count($packages) > 0): ?>
    <div class="row">
        <?php foreach ($packages as $p): 
            $isActive = $p['is_active'];
            $durationText = '';
            if ($p['duration_minutes'] >= 1440) {
                $durationText = round($p['duration_minutes'] / 1440, 1) . ' ' . t('days');
            } elseif ($p['duration_minutes'] >= 60) {
                $durationText = round($p['duration_minutes'] / 60, 1) . ' ' . t('hours');
            } else {
                $durationText = $p['duration_minutes'] . ' ' . t('minutes');
            }
        ?>
        <div class="col-md-6 col-lg-4 mb-3">
            <div class="card h-100 <?php echo !$isActive ? 'opacity-75' : ''; ?>">
                <!-- Featured Badge -->
                <?php if ($p['is_featured']): ?>
                <div style="position:absolute;top:0.5rem;right:0.5rem;z-index:2;">
                    <span class="badge bg-warning text-dark"><i class="fas fa-star"></i> Featured</span>
                </div>
                <?php endif; ?>
                
                <div class="card-header bg-white d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="mb-1">
                            <i class="fas fa-box text-primary"></i>
                            <?php echo htmlspecialchars($p['name']); ?>
                        </h6>
                        <small class="text-muted">
                            <i class="fas fa-wifi"></i>
                            <?php echo htmlspecialchars($p['router_name']); ?>
                        </small>
                    </div>
                    <span class="badge bg-<?php echo $isActive ? 'success' : 'secondary'; ?>">
                        <?php echo $isActive ? t('active') : t('inactive'); ?>
                    </span>
                </div>
                
                <div class="card-body">
                    <!-- Price -->
                    <div class="text-center mb-3">
                        <div class="metric-value" style="font-size:2rem;color:var(--primary);">
                            <?php echo CURRENCY . ' ' . number_format($p['price'], 0); ?>
                        </div>
                        <small class="text-muted">per voucher</small>
                    </div>
                    
                    <!-- Description -->
                    <?php if ($p['description']): ?>
                    <p class="text-muted small mb-3"><?php echo htmlspecialchars($p['description']); ?></p>
                    <?php endif; ?>
                    
                    <!-- Package Details -->
                    <div class="small">
                        <div class="stat-row">
                            <span><i class="fas fa-clock text-info"></i> <?php echo t('duration'); ?></span>
                            <strong><?php echo $durationText; ?></strong>
                        </div>
                        <div class="stat-row">
                            <span><i class="fas fa-tachometer-alt text-warning"></i> <?php echo t('speed'); ?></span>
                            <strong><?php echo $p['speed_limit_mbps']; ?> Mbps</strong>
                        </div>
                        <div class="stat-row">
                            <span><i class="fas fa-database text-primary"></i> <?php echo t('data_limit'); ?></span>
                            <strong><?php echo $p['data_limit_mb'] > 0 ? $p['data_limit_mb'] . ' MB' : t('unlimited'); ?></strong>
                        </div>
                        <div class="stat-row">
                            <span><i class="fas fa-laptop text-success"></i> <?php echo t('max_devices'); ?></span>
                            <strong><?php echo $p['max_devices']; ?></strong>
                        </div>
                    </div>
                    
                    <hr style="border-color:var(--border-color);">
                    
                    <!-- Voucher Stats -->
                    <div class="row text-center mb-3">
                        <div class="col-4">
                            <div class="small text-muted"><?php echo t('available'); ?></div>
                            <div class="fw-bold text-success"><?php echo $p['available_vouchers']; ?></div>
                        </div>
                        <div class="col-4">
                            <div class="small text-muted"><?php echo t('used'); ?></div>
                            <div class="fw-bold text-primary"><?php echo $p['used_vouchers']; ?></div>
                        </div>
                        <div class="col-4">
                            <div class="small text-muted"><?php echo t('revenue'); ?></div>
                            <div class="fw-bold text-info" style="font-size:0.85rem;">
                                <?php echo CURRENCY . ' ' . number_format($p['total_revenue'], 0); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card-footer bg-white">
                    <div class="d-flex gap-1 flex-wrap">
                        <!-- Generate Vouchers -->
                        <button class="btn btn-sm btn-success flex-grow-1" 
                                data-bs-toggle="modal" data-bs-target="#genVoucherModal<?php echo $p['id']; ?>">
                            <i class="fas fa-ticket-alt"></i> <?php echo t('generate'); ?>
                        </button>
                        
                        <!-- Edit -->
                        <button class="btn btn-sm btn-outline-primary"
                                data-bs-toggle="modal" data-bs-target="#editPackageModal<?php echo $p['id']; ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        
                        <!-- Duplicate -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                            <button type="submit" name="duplicate_package" class="btn btn-sm btn-outline-info" 
                                    title="Duplicate" onclick="return confirm('Duplicate this package?');">
                                <i class="fas fa-copy"></i>
                            </button>
                        </form>
                        
                        <!-- Toggle Active -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                            <button type="submit" name="toggle_package" class="btn btn-sm btn-outline-<?php echo $isActive ? 'warning' : 'success'; ?>" 
                                    title="<?php echo $isActive ? 'Deactivate' : 'Activate'; ?>">
                                <i class="fas fa-<?php echo $isActive ? 'pause' : 'play'; ?>"></i>
                            </button>
                        </form>
                        
                        <!-- Delete -->
                        <button class="btn btn-sm btn-outline-danger"
                                data-bs-toggle="modal" data-bs-target="#deletePackageModal<?php echo $p['id']; ?>">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- ============================================ -->
        <!-- GENERATE VOUCHER MODAL                       -->
        <!-- ============================================ -->
        <div class="modal fade" id="genVoucherModal<?php echo $p['id']; ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST">
                        <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-ticket-alt text-success"></i> <?php echo t('generate_vouchers'); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="alert alert-info">
                                <strong><?php echo htmlspecialchars($p['name']); ?></strong><br>
                                <small>
                                    <i class="fas fa-money-bill-wave"></i> <?php echo CURRENCY . ' ' . number_format($p['price'], 0); ?> |
                                    <i class="fas fa-clock"></i> <?php echo $durationText; ?> |
                                    <i class="fas fa-tachometer-alt"></i> <?php echo $p['speed_limit_mbps']; ?> Mbps
                                </small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label"><?php echo t('quantity'); ?> <span class="text-danger">*</span></label>
                                <input type="number" name="quantity" class="form-control" value="10" min="1" max="1000" required>
                                <small class="text-muted">Maximum 1000 vouchers per batch</small>
                            </div>
                            <div class="alert alert-warning small mb-0">
                                <i class="fas fa-info-circle"></i> Vouchers will be valid for 30 days and can be sold to customers.
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                            <button type="submit" name="generate_vouchers" class="btn btn-success">
                                <i class="fas fa-magic"></i> <?php echo t('generate'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- ============================================ -->
        <!-- EDIT PACKAGE MODAL                           -->
        <!-- ============================================ -->
        <div class="modal fade" id="editPackageModal<?php echo $p['id']; ?>">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form method="POST">
                        <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-edit text-primary"></i> <?php echo t('edit'); ?> <?php echo htmlspecialchars($p['name']); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('router'); ?> <span class="text-danger">*</span></label>
                                    <select name="router_id" class="form-select" required>
                                        <?php foreach ($routers as $r): ?>
                                        <option value="<?php echo $r['id']; ?>" <?php echo $r['id'] == $p['router_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($r['device_name'] . ' (' . ($r['ssid'] ?: 'No SSID') . ')'); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('package_name'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($p['name']); ?>" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <label class="form-label"><?php echo t('description'); ?></label>
                                    <textarea name="description" class="form-control" rows="2"><?php echo htmlspecialchars($p['description']); ?></textarea>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('price_tzs'); ?> <span class="text-danger">*</span></label>
                                    <input type="number" name="price" class="form-control" step="0.01" min="0" value="<?php echo $p['price']; ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('duration_minutes'); ?> <span class="text-danger">*</span></label>
                                    <input type="number" name="duration_minutes" class="form-control" min="1" value="<?php echo $p['duration_minutes']; ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label"><?php echo t('data_limit'); ?></label>
                                    <input type="number" name="data_limit_mb" class="form-control" value="<?php echo $p['data_limit_mb']; ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label"><?php echo t('speed_limit'); ?></label>
                                    <input type="number" name="speed_limit_mbps" class="form-control" value="<?php echo $p['speed_limit_mbps']; ?>" min="1">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label"><?php echo t('max_devices'); ?></label>
                                    <input type="number" name="max_devices" class="form-control" value="<?php echo $p['max_devices']; ?>" min="1">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('search_tags'); ?></label>
                                    <input type="text" name="tags" class="form-control" value="<?php echo htmlspecialchars($p['tags']); ?>" placeholder="e.g., basic, cheap">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label d-block"><?php echo t('status'); ?></label>
                                    <div class="form-check form-switch d-inline-block me-3">
                                        <input class="form-check-input" type="checkbox" name="is_active" id="editIsActive<?php echo $p['id']; ?>" 
                                               <?php echo $p['is_active'] ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="editIsActive<?php echo $p['id']; ?>"><?php echo t('active'); ?></label>
                                    </div>
                                    <div class="form-check form-switch d-inline-block">
                                        <input class="form-check-input" type="checkbox" name="is_featured" id="editIsFeatured<?php echo $p['id']; ?>" 
                                               <?php echo $p['is_featured'] ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="editIsFeatured<?php echo $p['id']; ?>"><?php echo t('featured'); ?></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                            <button type="submit" name="edit_package" class="btn btn-primary">
                                <i class="fas fa-save"></i> <?php echo t('save'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- ============================================ -->
        <!-- DELETE PACKAGE MODAL                         -->
        <!-- ============================================ -->
        <div class="modal fade" id="deletePackageModal<?php echo $p['id']; ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST">
                        <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-trash text-danger"></i> <?php echo t('confirm_delete'); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to delete package <strong><?php echo htmlspecialchars($p['name']); ?></strong>?</p>
                            <div class="alert alert-warning small">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>Warning:</strong> This will permanently delete:
                                <ul class="mb-0 mt-1">
                                    <li><?php echo $p['voucher_count']; ?> vouchers</li>
                                    <li>Associated payment records</li>
                                </ul>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                            <button type="submit" name="delete_package" class="btn btn-danger">
                                <i class="fas fa-trash"></i> <?php echo t('yes_delete'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <!-- ============================================ -->
    <!-- EMPTY STATE                                  -->
    <!-- ============================================ -->
    <div class="card">
        <div class="card-body">
            <div class="empty-state py-5">
                <i class="fas fa-box"></i>
                <h5><?php echo $filterRouterId ? 'No packages for this router' : t('no_packages'); ?></h5>
                <p>Create your first WiFi package to start selling vouchers to customers.</p>
                <?php if (count($routers) > 0): ?>
                <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addPackageModal">
                    <i class="fas fa-plus-circle"></i> <?php echo t('create_package'); ?>
                </button>
                <?php else: ?>
                <a href="?page=connect" class="btn btn-warning mt-3">
                    <i class="fas fa-plus-circle"></i> Add Router First
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- ============================================ -->
<!-- ADD PACKAGE MODAL                           -->
<!-- ============================================ -->
<div class="modal fade" id="addPackageModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-box text-primary"></i> <?php echo t('create_wifi_package'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php if (count($routers) === 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        You need to add a router first before creating packages.
                    </div>
                    <?php else: ?>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('select_router'); ?> <span class="text-danger">*</span></label>
                        <select name="router_id" class="form-select" required>
                            <option value=""><?php echo t('select_router'); ?></option>
                            <?php foreach ($routers as $r): ?>
                            <option value="<?php echo $r['id']; ?>">
                                <?php echo htmlspecialchars($r['device_name'] . ' (' . ($r['ssid'] ?: 'No SSID') . ')'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('package_name'); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g., 1 Hour Basic" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('description'); ?></label>
                        <textarea name="description" class="form-control" rows="2" placeholder="Optional description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('price_tzs'); ?> <span class="text-danger">*</span></label>
                            <input type="number" name="price" class="form-control" step="0.01" min="0" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('duration_minutes'); ?> <span class="text-danger">*</span></label>
                            <input type="number" name="duration_minutes" class="form-control" min="1" required>
                            <small class="text-muted">
                                <strong>Quick:</strong>
                                <a href="#" onclick="setDuration(30); return false;">30min</a> |
                                <a href="#" onclick="setDuration(60); return false;">1hr</a> |
                                <a href="#" onclick="setDuration(360); return false;">6hr</a> |
                                <a href="#" onclick="setDuration(1440); return false;">1day</a> |
                                <a href="#" onclick="setDuration(10080); return false;">1week</a> |
                                <a href="#" onclick="setDuration(43200); return false;">1month</a>
                            </small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><?php echo t('data_limit'); ?></label>
                            <input type="number" name="data_limit_mb" class="form-control" value="0">
                            <small class="text-muted">0 = unlimited</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><?php echo t('speed_limit'); ?></label>
                            <input type="number" name="speed_limit_mbps" class="form-control" value="5" min="1">
                            <small class="text-muted">Mbps</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><?php echo t('max_devices'); ?></label>
                            <input type="number" name="max_devices" class="form-control" value="1" min="1">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('search_tags'); ?></label>
                            <input type="text" name="tags" class="form-control" placeholder="e.g., basic, cheap">
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="form-check form-switch mt-4">
                                <input class="form-check-input" type="checkbox" name="is_featured" id="addIsFeatured">
                                <label class="form-check-label" for="addIsFeatured"><?php echo t('featured'); ?></label>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <?php if (count($routers) > 0): ?>
                    <button type="submit" name="add_package" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo t('create_package'); ?>
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- PAGE SCRIPT                                 -->
<!-- ============================================ -->
<script>
// Quick duration setter for add package form
function setDuration(minutes) {
    const input = document.querySelector('#addPackageModal input[name="duration_minutes"]');
    if (input) input.value = minutes;
}
</script>