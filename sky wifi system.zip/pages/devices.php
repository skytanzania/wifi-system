<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Device Manager Page - Loaded from external file
 * 
 * Sellers can view connected devices per router, block/unblock devices,
 * disconnect devices, and view device details
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE BLOCK DEVICE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['block_device'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    
    if ($sessionId) {
        $result = $sessionManager->blockDevice($sessionId, $userId, $reason);
        if ($result['success']) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $result['message'] . '</div>';
            redirectTo('?page=devices');
        } else {
            $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
        }
    }
}

// ============================================
// HANDLE UNBLOCK DEVICE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unblock_device'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    
    if ($sessionId) {
        $result = $sessionManager->unblockDevice($sessionId, $userId);
        if ($result['success']) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $result['message'] . '</div>';
            redirectTo('?page=devices');
        } else {
            $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
        }
    }
}

// ============================================
// HANDLE DISCONNECT DEVICE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['disconnect_device'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? 'Manual disconnect');
    
    if ($sessionId) {
        $result = $sessionManager->disconnectDevice($sessionId, $userId, $reason);
        if ($result['success']) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $result['message'] . '</div>';
            redirectTo('?page=devices');
        } else {
            $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
        }
    }
}

// ============================================
// HANDLE BULK DISCONNECT
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_disconnect'])) {
    $sessionIds = isset($_POST['session_ids']) ? $_POST['session_ids'] : [];
    $reason = trim($_POST['bulk_reason'] ?? 'Bulk disconnect');
    
    if (!empty($sessionIds)) {
        $successCount = 0;
        $failCount = 0;
        foreach ($sessionIds as $sid) {
            $sid = intval($sid);
            $result = $sessionManager->disconnectDevice($sid, $userId, $reason);
            if ($result['success']) $successCount++;
            else $failCount++;
        }
        $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Disconnected ' . $successCount . ' device(s)' . ($failCount > 0 ? '. ' . $failCount . ' failed.' : '') . '</div>';
        redirectTo('?page=devices');
    }
}

// ============================================
// HANDLE BULK BLOCK
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_block'])) {
    $sessionIds = isset($_POST['session_ids']) ? $_POST['session_ids'] : [];
    $reason = trim($_POST['bulk_block_reason'] ?? 'Bulk block');
    
    if (!empty($sessionIds)) {
        $successCount = 0;
        $failCount = 0;
        foreach ($sessionIds as $sid) {
            $sid = intval($sid);
            $result = $sessionManager->blockDevice($sid, $userId, $reason);
            if ($result['success']) $successCount++;
            else $failCount++;
        }
        $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Blocked ' . $successCount . ' device(s)' . ($failCount > 0 ? '. ' . $failCount . ' failed.' : '') . '</div>';
        redirectTo('?page=devices');
    }
}

// ============================================
// HANDLE ADJUST TIME (from device manager)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adjust_time'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    $minutes = intval($_POST['minutes'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    
    if ($sessionId && $minutes != 0) {
        $result = $sessionManager->adjustSessionTime($sessionId, $userId, $minutes, $reason);
        if ($result['success']) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Time adjusted successfully!</div>';
            redirectTo('?page=devices');
        } else {
            $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
        }
    }
}

// ============================================
// FETCH FILTERS
// ============================================
$routerFilter = intval($_GET['router_id'] ?? 0);
$statusFilter = $_GET['status'] ?? 'all'; // all, active, blocked
$searchTerm = trim($_GET['search'] ?? '');

// ============================================
// FETCH ROUTERS
// ============================================
$routers = $router->getRouters($userId);

// ============================================
// FETCH DEVICES
// ============================================
if ($routerFilter) {
    // Verify router belongs to seller
    $routerValid = false;
    foreach ($routers as $r) {
        if ($r['id'] == $routerFilter) {
            $routerValid = true;
            break;
        }
    }
    
    if ($routerValid) {
        $devices = $sessionManager->getConnectedDevices($routerFilter, $userId);
    } else {
        $devices = [];
        $msg = '<div class="alert alert-warning">Router not found or access denied</div>';
    }
} else {
    // Get all active sessions from all routers
    $devices = $sessionManager->getActiveSessions($userId);
}

// Get all blocked devices too (if filter allows)
if ($statusFilter === 'blocked' || $statusFilter === 'all') {
    try {
        $sql = "SELECT ws.*, 
                       r.device_name as router_name, r.status as router_status,
                       v.voucher_code, p.name as package_name,
                       u.full_name as user_name, u.phone as user_phone,
                       TIMESTAMPDIFF(MINUTE, NOW(), ws.session_end) as minutes_remaining
                FROM wifi_sessions ws
                JOIN routers r ON ws.router_id = r.id
                LEFT JOIN vouchers v ON ws.voucher_id = v.id
                LEFT JOIN packages p ON v.package_id = p.id
                LEFT JOIN users u ON ws.user_id = u.id
                WHERE r.user_id = ? AND ws.status = 'blocked'";
        
        $params = [$userId];
        $types = "i";
        
        if ($routerFilter) {
            $sql .= " AND ws.router_id = ?";
            $params[] = $routerFilter;
            $types .= "i";
        }
        
        $sql .= " ORDER BY ws.created_at DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $blockedDevices = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Merge with active if status is 'all'
        if ($statusFilter === 'all') {
            foreach ($blockedDevices as $bd) {
                $bd['is_blocked'] = true;
                $devices[] = $bd;
            }
        } else {
            $devices = $blockedDevices;
            foreach ($devices as &$d) {
                $d['is_blocked'] = true;
            }
            unset($d);
        }
    } catch (Throwable $e) {
        // ignore
    }
}

// Apply status filter
if ($statusFilter === 'active') {
    $devices = array_filter($devices, function($d) {
        return ($d['status'] ?? 'active') === 'active';
    });
    $devices = array_values($devices);
}

// Apply search filter
if ($searchTerm) {
    $devices = array_filter($devices, function($d) use ($searchTerm) {
        return 
            stripos($d['mac_address'] ?? '', $searchTerm) !== false ||
            stripos($d['device_name'] ?? '', $searchTerm) !== false ||
            stripos($d['ip_address'] ?? '', $searchTerm) !== false ||
            stripos($d['voucher_code'] ?? '', $searchTerm) !== false ||
            stripos($d['user_name'] ?? '', $searchTerm) !== false ||
            stripos($d['user_phone'] ?? '', $searchTerm) !== false;
    });
    $devices = array_values($devices);
}

// ============================================
// STATS
// ============================================
$totalActive = 0;
$totalBlocked = 0;
$totalExpired = 0;
$totalOnline = 0;
$totalOffline = 0;
$onlineRouters = 0;

foreach ($routers as $r) {
    if ($r['status'] === 'online') $onlineRouters++;
}

try {
    $res = $conn->query("SELECT COUNT(*) as c FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = $userId AND ws.status = 'active'");
    if ($res) $totalActive = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = $userId AND ws.status = 'blocked'");
    if ($res) $totalBlocked = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = $userId AND ws.status = 'expired'");
    if ($res) $totalExpired = $res->fetch_assoc()['c'];
    
    // Devices on online vs offline routers
    foreach ($devices as $d) {
        if (($d['router_status'] ?? 'online') === 'online') $totalOnline++;
        else $totalOffline++;
    }
} catch (Throwable $e) {}

// ============================================
// GROUP DEVICES BY ROUTER (for better view)
// ============================================
$devicesByRouter = [];
foreach ($devices as $d) {
    $rid = $d['router_id'] ?? 0;
    if (!isset($devicesByRouter[$rid])) {
        $devicesByRouter[$rid] = [
            'router_name' => $d['router_name'] ?? 'Unknown',
            'router_status' => $d['router_status'] ?? 'offline',
            'devices' => []
        ];
    }
    $devicesByRouter[$rid]['devices'][] = $d;
}

?>

<!-- ============================================ -->
<!-- DEVICE MANAGER HEADER                       -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-laptop"></i> <?php echo t('device_manager'); ?></h2>
        <small class="text-muted">Monitor, manage, and control connected devices</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <button type="button" class="btn btn-outline-info btn-sm" onclick="refreshDevices()">
            <i class="fas fa-sync"></i> Refresh
        </button>
        <a href="?page=sessions" class="btn btn-outline-warning btn-sm">
            <i class="fas fa-clock"></i> <?php echo t('session_manager'); ?>
        </a>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- DEVICE STATS                                -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-laptop text-primary"></i> <?php echo t('connected_devices'); ?></div>
            <div class="metric-value"><?php echo $totalActive; ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-check-circle text-success"></i> <?php echo t('online'); ?> Devices</div>
            <div class="metric-value text-success"><?php echo $totalOnline; ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-exclamation-triangle text-warning"></i> <?php echo t('offline'); ?> Routers</div>
            <div class="metric-value text-warning"><?php echo $totalOffline; ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-ban text-danger"></i> <?php echo t('blocked'); ?></div>
            <div class="metric-value text-danger"><?php echo $totalBlocked; ?></div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- FILTERS                                     -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-end">
            <input type="hidden" name="page" value="devices">
            
            <div class="col-md-4 col-6">
                <label class="form-label small mb-1"><i class="fas fa-search"></i> <?php echo t('search'); ?></label>
                <input type="text" name="search" class="form-control form-control-sm" 
                       placeholder="MAC, name, phone, voucher..." value="<?php echo htmlspecialchars($searchTerm); ?>">
            </div>
            
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-wifi"></i> <?php echo t('router'); ?></label>
                <select name="router_id" class="form-select form-select-sm">
                    <option value="0"><?php echo t('all_routers'); ?></option>
                    <?php foreach ($routers as $r): 
                        // Count devices on this router
                        $deviceCount = $devicesByRouter[$r['id']]['devices'] ?? [];
                        $count = count($deviceCount);
                    ?>
                    <option value="<?php echo $r['id']; ?>" <?php echo $routerFilter == $r['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($r['device_name']); ?>
                        <?php if ($r['status'] !== 'online'): ?>
                        [<?php echo $r['status']; ?>]
                        <?php endif; ?>
                        (<?php echo $count; ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2 col-6">
                <label class="form-label small mb-1"><i class="fas fa-filter"></i> <?php echo t('status'); ?></label>
                <select name="status" class="form-select form-select-sm">
                    <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>><?php echo t('all'); ?></option>
                    <option value="active" <?php echo $statusFilter === 'active' ? 'selected' : ''; ?>><?php echo t('active'); ?></option>
                    <option value="blocked" <?php echo $statusFilter === 'blocked' ? 'selected' : ''; ?>><?php echo t('blocked'); ?></option>
                </select>
            </div>
            
            <div class="col-md-3 col-6 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">
                    <i class="fas fa-filter"></i> <?php echo t('filter'); ?>
                </button>
                <a href="?page=devices" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-times"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<!-- ============================================ -->
<!-- DEVICES LIST                                -->
<!-- ============================================ -->
<?php if (count($devices) > 0): ?>
    <form method="POST" id="devicesForm">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="mb-0">
                    <i class="fas fa-list"></i> <?php echo t('connected_devices'); ?>
                    <small class="text-muted ms-2">(<?php echo count($devices); ?>)</small>
                </h5>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="selectAllDevices" onchange="toggleAllDevices(this)">
                    <label class="form-check-label small" for="selectAllDevices"><?php echo t('select_all'); ?></label>
                </div>
            </div>
            
            <div class="card-body p-0">
                <?php foreach ($devicesByRouter as $routerId => $group): 
                    $routerName = $group['router_name'];
                    $routerStatus = $group['router_status'];
                    $isRouterOffline = ($routerStatus !== 'online');
                    $groupDevices = $group['devices'];
                ?>
                
                <!-- Router Group Header -->
                <div class="p-3" style="background:var(--bg-body);border-bottom:1px solid var(--border-color);">
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                        <span class="router-status-indicator <?php echo $routerStatus; ?>"></span>
                        <strong><?php echo htmlspecialchars($routerName); ?></strong>
                        <span class="badge bg-<?php echo $routerStatus === 'online' ? 'success' : 'danger'; ?>">
                            <?php echo $routerStatus; ?>
                        </span>
                        <span class="badge bg-primary"><?php echo count($groupDevices); ?> <?php echo t('device_s'); ?></span>
                        <?php if ($isRouterOffline): ?>
                        <span class="offline-badge">
                            <i class="fas fa-wifi-slash"></i> <?php echo t('router_is_offline'); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Devices in this router group -->
                <?php foreach ($groupDevices as $device): 
                    $isBlocked = (($device['status'] ?? 'active') === 'blocked');
                    $minutesRemaining = intval($device['minutes_remaining'] ?? 0);
                    $isExpired = $minutesRemaining <= 0;
                    $isCritical = $minutesRemaining > 0 && $minutesRemaining <= 5;
                    $isWarning = $minutesRemaining > 5 && $minutesRemaining <= 15;
                    $timeClass = $isExpired ? 'critical' : ($isCritical ? 'critical' : ($isWarning ? 'warning' : 'good'));
                    $deviceOffline = (($device['router_status'] ?? 'online') !== 'online');
                ?>
                <div class="device-manager-card m-2 <?php echo $isBlocked ? 'border-danger' : ''; ?>" 
                     style="<?php echo $isBlocked ? 'border-left:4px solid var(--danger);' : ''; ?>">
                    <div class="device-header">
                        <div class="d-flex align-items-start gap-2 flex-grow-1" style="min-width:0;">
                            <input type="checkbox" name="session_ids[]" value="<?php echo $device['id']; ?>" 
                                   class="session-checkbox device-select" onchange="updateBulkBar()">
                            <div class="avatar-icon" style="width:40px;height:40px;border-radius:50%;background:var(--<?php echo $isBlocked ? 'danger' : 'primary'; ?>);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.1rem;flex-shrink:0;">
                                <i class="fas fa-<?php echo $isBlocked ? 'ban' : ($deviceOffline ? 'wifi-slash' : 'laptop'); ?>"></i>
                            </div>
                            <div style="min-width:0;flex:1;">
                                <div class="fw-semibold d-flex align-items-center gap-2 flex-wrap">
                                    <?php echo htmlspecialchars($device['device_name'] ?? 'Unknown Device'); ?>
                                    
                                    <?php if ($isBlocked): ?>
                                    <span class="badge bg-danger" style="font-size:0.65rem;">
                                        <i class="fas fa-ban"></i> <?php echo t('blocked'); ?>
                                    </span>
                                    <?php elseif ($deviceOffline): ?>
                                    <span class="offline-badge">
                                        <i class="fas fa-wifi-slash"></i> <?php echo t('offline'); ?>
                                    </span>
                                    <?php else: ?>
                                    <span class="online-badge">
                                        <i class="fas fa-check-circle"></i> <?php echo t('active'); ?>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="text-muted small mt-1">
                                    <i class="fas fa-network-wired"></i> 
                                    <code><?php echo htmlspecialchars($device['mac_address']); ?></code>
                                    <?php if (!empty($device['ip_address'])): ?>
                                    &middot; IP: <code><?php echo htmlspecialchars($device['ip_address']); ?></code>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if (!empty($device['voucher_code'])): ?>
                                <div class="text-muted small mt-1">
                                    <i class="fas fa-ticket-alt"></i> Voucher: <code><?php echo htmlspecialchars($device['voucher_code']); ?></code>
                                    <?php if (!empty($device['package_name'])): ?>
                                    &middot; <i class="fas fa-box"></i> <?php echo htmlspecialchars($device['package_name']); ?>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Time Remaining -->
                        <div class="text-end flex-shrink-0">
                            <?php if ($isBlocked): ?>
                            <div class="text-danger fw-bold">
                                <i class="fas fa-ban"></i> Blocked
                            </div>
                            <?php elseif ($isExpired): ?>
                            <div class="text-danger fw-bold">
                                <i class="fas fa-hourglass-end"></i> Expired
                            </div>
                            <?php else: ?>
                            <div class="time-remaining <?php echo $timeClass; ?>">
                                <i class="fas fa-hourglass-half"></i> <?php echo $minutesRemaining; ?>m
                            </div>
                            <small class="text-muted"><?php echo t('time_remaining'); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Additional Info -->
                    <div class="session-info mt-2">
                        <div class="info-item">
                            <i class="fas fa-user"></i>
                            <?php echo htmlspecialchars($device['user_name'] ?? 'Guest'); ?>
                        </div>
                        <?php if (!empty($device['user_phone'])): ?>
                        <div class="info-item">
                            <i class="fas fa-phone"></i>
                            <?php echo htmlspecialchars($device['user_phone']); ?>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($device['session_start'])): ?>
                        <div class="info-item">
                            <i class="fas fa-play text-success"></i>
                            <?php echo date('d M H:i', strtotime($device['session_start'])); ?>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($device['session_end'])): ?>
                        <div class="info-item">
                            <i class="fas fa-stop text-danger"></i>
                            <?php echo date('d M H:i', strtotime($device['session_end'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Device Actions -->
                    <div class="device-actions mt-3">
                        <?php if ($isBlocked): ?>
                        <button type="button" class="btn btn-sm btn-success" 
                                data-bs-toggle="modal" data-bs-target="#unblockModal<?php echo $device['id']; ?>">
                            <i class="fas fa-unlock"></i> <?php echo t('unblock_device'); ?>
                        </button>
                        <?php else: ?>
                        <button type="button" class="btn btn-sm btn-warning" 
                                data-bs-toggle="modal" data-bs-target="#disconnectModal<?php echo $device['id']; ?>">
                            <i class="fas fa-plug"></i> <?php echo t('disconnect_device'); ?>
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger" 
                                data-bs-toggle="modal" data-bs-target="#blockModal<?php echo $device['id']; ?>">
                            <i class="fas fa-ban"></i> <?php echo t('block_device'); ?>
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                data-bs-toggle="modal" data-bs-target="#adjustModal<?php echo $device['id']; ?>">
                            <i class="fas fa-clock"></i> <?php echo t('adjust_time'); ?>
                        </button>
                        <?php endif; ?>
                        
                        <button type="button" class="btn btn-sm btn-outline-secondary" 
                                data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo $device['id']; ?>">
                            <i class="fas fa-info-circle"></i>
                        </button>
                    </div>
                </div>
                
                <!-- ============================================ -->
                <!-- DISCONNECT MODAL                             -->
                <!-- ============================================ -->
                <div class="modal fade" id="disconnectModal<?php echo $device['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST">
                                <input type="hidden" name="session_id" value="<?php echo $device['id']; ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="fas fa-plug text-warning"></i> <?php echo t('disconnect_device'); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="alert alert-warning">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        Are you sure you want to disconnect this device?
                                    </div>
                                    <p>
                                        <strong><?php echo htmlspecialchars($device['device_name'] ?? 'Unknown'); ?></strong><br>
                                        <small class="text-muted">MAC: <code><?php echo htmlspecialchars($device['mac_address']); ?></code></small>
                                    </p>
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('reason'); ?> (<?php echo t('optional'); ?>)</label>
                                        <input type="text" name="reason" class="form-control" 
                                               value="Manual disconnect" placeholder="e.g., Maintenance">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                    <button type="submit" name="disconnect_device" class="btn btn-warning">
                                        <i class="fas fa-plug"></i> <?php echo t('disconnect_device'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- ============================================ -->
                <!-- BLOCK MODAL                                  -->
                <!-- ============================================ -->
                <div class="modal fade" id="blockModal<?php echo $device['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST">
                                <input type="hidden" name="session_id" value="<?php echo $device['id']; ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="fas fa-ban text-danger"></i> <?php echo t('block_device'); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="alert alert-danger">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        <strong>Warning:</strong> Blocking this device will prevent it from reconnecting until manually unblocked.
                                    </div>
                                    <p>Block device <strong><?php echo htmlspecialchars($device['device_name'] ?? 'Unknown'); ?></strong>?</p>
                                    <p class="small text-muted">MAC: <code><?php echo htmlspecialchars($device['mac_address']); ?></code></p>
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('reason'); ?> (<?php echo t('optional'); ?>)</label>
                                        <textarea name="reason" class="form-control" rows="2" 
                                                  placeholder="e.g., Terms violation, Payment issue"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                    <button type="submit" name="block_device" class="btn btn-danger">
                                        <i class="fas fa-ban"></i> <?php echo t('block_device'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- ============================================ -->
                <!-- ADJUST TIME MODAL                            -->
                <!-- ============================================ -->
                <div class="modal fade" id="adjustModal<?php echo $device['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST">
                                <input type="hidden" name="session_id" value="<?php echo $device['id']; ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="fas fa-clock text-primary"></i> <?php echo t('adjust_time'); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="alert alert-info">
                                        <strong><?php echo htmlspecialchars($device['device_name'] ?? 'Unknown'); ?></strong><br>
                                        <small>Current: <strong><?php echo date('d M Y H:i', strtotime($device['session_end'])); ?></strong></small><br>
                                        <small>Remaining: <strong><?php echo $minutesRemaining; ?> min</strong></small>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('adjustment_amount'); ?> (<?php echo t('minutes'); ?>)</label>
                                        <input type="number" name="minutes" class="form-control form-control-lg" value="15" required>
                                        <small class="text-muted">Positive = extend, Negative = reduce</small>
                                    </div>
                                    
                                    <div class="d-flex gap-2 flex-wrap mb-3">
                                        <button type="button" class="btn btn-sm btn-outline-success" onclick="setAdjustMinutes(15)">+15m</button>
                                        <button type="button" class="btn btn-sm btn-outline-success" onclick="setAdjustMinutes(30)">+30m</button>
                                        <button type="button" class="btn btn-sm btn-outline-success" onclick="setAdjustMinutes(60)">+1h</button>
                                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="setAdjustMinutes(-15)">-15m</button>
                                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="setAdjustMinutes(-30)">-30m</button>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('adjustment_reason'); ?></label>
                                        <textarea name="reason" class="form-control" rows="2" 
                                                  placeholder="e.g., Router was offline"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                    <button type="submit" name="adjust_time" class="btn btn-primary">
                                        <i class="fas fa-save"></i> <?php echo t('adjust_time'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <?php if ($isBlocked): ?>
                <!-- ============================================ -->
                <!-- UNBLOCK MODAL                                -->
                <!-- ============================================ -->
                <div class="modal fade" id="unblockModal<?php echo $device['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST">
                                <input type="hidden" name="session_id" value="<?php echo $device['id']; ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="fas fa-unlock text-success"></i> <?php echo t('unblock_device'); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to unblock this device?</p>
                                    <p><strong><?php echo htmlspecialchars($device['device_name'] ?? 'Unknown'); ?></strong></p>
                                    <p class="small text-muted">MAC: <code><?php echo htmlspecialchars($device['mac_address']); ?></code></p>
                                    <div class="alert alert-info small mb-0">
                                        <i class="fas fa-info-circle"></i>
                                        The device will be able to reconnect with a valid voucher.
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                    <button type="submit" name="unblock_device" class="btn btn-success">
                                        <i class="fas fa-unlock"></i> <?php echo t('unblock_device'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- ============================================ -->
                <!-- DETAILS MODAL                                -->
                <!-- ============================================ -->
                <div class="modal fade" id="detailsModal<?php echo $device['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title"><i class="fas fa-info-circle"></i> Device Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="stat-row">
                                    <span>Session ID:</span>
                                    <strong>#<?php echo $device['id']; ?></strong>
                                </div>
                                <div class="stat-row">
                                    <span>Device:</span>
                                    <strong><?php echo htmlspecialchars($device['device_name'] ?? 'Unknown'); ?></strong>
                                </div>
                                <div class="stat-row">
                                    <span>MAC Address:</span>
                                    <code><?php echo htmlspecialchars($device['mac_address']); ?></code>
                                </div>
                                <div class="stat-row">
                                    <span>IP Address:</span>
                                    <code><?php echo htmlspecialchars($device['ip_address'] ?? '-'); ?></code>
                                </div>
                                <div class="stat-row">
                                    <span>User:</span>
                                    <strong><?php echo htmlspecialchars($device['user_name'] ?? 'Guest'); ?></strong>
                                </div>
                                <?php if (!empty($device['user_phone'])): ?>
                                <div class="stat-row">
                                    <span>Phone:</span>
                                    <strong><?php echo htmlspecialchars($device['user_phone']); ?></strong>
                                </div>
                                <?php endif; ?>
                                <div class="stat-row">
                                    <span>Router:</span>
                                    <strong><?php echo htmlspecialchars($device['router_name'] ?? '-'); ?></strong>
                                    <span class="badge bg-<?php echo ($device['router_status'] ?? 'offline') === 'online' ? 'success' : 'danger'; ?>">
                                        <?php echo $device['router_status'] ?? 'offline'; ?>
                                    </span>
                                </div>
                                <?php if (!empty($device['package_name'])): ?>
                                <div class="stat-row">
                                    <span>Package:</span>
                                    <strong><?php echo htmlspecialchars($device['package_name']); ?></strong>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($device['voucher_code'])): ?>
                                <div class="stat-row">
                                    <span>Voucher:</span>
                                    <code><?php echo htmlspecialchars($device['voucher_code']); ?></code>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($device['session_start'])): ?>
                                <div class="stat-row">
                                    <span>Started:</span>
                                    <span><?php echo date('d M Y H:i', strtotime($device['session_start'])); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($device['session_end'])): ?>
                                <div class="stat-row">
                                    <span>Expires:</span>
                                    <span><?php echo date('d M Y H:i', strtotime($device['session_end'])); ?></span>
                                </div>
                                <?php endif; ?>
                                <div class="stat-row">
                                    <span>Time Remaining:</span>
                                    <span class="<?php echo $timeClass; ?>">
                                        <?php echo $minutesRemaining > 0 ? $minutesRemaining . ' min' : 'Expired'; ?>
                                    </span>
                                </div>
                                <div class="stat-row">
                                    <span>Status:</span>
                                    <span class="badge bg-<?php echo $isBlocked ? 'danger' : ($deviceOffline ? 'warning' : 'success'); ?>">
                                        <?php echo $isBlocked ? 'Blocked' : ($deviceOffline ? 'Offline' : 'Active'); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php endforeach; ?>
                <?php endforeach; ?>
            </div>
            
            <!-- ============================================ -->
            <!-- BULK ACTIONS BAR                             -->
            <!-- ============================================ -->
            <div class="bulk-actions-bar" id="bulkActionsBar" style="display:none;">
                <div>
                    <span id="selectedCount">0</span> device(s) selected
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <button type="button" class="btn btn-sm btn-outline-warning" 
                            data-bs-toggle="modal" data-bs-target="#bulkDisconnectModal">
                        <i class="fas fa-plug"></i> <?php echo t('disconnect_device'); ?>
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-danger" 
                            data-bs-toggle="modal" data-bs-target="#bulkBlockModal">
                        <i class="fas fa-ban"></i> <?php echo t('block_device'); ?>
                    </button>
                </div>
            </div>
        </div>
    </form>
    
    <!-- ============================================ -->
    <!-- BULK DISCONNECT MODAL                        -->
    <!-- ============================================ -->
    <div class="modal fade" id="bulkDisconnectModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-plug text-warning"></i> Bulk Disconnect</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Disconnect <strong id="bulkDisconnectCount">0</strong> selected device(s)?</p>
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('reason'); ?></label>
                            <input type="text" name="bulk_reason" class="form-control" value="Bulk disconnect" required>
                        </div>
                        <div id="bulkDisconnectIds"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="bulk_disconnect" class="btn btn-warning">
                            <i class="fas fa-plug"></i> Disconnect All
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- ============================================ -->
    <!-- BULK BLOCK MODAL                             -->
    <!-- ============================================ -->
    <div class="modal fade" id="bulkBlockModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-ban text-danger"></i> Bulk Block</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger small">
                            <i class="fas fa-exclamation-triangle"></i>
                            Blocking multiple devices will prevent them from reconnecting.
                        </div>
                        <p>Block <strong id="bulkBlockCount">0</strong> selected device(s)?</p>
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('reason'); ?></label>
                            <textarea name="bulk_block_reason" class="form-control" rows="2" placeholder="Reason for blocking"></textarea>
                        </div>
                        <div id="bulkBlockIds"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="bulk_block" class="btn btn-danger">
                            <i class="fas fa-ban"></i> Block All
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
<?php else: ?>
    <!-- Empty State -->
    <div class="card">
        <div class="card-body">
            <div class="empty-state py-5">
                <i class="fas fa-laptop"></i>
                <h5><?php echo t('no_data'); ?></h5>
                <p>
                    <?php if ($searchTerm || $routerFilter || $statusFilter !== 'all'): ?>
                        No devices match your filters. <a href="?page=devices">Clear filters</a>
                    <?php else: ?>
                        No devices are currently connected to your routers.
                    <?php endif; ?>
                </p>
                <?php if (count($routers) === 0): ?>
                <a href="?page=connect" class="btn btn-primary mt-3">
                    <i class="fas fa-plus-circle"></i> Add Your First Router
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- ============================================ -->
<!-- AUTO-REFRESH SCRIPT                         -->
<!-- ============================================ -->
<script>
// Refresh devices list
function refreshDevices() {
    window.location.reload();
}

// Toggle all device checkboxes
function toggleAllDevices(checkbox) {
    document.querySelectorAll('.device-select').forEach(cb => cb.checked = checkbox.checked);
    updateBulkBar();
}

// Update bulk actions bar
function updateBulkBar() {
    const checked = document.querySelectorAll('.device-select:checked');
    const bar = document.getElementById('bulkActionsBar');
    const count = document.getElementById('selectedCount');
    if (bar) bar.style.display = checked.length > 0 ? 'flex' : 'none';
    if (count) count.textContent = checked.length;
    
    // Update bulk disconnect/block modals
    const disconnectCount = document.getElementById('bulkDisconnectCount');
    const blockCount = document.getElementById('bulkBlockCount');
    const disconnectIds = document.getElementById('bulkDisconnectIds');
    const blockIds = document.getElementById('bulkBlockIds');
    
    if (disconnectCount) disconnectCount.textContent = checked.length;
    if (blockCount) blockCount.textContent = checked.length;
    
    // Clear and repopulate IDs
    if (disconnectIds) {
        disconnectIds.innerHTML = '';
        checked.forEach(cb => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'session_ids[]';
            input.value = cb.value;
            disconnectIds.appendChild(input);
        });
    }
    
    if (blockIds) {
        blockIds.innerHTML = '';
        checked.forEach(cb => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'session_ids[]';
            input.value = cb.value;
            blockIds.appendChild(input);
        });
    }
}

// Set adjustment minutes in modal
function setAdjustMinutes(minutes) {
    const activeModal = document.querySelector('.modal.show');
    if (activeModal) {
        const input = activeModal.querySelector('input[name="minutes"]');
        if (input) input.value = minutes;
    }
}

// Auto-refresh every 60 seconds
(function() {
    if (window.location.search.includes('search=')) return;
    if (window.location.search.includes('router_id=') && parseInt(window.location.search.match(/router_id=(\d+)/)?.[1] || 0) > 0) return;
    
    setInterval(function() {
        // Don't refresh if user is in a modal or focused on input
        if (document.querySelector('.modal.show')) return;
        if (document.activeElement && 
            (document.activeElement.tagName === 'INPUT' || 
             document.activeElement.tagName === 'TEXTAREA' || 
             document.activeElement.tagName === 'SELECT')) return;
        
        // Silent fetch to check for updates
        fetch(window.location.pathname + '?page=devices&ajax_check=1', { 
            headers: { 'X-Requested-With': 'XMLHttpRequest' } 
        }).then(() => {
            // Just checking - no auto reload to avoid disruption
        }).catch(() => {});
    }, 60000);
})();

// Auto-uppercase MAC in search
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            // Only uppercase if it looks like a MAC address pattern
            if (/^[0-9a-fA-F:]+$/.test(this.value)) {
                const cursorPos = this.selectionStart;
                this.value = this.value.toUpperCase();
                this.setSelectionRange(cursorPos, cursorPos);
            }
        });
    }
});
</script>