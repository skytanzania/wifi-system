<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Connect Page - Loaded from external file
 * 
 * For SELLERS: Add/manage routers, test connections
 * For CUSTOMERS: Enter voucher code to connect to WiFi
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

$auth->requireLogin();
$userId = $_SESSION['user_id'];
$user = $auth->getUser();
$userType = $user['user_type'];

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// ============================================
// SELLER / ADMIN SECTION
// ============================================
// ============================================
if ($userType === 'seller' || $userType === 'admin') {

    // --------------------------------------------
    // HANDLE CHECK ROUTER STATUS
    // --------------------------------------------
    if (isset($_GET['check'])) {
        $checkId = (int)$_GET['check'];
        $stmt = $conn->prepare("SELECT id, device_name FROM routers WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $checkId, $userId);
        $stmt->execute();
        $checkRouter = $stmt->get_result()->fetch_assoc();

        if ($checkRouter) {
            if (strpos($checkRouter['device_name'], 'Sample Router') === 0) {
                $router->updateStatus($checkId, 'online');
                $isOnline = true;
            } else {
                $isOnline = $router->checkOnline($checkId);
            }
            $_SESSION['flash_msg'] = $isOnline
                ? '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . htmlspecialchars($checkRouter['device_name']) . ': ' . t('router_is_online') . '</div>'
                : '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> ' . htmlspecialchars($checkRouter['device_name']) . ': ' . t('router_is_offline') . '</div>';
        } else {
            $_SESSION['flash_msg'] = '<div class="alert alert-danger">' . t('router_not_found') . '</div>';
        }
        redirectTo('?page=connect#routers');
    }

    // --------------------------------------------
    // HANDLE CREATE SAMPLE ROUTER
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_sample_router'])) {
        $result = $router->createSampleRouter($userId);
        if ($result['success']) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . t('sample_router_created') . '</div>';
            redirectTo('?page=connect#routers');
        } else {
            $msg = '<div class="alert alert-danger">Error: ' . htmlspecialchars($result['message']) . '</div>';
        }
    }

    // --------------------------------------------
    // HANDLE ADD ROUTER
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_router'])) {
        $data = [
            'user_id' => $userId,
            'provider_id' => intval($_POST['provider_id'] ?? 0),
            'device_name' => $_POST['device_name'] ?? '',
            'device_type' => $_POST['device_type'] ?? 'other',
            'model' => $_POST['model'] ?? '',
            'mac_address' => $_POST['mac_address'] ?? '',
            'ip_address' => $_POST['ip_address'] ?? '',
            'ssid' => $_POST['ssid'] ?? '',
            'password' => $_POST['password'] ?? '',
            'api_port' => intval($_POST['api_port'] ?? 80),
            'api_username' => $_POST['api_username'] ?? '',
            'api_password' => $_POST['api_password'] ?? '',
            'location' => $_POST['location'] ?? '',
            'latitude' => floatval($_POST['latitude'] ?? 0),
            'longitude' => floatval($_POST['longitude'] ?? 0)
        ];
        $result = $router->addRouter($data);
        if ($result['success']) {
            $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . t('router_added') . '</div>';
            redirectTo('?page=connect#routers');
        } else {
            $msg = '<div class="alert alert-danger">Error: ' . htmlspecialchars($result['message']) . '</div>';
        }
    }

    // --------------------------------------------
    // HANDLE EDIT ROUTER
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_router'])) {
        $routerId = intval($_POST['router_id'] ?? 0);
        
        // Verify ownership
        $check = $conn->prepare("SELECT id FROM routers WHERE id = ? AND user_id = ?");
        $check->bind_param("ii", $routerId, $userId);
        $check->execute();
        
        if ($check->get_result()->num_rows === 0) {
            $msg = '<div class="alert alert-danger">Router not found</div>';
        } else {
            $providerId = !empty($_POST['provider_id']) ? intval($_POST['provider_id']) : null;
            $deviceName = trim($_POST['device_name'] ?? '');
            $deviceType = $_POST['device_type'] ?? 'other';
            $model = trim($_POST['model'] ?? '');
            $macAddress = strtoupper(trim($_POST['mac_address'] ?? ''));
            $ipAddress = trim($_POST['ip_address'] ?? '');
            $ssid = trim($_POST['ssid'] ?? '');
            $wifiPass = $_POST['password'] ?? '';
            $apiPort = intval($_POST['api_port'] ?? 80);
            $apiUser = $_POST['api_username'] ?? '';
            $apiPass = $_POST['api_password'] ?? '';
            $location = trim($_POST['location'] ?? '');
            $latitude = floatval($_POST['latitude'] ?? 0);
            $longitude = floatval($_POST['longitude'] ?? 0);
            
            if ($providerId !== null) {
                $chk = $conn->prepare("SELECT id FROM providers WHERE id = ?");
                $chk->bind_param("i", $providerId);
                $chk->execute();
                if ($chk->get_result()->num_rows === 0) $providerId = null;
            }
            
            if ($deviceName && $macAddress) {
                $stmt = $conn->prepare("UPDATE routers SET provider_id = ?, device_name = ?, device_type = ?, model = ?, mac_address = ?, ip_address = ?, ssid = ?, password = ?, api_port = ?, api_username = ?, api_password = ?, location = ?, latitude = ?, longitude = ? WHERE id = ? AND user_id = ?");
                $stmt->bind_param("isssssssisssddii", 
                    $providerId, $deviceName, $deviceType, $model, 
                    $macAddress, $ipAddress, $ssid, $wifiPass, 
                    $apiPort, $apiUser, $apiPass, $location, 
                    $latitude, $longitude, $routerId, $userId
                );
                if ($stmt->execute()) {
                    $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Router updated successfully!</div>';
                    redirectTo('?page=connect#routers');
                } else {
                    $msg = '<div class="alert alert-danger">Failed to update: ' . htmlspecialchars($conn->error) . '</div>';
                }
            } else {
                $msg = '<div class="alert alert-warning">Device name and MAC address are required</div>';
            }
        }
    }

    // --------------------------------------------
    // HANDLE DELETE ROUTER
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_router'])) {
        $routerId = intval($_POST['router_id'] ?? 0);
        if ($routerId) {
            $stmt = $conn->prepare("DELETE FROM routers WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $routerId, $userId);
            if ($stmt->execute() && $stmt->affected_rows > 0) {
                $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Router deleted successfully!</div>';
                redirectTo('?page=connect#routers');
            } else {
                $msg = '<div class="alert alert-danger">Failed to delete router</div>';
            }
        }
    }

    // --------------------------------------------
    // HANDLE BULK CHECK ALL ROUTERS
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['check_all'])) {
        $routers = $router->getRouters($userId);
        $onlineCount = 0;
        foreach ($routers as $r) {
            if (strpos($r['device_name'], 'Sample Router') === 0) {
                $router->updateStatus($r['id'], 'online');
                $onlineCount++;
            } else {
                if ($router->checkOnline($r['id'])) $onlineCount++;
            }
        }
        $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Checked ' . count($routers) . ' routers. ' . $onlineCount . ' online.</div>';
        redirectTo('?page=connect#routers');
    }

    // --------------------------------------------
    // FETCH DATA
    // --------------------------------------------
    $routers = $router->getRouters($userId);
    $providers = $conn->query("SELECT * FROM providers WHERE status = 'active' ORDER BY name")->fetch_all(MYSQLI_ASSOC);

    // Get package count per router
    $routerPackageCounts = [];
    try {
        $stmt = $conn->prepare("SELECT router_id, COUNT(*) as count FROM packages WHERE seller_id = ? GROUP BY router_id");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $routerPackageCounts[$row['router_id']] = $row['count'];
        }
    } catch (Throwable $e) {}

    // Get active session count per router
    $routerSessionCounts = [];
    try {
        $stmt = $conn->prepare("SELECT ws.router_id, COUNT(*) as count FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = ? AND ws.status = 'active' GROUP BY ws.router_id");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $routerSessionCounts[$row['router_id']] = $row['count'];
        }
    } catch (Throwable $e) {}

    // Stats
    $onlineCount = 0;
    $offlineCount = 0;
    $maintenanceCount = 0;
    foreach ($routers as $r) {
        if ($r['status'] === 'online') $onlineCount++;
        elseif ($r['status'] === 'maintenance') $maintenanceCount++;
        else $offlineCount++;
    }
    
    // Count connected devices
    $totalDevices = 0;
    try {
        $res = $conn->query("SELECT COUNT(*) as c FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = $userId AND ws.status = 'active'");
        if ($res) $totalDevices = $res->fetch_assoc()['c'];
    } catch (Throwable $e) {}

?>

<!-- ============================================ -->
<!-- SELLER: CONNECT / ROUTER MANAGEMENT         -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-wifi"></i> <?php echo t('connect_router'); ?></h2>
        <small class="text-muted">Add and manage your WiFi routers</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <?php if (count($routers) > 0): ?>
        <form method="POST" class="d-inline">
            <button type="submit" name="check_all" class="btn btn-outline-info btn-sm">
                <i class="fas fa-sync"></i> Check All
            </button>
        </form>
        <?php endif; ?>
        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#sampleRouterModal">
            <i class="fas fa-magic"></i> <?php echo t('create_sample_router'); ?>
        </button>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addRouterModal">
            <i class="fas fa-plus-circle"></i> <?php echo t('add_router'); ?>
        </button>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- ROUTER STATS                                -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-wifi text-primary"></i> <?php echo t('total_routers'); ?></div>
            <div class="metric-value"><?php echo count($routers); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-check-circle text-success"></i> <?php echo t('online'); ?></div>
            <div class="metric-value text-success"><?php echo $onlineCount; ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-times-circle text-danger"></i> <?php echo t('offline'); ?></div>
            <div class="metric-value text-danger"><?php echo $offlineCount; ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-laptop text-info"></i> <?php echo t('connected_devices'); ?></div>
            <div class="metric-value text-info"><?php echo $totalDevices; ?></div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- ROUTERS GRID                                -->
<!-- ============================================ -->
<div id="routers">
<?php if (count($routers) > 0): ?>
    <div class="row">
        <?php foreach ($routers as $r): 
            $isOnline = ($r['status'] === 'online');
            $packageCount = $routerPackageCounts[$r['id']] ?? 0;
            $sessionCount = $routerSessionCounts[$r['id']] ?? 0;
            $isSample = (strpos($r['device_name'], 'Sample Router') === 0);
        ?>
        <div class="col-md-6 mb-3" data-router-id="<?php echo $r['id']; ?>">
            <div class="card h-100">
                <!-- Status Bar -->
                <div style="height:4px;background:var(--<?php echo $isOnline ? 'success' : ($r['status'] === 'maintenance' ? 'warning' : 'danger'); ?>);"></div>
                
                <div class="card-body">
                    <!-- Header -->
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div style="min-width:0;flex:1;">
                            <h6 class="mb-1 text-truncate">
                                <span class="router-status-indicator <?php echo $r['status']; ?>"></span>
                                <?php echo htmlspecialchars($r['device_name']); ?>
                                <?php if ($isSample): ?>
                                <span class="badge bg-secondary ms-1" style="font-size:0.6rem;">DEMO</span>
                                <?php endif; ?>
                            </h6>
                            <small class="text-muted">
                                <i class="fas fa-tag"></i> <?php echo htmlspecialchars(ucfirst($r['device_type'])); ?>
                                <?php if ($r['model']): ?>
                                &middot; <?php echo htmlspecialchars($r['model']); ?>
                                <?php endif; ?>
                            </small>
                        </div>
                        <span class="badge bg-<?php echo $isOnline ? 'success' : ($r['status'] === 'maintenance' ? 'warning text-dark' : 'danger'); ?> router-status-badge">
                            <?php echo t($r['status']); ?>
                        </span>
                    </div>
                    
                    <!-- Router Details Grid -->
                    <div class="small mb-3">
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="text-muted" style="font-size:0.7rem;text-transform:uppercase;">SSID</div>
                                <div class="text-truncate"><i class="fas fa-wifi text-primary"></i> <strong><?php echo htmlspecialchars($r['ssid'] ?: 'N/A'); ?></strong></div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted" style="font-size:0.7rem;text-transform:uppercase;">IP Address</div>
                                <div class="text-truncate"><code style="font-size:0.75rem;"><?php echo htmlspecialchars($r['ip_address'] ?: 'N/A'); ?></code></div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted" style="font-size:0.7rem;text-transform:uppercase;">MAC</div>
                                <div class="text-truncate"><code style="font-size:0.7rem;"><?php echo htmlspecialchars($r['mac_address']); ?></code></div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted" style="font-size:0.7rem;text-transform:uppercase;">Port</div>
                                <div><strong><?php echo $r['api_port']; ?></strong></div>
                            </div>
                            <?php if ($r['provider_name']): ?>
                            <div class="col-6">
                                <div class="text-muted" style="font-size:0.7rem;text-transform:uppercase;">Provider</div>
                                <div><i class="fas fa-tower-cell text-info"></i> <?php echo htmlspecialchars($r['provider_name']); ?></div>
                            </div>
                            <?php endif; ?>
                            <?php if ($r['location']): ?>
                            <div class="col-6">
                                <div class="text-muted" style="font-size:0.7rem;text-transform:uppercase;">Location</div>
                                <div class="text-truncate"><i class="fas fa-map-marker-alt text-danger"></i> <?php echo htmlspecialchars($r['location']); ?></div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Status Row -->
                    <div class="d-flex justify-content-between align-items-center p-2 rounded mb-3" style="background:var(--bg-body);">
                        <div class="text-center flex-fill">
                            <div class="fw-bold text-primary"><?php echo $packageCount; ?></div>
                            <div class="text-muted" style="font-size:0.7rem;"><?php echo t('packages'); ?></div>
                        </div>
                        <div class="text-center flex-fill border-start border-end" style="border-color:var(--border-color) !important;">
                            <div class="fw-bold text-success"><?php echo $sessionCount; ?></div>
                            <div class="text-muted" style="font-size:0.7rem;"><?php echo t('sessions'); ?></div>
                        </div>
                        <div class="text-center flex-fill">
                            <div class="fw-bold">
                                <?php 
                                if ($r['last_seen']) {
                                    $diff = time() - strtotime($r['last_seen']);
                                    if ($diff < 60) echo 'Now';
                                    elseif ($diff < 3600) echo floor($diff / 60) . 'm';
                                    elseif ($diff < 86400) echo floor($diff / 3600) . 'h';
                                    else echo floor($diff / 86400) . 'd';
                                } else {
                                    echo '—';
                                }
                                ?>
                            </div>
                            <div class="text-muted" style="font-size:0.7rem;"><?php echo t('last_seen'); ?></div>
                        </div>
                    </div>
                    
                    <!-- Actions -->
                    <div class="d-flex gap-1 flex-wrap">
                        <a href="?page=connect&check=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-primary flex-grow-1">
                            <i class="fas fa-sync"></i> <?php echo t('check'); ?>
                        </a>
                        <a href="?page=packages&router=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-success">
                            <i class="fas fa-box"></i>
                        </a>
                        <a href="?page=devices&router_id=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-info">
                            <i class="fas fa-laptop"></i>
                        </a>
                        <button class="btn btn-sm btn-outline-warning" 
                                data-bs-toggle="modal" data-bs-target="#editRouterModal<?php echo $r['id']; ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger"
                                data-bs-toggle="modal" data-bs-target="#deleteRouterModal<?php echo $r['id']; ?>">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- ============================================ -->
        <!-- EDIT ROUTER MODAL                            -->
        <!-- ============================================ -->
        <div class="modal fade" id="editRouterModal<?php echo $r['id']; ?>">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form method="POST">
                        <input type="hidden" name="router_id" value="<?php echo $r['id']; ?>">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-edit text-primary"></i> Edit Router</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('device_name'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="device_name" class="form-control" value="<?php echo htmlspecialchars($r['device_name']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('device_type'); ?></label>
                                    <select name="device_type" class="form-select">
                                        <option value="tp-link" <?php echo $r['device_type'] === 'tp-link' ? 'selected' : ''; ?>>TP-Link</option>
                                        <option value="omada" <?php echo $r['device_type'] === 'omada' ? 'selected' : ''; ?>>Omada</option>
                                        <option value="mikrotik" <?php echo $r['device_type'] === 'mikrotik' ? 'selected' : ''; ?>>MikroTik</option>
                                        <option value="ubiquiti" <?php echo $r['device_type'] === 'ubiquiti' ? 'selected' : ''; ?>>Ubiquiti</option>
                                        <option value="other" <?php echo $r['device_type'] === 'other' ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('model'); ?></label>
                                    <input type="text" name="model" class="form-control" value="<?php echo htmlspecialchars($r['model']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('mac_address'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="mac_address" class="form-control" value="<?php echo htmlspecialchars($r['mac_address']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('ip_address'); ?></label>
                                    <input type="text" name="ip_address" class="form-control" value="<?php echo htmlspecialchars($r['ip_address']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('api_port'); ?></label>
                                    <input type="number" name="api_port" class="form-control" value="<?php echo $r['api_port']; ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('wifi_name'); ?></label>
                                    <input type="text" name="ssid" class="form-control" value="<?php echo htmlspecialchars($r['ssid']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('wifi_password'); ?></label>
                                    <input type="text" name="password" class="form-control" value="<?php echo htmlspecialchars($r['password']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('api_username'); ?></label>
                                    <input type="text" name="api_username" class="form-control" value="<?php echo htmlspecialchars($r['api_username']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('api_password'); ?></label>
                                    <input type="text" name="api_password" class="form-control" value="<?php echo htmlspecialchars($r['api_password']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('internet_provider'); ?></label>
                                    <select name="provider_id" class="form-select">
                                        <option value=""><?php echo t('select_provider'); ?></option>
                                        <?php foreach ($providers as $pr): ?>
                                        <option value="<?php echo $pr['id']; ?>" <?php echo $r['provider_id'] == $pr['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($pr['name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('location'); ?></label>
                                    <input type="text" name="location" class="form-control" value="<?php echo htmlspecialchars($r['location']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('latitude'); ?></label>
                                    <input type="text" name="latitude" class="form-control" value="<?php echo $r['latitude']; ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo t('longitude'); ?></label>
                                    <input type="text" name="longitude" class="form-control" value="<?php echo $r['longitude']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                            <button type="submit" name="edit_router" class="btn btn-primary">
                                <i class="fas fa-save"></i> <?php echo t('save'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- ============================================ -->
        <!-- DELETE ROUTER MODAL                          -->
        <!-- ============================================ -->
        <div class="modal fade" id="deleteRouterModal<?php echo $r['id']; ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST">
                        <input type="hidden" name="router_id" value="<?php echo $r['id']; ?>">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-trash text-danger"></i> <?php echo t('confirm_delete'); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to delete router <strong><?php echo htmlspecialchars($r['device_name']); ?></strong>?</p>
                            <div class="alert alert-danger small">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>This will also delete:</strong>
                                <ul class="mb-0 mt-1">
                                    <li><?php echo $packageCount; ?> packages</li>
                                    <li>All associated vouchers</li>
                                    <li>Session history</li>
                                </ul>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                            <button type="submit" name="delete_router" class="btn btn-danger">
                                <i class="fas fa-trash"></i> <?php echo t('yes_delete'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <!-- Empty State -->
    <div class="card">
        <div class="card-body">
            <div class="empty-state py-5">
                <i class="fas fa-wifi"></i>
                <h5><?php echo t('no_routers'); ?></h5>
                <p>Add your first WiFi router to start creating packages and selling vouchers.</p>
                <div class="d-flex gap-2 justify-content-center mt-3 flex-wrap">
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#sampleRouterModal">
                        <i class="fas fa-magic"></i> <?php echo t('create_sample_router'); ?>
                    </button>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRouterModal">
                        <i class="fas fa-plus-circle"></i> <?php echo t('add_router'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
</div>

<!-- ============================================ -->
<!-- ADD ROUTER MODAL                            -->
<!-- ============================================ -->
<div class="modal fade" id="addRouterModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus-circle text-primary"></i> <?php echo t('add_wifi_router'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('device_name'); ?> <span class="text-danger">*</span></label>
                            <input type="text" name="device_name" class="form-control" placeholder="e.g., Office Router" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('device_type'); ?></label>
                            <select name="device_type" class="form-select">
                                <option value="tp-link">TP-Link</option>
                                <option value="omada">Omada</option>
                                <option value="mikrotik">MikroTik</option>
                                <option value="ubiquiti">Ubiquiti</option>
                                <option value="other" selected>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('model'); ?></label>
                            <input type="text" name="model" class="form-control" placeholder="e.g., Archer C6">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('mac_address'); ?> <span class="text-danger">*</span></label>
                            <input type="text" name="mac_address" class="form-control" placeholder="AA:BB:CC:DD:EE:FF" required>
                            <small class="text-muted">Format: XX:XX:XX:XX:XX:XX</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('ip_address'); ?></label>
                            <input type="text" name="ip_address" class="form-control" placeholder="192.168.1.1">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('api_port'); ?></label>
                            <input type="number" name="api_port" class="form-control" value="80">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('wifi_name'); ?></label>
                            <input type="text" name="ssid" class="form-control" placeholder="e.g., MyWiFi">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('wifi_password'); ?></label>
                            <input type="text" name="password" class="form-control" placeholder="WiFi password">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('api_username'); ?></label>
                            <input type="text" name="api_username" class="form-control" value="admin">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('api_password'); ?></label>
                            <input type="text" name="api_password" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('internet_provider'); ?></label>
                            <select name="provider_id" class="form-select">
                                <option value=""><?php echo t('select_provider'); ?></option>
                                <?php foreach ($providers as $pr): ?>
                                <option value="<?php echo $pr['id']; ?>"><?php echo htmlspecialchars($pr['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('location'); ?></label>
                            <input type="text" name="location" class="form-control" placeholder="e.g., Dar es Salaam">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('latitude'); ?></label>
                            <input type="text" name="latitude" class="form-control" placeholder="-6.7924">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('longitude'); ?></label>
                            <input type="text" name="longitude" class="form-control" placeholder="39.2083">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="submit" name="add_router" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo t('add_router'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- SAMPLE ROUTER MODAL                         -->
<!-- ============================================ -->
<div class="modal fade" id="sampleRouterModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-magic text-success"></i> <?php echo t('create_sample_router'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        This will create a demo router with random details to help you test the system. You can delete it anytime.
                    </div>
                    <ul class="list-unstyled small mb-0">
                        <li><i class="fas fa-check text-success"></i> Auto-generated device name</li>
                        <li><i class="fas fa-check text-success"></i> Random MAC address</li>
                        <li><i class="fas fa-check text-success"></i> Random SSID & password</li>
                        <li><i class="fas fa-check text-success"></i> Dar es Salaam location</li>
                        <li><i class="fas fa-check text-success"></i> Marked as online automatically</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="submit" name="create_sample_router" class="btn btn-success">
                        <i class="fas fa-magic"></i> <?php echo t('create_sample_router'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Copy MAC helper
document.addEventListener('DOMContentLoaded', function() {
    // Auto-uppercase MAC address input
    const macInputs = document.querySelectorAll('input[name="mac_address"]');
    macInputs.forEach(input => {
        input.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
    });
});
</script>

<?php
// ============================================
// ============================================
// CUSTOMER SECTION - Connect to WiFi
// ============================================
// ============================================
} else {

    // --------------------------------------------
    // HANDLE CONNECT WITH VOUCHER
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['connect_voucher'])) {
        $code = strtoupper(trim($_POST['voucher_code'] ?? ''));
        if ($code) {
            $validation = $voucher->validateVoucher($code);
            if ($validation['valid']) {
                $mac = $_POST['mac_address'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                $deviceName = $_POST['device_name'] ?? 'Web Device';
                $result = $voucher->useVoucher($validation['voucher']['id'], $userId, $mac, $_SERVER['REMOTE_ADDR'], $deviceName);
                if ($result['success']) {
                    $msg = '<div class="alert alert-success">
                        <h5><i class="fas fa-wifi"></i> ' . t('connected') . '</h5>
                        <p class="mb-0">' . t('session_expires') . ' <strong>' . date('d M Y H:i', strtotime($result['expires_at'])) . '</strong></p>
                    </div>';
                } else {
                    $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
                }
            } else {
                $msg = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> ' . htmlspecialchars($validation['message']) . '</div>';
            }
        }
    }

    // Get active sessions
    $customerSessions = [];
    try {
        $stmt = $conn->prepare("
            SELECT ws.*, r.device_name as router_name, r.ssid,
                   v.voucher_code, p.name as package_name
            FROM wifi_sessions ws
            LEFT JOIN routers r ON ws.router_id = r.id
            LEFT JOIN vouchers v ON ws.voucher_id = v.id
            LEFT JOIN packages p ON v.package_id = p.id
            WHERE ws.user_id = ? AND ws.status = 'active'
            ORDER BY ws.session_end ASC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $customerSessions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Throwable $e) {}

?>

<!-- ============================================ -->
<!-- CUSTOMER: CONNECT TO WIFI                   -->
<!-- ============================================ -->
<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        
        <div class="text-center mb-4">
            <i class="fas fa-wifi display-4 text-primary"></i>
            <h2 class="mt-2"><?php echo t('connect_to_wifi'); ?></h2>
            <p class="text-muted"><?php echo t('enter_voucher_desc'); ?></p>
        </div>
        
        <?php echo $msg; ?>
        
        <?php if (count($customerSessions) > 0): ?>
        <!-- Active Sessions -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="fas fa-check-circle text-success"></i> <?php echo t('active_sessions'); ?></h5>
            </div>
            <div class="card-body">
                <?php foreach ($customerSessions as $cs): 
                    $minutesRemaining = intval($cs['minutes_remaining'] ?? 0);
                    $timeClass = $minutesRemaining <= 5 ? 'critical' : ($minutesRemaining <= 15 ? 'warning' : 'good');
                ?>
                <div class="session-card mb-2">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div>
                            <strong><i class="fas fa-wifi text-success"></i> <?php echo htmlspecialchars($cs['router_name']); ?></strong>
                            <?php if ($cs['ssid']): ?>
                            <br><small class="text-muted">SSID: <?php echo htmlspecialchars($cs['ssid']); ?></small>
                            <?php endif; ?>
                            <?php if ($cs['voucher_code']): ?>
                            <br><small class="text-muted">Voucher: <code><?php echo htmlspecialchars($cs['voucher_code']); ?></code></small>
                            <?php endif; ?>
                        </div>
                        <div class="text-end">
                            <div class="time-remaining <?php echo $timeClass; ?>">
                                <i class="fas fa-hourglass-half"></i> <?php echo $minutesRemaining; ?>m
                            </div>
                            <small class="text-muted"><?php echo t('time_remaining'); ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Connect Form -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="fas fa-ticket-alt text-success"></i> <?php echo t('enter_voucher'); ?></h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('voucher_code'); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="voucher_code" class="form-control form-control-lg text-center" 
                               placeholder="XXXXXXXXXX" 
                               style="font-family:monospace;letter-spacing:3px;text-transform:uppercase;font-size:1.3rem;"
                               maxlength="20" required autocomplete="off" autofocus>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('device_name'); ?> (<?php echo t('optional'); ?>)</label>
                        <input type="text" name="device_name" class="form-control" 
                               placeholder="e.g., My Phone" value="Web Device">
                    </div>
                    <button type="submit" name="connect_voucher" class="btn btn-success w-100 py-3">
                        <i class="fas fa-wifi"></i> <?php echo t('connect'); ?>
                    </button>
                </form>
                
                <hr class="my-3" style="border-color:var(--border-color);">
                
                <div class="text-center">
                    <small class="text-muted"><?php echo t('already_voucher'); ?></small>
                    <br>
                    <a href="?page=voucher" class="btn btn-primary btn-sm mt-2">
                        <i class="fas fa-shopping-cart"></i> <?php echo t('buy_voucher'); ?>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
            </a>
        </div>
    </div>
</div>

<?php
}
?>