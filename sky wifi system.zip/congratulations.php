<?php
/**
 * ============================================================================
 *  SKYTANZA WIFI — CAPTIVE PORTAL CONGRATULATIONS PAGE
 *  File: congratulations.php
 *
 *  Served after a successful voucher login / purchase on portal.php.
 *  Point Omada's "Redirect URL after successful authentication" at:
 *      https://your-domain/congratulations.php
 *
 *  Omada will append the same query string as portal.php:
 *      ?clientMac=..&apMac=..&ssidName=..&target=..&targetPort=..&scheme=..
 *      &redirectUrl=..&originUrl=..
 *
 *  portal.php also forwards the used voucher as ?code=XXXXXXXX.
 *
 *  Requirements: PHP 8.0+, MySQL 5.7+ / MariaDB 10.3+
 *  Uses config.local.php (same folder) for DB credentials.
 * ============================================================================
 */

declare(strict_types=1);
ob_start();
date_default_timezone_set('Africa/Dar_es_Salaam');

// ---------------------------------------------------------------------------
// CONFIG (identical to portal.php so both files share config.local.php)
// ---------------------------------------------------------------------------
if (is_file(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';

function pcfg(string $name, string $env, $default): void {
    if (defined($name)) return;
    $v = getenv($env);
    define($name, ($v !== false && $v !== '') ? $v : $default);
}

pcfg('DB_HOST', 'SKY_DB_HOST', 'localhost');
pcfg('DB_USER', 'SKY_DB_USER', 'skytanza_wifi');
pcfg('DB_PASS', 'SKY_DB_PASS', '');
pcfg('DB_NAME', 'SKY_DB_NAME', 'skytanza_wifi');

pcfg('SITE_NAME', 'SKY_SITE_NAME', 'SkyTanza WiFi');
pcfg('SITE_URL',  'SKY_SITE_URL',  '');            // auto-detected if empty
pcfg('CURRENCY',  'SKY_CURRENCY',  'TZS');
pcfg('APP_VERSION', 'SKY_APP_VERSION', '1.0');

pcfg('APP_SECRET', 'SKY_APP_SECRET', 'change-me-please-32bytes-secret!!');
pcfg('PAYMENT_WEBHOOK_SECRET', 'SKY_WEBHOOK_SECRET', 'webhook-secret-change-me');

pcfg('SESSION_TIMEOUT', 'SKY_SESSION_TIMEOUT', 3600);

// ---------------------------------------------------------------------------
// HELPERS (identical to portal.php so behaviour matches)
// ---------------------------------------------------------------------------
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($a): string { return CURRENCY . ' ' . number_format((float)$a, 0); }
function normMac($s): string {
    $hex = strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', substr((string)$s, 0, 17)));
    if (strlen($hex) < 12) return '';
    return implode(':', str_split(substr($hex, 0, 12), 2));
}
function fmtSecs(int $s): string {
    if ($s <= 0) return '0 min';
    $d = intdiv($s, 86400); $h = intdiv($s % 86400, 3600); $m = intdiv($s % 3600, 60);
    $out = [];
    if ($d) $out[] = $d . 'd';
    if ($h) $out[] = $h . 'h';
    if ($m || !$out) $out[] = max(1, $m) . 'm';
    return implode(' ', $out);
}
function fmtBytes($b): string {
    $b = (float)$b;
    foreach (['B','KB','MB','GB','TB'] as $u) { if ($b < 1024) return round($b, 1) . ' ' . $u; $b /= 1024; }
    return round($b, 1) . ' PB';
}
function jsonOut($data, int $code = 200): void {
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function portalBaseUrl(): string {
    if (SITE_URL !== '') return rtrim(SITE_URL, '/');
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || ((string)($_SERVER['SERVER_PORT'] ?? '') === '443');
    $host = strtolower(preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    $dir  = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/.');
    return ($host !== '' ? (($https ? 'https' : 'http') . '://' . $host . $dir) : '');
}
function selfPath(): string {
    $uri  = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = parse_url($uri, PHP_URL_PATH);
    if (is_string($path) && $path !== '' && $path[0] === '/') return $path;
    $p = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    return ($p !== '' && $p[0] === '/') ? $p : '/congratulations.php';
}

// ---------------------------------------------------------------------------
// DATABASE
// ---------------------------------------------------------------------------
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+03:00'");
} catch (Throwable $e) {
    error_log('congratulations.php DB connect failed: ' . $e->getMessage());
    http_response_code(500);
    if (isset($_GET['ajax'])) jsonOut(['success' => false, 'message' => 'Database unavailable'], 500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><meta charset="utf-8"><title>Setup</title>'
       . '<div style="font-family:system-ui,Arial,sans-serif;max-width:640px;margin:48px auto;padding:28px;border:1px solid #ccc;border-radius:16px;line-height:1.6">'
       . '<h2 style="margin-top:0">Setup needed / Usanidi unahitajika</h2>'
       . '<p>Create <b>config.local.php</b> next to <b>congratulations.php</b> with your database credentials.</p></div>';
    exit;
}
function db(): mysqli { global $conn; return $conn; }
function q(string $sql, string $types = '', ...$params): mysqli_stmt {
    $st = db()->prepare($sql);
    if ($types !== '') $st->bind_param($types, ...$params);
    $st->execute();
    return $st;
}
function row(string $sql, string $types = '', ...$p): ?array {
    $r = q($sql, $types, ...$p)->get_result();
    return $r ? ($r->fetch_assoc() ?: null) : null;
}
function rows(string $sql, string $types = '', ...$p): array {
    $r = q($sql, $types, ...$p)->get_result();
    return $r ? $r->fetch_all(MYSQLI_ASSOC) : [];
}
function val(string $sql, string $types = '', ...$p) {
    $r = row($sql, $types, ...$p);
    return $r ? reset($r) : null;
}
function run(string $sql, string $types = '', ...$p): int {
    return q($sql, $types, ...$p)->affected_rows;
}

// ---------------------------------------------------------------------------
// LANGUAGE (EN / SW) — same keys as portal.php so the toggle feels native
// ---------------------------------------------------------------------------
$currentLang = $_GET['lang'] ?? 'sw';
if (!in_array($currentLang, ['en','sw'], true)) $currentLang = 'sw';

$T = [
  'en' => [
    'c_connected'   => 'You are connected!',
    'c_subtitle'    => 'Enjoy the internet. Your session is now active.',
    'c_time_left'   => 'Time left',
    'c_data_left'   => 'Data left',
    'c_unlimited'   => 'Unlimited',
    'c_package'     => 'Package',
    'c_voucher'     => 'Voucher code',
    'c_copied'      => 'Copied!',
    'c_open'        => 'Open Internet',
    'c_start'       => 'Start browsing',
    'c_help'        => 'Help',
    'c_powered_by'  => 'Powered by',
    'c_lang'        => 'Language',
    'c_no_code'     => 'Connected successfully.',
    'c_ssid'        => 'Network',
    'c_device'      => 'Your device',
    'c_status'      => 'Status',
    'c_active'      => 'Active',
    'c_expired'     => 'Expired',
    'c_almost'      => 'Almost done',
    'c_tip'         => 'Tip: keep this page open to see live time & data usage.',
  ],
  'sw' => [
    'c_connected'   => 'Umeunganishwa!',
    'c_subtitle'    => 'Karibu mtandaoni. Kipindi chako kinaendelea sasa.',
    'c_time_left'   => 'Muda uliobaki',
    'c_data_left'   => 'Data iliyobaki',
    'c_unlimited'   => 'Bila kikomo',
    'c_package'     => 'Kifurushi',
    'c_voucher'     => 'Msimbo wa vocha',
    'c_copied'      => 'Imenakiliwa!',
    'c_open'        => 'Fungua Intaneti',
    'c_start'       => 'Anza kuvinjari',
    'c_help'        => 'Msaada',
    'c_powered_by'  => 'Inaendeshwa na',
    'c_lang'        => 'Lugha',
    'c_no_code'     => 'Umeunganishwa kwa mafanikio.',
    'c_ssid'        => 'Mtandao',
    'c_device'      => 'Kifaa chako',
    'c_status'      => 'Hali',
    'c_active'      => 'Inaendelea',
    'c_expired'     => 'Imeisha',
    'c_almost'      => 'Inakaribia kwisha',
    'c_tip'         => 'Kidokezo: acha ukurasa huu wazi ili kuona muda na data inayobaki.',
  ],
];
function t(string $k): string {
    global $T, $currentLang;
    return $T[$currentLang][$k] ?? $T['en'][$k] ?? ucfirst(str_replace('_', ' ', $k));
}

// ---------------------------------------------------------------------------
// CAPTIVE PORTAL CONTEXT (same as portal.php)
// ---------------------------------------------------------------------------
$CTX_KEYS = ['clientMac','clientIp','apMac','gatewayMac','ssidName','radioId','vid',
             'scheme','originUrl','redirectUrl','target','targetPort','site','t',
             'hostname','serverPort','chapId','chapChallenge','code'];
$ctx = [];
foreach ($CTX_KEYS as $k) $ctx[$k] = substr(trim((string)($_GET[$k] ?? '')), 0, 600);

$apMac  = normMac($ctx['apMac'] ?? '');
$cliMac = normMac($ctx['clientMac'] ?? '');
$code   = strtoupper(preg_replace('/\s+/', '', (string)($ctx['code'] ?? '')));

// Origin the user originally asked for (used by "Open Internet")
$origin = ($ctx['redirectUrl'] ?? '') ?: (($ctx['originUrl'] ?? '') ?: 'http://www.google.com');
if (!preg_match('#^https?://#i', $origin)) $origin = 'http://www.google.com';
// Strip Omada's own redirect wrapper if present
if (preg_match('#^https?://[^/]*msftconnecttest\.com#i', $origin)) $origin = 'http://www.google.com';
if (preg_match('#^https?://[^/]*gstatic\.com#i', $origin))            $origin = 'http://www.google.com';

// Resolve device + seller
$dev    = $apMac !== '' ? row("SELECT * FROM hs_devices WHERE ap_mac=? AND is_active=1 LIMIT 1", 's', $apMac) : null;
$seller = $dev ? row("SELECT full_name, phone FROM users WHERE id=?", 'i', $dev['user_id']) : null;
$title  = $dev['ssid'] ?? ($ctx['ssidName'] ?? SITE_NAME);

// ---------------------------------------------------------------------------
// VOUCHER LOOKUP (read-only mirror of portal.php's voucherCheck, no commit)
// ---------------------------------------------------------------------------
function voucherRemainingSeconds(array $v): int {
    $dur = (int)$v['duration_minutes'] * 60;
    if ($v['time_mode'] === 'online') return max(0, $dur - (int)$v['seconds_used']);
    if (empty($v['first_used_at'])) return $dur;
    return max(0, strtotime((string)$v['expires_at']) - time());
}
function voucherStatus(string $code, string $mac = '', ?array $dev = null): ?array {
    $code = strtoupper(preg_replace('/\s+/', '', $code));
    if ($code === '' || strlen($code) > 20) return null;
    $v = row("SELECT v.*, p.name AS package_name
              FROM hs_vouchers v
              LEFT JOIN hs_packages p ON p.id = v.package_id
              WHERE v.code = ?", 's', $code);
    if (!$v) return null;

    // Refresh usage counters for online-mode vouchers
    if ($v['time_mode'] === 'online' && $v['first_used_at']) {
        run("UPDATE hs_vouchers v SET
               data_used_bytes = (SELECT COALESCE(SUM(s.bytes_in + s.bytes_out),0) FROM hs_sessions s WHERE s.voucher_id=v.id),
               seconds_used    = (SELECT COALESCE(SUM(s.session_time),0) FROM hs_sessions s WHERE s.voucher_id=v.id)
             WHERE v.id=?", 'i', $v['id']);
        $v = row("SELECT v.*, p.name AS package_name
                  FROM hs_vouchers v
                  LEFT JOIN hs_packages p ON p.id = v.package_id
                  WHERE v.id = ?", 'i', $v['id']) ?: $v;
    }

    $remaining = voucherRemainingSeconds($v);
    $limit     = (int)$v['data_limit_mb'] * 1048576;
    $dataLeft  = $limit > 0 ? max(0, $limit - (int)$v['data_used_bytes']) : null;

    // Compute a friendly status
    $status = 'active';
    if (in_array($v['status'], ['blocked','cancelled','expired','exhausted'], true)) {
        $status = 'expired';
    } elseif ($remaining <= 0) {
        $status = 'expired';
    } elseif ($remaining <= 300) { // 5 min or less
        $status = 'almost';
    } elseif ($limit > 0 && $dataLeft !== null && $dataLeft <= 5 * 1048576) { // 5 MB or less
        $status = 'almost';
    }

    return [
        'ok'         => true,
        'code'       => (string)$v['code'],
        'status'     => $status,
        'remaining'  => $remaining,
        'data_left'  => $dataLeft,
        'package'    => (string)($v['package_name'] ?? ''),
        'time_mode'  => (string)$v['time_mode'],
        'first_used' => !empty($v['first_used_at']),
    ];
}

// ---------------------------------------------------------------------------
// AJAX: live status
// ---------------------------------------------------------------------------
if (isset($_GET['ajax'])) {
    $ajax = (string)$_GET['ajax'];

    if ($ajax === 'ping') jsonOut(['ok' => true, 'version' => APP_VERSION, 'time' => date('c')]);

    if ($ajax === 'status') {
        $qcode = strtoupper(preg_replace('/\s+/', '', (string)($_POST['code'] ?? $_GET['code'] ?? '')));
        if ($qcode === '') jsonOut(['success' => false, 'message' => 'no-code']);
        $r = voucherStatus($qcode, $cliMac, $dev);
        if (!$r) jsonOut(['success' => false, 'message' => 'not-found']);
        jsonOut([
            'success'        => true,
            'code'           => $r['code'],
            'status'         => $r['status'],
            'remaining'      => $r['remaining'],
            'remaining_text' => fmtSecs((int)$r['remaining']),
            'data_left'      => $r['data_left'] === null ? t('c_unlimited') : fmtBytes($r['data_left']),
            'data_left_raw'  => $r['data_left'],
            'package'        => $r['package'],
        ]);
    }

    jsonOut(['success' => false, 'message' => 'Unknown action'], 400);
}

// ---------------------------------------------------------------------------
// PWA ENDPOINTS (independent of portal.php — same shape, same assets)
// ---------------------------------------------------------------------------
if (isset($_GET['pwa'])) {
    while (ob_get_level() > 0) ob_end_clean();
    if ($_GET['pwa'] === 'manifest') {
        header('Content-Type: application/manifest+json');
        header('Cache-Control: public, max-age=86400');
        echo json_encode([
            'name'             => SITE_NAME . ' Portal',
            'short_name'       => 'WiFi',
            'start_url'        => './congratulations.php',
            'scope'            => './',
            'display'          => 'standalone',
            'background_color' => '#060a13',
            'theme_color'      => '#060a13',
            'icons' => [[
                'src'     => 'congratulations.php?pwa=icon',
                'sizes'   => 'any',
                'type'    => 'image/svg+xml',
                'purpose' => 'any maskable',
            ]],
        ]);
        exit;
    }
    if ($_GET['pwa'] === 'sw') {
        header('Content-Type: application/javascript');
        header('Cache-Control: no-cache');
        echo <<<'JS'
const CACHE = 'sky-congrats-v1';
const SHELL = ['./congratulations.php'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(()=>{}));
  self.skipWaiting();
});
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  if (url.searchParams.has('ajax') || url.searchParams.has('pwa')) return;
  e.respondWith(
    fetch(e.request).then(r => {
      const copy = r.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy)).catch(()=>{});
      return r;
    }).catch(() => caches.match(e.request).then(r => r || caches.match('./congratulations.php')))
  );
});
JS;
        exit;
    }
    // Default: icon
    header('Content-Type: image/svg+xml');
    header('Cache-Control: public, max-age=604800, immutable');
    echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">'
       . '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
       . '<stop offset="0" stop-color="#22c55e"/><stop offset="1" stop-color="#5b8cff"/>'
       . '</linearGradient></defs>'
       . '<rect width="512" height="512" rx="112" fill="url(#g)"/>'
       . '<path d="M96 208a224 224 0 0 1 320 0l-36 36a173 173 0 0 0-248 0zm68 68a128 128 0 0 1 184 0l-36 36a77 77 0 0 0-112 0zm92 52 44 44-44 44-44-44z" fill="#fff"/>'
       . '</svg>';
    exit;
}

// ---------------------------------------------------------------------------
// COLLECT DATA FOR THE PAGE
// ---------------------------------------------------------------------------
$status   = $code !== '' ? voucherStatus($code, $cliMac, $dev) : null;
$csrf     = bin2hex(random_bytes(32)); // displayed to JS for the ajax=status call
$hasCode  = $code !== '';
$base     = portalBaseUrl() . selfPath();

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');

while (ob_get_level() > 0) ob_end_clean();
?>
<!DOCTYPE html>
<html lang="<?= h($currentLang) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#060a13">
<meta name="color-scheme" content="dark light">
<meta name="format-detection" content="telephone=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="WiFi">
<link rel="manifest" href="?pwa=manifest">
<link rel="icon" href="?pwa=icon" type="image/svg+xml">
<link rel="apple-touch-icon" href="?pwa=icon">
<title><?= h($title ?: SITE_NAME) ?> — <?= t('c_connected') ?></title>
<style>
:root{
  --bg:#060a13; --card:rgba(15,22,38,.74); --field:rgba(6,10,19,.72);
  --line:rgba(148,163,184,.13); --line-2:rgba(148,163,184,.24);
  --txt:#eef2f9; --mut:#93a3bc;
  --pri:#5b8cff; --pri-2:#8b5cf6; --ok:#22c55e; --ok-2:#16a34a;
  --bad:#f43f5e; --warn:#f59e0b;
  --r:20px; --mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  --shadow:0 30px 60px -32px rgba(0,0,0,.85),inset 0 1px 0 rgba(255,255,255,.05);
}
@media (prefers-color-scheme: light){
  :root{
    --bg:#eef2f9; --card:rgba(255,255,255,.9); --field:rgba(255,255,255,.95);
    --line:rgba(15,23,42,.08); --line-2:rgba(15,23,42,.16);
    --txt:#0e1726; --mut:#5b6779;
    --shadow:0 24px 50px -30px rgba(15,23,42,.35),inset 0 1px 0 rgba(255,255,255,.6);
  }
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0}
body{
  font-family:system-ui,-apple-system,"Segoe UI",Roboto,Inter,"Helvetica Neue",Arial,sans-serif;
  background:var(--bg); color:var(--txt); min-height:100vh; min-height:100dvh;
  -webkit-font-smoothing:antialiased; overflow-x:hidden; line-height:1.45;
}
body::before,body::after{
  content:""; position:fixed; z-index:-1; border-radius:50%;
  filter:blur(80px); pointer-events:none;
}
body::before{width:440px;height:440px;background:var(--ok);top:-180px;left:-140px;opacity:.45}
body::after{width:400px;height:400px;background:var(--pri);bottom:-180px;right:-160px;opacity:.4}

.wrap{max-width:430px;margin:0 auto;padding:30px 18px calc(36px + env(safe-area-inset-bottom))}
.brand{text-align:center;margin:12px 0 24px}
.logo{
  width:88px;height:88px;border-radius:28px;
  background:linear-gradient(135deg,var(--ok),var(--ok-2));
  display:inline-grid;place-items:center;
  box-shadow:0 24px 48px -14px rgba(34,197,94,.75),inset 0 1px 0 rgba(255,255,255,.28);
  animation:pop .5s cubic-bezier(.2,1.4,.4,1) both, float 5s ease-in-out infinite .5s;
}
.logo svg{width:48px;height:48px}
@keyframes pop{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:none}}
@keyframes float{50%{transform:translateY(-6px)}}
h1{font-size:1.65rem;margin:18px 0 6px;letter-spacing:-.025em;font-weight:800}
h2{letter-spacing:-.02em}
.sub{color:var(--mut);font-size:.95rem;margin:0}
.card{
  background:var(--card);
  -webkit-backdrop-filter:blur(20px) saturate(160%);
  backdrop-filter:blur(20px) saturate(160%);
  border:1px solid var(--line); border-radius:var(--r); padding:20px;
  margin-bottom:14px; box-shadow:var(--shadow);
  animation:rise .45s cubic-bezier(.2,.8,.2,1) both;
}
@keyframes rise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.card.hl{ border-color:rgba(34,197,94,.35); box-shadow:0 30px 60px -32px rgba(34,197,94,.55),inset 0 1px 0 rgba(255,255,255,.05); }
.mut{color:var(--mut)}
.ctr{text-align:center}
.big{
  font-size:2.55rem;font-weight:800;text-align:center;margin:6px 0;
  letter-spacing:-.035em;
  background:linear-gradient(135deg,#bbf7d0,#22c55e);
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
@media (prefers-color-scheme: light){
  .big{background:linear-gradient(135deg,#166534,#22c55e);-webkit-background-clip:text;background-clip:text}
}
.big.warn{background:linear-gradient(135deg,#fde68a,#f59e0b);-webkit-background-clip:text;background-clip:text}
.big.bad{background:linear-gradient(135deg,#fecdd3,#f43f5e);-webkit-background-clip:text;background-clip:text}
.stat{
  display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;
}
.stat > div{
  border:1px solid var(--line-2); border-radius:14px; padding:12px;
  background:var(--field); text-align:center;
}
.stat .k{ color:var(--mut); font-size:.74rem; text-transform:uppercase; letter-spacing:.06em; font-weight:700; }
.stat .v{ font-size:1.15rem; font-weight:800; margin-top:4px; letter-spacing:-.01em; }
.vc{
  font-family:var(--mono);letter-spacing:.28em;font-size:1.55rem;font-weight:800;
  text-align:center;padding:14px;border:2px dashed rgba(34,197,94,.6);
  border-radius:14px;margin:12px 0;background:rgba(34,197,94,.08);
  cursor:pointer; user-select:all; -webkit-user-select:all;
  transition:transform .12s, border-color .18s;
}
.vc:active{transform:scale(.985)}
.vc:hover{border-color:var(--ok)}
.btn{
  display:block; width:100%; border:0; border-radius:14px; padding:16px;
  font-size:1.06rem; font-weight:800; letter-spacing:.01em;
  background:linear-gradient(135deg,var(--ok),var(--ok-2));
  color:#fff; margin-top:14px; cursor:pointer; font-family:inherit;
  text-align:center; box-shadow:0 16px 30px -14px rgba(34,197,94,.85);
  transition:transform .12s,filter .15s,opacity .15s;
  text-decoration:none;
}
.btn:hover{filter:brightness(1.08)}
.btn:active{transform:scale(.985)}
.btn.ghost{background:transparent;border:1px solid var(--line-2);color:var(--txt);box-shadow:none}
.chip{
  display:inline-flex;align-items:center;gap:6px;
  padding:5px 11px;border-radius:999px;font-size:.76rem;font-weight:800;
  letter-spacing:.03em;border:1px solid;text-transform:uppercase;
}
.chip.ok   { background:rgba(34,197,94,.14); border-color:rgba(34,197,94,.45); color:#86efac; }
.chip.warn { background:rgba(245,158,11,.14);border-color:rgba(245,158,11,.45);color:#fcd34d; }
.chip.bad  { background:rgba(244,63,94,.14); border-color:rgba(244,63,94,.45); color:#fda4af; }
.foot{text-align:center;color:var(--mut);font-size:.8rem;margin-top:22px;opacity:.85}
.foot a{color:var(--txt);text-decoration:none;font-weight:600}
.hide{display:none!important}
.row{display:flex;gap:10px}
.row .btn{margin-top:10px}
.lang{
  position:fixed;top:calc(12px + env(safe-area-inset-top));right:12px;z-index:5;
  display:flex;gap:2px;background:rgba(8,13,25,.75);
  -webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);
  border:1px solid var(--line);border-radius:12px;padding:3px;
}
.lang a{
  color:var(--mut);text-decoration:none;font-size:.74rem;font-weight:800;
  padding:6px 10px;border-radius:9px;letter-spacing:.04em;
}
.lang a.on{background:var(--pri);color:#fff}
.toast{
  position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(20px);
  background:rgba(34,197,94,.95);color:#fff;padding:10px 16px;border-radius:12px;
  font-weight:700;font-size:.85rem;opacity:0;pointer-events:none;
  transition:opacity .25s, transform .25s; z-index:20;
}
.toast.on{opacity:1;transform:translateX(-50%) translateY(0)}
@media (prefers-color-scheme: light){
  .lang{background:rgba(255,255,255,.85)}
  .lang a{color:var(--mut)}
}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="lang">
  <a href="?lang=sw&code=<?= h($code) ?>" class="<?= $currentLang === 'sw' ? 'on' : '' ?>">SW</a>
  <a href="?lang=en&code=<?= h($code) ?>" class="<?= $currentLang === 'en' ? 'on' : '' ?>">EN</a>
</div>

<div class="wrap">
  <div class="brand">
    <div class="logo">
      <svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true">
        <path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/>
      </svg>
    </div>
    <h1><?= t('c_connected') ?></h1>
    <p class="sub"><?= t('c_subtitle') ?></p>
  </div>

  <div class="card hl ctr" id="statusCard"
       data-code="<?= h($code) ?>"
       data-base="<?= h($base) ?>">
    <?php if ($hasCode && $status): ?>
      <div id="statusChip" class="chip <?= $status['status'] === 'active' ? 'ok' : ($status['status'] === 'almost' ? 'warn' : 'bad') ?>">
        <?= $status['status'] === 'active' ? t('c_active') : ($status['status'] === 'almost' ? t('c_almost') : t('c_expired')) ?>
      </div>
      <div class="mut" style="margin-top:14px"><?= t('c_time_left') ?></div>
      <div class="big<?= $status['status'] === 'almost' ? ' warn' : ($status['status'] === 'expired' ? ' bad' : '') ?>" id="leftBig">
        <?= h(fmtSecs((int)$status['remaining'])) ?>
      </div>
      <div class="stat">
        <div>
          <div class="k"><?= t('c_data_left') ?></div>
          <div class="v" id="dataLeftV"><?= $status['data_left'] === null ? h(t('c_unlimited')) : h(fmtBytes($status['data_left'])) ?></div>
        </div>
        <div>
          <div class="k"><?= t('c_package') ?></div>
          <div class="v" id="packageV" style="font-size:1rem"><?= h($status['package'] !== '' ? $status['package'] : '—') ?></div>
        </div>
      </div>
      <div style="margin-top:16px" class="mut" id="voucherLabel"><?= t('c_voucher') ?></div>
      <div class="vc" id="voucherCode" title="<?= t('c_copied') ?>"><?= h($code) ?></div>
    <?php else: ?>
      <div id="statusChip" class="chip ok"><?= t('c_active') ?></div>
      <div class="mut" style="margin-top:14px"><?= t('c_no_code') ?></div>
      <div class="stat">
        <div>
          <div class="k"><?= t('c_ssid') ?></div>
          <div class="v" style="font-size:1rem"><?= h($title) ?></div>
        </div>
        <div>
          <div class="k"><?= t('c_device') ?></div>
          <div class="v" style="font-size:.85rem;font-family:var(--mono)"><?= h($cliMac !== '' ? $cliMac : '—') ?></div>
        </div>
      </div>
    <?php endif; ?>

    <a class="btn" id="openBtn" href="<?= h($origin) ?>" rel="noopener">
      <?= t('c_open') ?> →
    </a>
    <div class="mut" style="font-size:.78rem;margin-top:10px"><?= t('c_tip') ?></div>
  </div>

  <div class="foot">
    <?php if ($seller): ?>
      <?= t('c_help') ?>: <a href="tel:<?= h($seller['phone']) ?>"><?= h($seller['phone']) ?></a> •
    <?php endif; ?>
    <?= t('c_powered_by') ?> <b><?= h(SITE_NAME) ?></b>
  </div>
</div>

<div class="toast" id="toast"><?= t('c_copied') ?></div>

<script>
(function(){
  'use strict';

  var CODE = <?= json_encode($code) ?>;
  var BASE = <?= json_encode($base) ?>;
  var L = {
    copied:   <?= json_encode(t('c_copied')) ?>,
    active:   <?= json_encode(t('c_active')) ?>,
    almost:   <?= json_encode(t('c_almost')) ?>,
    expired:  <?= json_encode(t('c_expired')) ?>,
    unlimited:<?= json_encode(t('c_unlimited')) ?>
  };

  var $ = function(id){ return document.getElementById(id); };
  var leftBig = $('leftBig');
  var dataV   = $('dataLeftV');
  var pkgV    = $('packageV');
  var chip    = $('statusChip');

  function toast(text){
    var el = $('toast'); if (!el) return;
    el.textContent = text;
    el.classList.add('on');
    setTimeout(function(){ el.classList.remove('on'); }, 1400);
  }

  function copyCode(){
    if (!CODE) return;
    var done = function(){ toast(L.copied); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(CODE).then(done).catch(function(){ fallbackCopy(CODE, done); });
    } else {
      fallbackCopy(CODE, done);
    }
  }
  function fallbackCopy(text, cb){
    try {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly','');
      ta.style.position = 'absolute'; ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select(); ta.setSelectionRange(0, ta.value.length);
      document.execCommand('copy');
      document.body.removeChild(ta);
      cb && cb();
    } catch(e){}
  }
  var vc = $('voucherCode');
  if (vc) vc.addEventListener('click', copyCode);

  function applyStatus(d){
    if (!d || !d.success) return;
    if (leftBig) {
      leftBig.textContent = d.remaining_text || '—';
      leftBig.classList.remove('warn','bad');
      if (d.status === 'almost') leftBig.classList.add('warn');
      if (d.status === 'expired') leftBig.classList.add('bad');
    }
    if (dataV) dataV.textContent = d.data_left || L.unlimited;
    if (pkgV && d.package) pkgV.textContent = d.package;
    if (chip) {
      chip.classList.remove('ok','warn','bad');
      if (d.status === 'active') { chip.classList.add('ok');   chip.textContent = L.active; }
      else if (d.status === 'almost') { chip.classList.add('warn'); chip.textContent = L.almost; }
      else { chip.classList.add('bad'); chip.textContent = L.expired; }
    }
  }

  function refresh(){
    if (!CODE) return;
    var fd = new FormData();
    fd.append('code', CODE);
    fetch(BASE + '?ajax=status', {
      method: 'POST',
      body: fd,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'fetch' }
    }).then(function(r){ return r.json(); })
      .then(applyStatus)
      .catch(function(){});
  }

  if (CODE) {
    refresh();
    setInterval(refresh, 30000);
  }

  // Persist this voucher locally so portal.php resumes it next time
  if (CODE) {
    try { localStorage.setItem('sky_voucher', CODE); } catch(e){}
  }

  // Register service worker (PWA shell)
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function(){
      navigator.serviceWorker.register(BASE + '?pwa=sw').catch(function(){});
    });
  }
})();
</script>
</body>
</html>