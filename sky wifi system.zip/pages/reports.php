<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Reports Page - Loaded from external file
 * 
 * Generate comprehensive reports: sales, revenue, vouchers, routers, customers.
 * All reports support date range filtering, CSV export, and print.
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE CSV EXPORTS
// ============================================
if (isset($_GET['export'])) {
    $exportType = $_GET['export'];
    $dateFrom = $_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
    $dateTo = $_GET['to'] ?? date('Y-m-d');
    
    // Validate dates
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) $dateFrom = date('Y-m-d', strtotime('-30 days'));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) $dateTo = date('Y-m-d');
    if ($dateFrom > $dateTo) {
        $temp = $dateFrom;
        $dateFrom = $dateTo;
        $dateTo = $temp;
    }
    
    while (ob_get_level() > 0) ob_end_clean();
    
    // --------------------------------------------
    // SALES REPORT
    // --------------------------------------------
    if ($exportType === 'sales') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="sales_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT p.id, p.created_at, p.amount, p.payment_method, p.payment_status,
                   p.phone_number, p.order_id, p.transaction_id,
                   v.voucher_code, pkg.name as package_name, r.device_name as router_name
            FROM payments p
            LEFT JOIN vouchers v ON p.voucher_id = v.id
            LEFT JOIN packages pkg ON v.package_id = pkg.id
            LEFT JOIN routers r ON pkg.router_id = r.id
            WHERE p.seller_id = ? AND DATE(p.created_at) BETWEEN ? AND ?
            ORDER BY p.created_at DESC
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'ID', 'Date', 'Amount', 'Method', 'Status',
            'Phone', 'Order ID', 'Transaction ID',
            'Voucher', 'Package', 'Router'
        ]);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['id'],
                $row['created_at'],
                $row['amount'],
                $row['payment_method'] ?? '',
                $row['payment_status'],
                $row['phone_number'] ?? '',
                $row['order_id'] ?? '',
                $row['transaction_id'] ?? '',
                $row['voucher_code'] ?? '',
                $row['package_name'] ?? '',
                $row['router_name'] ?? ''
            ]);
        }
        fclose($output);
        exit;
    }
    
    // --------------------------------------------
    // REVENUE REPORT
    // --------------------------------------------
    if ($exportType === 'revenue') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="revenue_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT DATE(created_at) as report_date,
                   COUNT(*) as total_sales,
                   COUNT(DISTINCT phone_number) as unique_customers,
                   SUM(CASE WHEN payment_method = 'mpesa' THEN amount ELSE 0 END) as mpesa_amount,
                   SUM(CASE WHEN payment_method = 'tigopesa' THEN amount ELSE 0 END) as tigopesa_amount,
                   SUM(CASE WHEN payment_method = 'airtelmoney' THEN amount ELSE 0 END) as airtelmoney_amount,
                   SUM(CASE WHEN payment_method = 'halopesa' THEN amount ELSE 0 END) as halopesa_amount,
                   SUM(CASE WHEN payment_method NOT IN ('mpesa','tigopesa','airtelmoney','halopesa') THEN amount ELSE 0 END) as other_amount,
                   COALESCE(SUM(amount), 0) as total_revenue
            FROM payments
            WHERE seller_id = ? AND payment_status = 'completed'
            AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY DATE(created_at)
            ORDER BY report_date DESC
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'Date', 'Sales', 'Customers',
            'M-Pesa', 'Tigo Pesa', 'Airtel Money', 'HaloPesa', 'Other', 'Total'
        ]);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['report_date'],
                $row['total_sales'],
                $row['unique_customers'],
                $row['mpesa_amount'],
                $row['tigopesa_amount'],
                $row['airtelmoney_amount'],
                $row['halopesa_amount'],
                $row['other_amount'],
                $row['total_revenue']
            ]);
        }
        fclose($output);
        exit;
    }
    
    // --------------------------------------------
    // VOUCHER REPORT
    // --------------------------------------------
    if ($exportType === 'vouchers') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="voucher_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT v.voucher_code, v.price, v.duration_minutes, v.status,
                   v.created_at, v.sold_at, v.used_at, v.expires_at,
                   pkg.name as package_name, r.device_name as router_name,
                   u.full_name as customer_name, u.phone as customer_phone
            FROM vouchers v
            JOIN packages pkg ON v.package_id = pkg.id
            JOIN routers r ON pkg.router_id = r.id
            LEFT JOIN users u ON v.sold_to = u.id
            WHERE v.seller_id = ? AND DATE(v.created_at) BETWEEN ? AND ?
            ORDER BY v.created_at DESC
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'Voucher Code', 'Package', 'Router', 'Price', 'Duration',
            'Status', 'Created', 'Sold', 'Used', 'Expires',
            'Customer', 'Customer Phone'
        ]);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['voucher_code'],
                $row['package_name'],
                $row['router_name'],
                $row['price'],
                $row['duration_minutes'],
                $row['status'],
                $row['created_at'],
                $row['sold_at'] ?? '',
                $row['used_at'] ?? '',
                $row['expires_at'] ?? '',
                $row['customer_name'] ?? '',
                $row['customer_phone'] ?? ''
            ]);
        }
        fclose($output);
        exit;
    }
    
    // --------------------------------------------
    // ROUTER REPORT
    // --------------------------------------------
    if ($exportType === 'routers') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="router_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT r.id, r.device_name, r.ssid, r.mac_address, r.ip_address,
                   r.status, r.location, r.last_seen,
                   (SELECT COUNT(*) FROM packages p WHERE p.router_id = r.id) as package_count,
                   (SELECT COUNT(*) FROM vouchers v JOIN packages p ON v.package_id = p.id WHERE p.router_id = r.id) as voucher_count,
                   (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id) as total_sessions,
                   (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id AND ws.status = 'active') as active_sessions,
                   (SELECT COALESCE(SUM(pay.amount), 0) FROM payments pay 
                    JOIN vouchers v ON pay.voucher_id = v.id 
                    JOIN packages p ON v.package_id = p.id 
                    WHERE p.router_id = r.id AND pay.payment_status = 'completed'
                    AND DATE(pay.created_at) BETWEEN ? AND ?) as revenue
            FROM routers r
            WHERE r.user_id = ?
            ORDER BY r.created_at DESC
        ");
        $stmt->bind_param("ssi", $dateFrom, $dateTo, $userId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'ID', 'Router', 'SSID', 'MAC', 'IP',
            'Status', 'Location', 'Last Seen',
            'Packages', 'Vouchers', 'Total Sessions', 'Active Sessions', 'Revenue'
        ]);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['id'],
                $row['device_name'],
                $row['ssid'] ?? '',
                $row['mac_address'],
                $row['ip_address'] ?? '',
                $row['status'],
                $row['location'] ?? '',
                $row['last_seen'] ?? '',
                $row['package_count'],
                $row['voucher_count'],
                $row['total_sessions'],
                $row['active_sessions'],
                $row['revenue']
            ]);
        }
        fclose($output);
        exit;
    }
    
    // --------------------------------------------
    // CUSTOMER REPORT
    // --------------------------------------------
    if ($exportType === 'customers') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="customer_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT phone_number, COUNT(*) as total_purchases, 
                   COALESCE(SUM(amount), 0) as total_spent,
                   MIN(created_at) as first_purchase,
                   MAX(created_at) as last_purchase,
                   COALESCE(AVG(amount), 0) as avg_purchase
            FROM payments
            WHERE seller_id = ? AND payment_status = 'completed' 
            AND phone_number IS NOT NULL
            AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY phone_number
            ORDER BY total_spent DESC
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'Phone Number', 'Total Purchases', 'Total Spent', 'Avg. Purchase',
            'First Purchase', 'Last Purchase'
        ]);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['phone_number'],
                $row['total_purchases'],
                $row['total_spent'],
                round($row['avg_purchase'], 2),
                $row['first_purchase'],
                $row['last_purchase']
            ]);
        }
        fclose($output);
        exit;
    }
    
    // --------------------------------------------
    // SESSION REPORT
    // --------------------------------------------
    if ($exportType === 'sessions') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="session_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT ws.id, ws.mac_address, ws.device_name, ws.ip_address,
                   ws.session_start, ws.session_end, ws.duration_minutes,
                   ws.data_used_mb, ws.status, ws.is_manually_adjusted, ws.adjustment_count,
                   r.device_name as router_name, v.voucher_code, pkg.name as package_name,
                   u.full_name as user_name, u.phone as user_phone
            FROM wifi_sessions ws
            JOIN routers r ON ws.router_id = r.id
            LEFT JOIN vouchers v ON ws.voucher_id = v.id
            LEFT JOIN packages pkg ON v.package_id = pkg.id
            LEFT JOIN users u ON ws.user_id = u.id
            WHERE r.user_id = ? AND DATE(ws.created_at) BETWEEN ? AND ?
            ORDER BY ws.created_at DESC
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'Session ID', 'MAC', 'Device', 'IP', 'Router', 'Voucher', 'Package',
            'User', 'Phone', 'Start', 'End', 'Duration (min)', 'Data Used (MB)',
            'Status', 'Adjusted', 'Adjustments'
        ]);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['id'],
                $row['mac_address'],
                $row['device_name'] ?? '',
                $row['ip_address'] ?? '',
                $row['router_name'],
                $row['voucher_code'] ?? '',
                $row['package_name'] ?? '',
                $row['user_name'] ?? 'Guest',
                $row['user_phone'] ?? '',
                $row['session_start'],
                $row['session_end'] ?? '',
                $row['duration_minutes'],
                $row['data_used_mb'],
                $row['status'],
                $row['is_manually_adjusted'] ? 'Yes' : 'No',
                $row['adjustment_count']
            ]);
        }
        fclose($output);
        exit;
    }
    
    // --------------------------------------------
    // PAYMENT METHODS REPORT
    // --------------------------------------------
    if ($exportType === 'payment_methods') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="payment_methods_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT payment_method,
                   COUNT(*) as total_transactions,
                   COALESCE(SUM(amount), 0) as total_amount,
                   COALESCE(AVG(amount), 0) as avg_amount
            FROM payments
            WHERE seller_id = ? AND payment_status = 'completed'
            AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY payment_method
            ORDER BY total_amount DESC
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Payment Method', 'Transactions', 'Total Amount', 'Average Amount']);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['payment_method'],
                $row['total_transactions'],
                $row['total_amount'],
                round($row['avg_amount'], 2)
            ]);
        }
        fclose($output);
        exit;
    }
    
    // --------------------------------------------
    // FULL SUMMARY REPORT
    // --------------------------------------------
    if ($exportType === 'summary') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="summary_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        fputcsv($output, ['SKYTANZA WIFI - SUMMARY REPORT']);
        fputcsv($output, ['Generated:', date('Y-m-d H:i:s')]);
        fputcsv($output, ['Date Range:', $dateFrom . ' to ' . $dateTo]);
        fputcsv($output, ['Seller:', $user['full_name'] . ' (' . $user['username'] . ')']);
        fputcsv($output, []);
        
        // Overall stats
        $stmt = $conn->prepare("
            SELECT 
                COUNT(*) as total_sales,
                COALESCE(SUM(amount), 0) as total_revenue,
                COUNT(DISTINCT phone_number) as unique_customers,
                COALESCE(AVG(amount), 0) as avg_sale
            FROM payments
            WHERE seller_id = ? AND payment_status = 'completed'
            AND DATE(created_at) BETWEEN ? AND ?
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $overall = $stmt->get_result()->fetch_assoc();
        
        fputcsv($output, ['OVERALL SUMMARY']);
        fputcsv($output, ['Total Sales', $overall['total_sales']]);
        fputcsv($output, ['Total Revenue', $overall['total_revenue']]);
        fputcsv($output, ['Unique Customers', $overall['unique_customers']]);
        fputcsv($output, ['Average Sale', round($overall['avg_sale'], 2)]);
        fputcsv($output, []);
        
        // Vouchers
        $stmt = $conn->prepare("
            SELECT status, COUNT(*) as count
            FROM vouchers
            WHERE seller_id = ? AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY status
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $vouchers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        fputcsv($output, ['VOUCHER BREAKDOWN']);
        fputcsv($output, ['Status', 'Count']);
        foreach ($vouchers as $v) {
            fputcsv($output, [$v['status'], $v['count']]);
        }
        fputcsv($output, []);
        
        // Payment methods
        $stmt = $conn->prepare("
            SELECT payment_method, COUNT(*) as count, COALESCE(SUM(amount), 0) as total
            FROM payments
            WHERE seller_id = ? AND payment_status = 'completed'
            AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY payment_method
            ORDER BY total DESC
        ");
        $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
        $stmt->execute();
        $methods = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        fputcsv($output, ['PAYMENT METHODS']);
        fputcsv($output, ['Method', 'Transactions', 'Total Amount']);
        foreach ($methods as $m) {
            fputcsv($output, [$m['payment_method'], $m['count'], $m['total']]);
        }
        fputcsv($output, []);
        
        // Top packages
        $stmt = $conn->prepare("
            SELECT p.name, COUNT(pay.id) as sales, COALESCE(SUM(pay.amount), 0) as revenue
            FROM packages p
            LEFT JOIN vouchers v ON v.package_id = p.id
            LEFT JOIN payments pay ON pay.voucher_id = v.id AND pay.payment_status = 'completed'
                AND DATE(pay.created_at) BETWEEN ? AND ?
            WHERE p.seller_id = ?
            GROUP BY p.id
            HAVING sales > 0
            ORDER BY revenue DESC
            LIMIT 10
        ");
        $stmt->bind_param("ssi", $dateFrom, $dateTo, $userId);
        $stmt->execute();
        $packages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        fputcsv($output, ['TOP PACKAGES']);
        fputcsv($output, ['Package', 'Sales', 'Revenue']);
        foreach ($packages as $p) {
            fputcsv($output, [$p['name'], $p['sales'], $p['revenue']]);
        }
        
        fclose($output);
        exit;
    }
}

// ============================================
// FETCH REPORT FILTERS
// ============================================
$dateFrom = $_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
$dateTo = $_GET['to'] ?? date('Y-m-d');

// Validate
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) $dateFrom = date('Y-m-d', strtotime('-30 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) $dateTo = date('Y-m-d');
if ($dateFrom > $dateTo) {
    $temp = $dateFrom;
    $dateFrom = $dateTo;
    $dateTo = $temp;
}
$activeTab = $_GET['tab'] ?? 'sales';

// ============================================
// SALES SUMMARY
// ============================================
$salesSummary = [
    'total_sales' => 0,
    'total_revenue' => 0,
    'unique_customers' => 0,
    'avg_sale' => 0
];
try {
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_sales,
            COALESCE(SUM(amount), 0) as total_revenue,
            COUNT(DISTINCT phone_number) as unique_customers,
            COALESCE(AVG(amount), 0) as avg_sale
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND DATE(created_at) BETWEEN ? AND ?
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $salesSummary = $stmt->get_result()->fetch_assoc();
} catch (Throwable $e) {}

// ============================================
// SALES REPORT DATA (daily)
// ============================================
$salesReportData = [];
try {
    $stmt = $conn->prepare("
        SELECT DATE(created_at) as sale_date,
               COUNT(*) as total_sales,
               COUNT(DISTINCT phone_number) as customers,
               COALESCE(SUM(amount), 0) as revenue
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY sale_date DESC
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $salesReportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// REVENUE BY PAYMENT METHOD
// ============================================
$revenueByMethod = [];
try {
    $stmt = $conn->prepare("
        SELECT payment_method,
               COUNT(*) as count,
               COALESCE(SUM(amount), 0) as total
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY payment_method
        ORDER BY total DESC
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $revenueByMethod = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// VOUCHER REPORT DATA
// ============================================
$voucherReportData = [];
try {
    $stmt = $conn->prepare("
        SELECT v.id, v.voucher_code, v.price, v.duration_minutes, v.status,
               v.created_at, v.sold_at, v.used_at,
               pkg.name as package_name, r.device_name as router_name,
               u.full_name as customer_name, u.phone as customer_phone
        FROM vouchers v
        JOIN packages pkg ON v.package_id = pkg.id
        JOIN routers r ON pkg.router_id = r.id
        LEFT JOIN users u ON v.sold_to = u.id
        WHERE v.seller_id = ? AND DATE(v.created_at) BETWEEN ? AND ?
        ORDER BY v.created_at DESC
        LIMIT 500
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $voucherReportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// Voucher status summary
$voucherStats = ['available' => 0, 'sold' => 0, 'used' => 0, 'expired' => 0, 'cancelled' => 0];
try {
    $stmt = $conn->prepare("
        SELECT status, COUNT(*) as count
        FROM vouchers
        WHERE seller_id = ? AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY status
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    foreach ($rows as $r) {
        $voucherStats[$r['status']] = $r['count'];
    }
} catch (Throwable $e) {}

// ============================================
// ROUTER REPORT DATA
// ============================================
$routerReportData = [];
try {
    $stmt = $conn->prepare("
        SELECT r.id, r.device_name, r.ssid, r.mac_address, r.status, r.location,
               (SELECT COUNT(*) FROM packages p WHERE p.router_id = r.id) as package_count,
               (SELECT COUNT(*) FROM vouchers v JOIN packages p ON v.package_id = p.id WHERE p.router_id = r.id) as voucher_count,
               (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id) as total_sessions,
               (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id AND ws.status = 'active') as active_sessions,
               (SELECT COALESCE(SUM(pay.amount), 0) FROM payments pay 
                JOIN vouchers v ON pay.voucher_id = v.id 
                JOIN packages p ON v.package_id = p.id 
                WHERE p.router_id = r.id AND pay.payment_status = 'completed'
                AND DATE(pay.created_at) BETWEEN ? AND ?) as revenue
        FROM routers r
        WHERE r.user_id = ?
        ORDER BY revenue DESC
    ");
    $stmt->bind_param("ssi", $dateFrom, $dateTo, $userId);
    $stmt->execute();
    $routerReportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// CUSTOMER REPORT DATA
// ============================================
$customerReportData = [];
try {
    $stmt = $conn->prepare("
        SELECT phone_number, COUNT(*) as purchases, 
               COALESCE(SUM(amount), 0) as total_spent,
               COALESCE(AVG(amount), 0) as avg_spent,
               MIN(created_at) as first_purchase,
               MAX(created_at) as last_purchase
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed' AND phone_number IS NOT NULL
        AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY phone_number
        ORDER BY total_spent DESC
        LIMIT 200
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $customerReportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// SESSION REPORT DATA
// ============================================
$sessionReportData = [];
try {
    $stmt = $conn->prepare("
        SELECT ws.id, ws.mac_address, ws.device_name, ws.session_start, ws.session_end,
               ws.duration_minutes, ws.data_used_mb, ws.status, ws.is_manually_adjusted,
               r.device_name as router_name, v.voucher_code
        FROM wifi_sessions ws
        JOIN routers r ON ws.router_id = r.id
        LEFT JOIN vouchers v ON ws.voucher_id = v.id
        WHERE r.user_id = ? AND DATE(ws.created_at) BETWEEN ? AND ?
        ORDER BY ws.created_at DESC
        LIMIT 500
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $sessionReportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// TOP PACKAGES
// ============================================
$topPackages = [];
try {
    $stmt = $conn->prepare("
        SELECT p.name, p.price, COUNT(pay.id) as sales, COALESCE(SUM(pay.amount), 0) as revenue
        FROM packages p
        LEFT JOIN vouchers v ON v.package_id = p.id
        LEFT JOIN payments pay ON pay.voucher_id = v.id AND pay.payment_status = 'completed'
            AND DATE(pay.created_at) BETWEEN ? AND ?
        WHERE p.seller_id = ?
        GROUP BY p.id
        HAVING sales > 0
        ORDER BY revenue DESC
        LIMIT 10
    ");
    $stmt->bind_param("ssi", $dateFrom, $dateTo, $userId);
    $stmt->execute();
    $topPackages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// TIME-OF-DAY DISTRIBUTION
// ============================================
$hourlyDistribution = [];
try {
    $stmt = $conn->prepare("
        SELECT HOUR(created_at) as hour_of_day, COUNT(*) as count, COALESCE(SUM(amount), 0) as revenue
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY HOUR(created_at)
        ORDER BY hour_of_day ASC
    ");
    $stmt->bind_param("iss", $userId, $dateFrom, $dateTo);
    $stmt->execute();
    $hourlyRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    $hourlyMap = [];
    foreach ($hourlyRows as $r) {
        $hourlyMap[$r['hour_of_day']] = $r;
    }
    for ($h = 0; $h < 24; $h++) {
        $hourlyDistribution[] = [
            'hour' => $h,
            'count' => $hourlyMap[$h]['count'] ?? 0,
            'revenue' => $hourlyMap[$h]['revenue'] ?? 0
        ];
    }
} catch (Throwable $e) {}

// Determine max for chart
$maxHourlyCount = 1;
foreach ($hourlyDistribution as $hd) {
    if ($hd['count'] > $maxHourlyCount) $maxHourlyCount = $hd['count'];
}

// ============================================
// HELPER FUNCTIONS
// ============================================
function formatDuration($minutes) {
    $minutes = intval($minutes);
    if ($minutes < 60) return $minutes . 'm';
    if ($minutes < 1440) return round($minutes / 60, 1) . 'h';
    return round($minutes / 1440, 1) . 'd';
}

function formatData($mb) {
    if ($mb < 1024) return round($mb, 0) . ' MB';
    if ($mb < 1024 * 1024) return round($mb / 1024, 1) . ' GB';
    return round($mb / 1024 / 1024, 2) . ' TB';
}

function methodLabel($method) {
    $map = [
        'mpesa' => 'M-Pesa',
        'tigopesa' => 'Tigo Pesa',
        'airtelmoney' => 'Airtel Money',
        'halopesa' => 'HaloPesa',
        'crdb' => 'CRDB Bank',
        'nmb' => 'NMB Bank',
        'selcom' => 'Selcom',
        'bank' => 'Bank Transfer'
    ];
    return $map[$method] ?? ucfirst($method);
}

?>

<!-- ============================================ -->
<!-- REPORTS HEADER                              -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-file-alt"></i> <?php echo t('reports'); ?></h2>
        <small class="text-muted">Generate and export detailed business reports</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <div class="dropdown">
            <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-download"></i> <?php echo t('export'); ?> CSV
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><h6 class="dropdown-header">Export Reports</h6></li>
                <li><a class="dropdown-item" href="?page=reports&export=summary&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-file-invoice text-primary"></i> Full Summary Report
                </a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="?page=reports&export=sales&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-shopping-cart text-primary"></i> <?php echo t('sales_report'); ?>
                </a></li>
                <li><a class="dropdown-item" href="?page=reports&export=revenue&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-money-bill-wave text-success"></i> <?php echo t('revenue_report'); ?>
                </a></li>
                <li><a class="dropdown-item" href="?page=reports&export=vouchers&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-ticket-alt text-warning"></i> <?php echo t('voucher_report'); ?>
                </a></li>
                <li><a class="dropdown-item" href="?page=reports&export=routers&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-wifi text-info"></i> <?php echo t('router_report'); ?>
                </a></li>
                <li><a class="dropdown-item" href="?page=reports&export=customers&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-users text-danger"></i> Customer Report
                </a></li>
                <li><a class="dropdown-item" href="?page=reports&export=sessions&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-clock text-secondary"></i> Session Report
                </a></li>
                <li><a class="dropdown-item" href="?page=reports&export=payment_methods&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>">
                    <i class="fas fa-credit-card text-primary"></i> Payment Methods
                </a></li>
            </ul>
        </div>
        <button class="btn btn-outline-info btn-sm" onclick="window.print()">
            <i class="fas fa-print"></i> <?php echo t('print'); ?>
        </button>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- DATE RANGE FILTER                           -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-end">
            <input type="hidden" name="page" value="reports">
            <input type="hidden" name="tab" value="<?php echo htmlspecialchars($activeTab); ?>">
            
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-calendar"></i> <?php echo t('from'); ?></label>
                <input type="date" name="from" class="form-control form-control-sm" value="<?php echo htmlspecialchars($dateFrom); ?>">
            </div>
            
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-calendar"></i> <?php echo t('to'); ?></label>
                <input type="date" name="to" class="form-control form-control-sm" value="<?php echo htmlspecialchars($dateTo); ?>">
            </div>
            
            <div class="col-md-3 col-6">
                <button type="submit" class="btn btn-primary btn-sm w-100">
                    <i class="fas fa-filter"></i> <?php echo t('filter'); ?>
                </button>
            </div>
            
            <div class="col-md-3 col-6">
                <a href="?page=reports" class="btn btn-outline-secondary btn-sm w-100">
                    <i class="fas fa-times"></i> <?php echo t('reset'); ?>
                </a>
            </div>
        </form>
        
        <!-- Quick Date Ranges -->
        <div class="mt-2 d-flex gap-2 flex-wrap align-items-center">
            <small class="text-muted">Quick:</small>
            <a href="?page=reports&from=<?php echo date('Y-m-d'); ?>&to=<?php echo date('Y-m-d'); ?>&tab=<?php echo $activeTab; ?>" 
               class="btn btn-sm btn-outline-info">Today</a>
            <a href="?page=reports&from=<?php echo date('Y-m-d', strtotime('-1 day')); ?>&to=<?php echo date('Y-m-d', strtotime('-1 day')); ?>&tab=<?php echo $activeTab; ?>" 
               class="btn btn-sm btn-outline-info">Yesterday</a>
            <a href="?page=reports&from=<?php echo date('Y-m-d', strtotime('-7 days')); ?>&to=<?php echo date('Y-m-d'); ?>&tab=<?php echo $activeTab; ?>" 
               class="btn btn-sm btn-outline-info">Last 7 Days</a>
            <a href="?page=reports&from=<?php echo date('Y-m-d', strtotime('-30 days')); ?>&to=<?php echo date('Y-m-d'); ?>&tab=<?php echo $activeTab; ?>" 
               class="btn btn-sm btn-outline-info">Last 30 Days</a>
            <a href="?page=reports&from=<?php echo date('Y-m-01'); ?>&to=<?php echo date('Y-m-t'); ?>&tab=<?php echo $activeTab; ?>" 
               class="btn btn-sm btn-outline-info">This Month</a>
            <a href="?page=reports&from=<?php echo date('Y-01-01'); ?>&to=<?php echo date('Y-12-31'); ?>&tab=<?php echo $activeTab; ?>" 
               class="btn btn-sm btn-outline-info">This Year</a>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- SUMMARY CARDS                               -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card">
            <h6 class="mb-1"><?php echo t('total_sales'); ?></h6>
            <h4 class="fw-bold mb-0"><?php echo number_format($salesSummary['total_sales']); ?></h4>
            <small style="opacity:0.85;">
                <?php echo date('d M', strtotime($dateFrom)); ?> - <?php echo date('d M', strtotime($dateTo)); ?>
            </small>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card success">
            <h6 class="mb-1"><?php echo t('revenue'); ?></h6>
            <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($salesSummary['total_revenue'], 0); ?></h4>
            <small style="opacity:0.85;">Period total</small>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card info">
            <h6 class="mb-1"><?php echo t('customers'); ?></h6>
            <h4 class="fw-bold mb-0"><?php echo number_format($salesSummary['unique_customers']); ?></h4>
            <small style="opacity:0.85;">Unique buyers</small>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card warning">
            <h6 class="mb-1">Avg. Sale</h6>
            <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($salesSummary['avg_sale'], 0); ?></h4>
            <small style="opacity:0.85;">Per transaction</small>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- REPORT TABS                                 -->
<!-- ============================================ -->
<ul class="nav nav-tabs mb-4" id="reportTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo $activeTab === 'sales' ? 'active' : ''; ?>" 
                id="sales-tab" data-bs-toggle="tab" data-bs-target="#salesTab" type="button">
            <i class="fas fa-shopping-cart"></i> <?php echo t('sales_report'); ?>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo $activeTab === 'vouchers' ? 'active' : ''; ?>" 
                id="vouchers-tab" data-bs-toggle="tab" data-bs-target="#vouchersTab" type="button">
            <i class="fas fa-ticket-alt"></i> <?php echo t('voucher_report'); ?>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo $activeTab === 'routers' ? 'active' : ''; ?>" 
                id="routers-tab" data-bs-toggle="tab" data-bs-target="#routersTab" type="button">
            <i class="fas fa-wifi"></i> <?php echo t('router_report'); ?>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo $activeTab === 'customers' ? 'active' : ''; ?>" 
                id="customers-tab" data-bs-toggle="tab" data-bs-target="#customersTab" type="button">
            <i class="fas fa-users"></i> Customers
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo $activeTab === 'sessions' ? 'active' : ''; ?>" 
                id="sessions-tab" data-bs-toggle="tab" data-bs-target="#sessionsTab" type="button">
            <i class="fas fa-clock"></i> Sessions
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo $activeTab === 'overview' ? 'active' : ''; ?>" 
                id="overview-tab" data-bs-toggle="tab" data-bs-target="#overviewTab" type="button">
            <i class="fas fa-chart-bar"></i> Overview
        </button>
    </li>
</ul>

<div class="tab-content">

    <!-- ============================================ -->
    <!-- SALES REPORT TAB                            -->
    <!-- ============================================ -->
    <div class="tab-pane fade <?php echo $activeTab === 'sales' ? 'show active' : ''; ?>" id="salesTab">
        <!-- Payment Methods Breakdown -->
        <?php if (count($revenueByMethod) > 0): ?>
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-credit-card text-primary"></i> Revenue by Payment Method</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php 
                    $totalMethodRevenue = array_sum(array_column($revenueByMethod, 'total'));
                    foreach ($revenueByMethod as $method): 
                        $pct = $totalMethodRevenue > 0 ? round(($method['total'] / $totalMethodRevenue) * 100, 1) : 0;
                    ?>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="p-3 rounded text-center" style="background:var(--bg-body);">
                            <div class="fw-semibold small text-muted">
                                <?php echo methodLabel($method['payment_method']); ?>
                            </div>
                            <div class="fw-bold text-success" style="font-size:1.2rem;">
                                <?php echo CURRENCY . ' ' . number_format($method['total'], 0); ?>
                            </div>
                            <small class="text-muted"><?php echo $method['count']; ?> sales · <?php echo $pct; ?>%</small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Daily Sales Table -->
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h6 class="mb-0">
                    <i class="fas fa-list"></i> <?php echo t('daily_sales'); ?>
                    <small class="text-muted ms-2">(<?php echo count($salesReportData); ?> days)</small>
                </h6>
                <a href="?page=reports&export=sales&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>" 
                   class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($salesReportData) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mobile-card-table mb-0">
                            <thead>
                                <tr>
                                    <th><?php echo t('date'); ?></th>
                                    <th><?php echo t('total_sales'); ?></th>
                                    <th><?php echo t('customers'); ?></th>
                                    <th><?php echo t('revenue'); ?></th>
                                    <th>Avg. Sale</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($salesReportData as $row): 
                                    $avg = $row['total_sales'] > 0 ? $row['revenue'] / $row['total_sales'] : 0;
                                ?>
                                <tr>
                                    <td data-label="<?php echo t('date'); ?>">
                                        <strong><?php echo date('D, d M Y', strtotime($row['sale_date'])); ?></strong>
                                    </td>
                                    <td data-label="<?php echo t('total_sales'); ?>">
                                        <span class="badge bg-primary"><?php echo $row['total_sales']; ?></span>
                                    </td>
                                    <td data-label="<?php echo t('customers'); ?>">
                                        <i class="fas fa-users text-info"></i> <?php echo $row['customers']; ?>
                                    </td>
                                    <td data-label="<?php echo t('revenue'); ?>">
                                        <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($row['revenue'], 0); ?></strong>
                                    </td>
                                    <td data-label="Avg. Sale">
                                        <small><?php echo CURRENCY . ' ' . number_format($avg, 0); ?></small>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot style="background:var(--bg-body);">
                                <tr>
                                    <td><strong>TOTAL</strong></td>
                                    <td><strong><?php echo $salesSummary['total_sales']; ?></strong></td>
                                    <td><strong><?php echo $salesSummary['unique_customers']; ?></strong></td>
                                    <td><strong class="text-success"><?php echo CURRENCY . ' ' . number_format($salesSummary['total_revenue'], 0); ?></strong></td>
                                    <td><strong><?php echo CURRENCY . ' ' . number_format($salesSummary['avg_sale'], 0); ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-shopping-cart"></i>
                        <p><?php echo t('no_sales'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- VOUCHER REPORT TAB                          -->
    <!-- ============================================ -->
    <div class="tab-pane fade <?php echo $activeTab === 'vouchers' ? 'show active' : ''; ?>" id="vouchersTab">
        <!-- Voucher Stats -->
        <div class="row mb-4">
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-ticket-alt text-success"></i> <?php echo t('available'); ?></div>
                    <div class="metric-value text-success"><?php echo number_format($voucherStats['available']); ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-dollar-sign text-info"></i> <?php echo t('sold'); ?></div>
                    <div class="metric-value text-info"><?php echo number_format($voucherStats['sold']); ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-check-circle text-primary"></i> <?php echo t('used'); ?></div>
                    <div class="metric-value text-primary"><?php echo number_format($voucherStats['used']); ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-hourglass-end text-danger"></i> <?php echo t('expired'); ?></div>
                    <div class="metric-value text-danger"><?php echo number_format($voucherStats['expired']); ?></div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h6 class="mb-0">
                    <i class="fas fa-list"></i> <?php echo t('vouchers'); ?>
                    <small class="text-muted ms-2">(<?php echo count($voucherReportData); ?> records)</small>
                </h6>
                <a href="?page=reports&export=vouchers&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>" 
                   class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($voucherReportData) > 0): ?>
                    <div class="table-responsive" style="max-height:600px;overflow-y:auto;">
                        <table class="table table-hover mobile-card-table mb-0">
                            <thead style="position:sticky;top:0;background:var(--bg-card);z-index:2;">
                                <tr>
                                    <th><?php echo t('code'); ?></th>
                                    <th><?php echo t('package'); ?></th>
                                    <th><?php echo t('price'); ?></th>
                                    <th><?php echo t('status'); ?></th>
                                    <th><?php echo t('created'); ?></th>
                                    <th><?php echo t('customer'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($voucherReportData as $v): 
                                    $statusColor = [
                                        'available' => 'success',
                                        'sold' => 'info',
                                        'used' => 'primary',
                                        'expired' => 'secondary',
                                        'cancelled' => 'danger'
                                    ][$v['status']] ?? 'secondary';
                                ?>
                                <tr>
                                    <td data-label="<?php echo t('code'); ?>">
                                        <code style="font-weight:700;"><?php echo htmlspecialchars($v['voucher_code']); ?></code>
                                    </td>
                                    <td data-label="<?php echo t('package'); ?>">
                                        <div><?php echo htmlspecialchars($v['package_name']); ?></div>
                                        <small class="text-muted"><i class="fas fa-wifi"></i> <?php echo htmlspecialchars($v['router_name']); ?></small>
                                    </td>
                                    <td data-label="<?php echo t('price'); ?>">
                                        <strong><?php echo CURRENCY . ' ' . number_format($v['price'], 0); ?></strong>
                                    </td>
                                    <td data-label="<?php echo t('status'); ?>">
                                        <span class="badge bg-<?php echo $statusColor; ?>">
                                            <?php echo t($v['status']); ?>
                                        </span>
                                    </td>
                                    <td data-label="<?php echo t('created'); ?>">
                                        <small><?php echo date('d M Y H:i', strtotime($v['created_at'])); ?></small>
                                    </td>
                                    <td data-label="<?php echo t('customer'); ?>">
                                        <?php if ($v['customer_name']): ?>
                                            <div class="small"><?php echo htmlspecialchars($v['customer_name']); ?></div>
                                            <?php if ($v['customer_phone']): ?>
                                            <small class="text-muted"><?php echo htmlspecialchars($v['customer_phone']); ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-ticket-alt"></i>
                        <p><?php echo t('no_data'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- ROUTER REPORT TAB                           -->
    <!-- ============================================ -->
    <div class="tab-pane fade <?php echo $activeTab === 'routers' ? 'show active' : ''; ?>" id="routersTab">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h6 class="mb-0">
                    <i class="fas fa-wifi"></i> <?php echo t('router_report'); ?>
                    <small class="text-muted ms-2">(<?php echo count($routerReportData); ?> routers)</small>
                </h6>
                <a href="?page=reports&export=routers&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>" 
                   class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($routerReportData) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mobile-card-table mb-0">
                            <thead>
                                <tr>
                                    <th><?php echo t('router'); ?></th>
                                    <th><?php echo t('status'); ?></th>
                                    <th><?php echo t('packages'); ?></th>
                                    <th><?php echo t('vouchers'); ?></th>
                                    <th><?php echo t('sessions'); ?></th>
                                    <th><?php echo t('revenue'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($routerReportData as $r): ?>
                                <tr>
                                    <td data-label="<?php echo t('router'); ?>">
                                        <div class="fw-semibold">
                                            <span class="router-status-indicator <?php echo $r['status']; ?>"></span>
                                            <?php echo htmlspecialchars($r['device_name']); ?>
                                        </div>
                                        <small class="text-muted">
                                            <i class="fas fa-wifi"></i> <?php echo htmlspecialchars($r['ssid'] ?: 'No SSID'); ?>
                                        </small>
                                    </td>
                                    <td data-label="<?php echo t('status'); ?>">
                                        <span class="badge bg-<?php echo $r['status'] === 'online' ? 'success' : 'danger'; ?>">
                                            <?php echo t($r['status']); ?>
                                        </span>
                                    </td>
                                    <td data-label="<?php echo t('packages'); ?>">
                                        <span class="badge bg-primary"><?php echo $r['package_count']; ?></span>
                                    </td>
                                    <td data-label="<?php echo t('vouchers'); ?>">
                                        <span class="badge bg-warning text-dark"><?php echo $r['voucher_count']; ?></span>
                                    </td>
                                    <td data-label="<?php echo t('sessions'); ?>">
                                        <?php echo $r['total_sessions']; ?> 
                                        <?php if ($r['active_sessions'] > 0): ?>
                                        <span class="badge bg-success"><?php echo $r['active_sessions']; ?> active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('revenue'); ?>">
                                        <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($r['revenue'], 0); ?></strong>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-wifi"></i>
                        <p><?php echo t('no_routers'); ?></p>
                        <a href="?page=connect" class="btn btn-primary mt-3">
                            <i class="fas fa-plus-circle"></i> Add Router
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- CUSTOMER REPORT TAB                         -->
    <!-- ============================================ -->
    <div class="tab-pane fade <?php echo $activeTab === 'customers' ? 'show active' : ''; ?>" id="customersTab">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h6 class="mb-0">
                    <i class="fas fa-users"></i> Customer Report
                    <small class="text-muted ms-2">(<?php echo count($customerReportData); ?> customers)</small>
                </h6>
                <a href="?page=reports&export=customers&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>" 
                   class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($customerReportData) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mobile-card-table mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo t('phone'); ?></th>
                                    <th><?php echo t('purchases'); ?></th>
                                    <th><?php echo t('total_spent'); ?></th>
                                    <th>Avg.</th>
                                    <th><?php echo t('last_purchase'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($customerReportData as $i => $c): 
                                    $rankClass = $i === 0 ? 'gold' : ($i === 1 ? 'silver' : ($i === 2 ? 'bronze' : 'normal'));
                                ?>
                                <tr>
                                    <td data-label="#">
                                        <?php if ($i < 3): ?>
                                        <div class="rank <?php echo $rankClass; ?>" style="width:24px;height:24px;font-size:0.75rem;">
                                            <?php echo $i + 1; ?>
                                        </div>
                                        <?php else: ?>
                                        <span class="text-muted"><?php echo $i + 1; ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('phone'); ?>">
                                        <i class="fas fa-phone text-info"></i>
                                        <strong><?php echo htmlspecialchars($c['phone_number']); ?></strong>
                                    </td>
                                    <td data-label="<?php echo t('purchases'); ?>">
                                        <span class="badge bg-primary"><?php echo $c['purchases']; ?></span>
                                    </td>
                                    <td data-label="<?php echo t('total_spent'); ?>">
                                        <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($c['total_spent'], 0); ?></strong>
                                    </td>
                                    <td data-label="Avg.">
                                        <small><?php echo CURRENCY . ' ' . number_format($c['avg_spent'], 0); ?></small>
                                    </td>
                                    <td data-label="<?php echo t('last_purchase'); ?>">
                                        <small><?php echo date('d M Y', strtotime($c['last_purchase'])); ?></small>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-users"></i>
                        <p><?php echo t('no_data'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- SESSION REPORT TAB                          -->
    <!-- ============================================ -->
    <div class="tab-pane fade <?php echo $activeTab === 'sessions' ? 'show active' : ''; ?>" id="sessionsTab">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h6 class="mb-0">
                    <i class="fas fa-clock"></i> Session Report
                    <small class="text-muted ms-2">(<?php echo count($sessionReportData); ?> sessions)</small>
                </h6>
                <a href="?page=reports&export=sessions&from=<?php echo $dateFrom; ?>&to=<?php echo $dateTo; ?>" 
                   class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($sessionReportData) > 0): ?>
                    <div class="table-responsive" style="max-height:600px;overflow-y:auto;">
                        <table class="table table-hover mobile-card-table mb-0">
                            <thead style="position:sticky;top:0;background:var(--bg-card);z-index:2;">
                                <tr>
                                    <th>#</th>
                                    <th><?php echo t('device'); ?></th>
                                    <th><?php echo t('router'); ?></th>
                                    <th><?php echo t('voucher'); ?></th>
                                    <th><?php echo t('duration'); ?></th>
                                    <th><?php echo t('data_used'); ?></th>
                                    <th><?php echo t('status'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sessionReportData as $s): ?>
                                <tr>
                                    <td data-label="#">
                                        <small>#<?php echo $s['id']; ?></small>
                                    </td>
                                    <td data-label="<?php echo t('device'); ?>">
                                        <div><?php echo htmlspecialchars($s['device_name'] ?? 'Unknown'); ?></div>
                                        <small class="text-muted">
                                            <code style="font-size:0.7rem;"><?php echo htmlspecialchars($s['mac_address']); ?></code>
                                        </small>
                                    </td>
                                    <td data-label="<?php echo t('router'); ?>">
                                        <small><?php echo htmlspecialchars($s['router_name']); ?></small>
                                    </td>
                                    <td data-label="<?php echo t('voucher'); ?>">
                                        <?php if ($s['voucher_code']): ?>
                                        <code style="font-size:0.8rem;"><?php echo htmlspecialchars($s['voucher_code']); ?></code>
                                        <?php else: ?>
                                        <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('duration'); ?>">
                                        <?php echo formatDuration($s['duration_minutes'] ?? 0); ?>
                                        <?php if ($s['is_manually_adjusted']): ?>
                                        <span class="badge bg-warning text-dark" style="font-size:0.6rem;">ADJ</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('data_used'); ?>">
                                        <?php echo formatData($s['data_used_mb'] ?? 0); ?>
                                    </td>
                                    <td data-label="<?php echo t('status'); ?>">
                                        <span class="badge bg-<?php 
                                            echo $s['status'] === 'active' ? 'success' : 
                                                ($s['status'] === 'expired' ? 'secondary' : 
                                                ($s['status'] === 'blocked' ? 'danger' : 'info')); 
                                        ?>">
                                            <?php echo t($s['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-clock"></i>
                        <p><?php echo t('no_data'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- OVERVIEW TAB                                -->
    <!-- ============================================ -->
    <div class="tab-pane fade <?php echo $activeTab === 'overview' ? 'show active' : ''; ?>" id="overviewTab">
        <!-- Top Packages -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-crown text-warning"></i> Top Packages (by Revenue)</h6>
            </div>
            <div class="card-body">
                <?php if (count($topPackages) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Package</th>
                                    <th>Price</th>
                                    <th>Sales</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($topPackages as $i => $p): ?>
                                <tr>
                                    <td><?php echo $i + 1; ?></td>
                                    <td><strong><?php echo htmlspecialchars($p['name']); ?></strong></td>
                                    <td><?php echo CURRENCY . ' ' . number_format($p['price'], 0); ?></td>
                                    <td><span class="badge bg-primary"><?php echo $p['sales']; ?></span></td>
                                    <td><strong class="text-success"><?php echo CURRENCY . ' ' . number_format($p['revenue'], 0); ?></strong></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-3 mb-0"><?php echo t('no_data'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Hourly Distribution -->
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-clock text-info"></i> Sales Distribution by Hour</h6>
            </div>
            <div class="card-body">
                <?php if (array_sum(array_column($hourlyDistribution, 'count')) > 0): ?>
                    <div class="row g-1">
                        <?php foreach ($hourlyDistribution as $hd): 
                            $pct = ($hd['count'] / $maxHourlyCount) * 100;
                        ?>
                        <div class="col-6 col-md-3 col-lg-2">
                            <div class="p-2 rounded text-center mb-2" style="background:var(--bg-body);">
                                <div class="small text-muted">
                                    <?php echo str_pad($hd['hour'], 2, '0', STR_PAD_LEFT); ?>:00
                                </div>
                                <div class="fw-bold text-primary"><?php echo $hd['count']; ?></div>
                                <div class="progress mt-1" style="height:3px;">
                                    <div class="progress-bar bg-primary" style="width: <?php echo $pct; ?>%"></div>
                                </div>
                                <?php if ($hd['revenue'] > 0): ?>
                                <small class="text-success" style="font-size:0.65rem;">
                                    <?php echo CURRENCY . ' ' . number_format($hd['revenue'], 0); ?>
                                </small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-3 mb-0"><?php echo t('no_data'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- PRINT STYLES                                -->
<!-- ============================================ -->
<style media="print">
    .desktop-sidebar, .mobile-topbar, .mobile-bottom-nav,
    .content-topbar, .nav-tabs, .btn, .dropdown,
    .sidebar-footer, .pwa-install-banner {
        display: none !important;
    }
    .main-content { margin-left: 0 !important; }
    .card { box-shadow: none !important; border: 1px solid #ddd !important; }
    body { background: #fff !important; color: #000 !important; }
    .table { color: #000 !important; }
    .table th, .table td { border-color: #ddd !important; }
    .tab-pane { display: block !important; opacity: 1 !important; }
    .tab-content > .tab-pane { display: block !important; page-break-inside: avoid; }
    .text-success, .text-primary, .text-info, .text-warning, .text-danger { color: #000 !important; }
    .badge { border: 1px solid #000 !important; }
</style>

<script>
// Auto-submit form when quick date link is clicked (already handled by anchor hrefs)

// Copy phone number on click
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('td strong').forEach(el => {
        if (/^\+?[0-9]{10,}/.test(el.textContent.trim())) {
            el.style.cursor = 'pointer';
            el.title = 'Click to copy';
            el.addEventListener('click', function() {
                const text = this.textContent.trim();
                navigator.clipboard.writeText(text).then(() => {
                    const original = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-check text-success"></i>';
                    setTimeout(() => { this.innerHTML = original; }, 1000);
                });
            });
        }
    });
    
    // Activate tab from URL
    const urlParams = new URLSearchParams(window.location.search);
    const tab = urlParams.get('tab');
    if (tab) {
        const tabEl = document.getElementById(tab + '-tab');
        if (tabEl) {
            new bootstrap.Tab(tabEl).show();
        }
    }
});

// Update URL when tabs change
document.querySelectorAll('[data-bs-toggle="tab"]').forEach(tab => {
    tab.addEventListener('shown.bs.tab', function(e) {
        const targetId = e.target.id.replace('-tab', '');
        const url = new URL(window.location.href);
        url.searchParams.set('tab', targetId);
        window.history.replaceState({}, '', url);
    });
});
</script>