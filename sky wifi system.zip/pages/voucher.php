<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Voucher Management Page - Loaded from external file
 * 
 * Sellers can generate, view, filter, and manage vouchers
 * Customers can buy vouchers and connect
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

$auth->requireLogin();
$userId = $_SESSION['user_id'];
$user = $auth->getUser();
$userType = $user['user_type'];

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// ============================================
// SELLER / ADMIN SECTION
// ============================================
// ============================================
if ($userType === 'seller' || $userType === 'admin') {

    // --------------------------------------------
    // GENERATE VOUCHERS
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_vouchers'])) {
        $packageId = intval($_POST['package_id'] ?? 0);
        $quantity = intval($_POST['quantity'] ?? 1);
        
        // Validate quantity
        if ($quantity < 1 || $quantity > 1000) {
            $msg = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Quantity must be between 1 and 1000</div>';
        } elseif ($packageId <= 0) {
            $msg = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Please select a package</div>';
        } else {
            // Verify package belongs to seller
            $check = $conn->prepare("SELECT id FROM packages WHERE id = ? AND seller_id = ?");
            $check->bind_param("ii", $packageId, $userId);
            $check->execute();
            
            if ($check->get_result()->num_rows === 0) {
                $msg = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Package not found or access denied</div>';
            } else {
                $result = $voucher->createVouchers($packageId, $userId, $quantity);
                if ($result['success']) {
                    $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Successfully generated ' . count($result['vouchers']) . ' vouchers!</div>';
                    redirectTo('?page=voucher');
                } else {
                    $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
                }
            }
        }
    }

    // --------------------------------------------
    // DELETE VOUCHER
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_voucher'])) {
        $voucherId = intval($_POST['voucher_id'] ?? 0);
        if ($voucherId) {
            $stmt = $conn->prepare("DELETE FROM vouchers WHERE id = ? AND seller_id = ? AND status = 'available'");
            $stmt->bind_param("ii", $voucherId, $userId);
            if ($stmt->execute() && $stmt->affected_rows > 0) {
                $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Voucher deleted successfully</div>';
            } else {
                $msg = '<div class="alert alert-danger">Cannot delete this voucher (already used or sold)</div>';
            }
        }
    }

    // --------------------------------------------
    // BULK DELETE VOUCHERS
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_delete'])) {
        $voucherIds = isset($_POST['voucher_ids']) ? $_POST['voucher_ids'] : [];
        if (!empty($voucherIds)) {
            $deleted = 0;
            foreach ($voucherIds as $vid) {
                $vid = intval($vid);
                $stmt = $conn->prepare("DELETE FROM vouchers WHERE id = ? AND seller_id = ? AND status = 'available'");
                $stmt->bind_param("ii", $vid, $userId);
                $stmt->execute();
                if ($stmt->affected_rows > 0) $deleted++;
            }
            $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Deleted ' . $deleted . ' vouchers</div>';
        }
    }

    // --------------------------------------------
    // EXPORT VOUCHERS TO CSV
    // --------------------------------------------
    if (isset($_GET['export']) && $_GET['export'] === 'csv') {
        $filterStatus = $_GET['status'] ?? 'all';
        $filterPackage = intval($_GET['package'] ?? 0);
        
        $sql = "SELECT v.voucher_code, v.price, v.duration_minutes, v.status, 
                       p.name as package_name, r.device_name as router_name,
                       v.created_at, v.sold_at, v.used_at, v.expires_at
                FROM vouchers v 
                JOIN packages p ON v.package_id = p.id 
                JOIN routers r ON p.router_id = r.id 
                WHERE v.seller_id = ?";
        $params = [$userId];
        $types = "i";
        
        if ($filterStatus !== 'all') {
            $sql .= " AND v.status = ?";
            $params[] = $filterStatus;
            $types .= "s";
        }
        if ($filterPackage) {
            $sql .= " AND v.package_id = ?";
            $params[] = $filterPackage;
            $types .= "i";
        }
        $sql .= " ORDER BY v.created_at DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $exportData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Clear output buffer
        while (ob_get_level() > 0) ob_end_clean();
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="vouchers_' . date('Y-m-d_His') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Voucher Code', 'Package', 'Router', 'Price', 'Duration (min)', 'Status', 'Created', 'Sold', 'Used', 'Expires']);
        foreach ($exportData as $row) {
            fputcsv($output, [
                $row['voucher_code'],
                $row['package_name'],
                $row['router_name'],
                $row['price'],
                $row['duration_minutes'],
                $row['status'],
                $row['created_at'],
                $row['sold_at'] ?? '',
                $row['used_at'] ?? '',
                $row['expires_at'] ?? ''
            ]);
        }
        fclose($output);
        exit;
    }

    // --------------------------------------------
    // FETCH FILTERS
    // --------------------------------------------
    $filterStatus = $_GET['status'] ?? 'all';
    $filterPackage = intval($_GET['package'] ?? 0);
    $searchCode = trim($_GET['search'] ?? '');
    $pageNum = max(1, intval($_GET['p'] ?? 1));
    $perPage = 50;
    $offset = ($pageNum - 1) * $perPage;

    // --------------------------------------------
    // BUILD QUERY
    // --------------------------------------------
    $whereClause = "WHERE v.seller_id = ?";
    $params = [$userId];
    $types = "i";

    if ($filterStatus !== 'all' && in_array($filterStatus, ['available', 'sold', 'used', 'expired', 'cancelled'])) {
        $whereClause .= " AND v.status = ?";
        $params[] = $filterStatus;
        $types .= "s";
    }

    if ($filterPackage) {
        $whereClause .= " AND v.package_id = ?";
        $params[] = $filterPackage;
        $types .= "i";
    }

    if ($searchCode) {
        $whereClause .= " AND v.voucher_code LIKE ?";
        $params[] = "%$searchCode%";
        $types .= "s";
    }

    // Count total
    $countSql = "SELECT COUNT(*) as total FROM vouchers v $whereClause";
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $totalVouchers = $countStmt->get_result()->fetch_assoc()['total'];
    $totalPages = max(1, ceil($totalVouchers / $perPage));

    // Fetch vouchers
    $sql = "SELECT v.*, 
                   p.name as package_name, p.price as package_price,
                   r.device_name as router_name, r.ssid,
                   u.full_name as sold_to_name, u.phone as sold_to_phone
            FROM vouchers v 
            JOIN packages p ON v.package_id = p.id 
            JOIN routers r ON p.router_id = r.id 
            LEFT JOIN users u ON v.sold_to = u.id
            $whereClause
            ORDER BY v.created_at DESC
            LIMIT ? OFFSET ?";
    $params[] = $perPage;
    $params[] = $offset;
    $types .= "ii";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $vouchers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // --------------------------------------------
    // FETCH STATS
    // --------------------------------------------
    $stats = [
        'total' => 0,
        'available' => 0,
        'sold' => 0,
        'used' => 0,
        'expired' => 0,
        'revenue' => 0
    ];
    try {
        $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId");
        if ($res) $stats['total'] = $res->fetch_assoc()['c'];
        
        $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'available'");
        if ($res) $stats['available'] = $res->fetch_assoc()['c'];
        
        $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'sold'");
        if ($res) $stats['sold'] = $res->fetch_assoc()['c'];
        
        $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'used'");
        if ($res) $stats['used'] = $res->fetch_assoc()['c'];
        
        $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'expired'");
        if ($res) $stats['expired'] = $res->fetch_assoc()['c'];
        
        $res = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE seller_id = $userId AND payment_status = 'completed' AND voucher_id IS NOT NULL");
        if ($res) $stats['revenue'] = $res->fetch_assoc()['total'];
    } catch (Throwable $e) {}

    // --------------------------------------------
    // FETCH SELLER'S PACKAGES (for generate dropdown)
    // --------------------------------------------
    $sellerPackages = [];
    try {
        $stmt = $conn->prepare("
            SELECT p.*, r.device_name as router_name, r.ssid,
                   (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = 'available') as available_count
            FROM packages p 
            JOIN routers r ON p.router_id = r.id 
            WHERE p.seller_id = ? AND p.is_active = 1
            ORDER BY p.name
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $sellerPackages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Throwable $e) {}

?>

<!-- ============================================ -->
<!-- SELLER: VOUCHER MANAGEMENT                  -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-ticket-alt"></i> <?php echo t('manage_vouchers'); ?></h2>
        <small class="text-muted">Generate, view, and manage all your WiFi vouchers</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <?php if (count($sellerPackages) > 0): ?>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#generateVoucherModal">
            <i class="fas fa-plus-circle"></i> <?php echo t('generate_vouchers'); ?>
        </button>
        <?php endif; ?>
        <a href="?page=voucher&export=csv&status=<?php echo $filterStatus; ?>&package=<?php echo $filterPackage; ?>" class="btn btn-outline-success btn-sm">
            <i class="fas fa-download"></i> <?php echo t('export_csv'); ?>
        </a>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- VOUCHER STATS                               -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-2 mb-2">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-ticket-alt text-primary"></i> <?php echo t('total_vouchers'); ?></div>
            <div class="metric-value" style="font-size:1.5rem;"><?php echo number_format($stats['total']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-2 mb-2">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-check-circle text-success"></i> <?php echo t('available'); ?></div>
            <div class="metric-value text-success" style="font-size:1.5rem;"><?php echo number_format($stats['available']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-2 mb-2">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-dollar-sign text-info"></i> <?php echo t('sold'); ?></div>
            <div class="metric-value text-info" style="font-size:1.5rem;"><?php echo number_format($stats['sold']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-2 mb-2">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-hourglass-half text-warning"></i> <?php echo t('used'); ?></div>
            <div class="metric-value text-warning" style="font-size:1.5rem;"><?php echo number_format($stats['used']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-2 mb-2">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-hourglass-end text-danger"></i> <?php echo t('expired'); ?></div>
            <div class="metric-value text-danger" style="font-size:1.5rem;"><?php echo number_format($stats['expired']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-2 mb-2">
        <div class="analytics-card text-center">
            <div class="metric-label"><i class="fas fa-money-bill-wave text-success"></i> <?php echo t('revenue'); ?></div>
            <div class="metric-value text-success" style="font-size:1.2rem;"><?php echo CURRENCY . ' ' . number_format($stats['revenue'], 0); ?></div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- FILTERS                                     -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-end">
            <input type="hidden" name="page" value="voucher">
            
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-search"></i> <?php echo t('search'); ?></label>
                <input type="text" name="search" class="form-control form-control-sm" 
                       placeholder="Voucher code..." value="<?php echo htmlspecialchars($searchCode); ?>">
            </div>
            
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-filter"></i> <?php echo t('status'); ?></label>
                <select name="status" class="form-select form-select-sm">
                    <option value="all"><?php echo t('all'); ?? 'All'; ?></option>
                    <option value="available" <?php echo $filterStatus === 'available' ? 'selected' : ''; ?>><?php echo t('available'); ?></option>
                    <option value="sold" <?php echo $filterStatus === 'sold' ? 'selected' : ''; ?>><?php echo t('sold'); ?></option>
                    <option value="used" <?php echo $filterStatus === 'used' ? 'selected' : ''; ?>><?php echo t('used'); ?></option>
                    <option value="expired" <?php echo $filterStatus === 'expired' ? 'selected' : ''; ?>><?php echo t('expired'); ?></option>
                </select>
            </div>
            
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-box"></i> <?php echo t('package'); ?></label>
                <select name="package" class="form-select form-select-sm">
                    <option value="0"><?php echo t('all_packages') ?? 'All Packages'; ?></option>
                    <?php foreach ($sellerPackages as $sp): ?>
                    <option value="<?php echo $sp['id']; ?>" <?php echo $filterPackage == $sp['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($sp['name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-3 col-6 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">
                    <i class="fas fa-filter"></i> <?php echo t('filter'); ?>
                </button>
                <a href="?page=voucher" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-times"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<!-- ============================================ -->
<!-- VOUCHERS TABLE                              -->
<!-- ============================================ -->
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="mb-0">
            <i class="fas fa-ticket-alt"></i> <?php echo t('vouchers'); ?>
            <small class="text-muted ms-2">(<?php echo number_format($totalVouchers); ?> results)</small>
        </h5>
        <?php if (count($vouchers) > 0): ?>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="selectAllVouchers" onchange="toggleAllVouchers(this)">
            <label class="form-check-label small" for="selectAllVouchers"><?php echo t('select_all'); ?></label>
        </div>
        <?php endif; ?>
    </div>
    <div class="card-body p-0">
        <?php if (count($vouchers) > 0): ?>
            <form method="POST" id="bulkForm">
                <div class="table-responsive">
                    <table class="table table-hover mobile-card-table mb-0">
                        <thead>
                            <tr>
                                <th style="width:40px;"></th>
                                <th><?php echo t('code'); ?></th>
                                <th><?php echo t('package'); ?></th>
                                <th><?php echo t('price'); ?></th>
                                <th><?php echo t('duration'); ?></th>
                                <th><?php echo t('status'); ?></th>
                                <th><?php echo t('created'); ?></th>
                                <th><?php echo t('actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vouchers as $v): 
                                $statusColor = [
                                    'available' => 'success',
                                    'sold' => 'info',
                                    'used' => 'primary',
                                    'expired' => 'secondary',
                                    'cancelled' => 'danger'
                                ][$v['status']] ?? 'secondary';
                                
                                $durationText = '';
                                if ($v['duration_minutes'] >= 1440) $durationText = round($v['duration_minutes'] / 1440, 1) . 'd';
                                elseif ($v['duration_minutes'] >= 60) $durationText = round($v['duration_minutes'] / 60, 1) . 'h';
                                else $durationText = $v['duration_minutes'] . 'm';
                            ?>
                            <tr>
                                <td data-label="">
                                    <?php if ($v['status'] === 'available'): ?>
                                    <input type="checkbox" name="voucher_ids[]" value="<?php echo $v['id']; ?>" 
                                           class="voucher-checkbox session-checkbox" onchange="updateBulkBar()">
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo t('code'); ?>">
                                    <code style="font-size:0.9rem;font-weight:700;letter-spacing:1px;">
                                        <?php echo htmlspecialchars($v['voucher_code']); ?>
                                    </code>
                                    <button type="button" class="btn btn-sm btn-link p-0 ms-1" 
                                            onclick="copyVoucherCode('<?php echo htmlspecialchars($v['voucher_code']); ?>')"
                                            title="<?php echo t('copy'); ?>">
                                        <i class="fas fa-copy text-muted" style="font-size:0.75rem;"></i>
                                    </button>
                                </td>
                                <td data-label="<?php echo t('package'); ?>">
                                    <strong><?php echo htmlspecialchars($v['package_name']); ?></strong>
                                    <br><small class="text-muted"><i class="fas fa-wifi"></i> <?php echo htmlspecialchars($v['router_name']); ?></small>
                                </td>
                                <td data-label="<?php echo t('price'); ?>">
                                    <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($v['price'], 0); ?></strong>
                                </td>
                                <td data-label="<?php echo t('duration'); ?>"><?php echo $durationText; ?></td>
                                <td data-label="<?php echo t('status'); ?>">
                                    <span class="badge bg-<?php echo $statusColor; ?>">
                                        <?php echo t($v['status']); ?>
                                    </span>
                                </td>
                                <td data-label="<?php echo t('created'); ?>">
                                    <small><?php echo date('d M Y', strtotime($v['created_at'])); ?></small>
                                    <br><small class="text-muted"><?php echo date('H:i', strtotime($v['created_at'])); ?></small>
                                </td>
                                <td data-label="<?php echo t('actions'); ?>">
                                    <?php if ($v['status'] === 'available'): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="voucher_id" value="<?php echo $v['id']; ?>">
                                        <button type="submit" name="delete_voucher" class="btn btn-sm btn-outline-danger" 
                                                onclick="return confirm('Delete this voucher?');">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    <?php elseif ($v['status'] === 'sold' || $v['status'] === 'used'): ?>
                                    <button type="button" class="btn btn-sm btn-outline-info" 
                                            data-bs-toggle="modal" data-bs-target="#viewVoucherModal<?php echo $v['id']; ?>">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <?php if ($v['status'] === 'sold' || $v['status'] === 'used'): ?>
                            <!-- View Voucher Modal -->
                            <div class="modal fade" id="viewVoucherModal<?php echo $v['id']; ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title"><i class="fas fa-ticket-alt"></i> Voucher Details</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="voucher-code mb-3 d-block text-center"><?php echo htmlspecialchars($v['voucher_code']); ?></div>
                                            
                                            <div class="stat-row">
                                                <span><?php echo t('package'); ?>:</span>
                                                <strong><?php echo htmlspecialchars($v['package_name']); ?></strong>
                                            </div>
                                            <div class="stat-row">
                                                <span><?php echo t('router'); ?>:</span>
                                                <strong><?php echo htmlspecialchars($v['router_name']); ?></strong>
                                            </div>
                                            <div class="stat-row">
                                                <span><?php echo t('price'); ?>:</span>
                                                <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($v['price'], 0); ?></strong>
                                            </div>
                                            <div class="stat-row">
                                                <span><?php echo t('status'); ?>:</span>
                                                <span class="badge bg-<?php echo $statusColor; ?>"><?php echo t($v['status']); ?></span>
                                            </div>
                                            <div class="stat-row">
                                                <span><?php echo t('created'); ?>:</span>
                                                <span><?php echo date('d M Y H:i', strtotime($v['created_at'])); ?></span>
                                            </div>
                                            <?php if ($v['sold_at']): ?>
                                            <div class="stat-row">
                                                <span><?php echo t('sold_at'); ?>:</span>
                                                <span><?php echo date('d M Y H:i', strtotime($v['sold_at'])); ?></span>
                                            </div>
                                            <?php endif; ?>
                                            <?php if ($v['used_at']): ?>
                                            <div class="stat-row">
                                                <span><?php echo t('used_at'); ?>:</span>
                                                <span><?php echo date('d M Y H:i', strtotime($v['used_at'])); ?></span>
                                            </div>
                                            <?php endif; ?>
                                            <?php if ($v['sold_to_name']): ?>
                                            <div class="stat-row">
                                                <span><?php echo t('customer_name'); ?>:</span>
                                                <span><?php echo htmlspecialchars($v['sold_to_name']); ?></span>
                                            </div>
                                            <?php endif; ?>
                                            <?php if ($v['sold_to_phone']): ?>
                                            <div class="stat-row">
                                                <span><?php echo t('phone'); ?>:</span>
                                                <span><?php echo htmlspecialchars($v['sold_to_phone']); ?></span>
                                            </div>
                                            <?php endif; ?>
                                            <div class="stat-row">
                                                <span><?php echo t('valid_until'); ?>:</span>
                                                <span><?php echo $v['expires_at'] ? date('d M Y H:i', strtotime($v['expires_at'])) : '-'; ?></span>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Bulk Actions Bar -->
                <div class="bulk-actions-bar" id="bulkActionsBar" style="display:none;">
                    <div>
                        <span id="selectedCount">0</span> <?php echo t('selected'); ?? 'selected'; ?>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" name="bulk_delete" class="btn btn-sm btn-danger" 
                                onclick="return confirm('Delete selected vouchers?');">
                            <i class="fas fa-trash"></i> <?php echo t('delete_selected'); ?>
                        </button>
                    </div>
                </div>
            </form>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <div class="d-flex justify-content-between align-items-center p-3 border-top" style="border-color:var(--border-color) !important;">
                <div class="text-muted small">
                    <?php echo t('showing'); ?> <?php echo $offset + 1; ?>-<?php echo min($offset + $perPage, $totalVouchers); ?> 
                    <?php echo t('of'); ?> <?php echo number_format($totalVouchers); ?>
                </div>
                <nav>
                    <ul class="pagination pagination-sm mb-0">
                        <?php if ($pageNum > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=voucher&p=<?php echo $pageNum - 1; ?>&status=<?php echo $filterStatus; ?>&package=<?php echo $filterPackage; ?>&search=<?php echo urlencode($searchCode); ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php
                        $startPage = max(1, $pageNum - 2);
                        $endPage = min($totalPages, $pageNum + 2);
                        for ($i = $startPage; $i <= $endPage; $i++):
                        ?>
                        <li class="page-item <?php echo $i == $pageNum ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=voucher&p=<?php echo $i; ?>&status=<?php echo $filterStatus; ?>&package=<?php echo $filterPackage; ?>&search=<?php echo urlencode($searchCode); ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                        <?php endfor; ?>
                        
                        <?php if ($pageNum < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=voucher&p=<?php echo $pageNum + 1; ?>&status=<?php echo $filterStatus; ?>&package=<?php echo $filterPackage; ?>&search=<?php echo urlencode($searchCode); ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="empty-state py-5">
                <i class="fas fa-ticket-alt"></i>
                <h5><?php echo t('no_data'); ?></h5>
                <p>
                    <?php if ($searchCode || $filterStatus !== 'all' || $filterPackage): ?>
                        No vouchers match your filters. <a href="?page=voucher">Clear filters</a>
                    <?php else: ?>
                        Generate your first vouchers to start selling WiFi access.
                    <?php endif; ?>
                </p>
                <?php if (count($sellerPackages) > 0): ?>
                <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#generateVoucherModal">
                    <i class="fas fa-plus-circle"></i> <?php echo t('generate_vouchers'); ?>
                </button>
                <?php else: ?>
                <a href="?page=packages" class="btn btn-warning mt-3">
                    <i class="fas fa-box"></i> <?php echo t('create_package'); ?> <?php echo t('first') ?? 'first'; ?>
                </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================ -->
<!-- GENERATE VOUCHER MODAL                      -->
<!-- ============================================ -->
<div class="modal fade" id="generateVoucherModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-ticket-alt text-success"></i> <?php echo t('generate_vouchers'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php if (count($sellerPackages) === 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        You need to create a package first before generating vouchers.
                    </div>
                    <?php else: ?>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('select_package'); ?> <span class="text-danger">*</span></label>
                        <select name="package_id" class="form-select" id="packageSelect" required onchange="updatePackageInfo()">
                            <option value=""><?php echo t('choose_package'); ?></option>
                            <?php foreach ($sellerPackages as $sp): 
                                $durText = '';
                                if ($sp['duration_minutes'] >= 1440) $durText = round($sp['duration_minutes'] / 1440, 1) . ' days';
                                elseif ($sp['duration_minutes'] >= 60) $durText = round($sp['duration_minutes'] / 60, 1) . ' hrs';
                                else $durText = $sp['duration_minutes'] . ' min';
                            ?>
                            <option value="<?php echo $sp['id']; ?>" 
                                    data-price="<?php echo $sp['price']; ?>"
                                    data-duration="<?php echo $durText; ?>"
                                    data-router="<?php echo htmlspecialchars($sp['router_name']); ?>"
                                    data-available="<?php echo $sp['available_count']; ?>">
                                <?php echo htmlspecialchars($sp['name']); ?> - <?php echo CURRENCY . ' ' . number_format($sp['price'], 0); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Package Info Preview -->
                    <div class="alert alert-info" id="packageInfo" style="display:none;">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('router'); ?>:</span>
                            <strong id="infoRouter">-</strong>
                        </div>
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('duration'); ?>:</span>
                            <strong id="infoDuration">-</strong>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span><?php echo t('available_vouchers'); ?>:</span>
                            <strong id="infoAvailable">-</strong>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('quantity'); ?> <span class="text-danger">*</span></label>
                        <input type="number" name="quantity" class="form-control" value="10" min="1" max="1000" required>
                        <small class="text-muted">Maximum 1000 vouchers per batch</small>
                    </div>
                    
                    <!-- Quick quantity buttons -->
                    <div class="mb-3">
                        <label class="form-label small"><?php echo t('quick_select'); ?? 'Quick Select'; ?>:</label>
                        <div class="d-flex gap-2 flex-wrap">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setQuantity(5)">5</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setQuantity(10)">10</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setQuantity(25)">25</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setQuantity(50)">50</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setQuantity(100)">100</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setQuantity(500)">500</button>
                        </div>
                    </div>
                    
                    <div class="alert alert-warning small">
                        <i class="fas fa-info-circle"></i>
                        Vouchers will be valid for 30 days from generation and can be sold to customers.
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <?php if (count($sellerPackages) > 0): ?>
                    <button type="submit" name="generate_vouchers" class="btn btn-success">
                        <i class="fas fa-magic"></i> <?php echo t('generate'); ?>
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleAllVouchers(checkbox) {
    document.querySelectorAll('.voucher-checkbox').forEach(cb => cb.checked = checkbox.checked);
    updateBulkBar();
}

function updateBulkBar() {
    const checked = document.querySelectorAll('.voucher-checkbox:checked');
    const bar = document.getElementById('bulkActionsBar');
    const count = document.getElementById('selectedCount');
    if (bar) bar.style.display = checked.length > 0 ? 'flex' : 'none';
    if (count) count.textContent = checked.length;
}

function copyVoucherCode(code) {
    navigator.clipboard.writeText(code).then(() => {
        // Small visual feedback
        const toast = document.createElement('div');
        toast.textContent = '<?php echo t('copied'); ?>';
        toast.style.cssText = 'position:fixed;bottom:20px;right:20px;background:var(--success);color:#fff;padding:8px 16px;border-radius:6px;z-index:9999;';
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 1500);
    });
}

function updatePackageInfo() {
    const select = document.getElementById('packageSelect');
    const info = document.getElementById('packageInfo');
    const opt = select.options[select.selectedIndex];
    
    if (opt.value) {
        document.getElementById('infoRouter').textContent = opt.dataset.router;
        document.getElementById('infoDuration').textContent = opt.dataset.duration;
        document.getElementById('infoAvailable').textContent = opt.dataset.available;
        info.style.display = 'block';
    } else {
        info.style.display = 'none';
    }
}

function setQuantity(n) {
    const input = document.querySelector('#generateVoucherModal input[name="quantity"]');
    if (input) input.value = n;
}
</script>

<?php
// ============================================
// ============================================
// CUSTOMER SECTION - Buy Voucher & Connect
// ============================================
// ============================================
} else {

    // --------------------------------------------
    // HANDLE VOUCHER PURCHASE
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_voucher'])) {
        $packageId = intval($_POST['package_id'] ?? 0);
        $phone = trim($_POST['phone'] ?? '');
        $method = $_POST['payment_method'] ?? 'mpesa';

        if (!$packageId || !$phone) {
            $msg = '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> ' . t('all_fields_required') . '</div>';
        } else {
            // Get package
            $stmt = $conn->prepare("SELECT p.*, r.ssid, r.location, p.seller_id FROM packages p JOIN routers r ON p.router_id = r.id WHERE p.id = ? AND p.is_active = 1");
            $stmt->bind_param("i", $packageId);
            $stmt->execute();
            $pkg = $stmt->get_result()->fetch_assoc();

            if (!$pkg) {
                $msg = '<div class="alert alert-danger">Package not found or unavailable</div>';
            } else {
                // Create transaction
                $txnResult = $transaction->create([
                    'user_id' => $userId,
                    'seller_id' => $pkg['seller_id'],
                    'voucher_id' => 0,
                    'amount' => $pkg['price'],
                    'payment_method' => $method,
                    'payment_phone' => $phone,
                    'type' => 'purchase',
                    'status' => 'pending',
                    'commission' => 0,
                    'admin_commission' => 0,
                    'seller_amount' => 0
                ]);

                if ($txnResult['success']) {
                    $payResult = $payment->processMobileMoney($method, $phone, $pkg['price'], $txnResult['ref']);

                    if ($payResult['success']) {
                        // Record in payments table
                        try {
                            $stmt = $conn->prepare("INSERT INTO payments (user_id, seller_id, amount, order_id, phone_number, package_type, payment_status, payment_method) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)");
                            $pkgType = $pkg['name'];
                            $stmt->bind_param("iidssss", $userId, $pkg['seller_id'], $pkg['price'], $txnResult['ref'], $phone, $pkgType, $method);
                            $stmt->execute();
                        } catch (Throwable $e) {}

                        $msg = '<div class="alert alert-success">
                            <h5><i class="fas fa-check-circle"></i> ' . t('payment_initiated') . '</h5>
                            <p class="mb-1">' . t('transaction_ref') . ': <strong>' . $txnResult['ref'] . '</strong></p>
                            <p class="mb-0 small">' . t('check_phone') . '</p>
                        </div>';
                    } else {
                        $msg = '<div class="alert alert-danger">' . htmlspecialchars($payResult['message']) . '</div>';
                    }
                } else {
                    $msg = '<div class="alert alert-danger">Failed to create transaction</div>';
                }
            }
        }
    }

    // --------------------------------------------
    // HANDLE CONNECT WITH VOUCHER
    // --------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['connect_voucher'])) {
        $code = strtoupper(trim($_POST['voucher_code'] ?? ''));
        if ($code) {
            $validation = $voucher->validateVoucher($code);
            if ($validation['valid']) {
                $mac = $_POST['mac_address'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                $deviceName = $_POST['device_name'] ?? 'Web Device';
                $result = $voucher->useVoucher($validation['voucher']['id'], $userId, $mac, $_SERVER['REMOTE_ADDR'], $deviceName);
                if ($result['success']) {
                    $msg = '<div class="alert alert-success">
                        <h5><i class="fas fa-wifi"></i> ' . t('connected') . '</h5>
                        <p class="mb-0">' . t('session_expires') . ' <strong>' . date('d M Y H:i', strtotime($result['expires_at'])) . '</strong></p>
                    </div>';
                } else {
                    $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
                }
            } else {
                $msg = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> ' . htmlspecialchars($validation['message']) . '</div>';
            }
        }
    }

    // --------------------------------------------
    // FETCH AVAILABLE PACKAGES
    // --------------------------------------------
    $availablePackages = [];
    try {
        $res = $conn->query("
            SELECT p.*, r.ssid, r.location, r.device_name as router_name,
                   u.full_name as seller_name,
                   (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = 'available') as available_vouchers
            FROM packages p 
            JOIN routers r ON p.router_id = r.id 
            JOIN users u ON p.seller_id = u.id
            WHERE p.is_active = 1
            ORDER BY p.price ASC
        ");
        if ($res) $availablePackages = $res->fetch_all(MYSQLI_ASSOC);
    } catch (Throwable $e) {}

    // Get selected package
    $selectedPackageId = isset($_GET['package']) ? intval($_GET['package']) : 0;
    $selectedPackage = null;
    if ($selectedPackageId) {
        foreach ($availablePackages as $ap) {
            if ($ap['id'] == $selectedPackageId) {
                $selectedPackage = $ap;
                break;
            }
        }
    }

    // Get active sessions for this customer
    $customerSessions = [];
    try {
        $stmt = $conn->prepare("
            SELECT ws.*, r.device_name as router_name, r.ssid,
                   v.voucher_code, p.name as package_name
            FROM wifi_sessions ws
            LEFT JOIN routers r ON ws.router_id = r.id
            LEFT JOIN vouchers v ON ws.voucher_id = v.id
            LEFT JOIN packages p ON v.package_id = p.id
            WHERE ws.user_id = ? AND ws.status = 'active'
            ORDER BY ws.session_end ASC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $customerSessions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Throwable $e) {}

?>

<!-- ============================================ -->
<!-- CUSTOMER: BUY VOUCHER PAGE                  -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-ticket-alt"></i> <?php echo t('buy_wifi_voucher'); ?></h2>
        <small class="text-muted">Purchase WiFi access or connect with an existing voucher</small>
    </div>
    <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
        <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
    </a>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- ACTIVE SESSIONS                             -->
<!-- ============================================ -->
<?php if (count($customerSessions) > 0): ?>
<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0"><i class="fas fa-wifi text-success"></i> <?php echo t('my_sessions'); ?></h5>
    </div>
    <div class="card-body">
        <?php foreach ($customerSessions as $cs): 
            $minutesRemaining = intval($cs['minutes_remaining'] ?? 0);
            $timeClass = $minutesRemaining <= 5 ? 'critical' : ($minutesRemaining <= 15 ? 'warning' : 'good');
        ?>
        <div class="session-card mb-2">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <strong><i class="fas fa-wifi text-success"></i> <?php echo htmlspecialchars($cs['router_name']); ?></strong>
                    <?php if ($cs['voucher_code']): ?>
                    <br><small class="text-muted">Voucher: <code><?php echo htmlspecialchars($cs['voucher_code']); ?></code></small>
                    <?php endif; ?>
                </div>
                <div class="text-end">
                    <div class="time-remaining <?php echo $timeClass; ?>">
                        <i class="fas fa-hourglass-half"></i> <?php echo $minutesRemaining; ?>m
                    </div>
                    <small class="text-muted"><?php echo t('time_remaining'); ?></small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- TWO COLUMN LAYOUT                           -->
<!-- ============================================ -->
<div class="row">
    <!-- CONNECT WITH VOUCHER -->
    <div class="col-md-5 mb-4">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="fas fa-wifi text-primary"></i> <?php echo t('connect_to_wifi'); ?></h5>
            </div>
            <div class="card-body">
                <p class="text-muted small mb-3"><?php echo t('enter_voucher_desc'); ?></p>
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('enter_voucher'); ?></label>
                        <input type="text" name="voucher_code" class="form-control form-control-lg text-center" 
                               placeholder="XXXXXXXXXX" style="font-family:monospace;letter-spacing:2px;text-transform:uppercase;"
                               maxlength="20" required autocomplete="off">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('device_name'); ?> (<?php echo t('optional'); ?>)</label>
                        <input type="text" name="device_name" class="form-control" 
                               placeholder="e.g., My Phone" value="Web Device">
                    </div>
                    <button type="submit" name="connect_voucher" class="btn btn-success w-100">
                        <i class="fas fa-wifi"></i> <?php echo t('connect'); ?>
                    </button>
                </form>
                
                <hr class="my-3" style="border-color:var(--border-color);">
                
                <div class="text-center">
                    <small class="text-muted"><?php echo t('no_account'); ?? "Don't have a voucher?"; ?></small>
                    <br>
                    <a href="#packagesSection" class="btn btn-link btn-sm">
                        <i class="fas fa-arrow-down"></i> <?php echo t('buy_now'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- BUY VOUCHER -->
    <div class="col-md-7 mb-4" id="packagesSection">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="fas fa-shopping-cart text-success"></i> <?php echo t('buy_wifi_voucher'); ?></h5>
            </div>
            <div class="card-body">
                <?php if (count($availablePackages) > 0): ?>
                    <!-- Package Selection -->
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('select_package'); ?></label>
                        <select class="form-select" id="packageSelect" onchange="selectPackage(this.value)">
                            <option value=""><?php echo t('choose_package'); ?></option>
                            <?php foreach ($availablePackages as $ap): 
                                $durText = '';
                                if ($ap['duration_minutes'] >= 1440) $durText = round($ap['duration_minutes'] / 1440, 1) . ' days';
                                elseif ($ap['duration_minutes'] >= 60) $durText = round($ap['duration_minutes'] / 60, 1) . ' hrs';
                                else $durText = $ap['duration_minutes'] . ' min';
                            ?>
                            <option value="<?php echo $ap['id']; ?>" <?php echo $selectedPackageId == $ap['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($ap['name']); ?> - 
                                <?php echo CURRENCY . ' ' . number_format($ap['price'], 0); ?> - 
                                <?php echo $durText; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Selected Package Details -->
                    <?php if ($selectedPackage): 
                        $durText = '';
                        if ($selectedPackage['duration_minutes'] >= 1440) $durText = round($selectedPackage['duration_minutes'] / 1440, 1) . ' days';
                        elseif ($selectedPackage['duration_minutes'] >= 60) $durText = round($selectedPackage['duration_minutes'] / 60, 1) . ' hrs';
                        else $durText = $selectedPackage['duration_minutes'] . ' min';
                    ?>
                    <div class="card mb-3" style="background:var(--bg-body);">
                        <div class="card-body">
                            <h6 class="mb-3"><?php echo htmlspecialchars($selectedPackage['name']); ?></h6>
                            
                            <div class="stat-row">
                                <span><i class="fas fa-money-bill-wave text-success"></i> <?php echo t('price'); ?>:</span>
                                <strong class="text-success" style="font-size:1.2rem;">
                                    <?php echo CURRENCY . ' ' . number_format($selectedPackage['price'], 0); ?>
                                </strong>
                            </div>
                            <div class="stat-row">
                                <span><i class="fas fa-clock text-info"></i> <?php echo t('duration'); ?>:</span>
                                <strong><?php echo $durText; ?></strong>
                            </div>
                            <div class="stat-row">
                                <span><i class="fas fa-tachometer-alt text-warning"></i> <?php echo t('speed'); ?>:</span>
                                <strong><?php echo $selectedPackage['speed_limit_mbps']; ?> Mbps</strong>
                            </div>
                            <div class="stat-row">
                                <span><i class="fas fa-database text-primary"></i> <?php echo t('data_limit'); ?>:</span>
                                <strong><?php echo $selectedPackage['data_limit_mb'] > 0 ? $selectedPackage['data_limit_mb'] . ' MB' : t('unlimited'); ?></strong>
                            </div>
                            <div class="stat-row">
                                <span><i class="fas fa-laptop text-success"></i> <?php echo t('max_devices'); ?>:</span>
                                <strong><?php echo $selectedPackage['max_devices']; ?></strong>
                            </div>
                            <div class="stat-row">
                                <span><i class="fas fa-wifi text-primary"></i> <?php echo t('router'); ?>:</span>
                                <strong><?php echo htmlspecialchars($selectedPackage['router_name']); ?></strong>
                            </div>
                            <?php if ($selectedPackage['location']): ?>
                            <div class="stat-row">
                                <span><i class="fas fa-map-marker-alt text-danger"></i> <?php echo t('location'); ?>:</span>
                                <strong><?php echo htmlspecialchars($selectedPackage['location']); ?></strong>
                            </div>
                            <?php endif; ?>
                            <div class="stat-row">
                                <span><i class="fas fa-user text-info"></i> <?php echo t('sold_by'); ?>:</span>
                                <strong><?php echo htmlspecialchars($selectedPackage['seller_name']); ?></strong>
                            </div>
                            <div class="stat-row">
                                <span><i class="fas fa-ticket-alt text-success"></i> <?php echo t('available'); ?>:</span>
                                <span class="badge bg-<?php echo $selectedPackage['available_vouchers'] > 0 ? 'success' : 'danger'; ?>">
                                    <?php echo $selectedPackage['available_vouchers']; ?> <?php echo t('available'); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Payment Form -->
                    <?php if ($selectedPackage['available_vouchers'] > 0): ?>
                    <form method="POST">
                        <input type="hidden" name="package_id" value="<?php echo $selectedPackage['id']; ?>">
                        
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('phone_number'); ?> <span class="text-danger">*</span></label>
                            <input type="tel" name="phone" class="form-control" 
                                   placeholder="07XXXXXXXX" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('payment_method'); ?> <span class="text-danger">*</span></label>
                            <select name="payment_method" class="form-select" required>
                                <option value="mpesa">M-Pesa (Vodacom)</option>
                                <option value="tigopesa">Tigo Pesa</option>
                                <option value="airtelmoney">Airtel Money</option>
                                <option value="halopesa">HaloPesa</option>
                            </select>
                        </div>
                        
                        <button type="submit" name="buy_voucher" class="btn btn-primary w-100 py-3">
                            <i class="fas fa-credit-card"></i> 
                            <?php echo t('pay'); ?> <?php echo CURRENCY . ' ' . number_format($selectedPackage['price'], 0); ?>
                        </button>
                    </form>
                    <?php else: ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        This package is currently out of stock. Please choose another package.
                    </div>
                    <?php endif; ?>
                    
                    <?php else: ?>
                    <!-- No package selected - show list -->
                    <p class="text-muted text-center mb-3">
                        <i class="fas fa-arrow-up"></i> <?php echo t('select_package'); ?>
                    </p>
                    
                    <div class="row">
                        <?php foreach (array_slice($availablePackages, 0, 6) as $ap): 
                            $durText = '';
                            if ($ap['duration_minutes'] >= 1440) $durText = round($ap['duration_minutes'] / 1440, 1) . 'd';
                            elseif ($ap['duration_minutes'] >= 60) $durText = round($ap['duration_minutes'] / 60, 1) . 'h';
                            else $durText = $ap['duration_minutes'] . 'm';
                        ?>
                        <div class="col-6 mb-2">
                            <a href="?page=voucher&package=<?php echo $ap['id']; ?>" class="text-decoration-none">
                                <div class="card p-2 h-100 quick-action-card">
                                    <div class="d-flex justify-content-between">
                                        <div class="fw-semibold small"><?php echo htmlspecialchars($ap['name']); ?></div>
                                    </div>
                                    <div class="text-success fw-bold" style="font-size:1.1rem;">
                                        <?php echo CURRENCY . ' ' . number_format($ap['price'], 0); ?>
                                    </div>
                                    <small class="text-muted">
                                        <i class="fas fa-clock"></i> <?php echo $durText; ?> |
                                        <i class="fas fa-tachometer-alt"></i> <?php echo $ap['speed_limit_mbps']; ?>Mbps
                                    </small>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <i class="fas fa-box"></i>
                        <p><?php echo t('no_packages_available'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function selectPackage(id) {
    if (id) {
        window.location.href = '?page=voucher&package=' + id;
    } else {
        window.location.href = '?page=voucher';
    }
}

// Auto-scroll to packages section
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.hash === '#packagesSection') {
        const el = document.getElementById('packagesSection');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
});
</script>

<?php
}
?>