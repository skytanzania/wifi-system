<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Withdraw Page - FIXED VERSION
 * 
 * All potential errors handled:
 * - Missing functions
 * - Missing settings
 * - Missing columns
 * - Safe null checks
 */

// Defensive: Ensure we have access to required context
if (!isset($auth) || !isset($conn) || !isset($user)) {
    if (function_exists('redirectTo')) {
        redirectTo('?page=login');
    } else {
        header('Location: ?page=login');
        exit;
    }
}

// Defensive: translation function
if (!function_exists('t')) {
    function t($key) {
        global $translations, $currentLang;
        if (isset($translations[$currentLang][$key])) {
            return $translations[$currentLang][$key];
        }
        if (isset($translations['en'][$key])) {
            return $translations['en'][$key];
        }
        return $key;
    }
}

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

if (!$user) {
    header('Location: ?page=login');
    exit;
}

$msg = '';
$error = '';
$pendingMessage = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// CONFIGURATION
// ============================================
$platformFeePercent = defined('WITHDRAWAL_FEE_PERCENT') ? WITHDRAWAL_FEE_PERCENT : 4;
$sonicPesaFeePercent = 6;
$totalFeePercent = $platformFeePercent + $sonicPesaFeePercent;
$sonicMinPayout = defined('SONIC_PESA_MIN_PAYOUT') ? SONIC_PESA_MIN_PAYOUT : 30000;

// Safe currency
$currency = defined('CURRENCY') ? CURRENCY : 'TZS';

// Get minimum withdrawal from settings (SAFE)
$minWithdrawal = 5000;
try {
    $res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'min_withdrawal' LIMIT 1");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if (!empty($row['setting_value'])) {
            $minWithdrawal = floatval($row['setting_value']);
        }
    }
} catch (Throwable $e) {
    // Silently use default
}

// Effective minimum calculation
$minForSonic = ceil($sonicMinPayout / (1 - $platformFeePercent / 100));
$effectiveMinWithdrawal = max($minWithdrawal, $minForSonic);

// Allowed withdrawal methods
$allowedMethods = [
    'mpesa' => ['label' => 'M-Pesa', 'icon' => 'mobile-alt', 'placeholder' => '07XXXXXXXX', 'hint' => 'Vodacom M-Pesa number'],
    'tigopesa' => ['label' => 'Tigo Pesa', 'icon' => 'mobile-alt', 'placeholder' => '07XXXXXXXX', 'hint' => 'Tigo Pesa number'],
    'airtelmoney' => ['label' => 'Airtel Money', 'icon' => 'mobile-alt', 'placeholder' => '07XXXXXXXX', 'hint' => 'Airtel Money number'],
    'halopesa' => ['label' => 'HaloPesa', 'icon' => 'mobile-alt', 'placeholder' => '07XXXXXXXX', 'hint' => 'Halotel HaloPesa number'],
    'crdb' => ['label' => 'CRDB Bank', 'icon' => 'university', 'placeholder' => 'Account Number', 'hint' => 'CRDB Bank account number'],
    'nmb' => ['label' => 'NMB Bank', 'icon' => 'university', 'placeholder' => 'Account Number', 'hint' => 'NMB Bank account number'],
    'selcom' => ['label' => 'Selcom', 'icon' => 'credit-card', 'placeholder' => '9-digit card number', 'hint' => 'Selcom: 9-digit (7XXXXXXXX) or card number'],
];

// ============================================
// HANDLE WITHDRAWAL REQUEST
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_withdrawal'])) {
    $amount = round(floatval($_POST['amount'] ?? 0), 2);
    $method = $_POST['method'] ?? '';
    $accountNumber = trim($_POST['account_number'] ?? '');
    $accountName = trim($_POST['account_name'] ?? '');
    
    // Refresh user
    $user = $auth->getUser();
    $currentBalance = floatval($user['balance'] ?? 0);
    
    // Validation
    if (!array_key_exists($method, $allowedMethods)) {
        $error = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Invalid withdrawal method</div>';
    } elseif ($accountNumber === '') {
        $error = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Account number is required</div>';
    } elseif ($amount <= 0) {
        $error = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Please enter a valid amount</div>';
    } elseif ($amount > $currentBalance) {
        $error = '<div class="insufficient-balance-alert">
            <i class="fas fa-exclamation-triangle text-danger"></i> 
            <strong>Insufficient balance</strong><br>
            Your balance: <strong>' . $currency . ' ' . number_format($currentBalance, 2) . '</strong> | 
            Requested: <strong>' . $currency . ' ' . number_format($amount, 2) . '</strong>
        </div>';
    } elseif ($amount < $effectiveMinWithdrawal) {
        $error = '<div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle"></i> 
            <strong>Below minimum withdrawal</strong><br>
            Minimum: <strong>' . $currency . ' ' . number_format($effectiveMinWithdrawal, 0) . '</strong>
        </div>';
    } else {
        // Calculate fees
        $platformFee = round($amount * $platformFeePercent / 100, 2);
        $amountToSonic = round($amount - $platformFee, 2);
        $sonicPesaFee = round($amountToSonic * $sonicPesaFeePercent / 100, 2);
        $netAmount = round($amountToSonic - $sonicPesaFee, 2);
        $totalFee = round($platformFee + $sonicPesaFee, 2);
        
        // Verify minimum for Sonic Pesa
        if ($amountToSonic < $sonicMinPayout) {
            $error = '<div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i>
                <strong>Below Sonic Pesa minimum</strong><br>
                Amount sent to Sonic must be at least ' . $currency . ' ' . number_format($sonicMinPayout, 0) . '
            </div>';
        } else {
            $withdrawalId = null;
            try {
                $conn->begin_transaction();
                
                // Deduct from balance
                $upd = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ? AND balance >= ?");
                if (!$upd) throw new Exception("Prepare failed: " . $conn->error);
                
                $upd->bind_param("did", $amount, $userId, $amount);
                $upd->execute();
                
                if ($upd->affected_rows !== 1) {
                    throw new Exception("Insufficient balance");
                }
                
                // Create withdrawal record
                $stmt = $conn->prepare("INSERT INTO withdrawals (user_id, amount, fee, net_amount, method, account_number, account_name, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
                if (!$stmt) throw new Exception("Prepare failed: " . $conn->error);
                
                $stmt->bind_param("idddsss", $userId, $amount, $totalFee, $netAmount, $method, $accountNumber, $accountName);
                $stmt->execute();
                $withdrawalId = $conn->insert_id;
                
                $conn->commit();
                
                // Call Sonic Pesa API (only if class is available)
                $payoutResult = ['success' => false, 'message' => 'Sonic Pesa not available', 'pending' => false];
                
                if (isset($sonicPayout) && is_object($sonicPayout) && method_exists($sonicPayout, 'createPayout')) {
                    $payoutResult = $sonicPayout->createPayout($amountToSonic, $method, $accountNumber, $accountName);
                }
                
                if ($payoutResult['success']) {
                    $sonicData = $payoutResult['data'] ?? [];
                    $sonicWithdrawalId = $sonicData['withdrawal_id'] ?? null;
                    $sonicFee = $sonicData['fee'] ?? $sonicPesaFee;
                    $sonicNetAmount = $sonicData['net_amount'] ?? $netAmount;
                    $sonicResponse = json_encode($sonicData);
                    $newStatus = 'processing';
                    
                    // Update withdrawal
                    $updStmt = $conn->prepare("UPDATE withdrawals SET status = ?, sonic_pesa_withdrawal_id = ?, sonic_pesa_fee = ?, sonic_pesa_net_amount = ?, sonic_pesa_response = ? WHERE id = ?");
                    if ($updStmt) {
                        $updStmt->bind_param("siddssi", $newStatus, $sonicWithdrawalId, $sonicFee, $sonicNetAmount, $sonicResponse, $withdrawalId);
                        $updStmt->execute();
                    }
                    
                    // Transaction record
                    $txnRef = 'WTH' . strtoupper(uniqid());
                    $stmt = $conn->prepare("INSERT INTO transactions (user_id, seller_id, transaction_ref, amount, payment_method, type, status, notes) VALUES (?, ?, ?, ?, ?, 'withdrawal', 'pending', ?)");
                    if ($stmt) {
                        $note = 'Sonic Pesa Payout ID: ' . ($sonicWithdrawalId ?? 'N/A');
                        $stmt->bind_param("iisdss", $userId, $userId, $txnRef, $amount, $method, $note);
                        $stmt->execute();
                    }
                    
                    // Notification
                    if (isset($notificationManager) && is_object($notificationManager)) {
                        try {
                            $notificationManager->create(
                                $userId,
                                'Withdrawal Processing',
                                'Your withdrawal of ' . $currency . ' ' . number_format($amount, 0) . ' is being processed.',
                                'info',
                                '?page=withdraw',
                                'money-bill-wave'
                            );
                        } catch (Throwable $e) {}
                    }
                    
                    $pendingMessage = '<div class="pending-withdrawal-alert">
                        <h5 class="mb-2"><i class="fas fa-clock text-warning"></i> Withdrawal Pending</h5>
                        <p class="mb-3">Your withdrawal request has been received and is being processed.</p>
                        <div class="withdraw-summary">
                            <div class="fw-semibold mb-2"><i class="fas fa-calculator"></i> Summary</div>
                            <div class="row-line"><span>Requested</span><span>' . $currency . ' ' . number_format($amount, 2) . '</span></div>
                            <div class="row-line text-danger"><span>Platform Fee (' . $platformFeePercent . '%)</span><span>- ' . $currency . ' ' . number_format($platformFee, 2) . '</span></div>
                            <div class="row-line"><span>To Sonic Pesa</span><span>' . $currency . ' ' . number_format($amountToSonic, 2) . '</span></div>
                            <div class="row-line text-danger"><span>Sonic Fee (' . $sonicPesaFeePercent . '%)</span><span>- ' . $currency . ' ' . number_format($sonicPesaFee, 2) . '</span></div>
                            <div class="row-line"><span>Total Fee</span><span class="text-danger">- ' . $currency . ' ' . number_format($totalFee, 2) . '</span></div>
                            <div class="row-line total"><span>You Will Receive</span><span>' . $currency . ' ' . number_format($netAmount, 2) . '</span></div>
                        </div>
                        <div class="small text-muted mt-2">
                            <i class="fas fa-info-circle"></i> Withdrawal ID: #' . $withdrawalId . '
                        </div>
                    </div>';
                    
                    $user = $auth->getUser();
                    
                } else {
                    // Failed or pending
                    if (isset($payoutResult['pending']) && $payoutResult['pending']) {
                        $pendingMessage = '<div class="pending-withdrawal-alert">
                            <h5 class="mb-2"><i class="fas fa-clock text-warning"></i> Withdrawal Pending</h5>
                            <p class="mb-3">Your withdrawal is being processed.</p>
                            <div class="small text-muted">
                                Withdrawal ID: #' . $withdrawalId . '
                            </div>
                        </div>';
                        $conn->query("UPDATE withdrawals SET status = 'processing' WHERE id = $withdrawalId");
                        $user = $auth->getUser();
                    } else {
                        // Rollback
                        $failMsg = $payoutResult['message'] ?? 'Unknown error';
                        $conn->query("UPDATE withdrawals SET status = 'rejected', admin_notes = 'Sonic Pesa payout failed: " . $conn->real_escape_string($failMsg) . "' WHERE id = $withdrawalId");
                        $conn->query("UPDATE users SET balance = balance + $amount WHERE id = $userId");
                        $error = '<div class="alert alert-danger">
                            <i class="fas fa-times-circle"></i> 
                            <strong>Payout failed</strong><br>
                            ' . htmlspecialchars($failMsg) . '
                        </div>';
                        $user = $auth->getUser();
                    }
                }
            } catch (Throwable $e) {
                if ($conn->connect_errno === 0) {
                    $conn->rollback();
                }
                $error = '<div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> 
                    Withdrawal failed: ' . htmlspecialchars($e->getMessage()) . '
                </div>';
            }
        }
    }
}

// ============================================
// FETCH DATA
// ============================================

// Refresh user balance
$user = $auth->getUser();
$availableBalance = floatval($user['balance'] ?? 0);

// Withdrawals
$withdrawals = [];
try {
    $stmt = $conn->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 100");
    if ($stmt) {
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result) {
            $withdrawals = $result->fetch_all(MYSQLI_ASSOC);
        }
    }
} catch (Throwable $e) {
    $withdrawals = [];
}

// Withdrawal stats
$withdrawStats = [
    'total' => 0, 'pending' => 0, 'processing' => 0, 'completed' => 0,
    'rejected' => 0, 'total_withdrawn' => 0, 'total_fees' => 0, 'total_pending_amount' => 0
];

try {
    $res = $conn->query("SELECT COUNT(*) as c FROM withdrawals WHERE user_id = $userId");
    if ($res) $withdrawStats['total'] = intval($res->fetch_assoc()['c']);
    
    $res = $conn->query("SELECT COUNT(*) as c FROM withdrawals WHERE user_id = $userId AND status = 'pending'");
    if ($res) $withdrawStats['pending'] = intval($res->fetch_assoc()['c']);
    
    $res = $conn->query("SELECT COUNT(*) as c FROM withdrawals WHERE user_id = $userId AND status = 'processing'");
    if ($res) $withdrawStats['processing'] = intval($res->fetch_assoc()['c']);
    
    $res = $conn->query("SELECT COUNT(*) as c FROM withdrawals WHERE user_id = $userId AND status = 'completed'");
    if ($res) $withdrawStats['completed'] = intval($res->fetch_assoc()['c']);
    
    $res = $conn->query("SELECT COUNT(*) as c FROM withdrawals WHERE user_id = $userId AND status = 'rejected'");
    if ($res) $withdrawStats['rejected'] = intval($res->fetch_assoc()['c']);
    
    $res = $conn->query("SELECT COALESCE(SUM(net_amount), 0) as total FROM withdrawals WHERE user_id = $userId AND status = 'completed'");
    if ($res) $withdrawStats['total_withdrawn'] = floatval($res->fetch_assoc()['total']);
    
    $res = $conn->query("SELECT COALESCE(SUM(fee), 0) as total FROM withdrawals WHERE user_id = $userId");
    if ($res) $withdrawStats['total_fees'] = floatval($res->fetch_assoc()['total']);
    
    $res = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM withdrawals WHERE user_id = $userId AND status IN ('pending', 'processing')");
    if ($res) $withdrawStats['total_pending_amount'] = floatval($res->fetch_assoc()['total']);
} catch (Throwable $e) {}

$hasPendingWithdrawal = ($withdrawStats['pending'] + $withdrawStats['processing']) > 0;

// Total earnings
$totalEarnings = 0;
try {
    $res = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE seller_id = $userId AND payment_status = 'completed'");
    if ($res) $totalEarnings = floatval($res->fetch_assoc()['total']);
} catch (Throwable $e) {}

// ============================================
// RENDER
// ============================================
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-money-bill-wave"></i> <?php echo t('withdraw'); ?></h2>
        <small class="text-muted">Request withdrawals via Sonic Pesa to mobile money or bank</small>
    </div>
    <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
        <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
    </a>
</div>

<?php echo $msg; ?>
<?php echo $pendingMessage; ?>
<?php if ($error): ?>
    <?php echo $error; ?>
<?php endif; ?>

<!-- BALANCE OVERVIEW -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('available_balance'); ?></h6>
                    <h4 class="fw-bold mb-0"><?php echo $currency . ' ' . number_format($availableBalance, 0); ?></h4>
                    <small style="opacity:0.85;">Ready to withdraw</small>
                </div>
                <i class="fas fa-wallet" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card success">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('total_earnings'); ?></h6>
                    <h4 class="fw-bold mb-0"><?php echo $currency . ' ' . number_format($totalEarnings, 0); ?></h4>
                    <small style="opacity:0.85;">All time</small>
                </div>
                <i class="fas fa-chart-line" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card info">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1">Withdrawn</h6>
                    <h4 class="fw-bold mb-0"><?php echo $currency . ' ' . number_format($withdrawStats['total_withdrawn'], 0); ?></h4>
                    <small style="opacity:0.85;"><?php echo $withdrawStats['completed']; ?> completed</small>
                </div>
                <i class="fas fa-check-circle" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card warning">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1">Pending</h6>
                    <h4 class="fw-bold mb-0"><?php echo $currency . ' ' . number_format($withdrawStats['total_pending_amount'], 0); ?></h4>
                    <small style="opacity:0.85;"><?php echo $withdrawStats['pending'] + $withdrawStats['processing']; ?> in process</small>
                </div>
                <i class="fas fa-clock" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
</div>

<?php if ($hasPendingWithdrawal): ?>
<div class="alert alert-info mb-4">
    <i class="fas fa-info-circle"></i>
    <strong>You have <?php echo ($withdrawStats['pending'] + $withdrawStats['processing']); ?> withdrawal(s) in progress.</strong>
    <br><small>You can request a new withdrawal while others are processing.</small>
</div>
<?php endif; ?>

<!-- MAIN LAYOUT -->
<div class="row">
    
    <!-- WITHDRAWAL FORM -->
    <div class="col-lg-5 mb-4">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="fas fa-hand-holding-usd text-success"></i> <?php echo t('request_withdrawal'); ?></h5>
            </div>
            <div class="card-body">
                
                <div class="alert alert-info mb-3">
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo t('your_balance'); ?>:</span>
                        <strong><?php echo $currency . ' ' . number_format($availableBalance, 2); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo t('minimum_withdrawal'); ?>:</span>
                        <strong><?php echo $currency . ' ' . number_format($effectiveMinWithdrawal, 0); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo t('platform_fee'); ?>:</span>
                        <strong class="text-danger"><?php echo $platformFeePercent; ?>%</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo t('sonic_pesa_fee'); ?>:</span>
                        <strong class="text-danger"><?php echo $sonicPesaFeePercent; ?>%</strong>
                    </div>
                    <div class="d-flex justify-content-between border-top pt-2 mt-2" style="border-color:var(--border-color) !important;">
                        <span><?php echo t('total_fee'); ?>:</span>
                        <strong class="text-danger"><?php echo $totalFeePercent; ?>%</strong>
                    </div>
                </div>
                
                <div class="alert alert-warning small mb-3">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Sonic Pesa Minimum:</strong> <?php echo $currency . ' ' . number_format($sonicMinPayout, 0); ?><br>
                    <small>Minimum withdrawal: <strong><?php echo $currency . ' ' . number_format($effectiveMinWithdrawal, 0); ?></strong></small>
                </div>
                
                <form method="POST" id="withdrawForm">
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('amount'); ?> <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><?php echo $currency; ?></span>
                            <input type="number" 
                                   name="amount" 
                                   id="wdAmount" 
                                   class="form-control form-control-lg" 
                                   min="<?php echo $effectiveMinWithdrawal; ?>" 
                                   max="<?php echo $availableBalance; ?>" 
                                   step="100"
                                   value="<?php echo min(max($availableBalance, 0), $effectiveMinWithdrawal); ?>"
                                   required 
                                   oninput="updateWithdrawSummary()">
                        </div>
                        <div class="d-flex justify-content-between mt-1">
                            <small class="text-muted">
                                <button type="button" class="btn btn-sm btn-link p-0" onclick="setAmount(<?php echo $availableBalance; ?>)">
                                    Withdraw All
                                </button>
                            </small>
                            <small class="text-muted">
                                Min: <?php echo $currency . ' ' . number_format($effectiveMinWithdrawal, 0); ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="withdraw-summary mb-3" id="wdSummary">
                        <div class="fw-semibold mb-1">
                            <i class="fas fa-calculator"></i> <?php echo t('withdrawal_summary'); ?>
                        </div>
                        <div class="row-line">
                            <span><?php echo t('requested_amount'); ?></span>
                            <span id="wdRequested"><?php echo $currency; ?> 0.00</span>
                        </div>
                        <div class="row-line text-danger">
                            <span><?php echo t('platform_fee'); ?> (<?php echo $platformFeePercent; ?>%)</span>
                            <span id="wdPlatformFee">- <?php echo $currency; ?> 0.00</span>
                        </div>
                        <div class="row-line sub">
                            <span><?php echo t('amount_sent_to_sonic'); ?></span>
                            <span id="wdToSonic"><?php echo $currency; ?> 0.00</span>
                        </div>
                        <div class="row-line text-danger">
                            <span><?php echo t('sonic_pesa_fee'); ?> (<?php echo $sonicPesaFeePercent; ?>%)</span>
                            <span id="wdSonicFee">- <?php echo $currency; ?> 0.00</span>
                        </div>
                        <div class="row-line">
                            <span><?php echo t('total_fee'); ?> (<?php echo $totalFeePercent; ?>%)</span>
                            <span id="wdTotalFee" class="text-danger">- <?php echo $currency; ?> 0.00</span>
                        </div>
                        <div class="row-line total">
                            <span><?php echo t('amount_after_sonic_fee'); ?></span>
                            <span id="wdNet"><?php echo $currency; ?> 0.00</span>
                        </div>
                        <div class="small text-warning mt-1" id="wdMinWarning" style="display:none;">
                            <i class="fas fa-exclamation-triangle"></i> 
                            Below Sonic Pesa minimum
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label small">Quick amounts:</label>
                        <div class="d-flex gap-2 flex-wrap">
                            <?php 
                            $quickAmounts = [30000, 50000, 100000, 200000, 500000];
                            foreach ($quickAmounts as $qa): 
                                if ($qa <= $availableBalance && $qa >= $effectiveMinWithdrawal):
                            ?>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setAmount(<?php echo $qa; ?>)">
                                <?php echo number_format($qa / 1000, 0); ?>K
                            </button>
                            <?php endif; endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('method'); ?> <span class="text-danger">*</span></label>
                        <select name="method" class="form-select" required onchange="updateMethodHint()" id="wdMethod">
                            <?php foreach ($allowedMethods as $key => $info): ?>
                            <option value="<?php echo $key; ?>" data-placeholder="<?php echo htmlspecialchars($info['placeholder']); ?>" data-hint="<?php echo htmlspecialchars($info['hint']); ?>">
                                <?php echo htmlspecialchars($info['label']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('account_number'); ?> <span class="text-danger">*</span></label>
                        <input type="text" 
                               name="account_number" 
                               id="wdAccountNumber"
                               class="form-control" 
                               placeholder="<?php echo htmlspecialchars($allowedMethods['mpesa']['placeholder']); ?>" 
                               required>
                        <small class="text-muted" id="wdMethodHint"><?php echo htmlspecialchars($allowedMethods['mpesa']['hint']); ?></small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('account_name'); ?></label>
                        <input type="text" 
                               name="account_name" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>"
                               placeholder="Your name on the account">
                    </div>
                    
                    <button type="submit" 
                            name="request_withdrawal" 
                            class="btn btn-success w-100 py-3" 
                            id="wdSubmitBtn"
                            <?php echo $availableBalance < $effectiveMinWithdrawal ? 'disabled' : ''; ?>
                            onclick="return confirmWithdrawal();">
                        <i class="fas fa-paper-plane"></i> 
                        <span id="wdSubmitText">
                            <?php if ($availableBalance < $effectiveMinWithdrawal): ?>
                                Insufficient Balance
                            <?php else: ?>
                                <?php echo t('submit_request'); ?>
                            <?php endif; ?>
                        </span>
                    </button>
                    
                    <?php if ($availableBalance < $effectiveMinWithdrawal): ?>
                    <div class="alert alert-warning small mt-3 mb-0">
                        <i class="fas fa-exclamation-triangle"></i>
                        You need at least <?php echo $currency . ' ' . number_format($effectiveMinWithdrawal, 0); ?> 
                        to make a withdrawal. You currently have <?php echo $currency . ' ' . number_format($availableBalance, 0); ?>.
                    </div>
                    <?php endif; ?>
                </form>
                
                <hr class="my-3" style="border-color:var(--border-color);">
                
                <div class="small text-muted">
                    <div class="fw-semibold mb-2"><i class="fas fa-info-circle"></i> How withdrawals work:</div>
                    <ul class="mb-0 ps-3">
                        <li>Submitted via <strong>Sonic Pesa</strong> automatically</li>
                        <li>You will receive a notification once processed</li>
                        <li>Mobile money: instant to a few minutes</li>
                        <li>Bank transfers: up to 24 hours</li>
                        <li>Fees: <?php echo $totalFeePercent; ?>% total</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- WITHDRAWAL HISTORY -->
    <div class="col-lg-7 mb-4">
        <div class="row mb-3">
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label small">Total</div>
                    <div class="metric-value" style="font-size:1.3rem;"><?php echo $withdrawStats['total']; ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label small">Pending</div>
                    <div class="metric-value text-warning" style="font-size:1.3rem;"><?php echo $withdrawStats['pending']; ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label small">Completed</div>
                    <div class="metric-value text-success" style="font-size:1.3rem;"><?php echo $withdrawStats['completed']; ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label small">Rejected</div>
                    <div class="metric-value text-danger" style="font-size:1.3rem;"><?php echo $withdrawStats['rejected']; ?></div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-history"></i> <?php echo t('withdrawal_history'); ?></h5>
                <span class="badge bg-secondary"><?php echo count($withdrawals); ?> records</span>
            </div>
            <div class="card-body p-0">
                <?php if (count($withdrawals) > 0): ?>
                    <div class="table-responsive" style="max-height:600px;overflow-y:auto;">
                        <table class="table table-hover mobile-card-table mb-0">
                            <thead style="position:sticky;top:0;background:var(--bg-card);z-index:2;">
                                <tr>
                                    <th>#</th>
                                    <th><?php echo t('amount'); ?></th>
                                    <th><?php echo t('fee'); ?></th>
                                    <th><?php echo t('net_amount'); ?></th>
                                    <th><?php echo t('method'); ?></th>
                                    <th><?php echo t('status'); ?></th>
                                    <th><?php echo t('date'); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($withdrawals as $w): 
                                    $statusColor = [
                                        'pending' => 'warning',
                                        'processing' => 'info',
                                        'completed' => 'success',
                                        'rejected' => 'danger'
                                    ][$w['status']] ?? 'secondary';
                                    
                                    $statusIcon = [
                                        'pending' => 'clock',
                                        'processing' => 'sync',
                                        'completed' => 'check-circle',
                                        'rejected' => 'times-circle'
                                    ][$w['status']] ?? 'circle';
                                    
                                    $methodInfo = $allowedMethods[$w['method']] ?? ['label' => ucfirst($w['method']), 'icon' => 'credit-card'];
                                ?>
                                <tr>
                                    <td data-label="#"><small class="text-muted">#<?php echo $w['id']; ?></small></td>
                                    <td data-label="<?php echo t('amount'); ?>">
                                        <strong><?php echo $currency . ' ' . number_format($w['amount'], 0); ?></strong>
                                    </td>
                                    <td data-label="<?php echo t('fee'); ?>">
                                        <small class="text-danger">-<?php echo $currency . ' ' . number_format($w['fee'], 0); ?></small>
                                    </td>
                                    <td data-label="<?php echo t('net_amount'); ?>">
                                        <strong class="text-success"><?php echo $currency . ' ' . number_format($w['net_amount'], 0); ?></strong>
                                    </td>
                                    <td data-label="<?php echo t('method'); ?>">
                                        <i class="fas fa-<?php echo $methodInfo['icon']; ?> text-primary"></i>
                                        <small><?php echo htmlspecialchars($methodInfo['label']); ?></small>
                                    </td>
                                    <td data-label="<?php echo t('status'); ?>">
                                        <span class="badge bg-<?php echo $statusColor; ?>">
                                            <i class="fas fa-<?php echo $statusIcon; ?>"></i>
                                            <?php echo htmlspecialchars($w['status']); ?>
                                        </span>
                                    </td>
                                    <td data-label="<?php echo t('date'); ?>">
                                        <small><?php echo date('d M Y', strtotime($w['created_at'])); ?></small>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                data-bs-toggle="modal" data-bs-target="#withdrawDetailModal<?php echo $w['id']; ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                                
                                <div class="modal fade" id="withdrawDetailModal<?php echo $w['id']; ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title"><i class="fas fa-money-bill-wave"></i> Withdrawal #<?php echo $w['id']; ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="alert alert-<?php echo $statusColor; ?> text-center">
                                                    <i class="fas fa-<?php echo $statusIcon; ?> fa-2x mb-2"></i>
                                                    <h5 class="mb-0"><?php echo ucfirst($w['status']); ?></h5>
                                                </div>
                                                
                                                <div class="stat-row">
                                                    <span>Amount:</span>
                                                    <strong><?php echo $currency . ' ' . number_format($w['amount'], 2); ?></strong>
                                                </div>
                                                <div class="stat-row">
                                                    <span>Fee:</span>
                                                    <strong class="text-danger">-<?php echo $currency . ' ' . number_format($w['fee'], 2); ?></strong>
                                                </div>
                                                <div class="stat-row">
                                                    <span>Net:</span>
                                                    <strong class="text-success"><?php echo $currency . ' ' . number_format($w['net_amount'], 2); ?></strong>
                                                </div>
                                                <div class="stat-row">
                                                    <span>Method:</span>
                                                    <strong><?php echo htmlspecialchars($methodInfo['label']); ?></strong>
                                                </div>
                                                <div class="stat-row">
                                                    <span>Account:</span>
                                                    <strong><?php echo htmlspecialchars($w['account_number']); ?></strong>
                                                </div>
                                                <div class="stat-row">
                                                    <span>Date:</span>
                                                    <span><?php echo date('d M Y H:i', strtotime($w['created_at'])); ?></span>
                                                </div>
                                                
                                                <?php if ($w['status'] === 'rejected' && !empty($w['admin_notes'])): ?>
                                                <div class="alert alert-danger small mt-3 mb-0">
                                                    <strong>Reason:</strong><br>
                                                    <?php echo nl2br(htmlspecialchars($w['admin_notes'])); ?>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-money-bill-wave"></i>
                        <h5>No withdrawals yet</h5>
                        <p>Your withdrawal history will appear here.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- INFO CARDS -->
<div class="row mb-4">
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-info-circle text-info"></i> Fee Structure</h6>
                <div class="stat-row">
                    <span>Platform fee</span>
                    <strong class="text-danger"><?php echo $platformFeePercent; ?>%</strong>
                </div>
                <div class="stat-row">
                    <span>Sonic Pesa fee</span>
                    <strong class="text-danger"><?php echo $sonicPesaFeePercent; ?>%</strong>
                </div>
                <div class="stat-row">
                    <span><strong>Total</strong></span>
                    <strong class="text-danger"><?php echo $totalFeePercent; ?>%</strong>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-clock text-warning"></i> Processing Times</h6>
                <ul class="small text-muted mb-0 ps-3">
                    <li class="mb-1"><i class="fas fa-mobile-alt text-primary"></i> Mobile Money — Instant</li>
                    <li class="mb-1"><i class="fas fa-university text-info"></i> Bank Transfer — 1-24 hours</li>
                    <li class="mb-1"><i class="fas fa-credit-card text-success"></i> Selcom — Instant</li>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-shield-alt text-success"></i> Requirements</h6>
                <ul class="small text-muted mb-0 ps-3">
                    <li>Minimum: <strong><?php echo $currency . ' ' . number_format($effectiveMinWithdrawal, 0); ?></strong></li>
                    <li>Valid account/mobile number</li>
                    <li>Processed within 24h</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
const WD_PLATFORM_FEE = <?php echo (float)$platformFeePercent; ?>;
const WD_SONIC_FEE = <?php echo (float)$sonicPesaFeePercent; ?>;
const WD_CURRENCY = '<?php echo addslashes($currency); ?>';
const WD_SONIC_MIN = <?php echo (float)$sonicMinPayout; ?>;
const WD_MIN_WITHDRAWAL = <?php echo (float)$effectiveMinWithdrawal; ?>;
const WD_BALANCE = <?php echo (float)$availableBalance; ?>;

function wdFormat(n) {
    return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function updateWithdrawSummary() {
    const input = document.getElementById('wdAmount');
    if (!input) return;
    
    const amount = Math.max(parseFloat(input.value) || 0, 0);
    const platformFee = Math.round(amount * WD_PLATFORM_FEE) / 100;
    const amountToSonic = Math.round((amount - platformFee) * 100) / 100;
    const sonicFee = Math.round(amountToSonic * WD_SONIC_FEE) / 100;
    const totalFee = Math.round((platformFee + sonicFee) * 100) / 100;
    const net = Math.round((amountToSonic - sonicFee) * 100) / 100;
    
    const setTxt = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
    
    setTxt('wdRequested', WD_CURRENCY + ' ' + wdFormat(amount));
    setTxt('wdPlatformFee', '- ' + WD_CURRENCY + ' ' + wdFormat(platformFee));
    setTxt('wdToSonic', WD_CURRENCY + ' ' + wdFormat(amountToSonic));
    setTxt('wdSonicFee', '- ' + WD_CURRENCY + ' ' + wdFormat(sonicFee));
    setTxt('wdTotalFee', '- ' + WD_CURRENCY + ' ' + wdFormat(totalFee));
    setTxt('wdNet', WD_CURRENCY + ' ' + wdFormat(net));
    
    const warning = document.getElementById('wdMinWarning');
    if (warning) {
        warning.style.display = (amountToSonic > 0 && amountToSonic < WD_SONIC_MIN) ? 'block' : 'none';
    }
    
    const submitBtn = document.getElementById('wdSubmitBtn');
    const submitText = document.getElementById('wdSubmitText');
    
    if (submitBtn && submitText) {
        if (amount < WD_MIN_WITHDRAWAL) {
            submitBtn.disabled = true;
            submitText.textContent = 'Below Minimum';
        } else if (amount > WD_BALANCE) {
            submitBtn.disabled = true;
            submitText.textContent = 'Insufficient Balance';
        } else if (amountToSonic < WD_SONIC_MIN) {
            submitBtn.disabled = true;
            submitText.textContent = 'Below Sonic Minimum';
        } else {
            submitBtn.disabled = false;
            submitText.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Request';
        }
    }
}

function setAmount(amount) {
    const input = document.getElementById('wdAmount');
    if (input) {
        input.value = Math.floor(amount);
        updateWithdrawSummary();
    }
}

function updateMethodHint() {
    const methodSelect = document.getElementById('wdMethod');
    if (!methodSelect) return;
    const selectedOption = methodSelect.options[methodSelect.selectedIndex];
    
    const accountInput = document.getElementById('wdAccountNumber');
    const hintEl = document.getElementById('wdMethodHint');
    
    if (accountInput) accountInput.placeholder = selectedOption.dataset.placeholder || 'Account Number';
    if (hintEl) hintEl.textContent = selectedOption.dataset.hint || '';
    if (accountInput) accountInput.value = '';
}

function confirmWithdrawal() {
    const amountEl = document.getElementById('wdAmount');
    const methodEl = document.getElementById('wdMethod');
    const accountEl = document.getElementById('wdAccountNumber');
    
    if (!amountEl || !methodEl || !accountEl) return true;
    
    const amount = parseFloat(amountEl.value) || 0;
    const methodLabel = methodEl.options[methodEl.selectedIndex].text;
    const accountNumber = accountEl.value;
    
    if (!accountNumber.trim()) {
        alert('Please enter account number');
        return false;
    }
    
    const platformFee = Math.round(amount * WD_PLATFORM_FEE) / 100;
    const amountToSonic = amount - platformFee;
    const sonicFee = Math.round(amountToSonic * WD_SONIC_FEE) / 100;
    const net = amountToSonic - sonicFee;
    
    return confirm(
        'Confirm Withdrawal:\n\n' +
        'Amount: ' + WD_CURRENCY + ' ' + wdFormat(amount) + '\n' +
        'Method: ' + methodLabel + '\n' +
        'Account: ' + accountNumber + '\n\n' +
        'Fees: ' + WD_CURRENCY + ' ' + wdFormat(amount - net) + '\n' +
        'You will receive: ' + WD_CURRENCY + ' ' + wdFormat(net) + '\n\n' +
        'Continue?'
    );
}

document.addEventListener('DOMContentLoaded', function() {
    updateWithdrawSummary();
    updateMethodHint();
});
</script>