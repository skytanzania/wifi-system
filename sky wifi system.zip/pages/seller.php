<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Seller Panel Page - Loaded from external file
 * 
 * Router Management, Package Management, Voucher Generation
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE CHECK ROUTER STATUS
// ============================================
if (isset($_GET['check'])) {
    $checkId = (int)$_GET['check'];
    $stmt = $conn->prepare("SELECT id, device_name FROM routers WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $checkId, $userId);
    $stmt->execute();
    $checkRouter = $stmt->get_result()->fetch_assoc();

    if ($checkRouter) {
        if (strpos($checkRouter['device_name'], 'Sample Router') === 0) {
            $router->updateStatus($checkId, 'online');
            $isOnline = true;
        } else {
            $isOnline = $router->checkOnline($checkId);
        }
        $_SESSION['flash_msg'] = $isOnline
            ? '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . htmlspecialchars($checkRouter['device_name']) . ': ' . t('router_is_online') . '</div>'
            : '<div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> ' . htmlspecialchars($checkRouter['device_name']) . ': ' . t('router_is_offline') . '</div>';
    } else {
        $_SESSION['flash_msg'] = '<div class="alert alert-danger">' . t('router_not_found') . '</div>';
    }
    redirectTo('?page=seller#routers');
}

// ============================================
// HANDLE CREATE SAMPLE ROUTER
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_sample_router'])) {
    $result = $router->createSampleRouter($userId);
    if ($result['success']) {
        $_SESSION['flash_msg'] = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . t('sample_router_created') . '</div>';
        redirectTo('?page=seller#routers');
    } else {
        $msg = '<div class="alert alert-danger">Error: ' . htmlspecialchars($result['message']) . '</div>';
    }
}

// ============================================
// HANDLE ADD ROUTER
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_router'])) {
    $data = [
        'user_id' => $userId,
        'provider_id' => intval($_POST['provider_id'] ?? 0),
        'device_name' => $_POST['device_name'] ?? '',
        'device_type' => $_POST['device_type'] ?? 'other',
        'model' => $_POST['model'] ?? '',
        'mac_address' => $_POST['mac_address'] ?? '',
        'ip_address' => $_POST['ip_address'] ?? '',
        'ssid' => $_POST['ssid'] ?? '',
        'password' => $_POST['password'] ?? '',
        'api_port' => intval($_POST['api_port'] ?? 80),
        'api_username' => $_POST['api_username'] ?? '',
        'api_password' => $_POST['api_password'] ?? '',
        'location' => $_POST['location'] ?? '',
        'latitude' => floatval($_POST['latitude'] ?? 0),
        'longitude' => floatval($_POST['longitude'] ?? 0)
    ];
    $result = $router->addRouter($data);
    if ($result['success']) {
        $_SESSION['flash_msg'] = '<div class="alert alert-success">' . t('router_added') . '</div>';
        redirectTo('?page=seller#routers');
    } else {
        $msg = '<div class="alert alert-danger">Error: ' . htmlspecialchars($result['message']) . '</div>';
    }
}

// ============================================
// HANDLE DELETE ROUTER
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_router'])) {
    $deleteId = intval($_POST['router_id'] ?? 0);
    if ($deleteId) {
        $stmt = $conn->prepare("DELETE FROM routers WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $deleteId, $userId);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Router deleted successfully</div>';
        } else {
            $msg = '<div class="alert alert-danger">Failed to delete router</div>';
        }
    }
}

// ============================================
// HANDLE ADD PACKAGE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_package'])) {
    $routerId = intval($_POST['router_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $duration = intval($_POST['duration_minutes'] ?? 0);
    $dataLimit = intval($_POST['data_limit_mb'] ?? 0);
    $speedLimit = intval($_POST['speed_limit_mbps'] ?? 5);
    $maxDevices = intval($_POST['max_devices'] ?? 1);

    if ($routerId && $name && $price > 0 && $duration > 0) {
        $stmt = $conn->prepare("INSERT INTO packages (router_id, seller_id, name, description, price, duration_minutes, data_limit_mb, speed_limit_mbps, max_devices) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iissdiiii", $routerId, $userId, $name, $description, $price, $duration, $dataLimit, $speedLimit, $maxDevices);
        if ($stmt->execute()) {
            $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Package created successfully!</div>';
        } else {
            $msg = '<div class="alert alert-danger">Failed to create package: ' . htmlspecialchars($conn->error) . '</div>';
        }
    } else {
        $msg = '<div class="alert alert-warning">Please fill in all required fields</div>';
    }
}

// ============================================
// HANDLE DELETE PACKAGE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_package'])) {
    $deleteId = intval($_POST['package_id'] ?? 0);
    if ($deleteId) {
        $stmt = $conn->prepare("DELETE FROM packages WHERE id = ? AND seller_id = ?");
        $stmt->bind_param("ii", $deleteId, $userId);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Package deleted successfully!</div>';
        } else {
            $msg = '<div class="alert alert-danger">Failed to delete package</div>';
        }
    }
}

// ============================================
// HANDLE GENERATE VOUCHERS
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_vouchers'])) {
    $packageId = intval($_POST['package_id'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 10);
    
    if ($packageId && $quantity > 0) {
        $result = $voucher->createVouchers($packageId, $userId, $quantity);
        if ($result['success']) {
            $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Generated ' . count($result['vouchers']) . ' vouchers successfully!</div>';
        } else {
            $msg = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
        }
    }
}

// ============================================
// FETCH DATA
// ============================================

// Get routers
$routers = $router->getRouters($userId);

// Get providers
$providers = $conn->query("SELECT * FROM providers WHERE status = 'active' ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// Get packages
$packages = [];
try {
    $stmt = $conn->prepare("
        SELECT p.*, r.device_name as router_name, r.ssid 
        FROM packages p 
        JOIN routers r ON p.router_id = r.id 
        WHERE p.seller_id = ? 
        ORDER BY p.created_at DESC
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $packages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {
    $packages = [];
}

// Get recent vouchers
$recentVouchers = [];
try {
    $stmt = $conn->prepare("
        SELECT v.*, p.name as package_name, r.device_name as router_name
        FROM vouchers v 
        JOIN packages p ON v.package_id = p.id 
        JOIN routers r ON p.router_id = r.id
        WHERE v.seller_id = ? 
        ORDER BY v.created_at DESC 
        LIMIT 20
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $recentVouchers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {
    $recentVouchers = [];
}

// Get voucher stats
$voucherStats = [
    'total' => 0,
    'available' => 0,
    'sold' => 0,
    'used' => 0,
    'expired' => 0
];
try {
    $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId");
    if ($res) $voucherStats['total'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'available'");
    if ($res) $voucherStats['available'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'sold'");
    if ($res) $voucherStats['sold'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'used'");
    if ($res) $voucherStats['used'] = $res->fetch_assoc()['c'];
    
    $res = $conn->query("SELECT COUNT(*) as c FROM vouchers WHERE seller_id = $userId AND status = 'expired'");
    if ($res) $voucherStats['expired'] = $res->fetch_assoc()['c'];
} catch (Throwable $e) {}

// Get seller stats
$stats = $transaction->getSellerStats($userId);

// Get active sessions count
$sessionStats = $sessionManager->getSessionStats($userId);

?>

<!-- ============================================ -->
<!-- SELLER PANEL HEADER                         -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-store"></i> <?php echo t('seller_panel'); ?></h2>
        <small class="text-muted">Manage your routers, packages, and vouchers</small>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addRouterModal">
            <i class="fas fa-plus-circle"></i> <?php echo t('add_router'); ?>
        </button>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- STATS OVERVIEW                              -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card">
            <h6 class="mb-1"><?php echo t('total_earnings'); ?></h6>
            <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($stats['total_earnings'], 0); ?></h4>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card success">
            <h6 class="mb-1"><?php echo t('total_sales'); ?></h6>
            <h4 class="fw-bold mb-0"><?php echo number_format($stats['total_sales']); ?></h4>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card info">
            <h6 class="mb-1"><?php echo t('active_sessions'); ?></h6>
            <h4 class="fw-bold mb-0"><?php echo number_format($sessionStats['active_sessions']); ?></h4>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card warning">
            <h6 class="mb-1"><?php echo t('total_vouchers'); ?></h6>
            <h4 class="fw-bold mb-0"><?php echo number_format($voucherStats['total']); ?></h4>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- NAVIGATION TABS                             -->
<!-- ============================================ -->
<ul class="nav nav-tabs mb-4" id="sellerTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="routers-tab" data-bs-toggle="tab" data-bs-target="#routers" type="button" role="tab">
            <i class="fas fa-network-wired"></i> <?php echo t('my_routers'); ?>
            <span class="badge bg-primary ms-1"><?php echo count($routers); ?></span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="packages-tab" data-bs-toggle="tab" data-bs-target="#packages" type="button" role="tab">
            <i class="fas fa-box"></i> <?php echo t('wifi_packages'); ?>
            <span class="badge bg-success ms-1"><?php echo count($packages); ?></span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="vouchers-tab" data-bs-toggle="tab" data-bs-target="#vouchers" type="button" role="tab">
            <i class="fas fa-ticket-alt"></i> <?php echo t('vouchers'); ?>
            <span class="badge bg-warning text-dark ms-1"><?php echo $voucherStats['available']; ?></span>
        </button>
    </li>
</ul>

<div class="tab-content" id="sellerTabsContent">
    
    <!-- ============================================ -->
    <!-- ROUTERS TAB                                 -->
    <!-- ============================================ -->
    <div class="tab-pane fade show active" id="routers" role="tabpanel">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="mb-0"><i class="fas fa-network-wired"></i> <?php echo t('my_routers'); ?></h5>
                <div class="d-flex gap-2 flex-wrap">
                    <button class="btn btn-outline-success btn-sm" data-bs-toggle="modal" data-bs-target="#sampleRouterModal">
                        <i class="fas fa-magic"></i> <?php echo t('create_sample_router'); ?>
                    </button>
                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addRouterModal">
                        <i class="fas fa-plus-circle"></i> <?php echo t('add_router'); ?>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <?php if (count($routers) > 0): ?>
                    <div class="row">
                        <?php foreach ($routers as $r): 
                            $isOnline = ($r['status'] === 'online');
                        ?>
                        <div class="col-md-6 mb-3">
                            <div class="card h-100" data-router-id="<?php echo $r['id']; ?>">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <div>
                                            <h6 class="mb-1">
                                                <span class="router-status-indicator <?php echo $r['status']; ?>"></span>
                                                <?php echo htmlspecialchars($r['device_name']); ?>
                                            </h6>
                                            <small class="text-muted">
                                                <i class="fas fa-tag"></i> <?php echo htmlspecialchars($r['device_type']); ?>
                                                <?php if ($r['model']): ?>
                                                | <?php echo htmlspecialchars($r['model']); ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                        <span class="badge bg-<?php echo $isOnline ? 'success' : 'danger'; ?>">
                                            <?php echo t($r['status']); ?>
                                        </span>
                                    </div>
                                    
                                    <div class="small text-muted mb-2">
                                        <div><i class="fas fa-wifi"></i> SSID: <strong><?php echo htmlspecialchars($r['ssid'] ?: 'N/A'); ?></strong></div>
                                        <div><i class="fas fa-network-wired"></i> MAC: <code><?php echo htmlspecialchars($r['mac_address']); ?></code></div>
                                        <div><i class="fas fa-globe"></i> IP: <code><?php echo htmlspecialchars($r['ip_address']); ?></code> : <?php echo $r['api_port']; ?></div>
                                        <?php if ($r['location']): ?>
                                        <div><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($r['location']); ?></div>
                                        <?php endif; ?>
                                        <?php if ($r['provider_name']): ?>
                                        <div><i class="fas fa-tower-cell"></i> <?php echo htmlspecialchars($r['provider_name']); ?></div>
                                        <?php endif; ?>
                                        <div class="mt-1">
                                            <i class="fas fa-clock"></i> <?php echo t('last_seen'); ?>: 
                                            <?php 
                                            if ($r['last_seen']) {
                                                $diff = time() - strtotime($r['last_seen']);
                                                if ($diff < 60) echo t('just_now');
                                                elseif ($diff < 3600) echo floor($diff / 60) . ' ' . t('minutes_ago');
                                                elseif ($diff < 86400) echo floor($diff / 3600) . ' ' . t('hours_ago');
                                                else echo floor($diff / 86400) . ' ' . t('days_ago');
                                            } else {
                                                echo t('never');
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex gap-1 flex-wrap">
                                        <a href="?page=seller&check=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-sync"></i> <?php echo t('check'); ?>
                                        </a>
                                        <a href="?page=packages&router=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-success">
                                            <i class="fas fa-box"></i> <?php echo t('packages'); ?>
                                        </a>
                                        <a href="?page=devices&router_id=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-laptop"></i> <?php echo t('devices'); ?>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-outline-danger" 
                                                data-bs-toggle="modal" data-bs-target="#deleteRouterModal<?php echo $r['id']; ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Delete Router Modal -->
                            <div class="modal fade" id="deleteRouterModal<?php echo $r['id']; ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="router_id" value="<?php echo $r['id']; ?>">
                                            <div class="modal-header">
                                                <h5 class="modal-title"><i class="fas fa-trash text-danger"></i> <?php echo t('confirm_delete'); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Are you sure you want to delete router <strong><?php echo htmlspecialchars($r['device_name']); ?></strong>?</p>
                                                <p class="text-danger small"><i class="fas fa-exclamation-triangle"></i> This will also delete all associated packages and vouchers.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                                <button type="submit" name="delete_router" class="btn btn-danger"><?php echo t('yes_delete'); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-network-wired"></i>
                        <p><?php echo t('no_routers'); ?></p>
                        <div class="d-flex gap-2 justify-content-center mt-3">
                            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#sampleRouterModal">
                                <i class="fas fa-magic"></i> <?php echo t('create_sample_router'); ?>
                            </button>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRouterModal">
                                <i class="fas fa-plus-circle"></i> <?php echo t('add_router'); ?>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- ============================================ -->
    <!-- PACKAGES TAB                                -->
    <!-- ============================================ -->
    <div class="tab-pane fade" id="packages" role="tabpanel">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="mb-0"><i class="fas fa-box"></i> <?php echo t('wifi_packages'); ?></h5>
                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addPackageModal">
                    <i class="fas fa-plus-circle"></i> <?php echo t('create_package'); ?>
                </button>
            </div>
            <div class="card-body">
                <?php if (count($packages) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mobile-card-table">
                            <thead>
                                <tr>
                                    <th><?php echo t('name'); ?></th>
                                    <th><?php echo t('router'); ?></th>
                                    <th><?php echo t('price'); ?></th>
                                    <th><?php echo t('duration'); ?></th>
                                    <th><?php echo t('speed'); ?></th>
                                    <th><?php echo t('active'); ?></th>
                                    <th><?php echo t('actions'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($packages as $p): ?>
                                <tr>
                                    <td data-label="<?php echo t('name'); ?>">
                                        <strong><?php echo htmlspecialchars($p['name']); ?></strong>
                                        <?php if ($p['description']): ?>
                                        <br><small class="text-muted"><?php echo htmlspecialchars(substr($p['description'], 0, 60)); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('router'); ?>">
                                        <?php echo htmlspecialchars($p['router_name']); ?>
                                        <?php if ($p['ssid']): ?>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($p['ssid']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo t('price'); ?>">
                                        <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($p['price'], 0); ?></strong>
                                    </td>
                                    <td data-label="<?php echo t('duration'); ?>">
                                        <?php 
                                        if ($p['duration_minutes'] >= 1440) {
                                            echo round($p['duration_minutes'] / 1440, 1) . ' days';
                                        } elseif ($p['duration_minutes'] >= 60) {
                                            echo round($p['duration_minutes'] / 60, 1) . ' hrs';
                                        } else {
                                            echo $p['duration_minutes'] . ' min';
                                        }
                                        ?>
                                    </td>
                                    <td data-label="<?php echo t('speed'); ?>"><?php echo $p['speed_limit_mbps']; ?> Mbps</td>
                                    <td data-label="<?php echo t('active'); ?>">
                                        <span class="badge bg-<?php echo $p['is_active'] ? 'success' : 'secondary'; ?>">
                                            <?php echo $p['is_active'] ? t('active') : t('inactive'); ?>
                                        </span>
                                    </td>
                                    <td data-label="<?php echo t('actions'); ?>">
                                        <button class="btn btn-sm btn-outline-success" 
                                                data-bs-toggle="modal" data-bs-target="#genVoucherModal<?php echo $p['id']; ?>">
                                            <i class="fas fa-ticket-alt"></i> <?php echo t('generate'); ?>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-danger"
                                                data-bs-toggle="modal" data-bs-target="#deletePackageModal<?php echo $p['id']; ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                
                                <!-- Generate Voucher Modal -->
                                <div class="modal fade" id="genVoucherModal<?php echo $p['id']; ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"><i class="fas fa-ticket-alt"></i> <?php echo t('generate_vouchers'); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="alert alert-info">
                                                        <strong><?php echo htmlspecialchars($p['name']); ?></strong><br>
                                                        <small><?php echo CURRENCY . ' ' . number_format($p['price'], 0); ?> - 
                                                        <?php echo $p['duration_minutes']; ?> <?php echo t('minutes'); ?></small>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label"><?php echo t('quantity'); ?></label>
                                                        <input type="number" name="quantity" class="form-control" value="10" min="1" max="1000" required>
                                                        <small class="text-muted">Maximum 1000 vouchers per batch</small>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                                    <button type="submit" name="generate_vouchers" class="btn btn-success">
                                                        <i class="fas fa-magic"></i> <?php echo t('generate'); ?>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Delete Package Modal -->
                                <div class="modal fade" id="deletePackageModal<?php echo $p['id']; ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"><i class="fas fa-trash text-danger"></i> <?php echo t('confirm_delete'); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete package <strong><?php echo htmlspecialchars($p['name']); ?></strong>?</p>
                                                    <p class="text-danger small"><i class="fas fa-exclamation-triangle"></i> All associated vouchers will also be deleted.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                                    <button type="submit" name="delete_package" class="btn btn-danger"><?php echo t('yes_delete'); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-box"></i>
                        <p><?php echo t('no_packages'); ?></p>
                        <?php if (count($routers) > 0): ?>
                        <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addPackageModal">
                            <i class="fas fa-plus-circle"></i> <?php echo t('create_package'); ?>
                        </button>
                        <?php else: ?>
                        <p class="text-warning mt-3"><i class="fas fa-exclamation-triangle"></i> Add a router first before creating packages.</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- ============================================ -->
    <!-- VOUCHERS TAB                                -->
    <!-- ============================================ -->
    <div class="tab-pane fade" id="vouchers" role="tabpanel">
        <!-- Voucher Stats -->
        <div class="row mb-3">
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-ticket-alt text-success"></i> <?php echo t('available'); ?></div>
                    <div class="metric-value text-success"><?php echo $voucherStats['available']; ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-dollar-sign text-info"></i> <?php echo t('sold'); ?></div>
                    <div class="metric-value text-info"><?php echo $voucherStats['sold']; ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-check-circle text-primary"></i> <?php echo t('used'); ?></div>
                    <div class="metric-value text-primary"><?php echo $voucherStats['used']; ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="analytics-card text-center">
                    <div class="metric-label"><i class="fas fa-hourglass-end text-danger"></i> <?php echo t('expired'); ?></div>
                    <div class="metric-value text-danger"><?php echo $voucherStats['expired']; ?></div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="mb-0"><i class="fas fa-ticket-alt"></i> <?php echo t('recent_vouchers'); ?></h5>
                <small class="text-muted">Showing latest 20 vouchers</small>
            </div>
            <div class="card-body">
                <?php if (count($recentVouchers) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mobile-card-table">
                            <thead>
                                <tr>
                                    <th><?php echo t('code'); ?></th>
                                    <th><?php echo t('package'); ?></th>
                                    <th><?php echo t('price'); ?></th>
                                    <th><?php echo t('status'); ?></th>
                                    <th><?php echo t('sold_at'); ?></th>
                                    <th><?php echo t('used_at'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentVouchers as $v): ?>
                                <tr>
                                    <td data-label="<?php echo t('code'); ?>">
                                        <code style="font-size:0.9rem;font-weight:600;"><?php echo htmlspecialchars($v['voucher_code']); ?></code>
                                    </td>
                                    <td data-label="<?php echo t('package'); ?>">
                                        <?php echo htmlspecialchars($v['package_name']); ?>
                                        <br><small class="text-muted"><i class="fas fa-wifi"></i> <?php echo htmlspecialchars($v['router_name']); ?></small>
                                    </td>
                                    <td data-label="<?php echo t('price'); ?>">
                                        <?php echo CURRENCY . ' ' . number_format($v['price'], 0); ?>
                                    </td>
                                    <td data-label="<?php echo t('status'); ?>">
                                        <span class="badge bg-<?php 
                                            echo $v['status'] === 'available' ? 'success' : 
                                                ($v['status'] === 'sold' ? 'info' : 
                                                ($v['status'] === 'used' ? 'primary' : 
                                                ($v['status'] === 'expired' ? 'secondary' : 'danger'))); 
                                        ?>">
                                            <?php echo t($v['status']); ?>
                                        </span>
                                    </td>
                                    <td data-label="<?php echo t('sold_at'); ?>">
                                        <?php echo $v['sold_at'] ? date('d M H:i', strtotime($v['sold_at'])) : '<span class="text-muted">-</span>'; ?>
                                    </td>
                                    <td data-label="<?php echo t('used_at'); ?>">
                                        <?php echo $v['used_at'] ? date('d M H:i', strtotime($v['used_at'])) : '<span class="text-muted">-</span>'; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-5">
                        <i class="fas fa-ticket-alt"></i>
                        <p><?php echo t('no_data'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- ADD ROUTER MODAL                            -->
<!-- ============================================ -->
<div class="modal fade" id="addRouterModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus-circle"></i> <?php echo t('add_wifi_router'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('device_name'); ?> <span class="text-danger">*</span></label>
                            <input type="text" name="device_name" class="form-control" placeholder="e.g., Office Router" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('device_type'); ?></label>
                            <select name="device_type" class="form-select">
                                <option value="tp-link">TP-Link</option>
                                <option value="omada">Omada</option>
                                <option value="mikrotik">MikroTik</option>
                                <option value="ubiquiti">Ubiquiti</option>
                                <option value="other" selected>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('model'); ?></label>
                            <input type="text" name="model" class="form-control" placeholder="e.g., Archer C6">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('mac_address'); ?> <span class="text-danger">*</span></label>
                            <input type="text" name="mac_address" class="form-control" placeholder="AA:BB:CC:DD:EE:FF" required>
                            <small class="text-muted">Format: XX:XX:XX:XX:XX:XX</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('ip_address'); ?></label>
                            <input type="text" name="ip_address" class="form-control" placeholder="192.168.1.1">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('api_port'); ?></label>
                            <input type="number" name="api_port" class="form-control" value="80">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('wifi_name'); ?></label>
                            <input type="text" name="ssid" class="form-control" placeholder="e.g., MyWiFi">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('wifi_password'); ?></label>
                            <input type="text" name="password" class="form-control" placeholder="WiFi password">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('api_username'); ?></label>
                            <input type="text" name="api_username" class="form-control" value="admin">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('api_password'); ?></label>
                            <input type="text" name="api_password" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('internet_provider'); ?></label>
                            <select name="provider_id" class="form-select">
                                <option value=""><?php echo t('select_provider'); ?></option>
                                <?php foreach ($providers as $pr): ?>
                                <option value="<?php echo $pr['id']; ?>"><?php echo htmlspecialchars($pr['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('location'); ?></label>
                            <input type="text" name="location" class="form-control" placeholder="e.g., Dar es Salaam">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('latitude'); ?></label>
                            <input type="text" name="latitude" class="form-control" placeholder="-6.7924">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('longitude'); ?></label>
                            <input type="text" name="longitude" class="form-control" placeholder="39.2083">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="submit" name="add_router" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo t('add_router'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- SAMPLE ROUTER MODAL                         -->
<!-- ============================================ -->
<div class="modal fade" id="sampleRouterModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-magic"></i> <?php echo t('create_sample_router'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        This will create a demo router with random details to help you test the system. You can delete it anytime.
                    </div>
                    <ul class="list-unstyled small">
                        <li><i class="fas fa-check text-success"></i> Auto-generated device name</li>
                        <li><i class="fas fa-check text-success"></i> Random MAC address</li>
                        <li><i class="fas fa-check text-success"></i> Random SSID</li>
                        <li><i class="fas fa-check text-success"></i> Dar es Salaam location</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="submit" name="create_sample_router" class="btn btn-success">
                        <i class="fas fa-magic"></i> <?php echo t('create_sample_router'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- ADD PACKAGE MODAL                           -->
<!-- ============================================ -->
<div class="modal fade" id="addPackageModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-box"></i> <?php echo t('create_wifi_package'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php if (count($routers) === 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        You need to add a router first before creating packages.
                    </div>
                    <?php else: ?>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('select_router'); ?> <span class="text-danger">*</span></label>
                        <select name="router_id" class="form-select" required>
                            <option value=""><?php echo t('select_router'); ?></option>
                            <?php foreach ($routers as $r): ?>
                            <option value="<?php echo $r['id']; ?>">
                                <?php echo htmlspecialchars($r['device_name'] . ' (' . ($r['ssid'] ?: 'No SSID') . ')'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('package_name'); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g., 1 Hour Basic" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('description'); ?></label>
                        <textarea name="description" class="form-control" rows="2" placeholder="Optional description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('price_tzs'); ?> <span class="text-danger">*</span></label>
                            <input type="number" name="price" class="form-control" step="0.01" min="0" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('duration_minutes'); ?> <span class="text-danger">*</span></label>
                            <input type="number" name="duration_minutes" class="form-control" min="1" required>
                            <small class="text-muted">60=1hr, 1440=1day, 10080=1week</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('data_limit'); ?></label>
                            <input type="number" name="data_limit_mb" class="form-control" value="0">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('speed_limit'); ?></label>
                            <input type="number" name="speed_limit_mbps" class="form-control" value="5" min="1">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('max_devices'); ?></label>
                            <input type="number" name="max_devices" class="form-control" value="1" min="1">
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <?php if (count($routers) > 0): ?>
                    <button type="submit" name="add_package" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo t('create_package'); ?>
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- PAGE SCRIPT - Auto activate tab from URL    -->
<!-- ============================================ -->
<script>
// Auto-activate tab based on URL hash or query
document.addEventListener('DOMContentLoaded', function() {
    // Check for hash
    if (window.location.hash) {
        const hash = window.location.hash.substring(1);
        const tab = document.getElementById(hash + '-tab');
        if (tab) {
            new bootstrap.Tab(tab).show();
        }
    }
    
    // Check for query param
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    if (tabParam) {
        const tab = document.getElementById(tabParam + '-tab');
        if (tab) {
            new bootstrap.Tab(tab).show();
        }
    }
    
    // Check for success redirect (to open packages tab after creating package)
    if (urlParams.get('created') === 'package') {
        const tab = document.getElementById('packages-tab');
        if (tab) new bootstrap.Tab(tab).show();
    }
});

// Smooth scroll to routers after check
if (window.location.hash === '#routers') {
    const routersTab = document.getElementById('routers-tab');
    if (routersTab) new bootstrap.Tab(routersTab).show();
}
</script>