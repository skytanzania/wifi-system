<?php
/**
 * ============================================================================
 *  SKYTANZA WIFI — STANDALONE CAPTIVE PORTAL (v6.5 — External RADIUS)
 *  File: portal.php
 *
 *  v6.5 FIX — "500 Internal Server Error" on
 *      https://wifi.skytanzania.co.tz/portal/radius/browserauth
 *
 *    The browserauth POST was being sent to THIS website (cPanel) instead of
 *    the Omada Controller. /portal/radius/browserauth only exists on the
 *    Omada Controller's PORTAL port (default HTTPS 8843 / HTTP 8088) —
 *    NOT on the website and NOT on the management port 8043.
 *
 *    Correct target:  https://169.58.93.38:8843/portal/radius/browserauth
 *
 *    Resolution order for the auth URL (first valid wins):
 *      1. CTRL_PORTAL_URL           (explicit override in config.local.php)
 *      2. target/targetPort/scheme  (sent by the EAP225 in the redirect)
 *      3. hs_devices.portal_target
 *      4. hs_devices.controller_url (host kept, port forced to portal port)
 *      5. settings.controller_url   (host kept, port forced to portal port)
 *      6. CTRL_PORTAL_HOST          (default 169.58.93.38)
 *    Any candidate pointing at this website's own host is rejected.
 *
 *  Also fixed in v6.5:
 *    - fulfillOrder(): bind_param type string had 15 types for 14 values,
 *      so paid orders never produced a voucher.
 *    - portalRegisterSession(): unique_id was bound as integer.
 *    - JS refuses to submit browserauth to the portal's own host.
 *
 *  Unchanged from v6.4:
 *    authType = 2 (External RADIUS). PAP inside RADIUS. No CHAP fields.
 *    originUrl = phone's REAL target (never portal.php).
 *    Vouchers come from hs_vouchers (source='batch'/'online'), never Omada.
 * ============================================================================
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ob_start();
date_default_timezone_set('Africa/Dar_es_Salaam');

// ---------------------------------------------------------------------------
// CONFIG
// ---------------------------------------------------------------------------
if (is_file(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';

function pcfg(string $name, string $env, $default): void {
    if (defined($name)) return;
    $v = getenv($env);
    define($name, ($v !== false && $v !== '') ? $v : $default);
}

pcfg('DB_HOST', 'SKY_DB_HOST', 'localhost');
pcfg('DB_USER', 'SKY_DB_USER', 'skytanza_wifi');
pcfg('DB_PASS', 'SKY_DB_PASS', '');
pcfg('DB_NAME', 'SKY_DB_NAME', 'skytanza_wifi');

pcfg('SITE_NAME', 'SKY_SITE_NAME', 'SkyTanza WiFi');
pcfg('SITE_URL',  'SKY_SITE_URL',  '');
pcfg('CURRENCY',  'SKY_CURRENCY',  'TZS');
pcfg('APP_VERSION', 'SKY_APP_VERSION', '6.5');

pcfg('RADIUS_API_KEY', 'SKY_RADIUS_API_KEY', 'change-radius-api-key-to-a-long-random-string');

pcfg('SONIC_PESA_API_KEY',    'SKY_SONIC_KEY',    '');
pcfg('SONIC_PESA_API_SECRET', 'SKY_SONIC_SECRET', '');
pcfg('SONIC_PESA_API_BASE',   'SKY_SONIC_BASE',   'https://api.sonicpesa.com/api/v1');
pcfg('SONIC_PESA_COLLECT_ENDPOINT', 'SKY_SONIC_COLLECT', '');

define('RADIUS_AUTH_PORT', 1812);
define('RADIUS_ACCT_PORT', 1813);
define('RADIUS_DAE_PORT',  3799);
define('RADIUS_INTERIM',   60);

pcfg('PORTAL_FALLBACK_ORIGIN', 'SKY_FALLBACK_ORIGIN', 'http://connectivitycheck.gstatic.com/generate_204');

// ★ v6.5 — Omada Controller PORTAL endpoint (where browserauth lives).
//   CTRL_PORTAL_URL : full override, e.g. 'https://169.58.93.38:8843'
//                     (leave empty to use the EAP's target/targetPort).
//   CTRL_PORTAL_HOST: controller public IP/hostname used as last fallback.
//   CTRL_PORTAL_SCHEME: 'https' (port 8843) or 'http' (port 8088).
pcfg('CTRL_PORTAL_URL',        'SKY_CTRL_PORTAL_URL',    '');
pcfg('CTRL_PORTAL_HOST',       'SKY_CTRL_PORTAL_HOST',   '169.58.93.38');
pcfg('CTRL_PORTAL_SCHEME',     'SKY_CTRL_PORTAL_SCHEME', 'https');
pcfg('CTRL_PORTAL_HTTPS_PORT', 'SKY_CTRL_PORTAL_HTTPS',  '8843');
pcfg('CTRL_PORTAL_HTTP_PORT',  'SKY_CTRL_PORTAL_HTTP',   '8088');

// browserauth authType = 2 = External RADIUS Server.
//   DO NOT change this to 0 or 1 — both return -41500 when the portal
//   profile is "External RADIUS".
define('CTRL_AUTH_TYPE', 2);

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($a): string { return CURRENCY . ' ' . number_format((float)$a, 0); }
function normMac($s): string {
    $hex = strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', substr((string)$s, 0, 17)));
    if (strlen($hex) < 12) return '';
    return implode(':', str_split(substr($hex, 0, 12), 2));
}
function dashMac(string $mac): string { return str_replace(':', '-', $mac); }
function normalizePhone(string $p): string {
    $d = preg_replace('/\D/', '', $p);
    if (strlen($d) === 12 && substr($d, 0, 3) === '255') $d = '0' . substr($d, 3);
    if (strlen($d) === 9) $d = '0' . $d;
    return $d;
}
function genCode(int $len = 8): string {
    $c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $o = '';
    for ($i = 0; $i < $len; $i++) $o .= $c[random_int(0, strlen($c) - 1)];
    return $o;
}
function fmtDur(int $min): string {
    if ($min >= 1440 && $min % 1440 === 0) { $d = $min / 1440; return $d . ' ' . ($d == 1 ? 'day' : 'days'); }
    if ($min >= 60 && $min % 60 === 0)     { $x = $min / 60;  return $x . ' ' . ($x == 1 ? 'hour' : 'hours'); }
    return $min . ' min';
}
function fmtSecs(int $s): string {
    if ($s <= 0) return '0 min';
    $d = intdiv($s, 86400); $h = intdiv($s % 86400, 3600); $m = intdiv($s % 3600, 60);
    $out = [];
    if ($d) $out[] = $d . 'd';
    if ($h) $out[] = $h . 'h';
    if ($m || !$out) $out[] = max(1, $m) . 'm';
    return implode(' ', $out);
}
function fmtBytes($b): string {
    $b = (float)$b;
    foreach (['B','KB','MB','GB','TB'] as $u) { if ($b < 1024) return round($b, 1) . ' ' . $u; $b /= 1024; }
    return round($b, 1) . ' PB';
}
function jsonOut($data, int $code = 200): void {
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function portalBaseUrl(): string {
    if (SITE_URL !== '') return rtrim(SITE_URL, '/');
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || ((string)($_SERVER['SERVER_PORT'] ?? '') === '443');
    $host = strtolower(preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    $dir  = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/.');
    return ($host !== '' ? (($https ? 'https' : 'http') . '://' . $host . $dir) : '');
}
function portalSelfPath(): string {
    $uri  = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = parse_url($uri, PHP_URL_PATH);
    if (is_string($path) && $path !== '' && $path[0] === '/') return $path;
    $p = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    return ($p !== '' && $p[0] === '/') ? $p : '/portal.php';
}
function clientIp(): string { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }
function canCall(string $fn): bool {
    static $off = null;
    if ($off === null) $off = array_filter(array_map('trim', explode(',', strtolower((string)ini_get('disable_functions')))));
    return function_exists($fn) && !in_array(strtolower($fn), $off, true);
}
function rateLimitCheck(string $identifier, string $action, int $max = 5, int $window = 300): bool {
    global $conn;
    $identifier = substr($identifier, 0, 100);
    try {
        $st = $conn->prepare("SELECT id, attempts, window_start FROM rate_limits WHERE identifier=? AND action=?");
        $st->bind_param('ss', $identifier, $action); $st->execute();
        $r = $st->get_result()->fetch_assoc();
        if (!$r) {
            $ins = $conn->prepare("INSERT IGNORE INTO rate_limits (identifier, action, attempts, window_start) VALUES (?,?,1,NOW())");
            $ins->bind_param('ss', $identifier, $action); $ins->execute();
            return true;
        }
        if (time() - strtotime($r['window_start']) > $window) {
            $up = $conn->prepare("UPDATE rate_limits SET attempts=1, window_start=NOW() WHERE id=?");
            $up->bind_param('i', $r['id']); $up->execute();
            return true;
        }
        if ((int)$r['attempts'] >= $max) return false;
        $up = $conn->prepare("UPDATE rate_limits SET attempts=attempts+1 WHERE id=?");
        $up->bind_param('i', $r['id']); $up->execute();
    } catch (Throwable $e) {
        error_log('rateLimitCheck: ' . $e->getMessage());
    }
    return true;
}

function phoneOrigin(array $ctx): string {
    foreach (['redirectUrl','originUrl'] as $k) {
        $u = trim((string)($ctx[$k] ?? ''));
        if ($u === '') continue;
        if (!preg_match('#^https?://#i', $u)) continue;
        if (stripos($u, 'portal.php') !== false) continue;
        if (stripos($u, 'page=portal') !== false) continue;
        if (stripos($u, '/portal/radius/') !== false) continue;
        return $u;
    }
    $fb = (string)PORTAL_FALLBACK_ORIGIN;
    return preg_match('#^https?://#i', $fb) ? $fb : 'http://connectivitycheck.gstatic.com/generate_204';
}

function controllerAuthType(): int {
    return 2;   // External RADIUS Server — the only value that works for this portal
}

// ---------------------------------------------------------------------------
// browserauth POST body.
//   authType = 2 (External RADIUS). username + password = voucher code.
//   NO chapId / chapChallenge.
// ---------------------------------------------------------------------------
function buildAuthFields(string $code, ?array $dev, array $ctx): array {
    $code = strtoupper(preg_replace('/\s+/', '', $code));
    $fields = [
        'authType' => 2,
        'username' => $code,
        'password' => $code,
    ];
    foreach (['clientMac','apMac','gatewayMac'] as $k) {
        $v = trim((string)($ctx[$k] ?? ''));
        if ($v === '') continue;
        $n = normMac($v);
        if ($n !== '') $fields[$k] = $n;
    }
    foreach (['clientIp','ssidName','radioId','scheme','hostname','serverPort'] as $k) {
        $v = trim((string)($ctx[$k] ?? ''));
        if ($v === '') continue;
        if ($k === 'serverPort' && !preg_match('/^\d+$/', $v)) continue;
        $fields[$k] = $v;
    }
    $vid = trim((string)($ctx['vid'] ?? ''));
    if ($vid !== '' && preg_match('/^\d+$/', $vid)) $fields['vid'] = $vid;
    $target = trim((string)($ctx['target'] ?? ''));
    if ($target !== '' && preg_match('/^[A-Za-z0-9.\-]+$/', $target)) $fields['target'] = $target;
    $targetPort = trim((string)($ctx['targetPort'] ?? ''));
    if ($targetPort !== '' && preg_match('/^\d+$/', $targetPort)) $fields['targetPort'] = $targetPort;
    $fields['originUrl'] = phoneOrigin($ctx);
    return $fields;
}

// ---------------------------------------------------------------------------
// DATABASE
// ---------------------------------------------------------------------------
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+03:00'");
} catch (Throwable $e) {
    error_log('portal.php DB connect failed: ' . $e->getMessage());
    http_response_code(500);
    if (isset($_GET['ajax'])) jsonOut(['success' => false, 'message' => 'Database unavailable'], 500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><meta charset="utf-8"><title>Setup</title>'
       . '<div style="font-family:system-ui,Arial,sans-serif;max-width:640px;margin:48px auto;padding:28px;border:1px solid #ccc;border-radius:16px;line-height:1.6">'
       . '<h2 style="margin-top:0">Portal setup needed</h2>'
       . '<p>Create <b>config.local.php</b> next to <b>portal.php</b> with your database credentials.</p></div>';
    exit;
}
function db(): mysqli { global $conn; return $conn; }

function q(string $sql, string $types = '', ...$params): mysqli_stmt {
    try {
        $st = db()->prepare($sql);
        if ($types !== '' && count($params) > 0) {
            if (strlen($types) !== count($params)) {
                throw new RuntimeException(sprintf('bind_param mismatch: types="%s" (%d) vs params=%d', $types, strlen($types), count($params)));
            }
            $st->bind_param($types, ...$params);
        }
        $st->execute();
        return $st;
    } catch (Throwable $e) {
        error_log('[q] ' . $e->getMessage() . ' | SQL: ' . preg_replace('/\s+/', ' ', $sql));
        throw $e;
    }
}
function row(string $sql, string $types = '', ...$p): ?array {
    try { $r = q($sql, $types, ...$p)->get_result(); return $r ? ($r->fetch_assoc() ?: null) : null; }
    catch (Throwable $e) { error_log('row() error: ' . $e->getMessage() . ' SQL: ' . $sql); return null; }
}
function rows(string $sql, string $types = '', ...$p): array {
    try { $r = q($sql, $types, ...$p)->get_result(); return $r ? $r->fetch_all(MYSQLI_ASSOC) : []; }
    catch (Throwable $e) { error_log('rows() error: ' . $e->getMessage()); return []; }
}
function val(string $sql, string $types = '', ...$p) {
    $r = row($sql, $types, ...$p); return $r ? reset($r) : null;
}
function run(string $sql, string $types = '', ...$p): int {
    try { return q($sql, $types, ...$p)->affected_rows; }
    catch (Throwable $e) { error_log('run() error: ' . $e->getMessage()); return 0; }
}
function getSetting(string $key, string $default = ''): string {
    $v = val("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1", 's', $key);
    return $v === null ? $default : (string)$v;
}

function ensurePortalSchema(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        db()->query("CREATE TABLE IF NOT EXISTS rate_limits (
            id INT AUTO_INCREMENT PRIMARY KEY,
            identifier VARCHAR(100) NOT NULL,
            action VARCHAR(50) NOT NULL,
            attempts INT DEFAULT 1,
            window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_ident_action (identifier, action),
            INDEX idx_window (window_start)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
    try {
        db()->query("UPDATE hs_vouchers SET status='sold' WHERE status='expired' AND first_used_at IS NULL AND (valid_until IS NULL OR valid_until > NOW())");
    } catch (Throwable $e) {}
}
ensurePortalSchema();

if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_name('SKYPORTAL');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','domain'=>'','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
    @session_start();
}
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

define('CSRF_COOKIE', 'sky_csrf');

function csrf_secure_flag(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || ((string)($_SERVER['SERVER_PORT'] ?? '') === '443');
}
function csrf_set_cookie(string $token): void {
    if (headers_sent()) return;
    setcookie(CSRF_COOKIE, $token, ['expires'=>time()+60*60*24*30,'path'=>'/','secure'=>csrf_secure_flag(),'httponly'=>false,'samesite'=>'Lax']);
    $_COOKIE[CSRF_COOKIE] = $token;
}
function csrf_token(): string {
    if (!empty($_SESSION['csrf_token']) && preg_match('/^[a-f0-9]{64}$/i', (string)$_SESSION['csrf_token'])) {
        $tok = (string)$_SESSION['csrf_token'];
        if (empty($_COOKIE[CSRF_COOKIE]) || $_COOKIE[CSRF_COOKIE] !== $tok) csrf_set_cookie($tok);
        return $tok;
    }
    if (!empty($_COOKIE[CSRF_COOKIE]) && preg_match('/^[a-f0-9]{64}$/i', (string)$_COOKIE[CSRF_COOKIE])) {
        $_SESSION['csrf_token'] = (string)$_COOKIE[CSRF_COOKIE];
        return (string)$_COOKIE[CSRF_COOKIE];
    }
    $tok = bin2hex(random_bytes(32));
    $_SESSION['csrf_token'] = $tok;
    csrf_set_cookie($tok);
    return $tok;
}
function csrf_check($token): bool {
    $token = (string)$token;
    if ($token === '' && !empty($_SERVER['HTTP_X_CSRF_TOKEN'])) $token = (string)$_SERVER['HTTP_X_CSRF_TOKEN'];
    if ($token === '' || !preg_match('/^[a-f0-9]{64}$/i', $token)) return false;
    $sess = (string)($_SESSION['csrf_token'] ?? '');
    $cook = (string)($_COOKIE[CSRF_COOKIE] ?? '');
    $ok = false;
    if ($sess !== '' && hash_equals($sess, $token)) $ok = true;
    if (!$ok && $cook !== '' && hash_equals($cook, $token)) { $ok = true; $_SESSION['csrf_token'] = $token; }
    return $ok;
}

$currentLang = $_GET['lang'] ?? ($_SESSION['lang'] ?? ($_COOKIE['lang'] ?? 'sw'));
if (!in_array($currentLang, ['en','sw'], true)) $currentLang = 'sw';
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en','sw'], true)) {
    $_SESSION['lang'] = $currentLang;
    setcookie('lang', $currentLang, ['expires'=>time()+86400*365,'path'=>'/','samesite'=>'Lax']);
}

$T = [
  'en' => [
    'p_title'=>'Connect to the Internet','p_have_voucher'=>'I have a voucher','p_buy'=>'Buy a package','p_enter_code'=>'Enter voucher code',
    'p_connect'=>'Connect','p_remember'=>'Remember on this phone','p_time_left'=>'Time left',
    'p_choose_pkg'=>'Choose a package','p_phone'=>'Mobile money number','p_pay'=>'Pay now','p_waiting'=>'Waiting for payment confirmation…',
    'p_push_sent'=>'Check your phone and enter your PIN to approve the payment.',
    'p_pay_instructions'=>'Pay using the details below, then wait here. Your voucher appears automatically once confirmed.',
    'p_paid_code'=>'Payment received! Your voucher','p_connecting'=>'Connecting…','p_connected'=>'You are connected!',
    'p_no_ctx'=>'Please connect to the WiFi network first, then open any website.','p_help'=>'Help','p_no_controller'=>'Portal is not linked to the controller.',
    'p_order_failed'=>'Payment failed or was cancelled.','p_order_expired'=>'Payment time expired. Please try again.','p_back'=>'Back',
    'p_data'=>'Data','p_devices'=>'device(s)','p_speed'=>'Speed','p_invalid_phone'=>'Enter a valid number e.g. 0712345678',
    'p_resume'=>'Saved voucher found','p_forget'=>'Forget','p_open_internet'=>'Open Internet','p_invalid_voucher'=>'Invalid voucher code',
    'p_voucher_blocked'=>'This voucher has been blocked','p_voucher_expired'=>'This voucher has expired','p_voucher_exhausted'=>'Data bundle for this voucher is finished',
    'p_voucher_wrong_hotspot'=>'This voucher belongs to a different hotspot','p_device_blocked'=>'This device is blocked on this hotspot',
    'p_voucher_in_use_other'=>'Voucher is already in use on another device','p_rate_limited'=>'Too many attempts. Try again in a few minutes.',
    'p_invalid_csrf'=>'Security token expired. Please refresh and try again.','p_network_error'=>'Network error. Please try again.',
    'p_unlimited'=>'Unlimited','p_online'=>'Online time only','p_continuous'=>'Continuous','p_welcome'=>'Welcome!','p_powered_by'=>'Powered by',
    'p_lang'=>'Language','p_payment_success'=>'Payment successful! Connecting you now…','p_auto_connect'=>'Auto-connecting with your voucher…',
    'p_payment_confirmed'=>'Payment confirmed! Generating voucher…','p_processing'=>'Processing payment…','p_ipaid'=>'I have already paid',
    'p_session_active'=>'Session active! You are online.','p_session_failed'=>'Could not start the session. Please enter the voucher manually.',
    'p_redirecting'=>'Opening the internet now…','p_voucher_omada_only'=>'This voucher only works on its Omada hotspot.',
  ],
  'sw' => [
    'p_title'=>'Unganishwa na Intaneti','p_have_voucher'=>'Nina vocha','p_buy'=>'Nunua kifurushi','p_enter_code'=>'Weka msimbo wa vocha',
    'p_connect'=>'Unganisha','p_remember'=>'Kumbuka kwenye simu hii','p_time_left'=>'Muda uliobaki',
    'p_choose_pkg'=>'Chagua kifurushi','p_phone'=>'Namba ya simu ya malipo','p_pay'=>'Lipa sasa','p_waiting'=>'Tunasubiri uthibitisho wa malipo…',
    'p_push_sent'=>'Angalia simu yako na weka PIN kuthibitisha malipo.',
    'p_pay_instructions'=>'Lipa kwa maelezo yaliyo hapa chini, kisha subiri hapa. Vocha yako itatokea yenyewe uthibitisho ukikamilika.',
    'p_paid_code'=>'Malipo yamepokelewa! Vocha yako','p_connecting'=>'Inaunganisha…','p_connected'=>'Umeunganishwa!',
    'p_no_ctx'=>'Tafadhali unganisha kwenye mtandao wa WiFi kwanza, kisha fungua tovuti yoyote.','p_help'=>'Msaada','p_no_controller'=>'Portal haijaunganishwa na controller.',
    'p_order_failed'=>'Malipo yameshindwa au yameghairiwa.','p_order_expired'=>'Muda wa kulipa umeisha. Jaribu tena.','p_back'=>'Rudi',
    'p_data'=>'Data','p_devices'=>'kifaa/vifaa','p_speed'=>'Kasi','p_invalid_phone'=>'Weka namba sahihi mf. 0712345678',
    'p_resume'=>'Vocha iliyohifadhiwa imepatikana','p_forget'=>'Sahau','p_open_internet'=>'Fungua Intaneti','p_invalid_voucher'=>'Msimbo wa vocha si sahihi',
    'p_voucher_blocked'=>'Vocha hii imezuiwa','p_voucher_expired'=>'Muda wa vocha hii umekwisha','p_voucher_exhausted'=>'Bando la data la vocha hii limekwisha',
    'p_voucher_wrong_hotspot'=>'Vocha hii ni ya hotspot nyingine','p_device_blocked'=>'Simu hii imezuiwa kwenye hotspot hii',
    'p_voucher_in_use_other'=>'Vocha tayari inatumika kwenye simu nyingine','p_rate_limited'=>'Majaribio mengi. Jaribu tena baada ya dakika chache.',
    'p_invalid_csrf'=>'Tokeni ya usalama imeisha. Tafadhali refresh na ujaribu tena.','p_network_error'=>'Tatizo la mtandao. Jaribu tena.',
    'p_unlimited'=>'Bila kikomo','p_online'=>'Muda wa mtandaoni tu','p_continuous'=>'Mfululizo','p_welcome'=>'Karibu!','p_powered_by'=>'Inaendeshwa na',
    'p_lang'=>'Lugha','p_payment_success'=>'Malipo yamefanikiwa! Tunakuunganisha sasa…','p_auto_connect'=>'Inaunganisha kiotomatiki na vocha yako…',
    'p_payment_confirmed'=>'Malipo yamethibitishwa! Tunatengeneza vocha…','p_processing'=>'Tunachakata malipo…','p_ipaid'=>'Nimekwisha lipa',
    'p_session_active'=>'Kipindi kimewashwa! Uko mtandaoni.','p_session_failed'=>'Imeshindwa kuwasha kipindi. Tafadhali weka vocha kwa mkono.',
    'p_redirecting'=>'Tunafungua intaneti sasa…','p_voucher_omada_only'=>'Vocha hii inafanya kazi kwenye hotspot yake ya Omada tu.',
  ],
];
function t(string $k): string {
    global $T, $currentLang;
    return $T[$currentLang][$k] ?? $T['en'][$k] ?? ucfirst(str_replace('_', ' ', $k));
}

$CTX_KEYS = ['clientMac','clientIp','apMac','gatewayMac','ssidName','radioId','vid',
             'scheme','originUrl','redirectUrl','target','targetPort','site','t',
             'hostname','serverPort'];
if (isset($_GET['clientMac'])) {
    $ctx = [];
    foreach ($CTX_KEYS as $k) $ctx[$k] = substr(trim((string)($_GET[$k] ?? '')), 0, 600);
    $_SESSION['portal_ctx'] = $ctx;
}
$ctx = $_SESSION['portal_ctx'] ?? [];
$apMac   = normMac($ctx['apMac'] ?? '');
$cliMac  = normMac($ctx['clientMac'] ?? '');
$hasCtx  = $cliMac !== '';
$origin  = phoneOrigin($ctx);

$dev = $apMac !== '' ? row("SELECT * FROM hs_devices WHERE ap_mac=? AND is_active=1 LIMIT 1", 's', $apMac) : null;
$seller = $dev ? row("SELECT full_name, phone FROM users WHERE id=?", 'i', $dev['user_id']) : null;
$title = $dev['ssid'] ?? ($ctx['ssidName'] ?? SITE_NAME);

// ---------------------------------------------------------------------------
// ★ v6.5 — Controller PORTAL endpoint resolution.
//   browserauth lives on the Omada Controller portal port (8843 https /
//   8088 http). It NEVER lives on this website, and NEVER on 8043.
// ---------------------------------------------------------------------------
function portalOwnHosts(): array {
    $hosts = [];
    if (SITE_URL !== '') { $h = parse_url((string)SITE_URL, PHP_URL_HOST); if (is_string($h) && $h !== '') $hosts[] = strtolower($h); }
    foreach (['HTTP_HOST','SERVER_NAME'] as $k) {
        $h = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER[$k] ?? '')));
        if ($h !== '') $hosts[] = $h;
    }
    return array_values(array_unique($hosts));
}
function isOwnHost(string $host): bool {
    $host = strtolower(trim($host));
    if ($host === '') return true;
    return in_array($host, portalOwnHosts(), true);
}
function ctrlPortalPort(string $scheme): int {
    return $scheme === 'http' ? (int)CTRL_PORTAL_HTTP_PORT : (int)CTRL_PORTAL_HTTPS_PORT;
}
function ctrlDefaultScheme(): string {
    return strtolower((string)CTRL_PORTAL_SCHEME) === 'http' ? 'http' : 'https';
}
/**
 * Turn a host/URL into "scheme://host:port".
 *  $forcePortalPort = true  → ignore the URL's port (e.g. management 8043)
 *                             and use the controller PORTAL port instead.
 */
function authBaseFrom(string $u, bool $forcePortalPort): string {
    $u = trim($u);
    if ($u === '') return '';
    if (!preg_match('#^[a-z]+://#i', $u)) $u = ctrlDefaultScheme() . '://' . $u;
    $p = parse_url($u);
    if (!$p || empty($p['host'])) return '';
    $scheme = strtolower((string)($p['scheme'] ?? 'https'));
    if (!in_array($scheme, ['http','https'], true)) return '';
    $host = strtolower((string)$p['host']);
    if (!preg_match('/^[a-z0-9.\-]+$/', $host) || isOwnHost($host)) return '';
    $port = isset($p['port']) ? (int)$p['port'] : 0;
    if ($forcePortalPort || $port <= 0 || $port === 8043) {
        $scheme = ctrlDefaultScheme();
        $port = ctrlPortalPort($scheme);
    }
    return $scheme . '://' . $host . ':' . $port;
}
function deviceAuthInfo(?array $dev, array $ctx): array {
    // 1. Explicit override
    $b = authBaseFrom((string)CTRL_PORTAL_URL, false);
    if ($b !== '') return ['base' => $b, 'source' => 'CTRL_PORTAL_URL'];

    // 2. What the EAP225 sent in the redirect (target = controller address)
    $target = trim((string)($ctx['target'] ?? ''));
    if ($target !== '' && preg_match('/^[A-Za-z0-9.\-]+$/', $target) && !isOwnHost($target)) {
        $scheme = in_array($ctx['scheme'] ?? '', ['http','https'], true) ? (string)$ctx['scheme'] : ctrlDefaultScheme();
        $port = (int)($ctx['targetPort'] ?? 0);
        if ($port <= 0 || $port === 8043) $port = ctrlPortalPort($scheme);
        return ['base' => $scheme . '://' . strtolower($target) . ':' . $port, 'source' => 'redirect target'];
    }

    // 3. Per-device portal target
    if ($dev && !empty($dev['portal_target'])) {
        $b = authBaseFrom((string)$dev['portal_target'], false);
        if ($b !== '') return ['base' => $b, 'source' => 'hs_devices.portal_target'];
    }

    // 4. Per-device controller URL (management URL → portal port)
    if ($dev && !empty($dev['controller_url'])) {
        $b = authBaseFrom((string)$dev['controller_url'], true);
        if ($b !== '') return ['base' => $b, 'source' => 'hs_devices.controller_url'];
    }

    // 5. Global controller URL setting
    $s = getSetting('controller_url');
    if ($s !== '') {
        $b = authBaseFrom($s, true);
        if ($b !== '') return ['base' => $b, 'source' => 'settings.controller_url'];
    }

    // 6. Built-in default (VPS controller)
    $b = authBaseFrom((string)CTRL_PORTAL_HOST, true);
    if ($b !== '') return ['base' => $b, 'source' => 'CTRL_PORTAL_HOST'];

    return ['base' => '', 'source' => 'none'];
}
function deviceAuthBase(?array $dev, array $ctx): string {
    return deviceAuthInfo($dev, $ctx)['base'];
}
function deviceAuthUrl(?array $dev, array $ctx): string {
    $base = deviceAuthBase($dev, $ctx);
    if ($base === '') return '';
    return $base . '/portal/radius/browserauth';
}

function voucherRemainingSeconds(array $v): int {
    $dur = (int)($v['duration_minutes'] ?? 0);
    if ($dur < 1) $dur = 60;
    $durSecs = $dur * 60;
    $mode = (string)($v['time_mode'] ?? 'continuous');
    if ($mode === 'online') return max(0, $durSecs - (int)($v['seconds_used'] ?? 0));
    if (empty($v['first_used_at'])) return $durSecs;
    $exp = !empty($v['expires_at']) ? (int)strtotime((string)$v['expires_at']) : 0;
    if ($exp <= 0) $exp = (int)strtotime((string)$v['first_used_at']) + $durSecs;
    return max(0, $exp - time());
}

function voucherCheck(string $code, string $mac = '', ?array $dev = null, bool $commit = false): array {
    $code = strtoupper(preg_replace('/\s+/', '', $code));
    $fail = fn($k) => ['ok' => false, 'key' => $k, 'msg' => t('p_' . $k)];
    if ($code === '' || strlen($code) > 20) return $fail('invalid_voucher');
    $v = row("SELECT v.*, p.name AS package_name FROM hs_vouchers v LEFT JOIN hs_packages p ON p.id=v.package_id WHERE v.code=?", 's', $code);
    if (!$v) return $fail('invalid_voucher');
    if (($v['source'] ?? '') === 'omada') return $fail('voucher_omada_only');

    if ($v['status'] === 'expired' && empty($v['first_used_at'])
        && (!empty($v['valid_until']) && strtotime((string)$v['valid_until']) > time())) {
        run("UPDATE hs_vouchers SET status='sold', expires_at=NULL WHERE id=?", 'i', $v['id']);
        $v['status'] = 'sold'; $v['expires_at'] = null;
    }

    if (in_array($v['status'], ['blocked','cancelled'], true)) return $fail('voucher_blocked');
    if ($v['status'] === 'expired')   return $fail('voucher_expired');
    if ($v['status'] === 'exhausted') return $fail('voucher_exhausted');
    if (in_array($v['status'], ['available','sold'], true) && $v['valid_until'] && strtotime((string)$v['valid_until']) < time()) {
        run("UPDATE hs_vouchers SET status='expired' WHERE id=?", 'i', $v['id']); return $fail('voucher_expired');
    }
    if ($dev) {
        if ((int)$dev['user_id'] !== (int)$v['seller_id']) return $fail('voucher_wrong_hotspot');
        if ($v['device_id'] && (int)$v['device_id'] !== (int)$dev['id']) return $fail('voucher_wrong_hotspot');
    }
    if ($mac !== '') {
        if (val("SELECT 1 FROM hs_blocked_macs WHERE seller_id=? AND mac=?", 'is', $v['seller_id'], $mac)) return $fail('device_blocked');
        $bound = array_column(rows("SELECT mac FROM hs_voucher_macs WHERE voucher_id=?", 'i', $v['id']), 'mac');
        if (!in_array($mac, $bound, true) && count($bound) >= max(1, (int)($v['max_devices'] ?? 1))) return $fail('voucher_in_use_other');
    }
    if (($v['time_mode'] ?? 'continuous') === 'online' && $v['first_used_at']) {
        run("UPDATE hs_vouchers v SET
               data_used_bytes = (SELECT COALESCE(SUM(s.bytes_in + s.bytes_out),0) FROM hs_sessions s WHERE s.voucher_id=v.id),
               seconds_used    = (SELECT COALESCE(SUM(s.session_time),0) FROM hs_sessions s WHERE s.voucher_id=v.id)
             WHERE v.id=?", 'i', $v['id']);
        $v = row("SELECT * FROM hs_vouchers WHERE id=?", 'i', $v['id']) + $v;
    }
    $remaining = voucherRemainingSeconds($v);
    if ($remaining <= 0) { run("UPDATE hs_vouchers SET status='expired' WHERE id=?", 'i', $v['id']); return $fail('voucher_expired'); }
    $limit = (int)($v['data_limit_mb'] ?? 0) * 1048576;
    if ($limit > 0 && (int)($v['data_used_bytes'] ?? 0) >= $limit) { run("UPDATE hs_vouchers SET status='exhausted' WHERE id=?", 'i', $v['id']); return $fail('voucher_exhausted'); }

    if ($commit) {
        if (empty($v['first_used_at'])) {
            $durMin = (int)($v['duration_minutes'] ?? 0); if ($durMin < 1) $durMin = 60;
            $exp = (($v['time_mode'] ?? 'continuous') === 'continuous') ? date('Y-m-d H:i:s', time() + $durMin * 60) : null;
            run("UPDATE hs_vouchers SET first_used_at=NOW(), expires_at=?, status='active', sold_at=COALESCE(sold_at,NOW()) WHERE id=? AND first_used_at IS NULL", 'si', $exp, $v['id']);
            $v = row("SELECT * FROM hs_vouchers WHERE id=?", 'i', $v['id']) + $v;
            $remaining = voucherRemainingSeconds($v);
        } elseif ($v['status'] !== 'active') {
            run("UPDATE hs_vouchers SET status='active' WHERE id=?", 'i', $v['id']);
        }
        if ($mac !== '') q("INSERT INTO hs_voucher_macs (voucher_id,mac,first_seen,last_seen) VALUES (?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE last_seen=NOW()", 'is', $v['id'], $mac);
        run("UPDATE hs_vouchers SET last_mac=?, last_seen=NOW() WHERE id=?", 'si', $mac, $v['id']);
    }
    $dataLeft = $limit > 0 ? max(0, $limit - (int)($v['data_used_bytes'] ?? 0)) : null;
    return ['ok' => true, 'voucher' => $v, 'remaining' => $remaining, 'data_left' => $dataLeft];
}

function portalRegisterSession(string $code, string $clientMac, ?array $dev): array {
    $v = row("SELECT * FROM hs_vouchers WHERE code=? LIMIT 1", 's', $code);
    if (!$v) return ['ok' => false, 'error' => 'voucher missing'];
    $mac = normMac($clientMac);
    if ($mac === '') return ['ok' => false, 'error' => 'no mac'];

    $check = voucherCheck($code, $mac, $dev, true);
    if (!$check['ok']) return ['ok' => false, 'error' => $check['msg']];

    $v = $check['voucher'];
    $sellerId = (int)$v['seller_id'];
    $deviceId = $v['device_id'] ? (int)$v['device_id'] : (isset($dev['id']) ? (int)$dev['id'] : null);
    $uniqueId = md5('portal:' . $v['id'] . '|' . $mac);

    // ★ v6.5 — unique_id is a string (was bound as integer)
    run("UPDATE hs_sessions SET status='closed', stopped_at=NOW(), terminate_cause='Portal-Reconnect'
         WHERE voucher_id=? AND mac=? AND status='active' AND unique_id<>?", 'iss', (int)$v['id'], $mac, $uniqueId);

    $now = date('Y-m-d H:i:s');
    $started = $v['first_used_at'] ?: $now;

    $existing = row("SELECT id, status FROM hs_sessions WHERE unique_id=? LIMIT 1", 's', $uniqueId);
    if ($existing) {
        if ($existing['status'] !== 'active') {
            run("UPDATE hs_sessions SET status='active', stopped_at=NULL, terminate_cause=NULL,
                    started_at=COALESCE(started_at,?), updated_at=NOW()
                 WHERE id=?", 'si', $started, $existing['id']);
        } else {
            run("UPDATE hs_sessions SET updated_at=NOW() WHERE id=?", 'i', $existing['id']);
        }
        $sid = (int)$existing['id'];
    } else {
        q("INSERT INTO hs_sessions
             (voucher_id, seller_id, device_id, username, unique_id, acct_session_id,
              mac, ip, nas_ip, nas_id, ap_mac, started_at, updated_at, session_time,
              bytes_in, bytes_out, status, terminate_cause)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,'active',NULL)",
           'iiissssssssss',
            (int)$v['id'], $sellerId, $deviceId, (string)$v['code'], $uniqueId,
            'portal-' . substr($uniqueId, 0, 16),
            $mac, (string)($dev['ip'] ?? ''), (string)($dev['nas_ip'] ?? ''),
            (string)($dev['nas_id'] ?? ''), (string)($dev['ap_mac'] ?? ''),
            $started, $now);
        $sid = (int)db()->insert_id;
    }

    return [
        'ok' => true,
        'session_id' => $sid,
        'voucher_id' => (int)$v['id'],
        'code' => (string)$v['code'],
        'remaining' => (int)$check['remaining'],
        'data_left' => $check['data_left'],
    ];
}

function spCurlCollect(array $payload): array {
    if (SONIC_PESA_COLLECT_ENDPOINT === '') return ['success' => false, 'manual' => true];
    if (!canCall('curl_init')) return ['success' => false, 'error' => 'cURL unavailable'];
    $ch = curl_init(rtrim(SONIC_PESA_API_BASE, '/') . SONIC_PESA_COLLECT_ENDPOINT);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json',
            'X-API-KEY: ' . SONIC_PESA_API_KEY, 'X-API-SECRET: ' . SONIC_PESA_API_SECRET],
        CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $res = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    if ($err) return ['success' => false, 'error' => $err];
    $d = json_decode((string)$res, true) ?: [];
    if ($http < 200 || $http >= 300) return ['success' => false, 'error' => 'HTTP ' . $http . ' ' . substr((string)$res, 0, 200)];
    if (in_array(strtolower((string)($d['status'] ?? '')), ['error', 'failed'], true)) return ['success' => false, 'error' => (string)($d['message'] ?? 'gateway error')];
    return ['success' => true, 'gateway_ref' => (string)($d['data']['transaction_id'] ?? $d['transaction_id'] ?? $d['data']['id'] ?? ''), 'raw' => substr((string)$res, 0, 2000)];
}

function createOrder(array $pkg, ?array $dev, string $phone, string $mac): array {
    $phone = normalizePhone($phone);
    if (!preg_match('/^0[67]\d{8}$/', $phone)) return ['success' => false, 'message' => t('p_invalid_phone')];
    if ((int)val("SELECT COUNT(*) FROM hs_orders WHERE client_mac=? AND status='pending' AND created_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE)", 's', $mac) >= 3)
        return ['success' => false, 'message' => t('p_rate_limited')];

    $ref = 'SKY' . date('ymdHis') . strtoupper(bin2hex(random_bytes(2)));
    $amount = (int)round((float)$pkg['price']);
    q("INSERT INTO hs_orders (order_ref, seller_id, package_id, device_id, phone, amount, client_mac, status) VALUES (?,?,?,?,?,?,?,'pending')",
        'siiisds', $ref, (int)$pkg['seller_id'], (int)$pkg['id'], isset($dev['id']) ? (int)$dev['id'] : null, $phone, $amount, $mac);

    $collect = spCurlCollect([
        'amount' => $amount, 'phone' => '255' . substr($phone, 1), 'reference' => $ref,
        'description' => substr((string)$pkg['name'], 0, 60),
        'callback_url' => portalBaseUrl() . portalSelfPath() . '?webhook=sonicpesa',
    ]);
    if (!empty($collect['success'])) {
        run("UPDATE hs_orders SET gateway_ref=?, gateway_response=? WHERE order_ref=?", 'sss',
            (string)($collect['gateway_ref'] ?? ''), (string)($collect['raw'] ?? ''), $ref);
        return ['success' => true, 'ref' => $ref, 'mode' => 'push', 'message' => t('p_push_sent')];
    }
    $sellerInfo = row("SELECT full_name, phone FROM users WHERE id=?", 'i', $pkg['seller_id']);
    $instr = trim(($dev['lipa_info'] ?? '') ?: ('Contact: ' . ($sellerInfo['full_name'] ?? '') . ' ' . ($sellerInfo['phone'] ?? '')));
    return ['success' => true, 'ref' => $ref, 'mode' => 'manual', 'message' => t('p_pay_instructions'),
        'instructions' => $instr, 'amount' => money($pkg['price'])];
}

function fulfillOrder(string $ref, string $gref = '', string $raw = ''): ?array {
    db()->begin_transaction();
    try {
        $o = row("SELECT * FROM hs_orders WHERE order_ref=? FOR UPDATE", 's', $ref);
        if (!$o || $o['status'] === 'paid') { db()->commit(); return $o; }
        if (!in_array($o['status'], ['pending', 'expired', 'failed'], true)) { db()->commit(); return $o; }

        $p = row("SELECT * FROM hs_packages WHERE id=?", 'i', $o['package_id']);
        if (!$p) throw new RuntimeException('Package missing');
        $len = max(6, min(12, (int)getSetting('voucher_length', '8')));
        $attempts = 0; $code = '';
        do { $code = genCode($len); $exists = val("SELECT 1 FROM hs_vouchers WHERE code=?", 's', $code); $attempts++; } while ($exists && $attempts < 10);
        if ($exists) throw new RuntimeException('Could not generate unique code');
        $validUntil = (int)$p['validity_days'] > 0 ? date('Y-m-d H:i:s', time() + (int)$p['validity_days'] * 86400) : null;

        // ★ v6.5 — 14 placeholders → 14 types (was 15, so every paid order failed)
        q("INSERT INTO hs_vouchers (package_id,seller_id,device_id,code,batch,price,duration_minutes,time_mode,data_limit_mb,speed_down_mbps,speed_up_mbps,max_devices,status,source,sold_to_phone,sold_at,valid_until)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'sold','online',?,NOW(),?)",
            'iiissdisiddiss',
            (int)$p['id'], (int)$o['seller_id'], $p['device_id'] !== null ? (int)$p['device_id'] : null,
            $code, 'ON' . date('ymdHi'), (float)$p['price'],
            (int)$p['duration_minutes'], (string)$p['time_mode'], (int)$p['data_limit_mb'],
            (float)$p['speed_down_mbps'], (float)$p['speed_up_mbps'], (int)$p['max_devices'],
            (string)$o['phone'], $validUntil);
        $vid = (int)db()->insert_id;

        run("UPDATE hs_orders SET status='paid', paid_at=NOW(), voucher_id=?, gateway_ref=IF(?<>'',?,gateway_ref), gateway_response=IF(?<>'',?,gateway_response) WHERE id=?",
            'issssi', $vid, $gref, $gref, $raw, $raw, (int)$o['id']);
        run("UPDATE users SET balance=balance+? WHERE id=?", 'di', (float)$o['amount'], (int)$o['seller_id']);
        db()->commit();
        return row("SELECT * FROM hs_orders WHERE id=?", 'i', $o['id']);
    } catch (Throwable $e) {
        db()->rollback();
        error_log('fulfillOrder ' . $ref . ': ' . $e->getMessage());
        return null;
    }
}

if (isset($_GET['webhook']) && $_GET['webhook'] === 'sonicpesa') {
    header('Content-Type: application/json');
    try {
        $raw = (string)file_get_contents('php://input');
        $d = json_decode($raw, true);
        if (!is_array($d)) $d = $_POST;
        $flat = $d + (isset($d['data']) && is_array($d['data']) ? $d['data'] : []);
        $ref = (string)($flat['reference'] ?? $flat['order_ref'] ?? '');
        $status = strtolower((string)($flat['status'] ?? $flat['payment_status'] ?? ''));
        $gref = (string)($flat['transaction_id'] ?? $flat['transid'] ?? '');
        if ($ref !== '' && in_array($status, ['success', 'successful', 'completed', 'paid'], true)) {
            fulfillOrder($ref, $gref, substr($raw, 0, 4000));
            echo json_encode(['ok' => true]); exit;
        }
        echo json_encode(['ok' => false, 'message' => 'ignored']); exit;
    } catch (Throwable $e) {
        error_log('webhook: ' . $e->getMessage());
        http_response_code(500); echo json_encode(['ok' => false]); exit;
    }
}

if (isset($_GET['ajax'])) {
    $ajax = (string)$_GET['ajax'];
    try {
        if ($ajax === 'ping') jsonOut(['ok' => true, 'version' => APP_VERSION, 'time' => date('c'), 'authType' => controllerAuthType(), 'mode' => 'External RADIUS (PAP inside)']);

        if ($ajax === 'ctx') {
            $info = deviceAuthInfo($dev, $ctx);
            jsonOut(['ok' => true, 'hasCtx' => $hasCtx, 'clientMac' => $cliMac, 'apMac' => $apMac,
                'ssid' => $title, 'seller' => $seller ? ['name' => $seller['full_name'], 'phone' => $seller['phone']] : null,
                'authUrl' => deviceAuthUrl($dev, $ctx), 'authSource' => $info['source'],
                'authType' => controllerAuthType(),
                'originUrl' => phoneOrigin($ctx), 'ctx' => $ctx,
                'portalUrl' => portalBaseUrl() . portalSelfPath()]);
        }

        // Diagnostic: open https://wifi.skytanzania.co.tz/portal.php?ajax=probe_auth
        if ($ajax === 'probe_auth') {
            $info = deviceAuthInfo($dev, $ctx);
            $authUrl = deviceAuthUrl($dev, $ctx);
            if ($authUrl === '') jsonOut(['success' => false, 'message' => 'No auth URL — set CTRL_PORTAL_HOST or CTRL_PORTAL_URL']);
            if (!canCall('curl_init')) jsonOut(['success' => false, 'authUrl' => $authUrl, 'message' => 'cURL unavailable on this host']);

            $probeCode = 'PROBE000';
            $results = [];
            foreach ([0, 1, 2] as $t) {
                $fields = buildAuthFields($probeCode, $dev, $ctx);
                $fields['authType'] = $t;
                $body = http_build_query($fields);

                $ch = curl_init($authUrl);
                curl_setopt_array($ch, [
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $body,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HEADER         => false,
                    CURLOPT_TIMEOUT        => 10,
                    CURLOPT_CONNECTTIMEOUT => 5,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_FOLLOWLOCATION => false,
                    CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded', 'Accept: */*'],
                    CURLOPT_USERAGENT      => 'SkyTanza-Probe/1.2',
                ]);
                $raw  = curl_exec($ch);
                $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $err  = curl_error($ch);
                curl_close($ch);

                $parsed = json_decode((string)$raw, true);
                $results[$t] = [
                    'http'      => $http,
                    'curl_err'  => $err,
                    'errorCode' => is_array($parsed) ? ($parsed['errorCode'] ?? null) : null,
                    'msg'       => is_array($parsed) ? ($parsed['msg'] ?? null) : substr((string)$raw, 0, 200),
                ];
            }
            jsonOut(['success' => true, 'authUrl' => $authUrl, 'authSource' => $info['source'],
                'hint' => 'authUrl must be the Omada Controller portal port (8843/8088), never this website. authType=2 should NOT return -41500.',
                'probe' => $results]);
        }

        $csrf_token_received = (string)($_POST['csrf'] ?? '');
        if (!csrf_check($csrf_token_received)) {
            error_log("AJAX[$ajax]: CSRF FAILED");
            jsonOut(['success' => false, 'message' => t('p_invalid_csrf'), 'reload' => true]);
        }

        if ($ajax === 'check') {
            if (!rateLimitCheck(clientIp() . '|' . $cliMac, 'portal_check', 15, 300))
                jsonOut(['success' => false, 'message' => t('p_rate_limited')]);
            $res = voucherCheck((string)($_POST['code'] ?? ''), $cliMac, $dev, false);
            if (!$res['ok']) jsonOut(['success' => false, 'message' => $res['msg']]);
            $v = $res['voucher'];
            jsonOut(['success' => true, 'code' => $v['code'],
                'remaining' => $res['remaining'], 'remaining_text' => fmtSecs((int)$res['remaining']),
                'data_left' => $res['data_left'] === null ? t('p_unlimited') : fmtBytes($res['data_left']),
                'package' => $v['package_name'] ?? '', 'started' => !empty($v['first_used_at'])]);
        }

        if ($ajax === 'prepare') {
            if (!rateLimitCheck(clientIp() . '|' . $cliMac, 'portal_prepare', 20, 300))
                jsonOut(['success' => false, 'message' => t('p_rate_limited')]);
            $code = (string)($_POST['code'] ?? '');
            $res = voucherCheck($code, $cliMac, $dev, false);
            if (!$res['ok']) jsonOut(['success' => false, 'message' => $res['msg']]);
            $authUrl = deviceAuthUrl($dev, $ctx);
            if ($authUrl === '') jsonOut(['success' => false, 'message' => t('p_no_controller')]);
            $fields = buildAuthFields($code, $dev, $ctx);
            jsonOut(['success' => true, 'authUrl' => $authUrl, 'fields' => $fields,
                'code' => strtoupper(preg_replace('/\s+/', '', $code)),
                'authType' => $fields['authType'], 'originUrl' => $fields['originUrl']]);
        }

        if ($ajax === 'activate') {
            $code = strtoupper(preg_replace('/\s+/', '', (string)($_POST['code'] ?? '')));
            if ($code === '') jsonOut(['success' => false, 'message' => t('p_invalid_voucher')]);
            if ($cliMac === '') jsonOut(['success' => false, 'message' => t('p_no_ctx')]);
            if (!rateLimitCheck(clientIp() . '|' . $cliMac, 'portal_activate', 20, 300))
                jsonOut(['success' => false, 'message' => t('p_rate_limited')]);
            $sess = portalRegisterSession($code, $cliMac, $dev);
            if (empty($sess['ok'])) jsonOut(['success' => false, 'message' => $sess['error'] ?? t('p_session_failed')]);
            jsonOut(['success' => true, 'status' => 'active', 'code' => $sess['code'],
                'session_id' => $sess['session_id'],
                'remaining' => (int)$sess['remaining'], 'remaining_text' => fmtSecs((int)$sess['remaining']),
                'data_left' => $sess['data_left'] === null ? t('p_unlimited') : fmtBytes($sess['data_left'])]);
        }

        if ($ajax === 'buy') {
            if (!rateLimitCheck(clientIp() . '|' . $cliMac, 'portal_buy', 6, 900))
                jsonOut(['success' => false, 'message' => t('p_rate_limited')]);
            $pkg = row("SELECT * FROM hs_packages WHERE id=? AND is_active=1 AND show_on_portal=1", 'i', (int)($_POST['package_id'] ?? 0));
            if (!$pkg || !$dev || (int)$pkg['seller_id'] !== (int)$dev['user_id'] || ($pkg['device_id'] && (int)$pkg['device_id'] !== (int)$dev['id']))
                jsonOut(['success' => false, 'message' => t('p_no_ctx')]);
            $r = createOrder($pkg, $dev, (string)($_POST['phone'] ?? ''), $cliMac);
            if (!empty($r['success']) && !empty($r['ref'])) {
                if (!isset($_SESSION['portal_orders'])) $_SESSION['portal_orders'] = [];
                $_SESSION['portal_orders'][] = $r['ref'];
            }
            jsonOut($r);
        }

        if ($ajax === 'order') {
            $ref = (string)($_POST['ref'] ?? '');
            if (!in_array($ref, $_SESSION['portal_orders'] ?? [], true))
                jsonOut(['success' => false, 'message' => 'Unknown order']);
            $o = row("SELECT o.status, o.created_at, v.code FROM hs_orders o LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.order_ref=?", 's', $ref);
            if (!$o) jsonOut(['success' => true, 'status' => 'failed', 'code' => null]);
            if ($o['status'] === 'paid') {
                $authUrl = deviceAuthUrl($dev, $ctx);
                jsonOut(['success' => true, 'status' => 'paid', 'code' => $o['code'],
                    'authUrl' => $authUrl, 'originUrl' => phoneOrigin($ctx)]);
            }
            if ($o['status'] === 'failed' || $o['status'] === 'cancelled') jsonOut(['success' => true, 'status' => 'failed', 'code' => null]);
            if ((time() - strtotime((string)$o['created_at'])) > 1800) {
                run("UPDATE hs_orders SET status='expired' WHERE order_ref=? AND status='pending'", 's', $ref);
                jsonOut(['success' => true, 'status' => 'expired', 'code' => null]);
            }
            jsonOut(['success' => true, 'status' => 'pending', 'code' => null]);
        }

        if ($ajax === 'ipaid') {
            if (!rateLimitCheck(clientIp() . '|' . $cliMac, 'portal_ipaid', 6, 900))
                jsonOut(['success' => false, 'message' => t('p_rate_limited')]);
            $ref = (string)($_POST['ref'] ?? '');
            if (!in_array($ref, $_SESSION['portal_orders'] ?? [], true))
                jsonOut(['success' => false, 'message' => 'Unknown order']);
            $o = row("SELECT o.status, v.code FROM hs_orders o LEFT JOIN hs_vouchers v ON v.id=o.voucher_id WHERE o.order_ref=?", 's', $ref);
            $authUrl = deviceAuthUrl($dev, $ctx);
            jsonOut(['success' => true, 'status' => $o['status'] ?? 'pending',
                'code' => ($o && $o['status'] === 'paid') ? $o['code'] : null,
                'authUrl' => $authUrl, 'originUrl' => phoneOrigin($ctx),
                'message' => ($o && $o['status'] === 'paid') ? t('p_payment_confirmed') : t('p_waiting')]);
        }

        jsonOut(['success' => false, 'message' => 'Unknown action'], 400);
    } catch (Throwable $e) {
        error_log("AJAX[$ajax] EXCEPTION: " . $e->getMessage() . "\n" . $e->getTraceAsString());
        jsonOut(['success' => false, 'message' => t('p_network_error')], 500);
    }
}

if (isset($_GET['pwa'])) {
    while (ob_get_level() > 0) ob_end_clean();
    if ($_GET['pwa'] === 'manifest') {
        header('Content-Type: application/manifest+json'); header('Cache-Control: public, max-age=86400');
        echo json_encode(['name' => SITE_NAME . ' Portal', 'short_name' => 'WiFi',
            'start_url' => './portal.php', 'scope' => './', 'display' => 'standalone',
            'background_color' => '#060a13', 'theme_color' => '#060a13',
            'icons' => [['src' => 'portal.php?pwa=icon', 'sizes' => 'any', 'type' => 'image/svg+xml', 'purpose' => 'any maskable']]]);
        exit;
    }
    if ($_GET['pwa'] === 'sw') {
        header('Content-Type: application/javascript'); header('Cache-Control: no-cache');
        echo <<<'JS'
const CACHE='sky-portal-v65';
const SHELL=['./portal.php'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).catch(()=>{}));self.skipWaiting();});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const url=new URL(e.request.url);if(url.origin!==location.origin)return;
 if(e.request.method!=='GET')return;
 if(url.searchParams.has('ajax')||url.searchParams.has('pwa')||url.searchParams.has('webhook'))return;
 e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy)).catch(()=>{});return r;}).catch(()=>caches.match(e.request).then(r=>r||caches.match('./portal.php'))));});
JS;
        exit;
    }
    header('Content-Type: image/svg+xml'); header('Cache-Control: public, max-age=604800, immutable');
    echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b8cff"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/><path d="M96 208a224 224 0 0 1 320 0l-36 36a173 173 0 0 0-248 0zm68 68a128 128 0 0 1 184 0l-36 36a77 77 0 0 0-112 0zm92 52 44 44-44 44-44-44z" fill="#fff"/></svg>';
    exit;
}

$pkgs = $dev
    ? rows("SELECT * FROM hs_packages WHERE seller_id=? AND is_active=1 AND show_on_portal=1 AND (device_id IS NULL OR device_id=?) ORDER BY sort_order, price", 'ii', $dev['user_id'], $dev['id'])
    : [];
$authUrl = deviceAuthUrl($dev, $ctx);
$done    = isset($_GET['done']);
$csrf    = csrf_token();

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');

while (ob_get_level() > 0) ob_end_clean();
?>
<!DOCTYPE html>
<html lang="<?= h($currentLang) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#060a13">
<meta name="color-scheme" content="dark light">
<meta name="format-detection" content="telephone=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="WiFi">
<link rel="manifest" href="?pwa=manifest">
<link rel="icon" href="?pwa=icon" type="image/svg+xml">
<link rel="apple-touch-icon" href="?pwa=icon">
<title><?= h($title ?: SITE_NAME) ?> — WiFi</title>
<style>
:root{--bg:#060a13;--card:rgba(15,22,38,.74);--field:rgba(6,10,19,.72);--line:rgba(148,163,184,.13);--line-2:rgba(148,163,184,.24);--txt:#eef2f9;--mut:#93a3bc;--pri:#5b8cff;--pri-2:#8b5cf6;--ok:#22c55e;--bad:#f43f5e;--warn:#f59e0b;--r:20px;--mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;--shadow:0 30px 60px -32px rgba(0,0,0,.85),inset 0 1px 0 rgba(255,255,255,.05)}
@media (prefers-color-scheme: light){:root{--bg:#eef2f9;--card:rgba(255,255,255,.85);--field:rgba(255,255,255,.9);--line:rgba(15,23,42,.08);--line-2:rgba(15,23,42,.16);--txt:#0e1726;--mut:#5b6779;--shadow:0 24px 50px -30px rgba(15,23,42,.35),inset 0 1px 0 rgba(255,255,255,.6)}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;padding:0}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Inter,"Helvetica Neue",Arial,sans-serif;background:var(--bg);color:var(--txt);min-height:100vh;min-height:100dvh;-webkit-font-smoothing:antialiased;overflow-x:hidden;line-height:1.45}
body::before,body::after{content:"";position:fixed;z-index:-1;border-radius:50%;filter:blur(80px);pointer-events:none}
body::before{width:440px;height:440px;background:var(--pri);top:-180px;left:-140px;opacity:.5}
body::after{width:400px;height:400px;background:var(--pri-2);bottom:-180px;right:-160px;opacity:.38}
.wrap{max-width:430px;margin:0 auto;padding:30px 18px calc(36px + env(safe-area-inset-bottom))}
.brand{text-align:center;margin:12px 0 24px}
.logo{width:74px;height:74px;border-radius:24px;background:linear-gradient(135deg,var(--pri),var(--pri-2));display:inline-grid;place-items:center;box-shadow:0 20px 44px -14px rgba(91,140,255,.75),inset 0 1px 0 rgba(255,255,255,.28);animation:float 5s ease-in-out infinite}
.logo svg{width:40px;height:40px}@keyframes float{50%{transform:translateY(-6px)}}
h1{font-size:1.55rem;margin:18px 0 4px;letter-spacing:-.025em;font-weight:800}h2{letter-spacing:-.02em}
.sub{color:var(--mut);font-size:.93rem;margin:0}
.card{background:var(--card);-webkit-backdrop-filter:blur(20px) saturate(160%);backdrop-filter:blur(20px) saturate(160%);border:1px solid var(--line);border-radius:var(--r);padding:20px;margin-bottom:14px;box-shadow:var(--shadow);animation:rise .4s cubic-bezier(.2,.8,.2,1) both}
@keyframes rise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.tabs{display:flex;gap:4px;background:rgba(8,13,25,.75);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);border:1px solid var(--line);border-radius:16px;padding:5px;margin-bottom:14px}
.tabs button{flex:1;border:0;background:none;color:var(--mut);padding:12px 8px;border-radius:12px;font-weight:700;font-size:.93rem;cursor:pointer;font-family:inherit;transition:background .2s,color .2s,box-shadow .2s}
.tabs button.on{background:linear-gradient(135deg,var(--pri),var(--pri-2));color:#fff;box-shadow:0 10px 22px -10px rgba(91,140,255,.9)}
label{display:block;font-size:.8rem;color:var(--mut);margin-bottom:8px;font-weight:600;letter-spacing:.01em}
input[type=text],input[type=tel]{width:100%;padding:15px 16px;border-radius:14px;border:1px solid var(--line-2);background:var(--field);color:var(--txt);font-size:1.05rem;outline:none;font-family:inherit;transition:border-color .2s,box-shadow .2s}
input[type=text]:focus,input[type=tel]:focus{border-color:var(--pri);box-shadow:0 0 0 4px rgba(91,140,255,.22)}
input::placeholder{color:var(--mut);opacity:.5}
input.code{text-transform:uppercase;letter-spacing:.32em;font-family:var(--mono);text-align:center;font-size:1.45rem;font-weight:700;padding:16px 10px}
.btn{display:block;width:100%;border:0;border-radius:14px;padding:15px;font-size:1.02rem;font-weight:800;letter-spacing:.01em;background:linear-gradient(135deg,var(--pri),var(--pri-2));color:#fff;margin-top:14px;cursor:pointer;font-family:inherit;text-align:center;box-shadow:0 16px 30px -14px rgba(91,140,255,.85);transition:transform .12s,filter .15s,opacity .15s;text-decoration:none}
.btn:hover{filter:brightness(1.08)}.btn:active{transform:scale(.985)}.btn:disabled{opacity:.6;cursor:wait}
.btn.ghost{background:transparent;border:1px solid var(--line-2);color:var(--txt);box-shadow:none}
.btn.ok{background:linear-gradient(135deg,#16a34a,#22c55e);box-shadow:0 16px 30px -14px rgba(34,197,94,.8)}
.chk{display:flex;align-items:center;gap:10px;margin-top:12px;color:var(--mut);font-size:.88rem;font-weight:500;cursor:pointer}
.chk input{width:18px;height:18px;accent-color:var(--pri);margin:0}
.msg{padding:12px 14px;border-radius:14px;margin-bottom:12px;font-size:.9rem;display:none;border:1px solid;-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);animation:rise .3s both}
.msg.err{display:block;background:rgba(244,63,94,.12);border-color:rgba(244,63,94,.4);color:#fecdd3}
.msg.ok{display:block;background:rgba(34,197,94,.12);border-color:rgba(34,197,94,.4);color:#bbf7d0}
.msg.info{display:block;background:rgba(91,140,255,.12);border-color:rgba(91,140,255,.4);color:#c7d7ff}
@media (prefers-color-scheme: light){.msg.err{color:#9f1239}.msg.ok{color:#166534}.msg.info{color:#1e3a8a}}
.pk{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.pkg{position:relative;border:1px solid var(--line-2);border-radius:16px;padding:14px 12px;background:var(--field);cursor:pointer;text-align:left;color:var(--txt);font-family:inherit;transition:border-color .18s,transform .18s,background .18s,box-shadow .18s}
.pkg:hover{border-color:rgba(91,140,255,.55);transform:translateY(-1px)}
.pkg.on{border-color:var(--pri);background:rgba(91,140,255,.13);box-shadow:0 0 0 3px rgba(91,140,255,.25)}
.pkg.on::after{content:"✓";position:absolute;top:9px;right:10px;width:21px;height:21px;border-radius:50%;background:var(--pri);color:#fff;font-size:.72rem;font-weight:800;display:grid;place-items:center}
.pkg b{display:block;font-size:.97rem;padding-right:22px;line-height:1.25}
.pkg .pr{color:var(--ok);font-weight:800;font-size:1.12rem;margin-top:6px;letter-spacing:-.01em}
.pkg small{color:var(--mut);display:block;font-size:.76rem;margin-top:3px}
.big{font-size:2.35rem;font-weight:800;text-align:center;margin:6px 0;letter-spacing:-.03em;background:linear-gradient(135deg,#fff,#a9c2ff);-webkit-background-clip:text;background-clip:text;color:transparent}
@media (prefers-color-scheme: light){.big{background:linear-gradient(135deg,#0e1726,#5b6779);-webkit-background-clip:text;background-clip:text}}
.mut{color:var(--mut)}.ctr{text-align:center}
.vc{font-family:var(--mono);letter-spacing:.28em;font-size:1.6rem;font-weight:800;text-align:center;padding:14px;border:2px dashed rgba(91,140,255,.6);border-radius:14px;margin:12px 0;background:rgba(91,140,255,.08)}
.spin{width:38px;height:38px;border:4px solid rgba(255,255,255,.12);border-top-color:var(--pri);border-right-color:var(--pri-2);border-radius:50%;animation:s .9s linear infinite;margin:12px auto}
@keyframes s{to{transform:rotate(360deg)}}
.foot{text-align:center;color:var(--mut);font-size:.8rem;margin-top:22px;opacity:.85}
.foot a{color:var(--txt);text-decoration:none;font-weight:600}
.hide{display:none!important}.row{display:flex;gap:10px}.row .btn{margin-top:10px}
.lang{position:fixed;top:calc(12px + env(safe-area-inset-top));right:12px;z-index:5;display:flex;gap:2px;background:rgba(8,13,25,.75);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);border:1px solid var(--line);border-radius:12px;padding:3px}
.lang a{color:var(--mut);text-decoration:none;font-size:.74rem;font-weight:800;padding:6px 10px;border-radius:9px;letter-spacing:.04em}
.lang a.on{background:var(--pri);color:#fff}
@media (prefers-color-scheme: light){.lang{background:rgba(255,255,255,.85)}.tabs{background:rgba(255,255,255,.85)}}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="lang">
  <a href="?lang=sw" class="<?= $currentLang === 'sw' ? 'on' : '' ?>">SW</a>
  <a href="?lang=en" class="<?= $currentLang === 'en' ? 'on' : '' ?>">EN</a>
</div>
<div class="wrap">
  <div class="brand">
    <div class="logo"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 18.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM4.2 11.3a11 11 0 0 1 15.6 0l-1.6 1.6a8.7 8.7 0 0 0-12.4 0zm3.2 3.2a6.5 6.5 0 0 1 9.2 0L15 16.1a4.2 4.2 0 0 0-6 0zM1 8.1a15.6 15.6 0 0 1 22 0l-1.6 1.6a13.3 13.3 0 0 0-18.8 0z"/></svg></div>
    <h1><?= h($title ?: SITE_NAME) ?></h1>
    <p class="sub"><?= t('p_title') ?></p>
  </div>

  <div id="msg" class="msg" role="alert"></div>

  <?php if ($done): ?>
    <div class="card ctr" id="doneCard">
      <div style="font-size:2.8rem">✅</div>
      <h2 style="margin:6px 0"><?= t('p_connected') ?></h2>
      <div class="mut"><?= t('p_time_left') ?></div>
      <div class="big" id="doneLeft">—</div>
      <div class="mut" id="doneData"></div>
      <a class="btn ok" href="<?= h($origin) ?>"><?= t('p_open_internet') ?></a>
    </div>
  <?php else: ?>
    <?php if (!$hasCtx): ?>
      <div class="msg info" style="display:block"><?= t('p_no_ctx') ?></div>
    <?php endif; ?>

    <div class="card hide" id="resumeCard">
      <div class="mut" style="font-size:.85rem"><?= t('p_resume') ?></div>
      <div class="vc" id="resumeCode"></div>
      <div class="ctr mut"><?= t('p_time_left') ?>: <b id="resumeLeft" style="color:inherit"></b></div>
      <div class="row">
        <button type="button" class="btn ok" onclick="connect(saved)"><?= t('p_connect') ?></button>
        <button type="button" class="btn ghost" style="flex:.5" onclick="forget()"><?= t('p_forget') ?></button>
      </div>
    </div>

    <div class="tabs">
      <button type="button" id="tabV" class="on" onclick="tab('v')"><?= t('p_have_voucher') ?></button>
      <?php if ($pkgs): ?><button type="button" id="tabB" onclick="tab('b')"><?= t('p_buy') ?></button><?php endif; ?>
    </div>

    <div class="card" id="paneV">
      <label for="code"><?= t('p_enter_code') ?></label>
      <input type="text" id="code" class="code" maxlength="20" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="XXXXXXXX" inputmode="text" enterkeyhint="go">
      <label class="chk"><input type="checkbox" id="remember" checked> <?= t('p_remember') ?></label>
      <button type="button" class="btn" id="btnV" onclick="connect(document.getElementById('code').value)"><?= t('p_connect') ?></button>
    </div>

    <?php if ($pkgs): ?>
      <div class="card hide" id="paneB">
        <div id="buyForm">
          <label><?= t('p_choose_pkg') ?></label>
          <div class="pk">
            <?php foreach ($pkgs as $p): ?>
              <button type="button" class="pkg" data-id="<?= (int)$p['id'] ?>" data-price="<?= (int)$p['price'] ?>" onclick="pick(this)">
                <b><?= h($p['name']) ?></b>
                <div class="pr"><?= money($p['price']) ?></div>
                <small>⏱ <?= fmtDur((int)$p['duration_minutes']) ?><?= $p['time_mode'] === 'online' ? ' (online)' : '' ?></small>
                <small>📶 <?= (int)$p['data_limit_mb'] > 0 ? fmtBytes($p['data_limit_mb'] * 1048576) : t('p_unlimited') ?><?= (float)$p['speed_down_mbps'] > 0 ? ' • ' . (float)$p['speed_down_mbps'] . ' Mbps' : '' ?></small>
                <?php if ((int)$p['max_devices'] > 1): ?><small>📱 <?= (int)$p['max_devices'] ?> <?= t('p_devices') ?></small><?php endif; ?>
              </button>
            <?php endforeach; ?>
          </div>
          <div style="margin-top:16px">
            <label for="phone"><?= t('p_phone') ?></label>
            <input type="tel" id="phone" inputmode="numeric" maxlength="13" placeholder="07XXXXXXXX" autocomplete="tel" enterkeyhint="go">
          </div>
          <button type="button" class="btn ok" id="btnPay" onclick="buy()"><?= t('p_pay') ?></button>
        </div>

        <div id="waitBox" class="hide ctr">
          <div class="spin"></div>
          <div id="waitMsg"><?= t('p_waiting') ?></div>
          <div id="payInstr" class="msg info" style="margin-top:12px;text-align:left"></div>
          <div class="mut" style="font-size:.8rem" id="orderRef"></div>
          <button type="button" class="btn ghost" id="btnIPaid" onclick="iPaid()" style="margin-top:10px">✓ <?= t('p_ipaid') ?></button>
          <button type="button" class="btn ghost" onclick="resetBuy()"><?= t('p_back') ?></button>
        </div>

        <div id="paidBox" class="hide ctr">
          <div><?= t('p_paid_code') ?>:</div>
          <div class="vc" id="paidCode"></div>
          <div class="mut" id="paidStatus"><?= t('p_connecting') ?></div>
        </div>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <div class="foot">
    <?php if ($seller): ?><?= t('p_help') ?>: <a href="tel:<?= h($seller['phone']) ?>"><?= h($seller['phone']) ?></a> •<?php endif; ?>
    <?= t('p_powered_by') ?> <b><?= h(SITE_NAME) ?></b>
  </div>
</div>

<!--
  browserauth form → Omada Controller PORTAL port (e.g. https://169.58.93.38:8843).
  authType = 2 (External RADIUS). username / password = voucher code (PAP).
  NO chapId / NO chapChallenge.
-->
<form id="authForm" method="POST" action="" class="hide" accept-charset="UTF-8" target="_self">
  <?php
  $authFields = buildAuthFields('', $dev, $ctx);
  foreach ($authFields as $k => $v):
    if (in_array($k, ['authType','username','password'], true)) continue;
    ?>
    <input type="hidden" name="<?= h($k) ?>" value="<?= h($v) ?>">
  <?php endforeach; ?>
  <input type="hidden" name="authType" value="2">
  <input type="hidden" name="username" value="">
  <input type="hidden" name="password" value="">
</form>

<script>
(function(){
  'use strict';
  var CSRF   = <?= json_encode($csrf) ?>;
  var AUTH   = <?= json_encode($authUrl) ?>;
  var HASCTX = <?= $hasCtx ? 'true' : 'false' ?>;
  var BASE   = <?= json_encode(portalBaseUrl() . portalSelfPath()) ?>;
  var ORIGIN = <?= json_encode($origin) ?>;
  var L = {
    noCtrl:  <?= json_encode(t('p_no_controller')) ?>,
    noCtx:   <?= json_encode(t('p_no_ctx')) ?>,
    phone:   <?= json_encode(t('p_invalid_phone')) ?>,
    fail:    <?= json_encode(t('p_order_failed')) ?>,
    exp:     <?= json_encode(t('p_order_expired')) ?>,
    conn:    <?= json_encode(t('p_connecting')) ?>,
    connect: <?= json_encode(t('p_connect')) ?>,
    pick:    <?= json_encode(t('p_choose_pkg')) ?>,
    net:     <?= json_encode(t('p_network_error')) ?>,
    waiting: <?= json_encode(t('p_waiting')) ?>,
    processing: <?= json_encode(t('p_processing')) ?>,
    ipaid:   <?= json_encode(t('p_ipaid')) ?>,
    sessionActive: <?= json_encode(t('p_session_active')) ?>,
    sessionFailed: <?= json_encode(t('p_session_failed')) ?>,
    redirecting: <?= json_encode(t('p_redirecting')) ?>,
    autoConnect: <?= json_encode(t('p_auto_connect')) ?>,
    dataLbl: <?= json_encode(t('p_data')) ?>
  };

  var $ = function(id){ return document.getElementById(id); };
  var saved = null, pkgId = null, pollT = null, currentRef = null, autoConnectDone = false;
  try { saved = localStorage.getItem('sky_voucher'); } catch(e){}

  function msg(text, kind){
    var m = $('msg'); if(!m) return;
    m.className = 'msg ' + (kind || 'err');
    m.textContent = text || '';
    if (text) window.scrollTo({top:0, behavior:'smooth'});
  }
  function clearMsg(){ var m=$('msg'); if(m) m.className='msg'; }

  function api(action, data){
    var fd = new FormData();
    fd.append('csrf', CSRF);
    for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) fd.append(k, data[k]);
    return fetch(BASE + '?ajax=' + encodeURIComponent(action), {
      method: 'POST', body: fd, credentials: 'same-origin',
      headers: { 'X-Requested-With':'fetch', 'X-CSRF-Token':CSRF }
    }).then(function(r){
      return r.json().catch(function(){ throw new Error('HTTP ' + r.status); });
    }).then(function(d){
      if (d && d.reload) { setTimeout(function(){ location.reload(); }, 1500); }
      return d;
    });
  }
  function norm(code){ return String(code || '').toUpperCase().replace(/\s+/g, ''); }

  // ★ v6.5 — never post browserauth to this website itself.
  function validAuthUrl(a){
    if (!a || !/\/portal\/radius\/browserauth\/?$/i.test(a)) return false;
    try {
      var u = new URL(a, location.href);
      if (u.hostname.toLowerCase() === location.hostname.toLowerCase()) return false;
    } catch(e){
      if (a.toLowerCase().indexOf('//' + location.hostname.toLowerCase()) !== -1) return false;
    }
    return true;
  }

  // External RADIUS submit. authType is always 2. No CHAP fields.
  function submitAuthForm(code, authUrlOverride){
    var f = $('authForm');
    if (!f) return false;
    var a = authUrlOverride || AUTH;
    if (!validAuthUrl(a)) { console.error('Invalid browserauth URL:', a); return false; }
    f.action = a;
    f.authType.value = '2';
    f.username.value = code;
    f.password.value = code;
    f.submit();
    return true;
  }

  function activateSession(code, cb){
    api('activate', {code: code}).then(function(d){
      if (d && d.success) {
        try { localStorage.setItem('sky_voucher', code); } catch(e){}
        if (typeof cb === 'function') cb(true, d);
      } else {
        if (typeof cb === 'function') cb(false, d);
      }
    }).catch(function(){ if (typeof cb === 'function') cb(false, null); });
  }

  window.tab = function(which){
    if (!$('paneB')) return;
    $('paneV').classList.toggle('hide', which !== 'v');
    $('paneB').classList.toggle('hide', which !== 'b');
    $('tabV').classList.toggle('on', which === 'v');
    $('tabB').classList.toggle('on', which === 'b');
    clearMsg();
  };

  window.connect = function(code){
    code = norm(code);
    if (!code) return;
    clearMsg();
    if (!HASCTX) { msg(L.noCtx); return; }
    if (!validAuthUrl(AUTH)) { msg(L.noCtrl); return; }
    var b = $('btnV');
    var resetBtn = function(){ if (b) { b.disabled = false; b.textContent = L.connect; } };
    if (b) { b.disabled = true; b.textContent = L.conn; }

    api('prepare', {code: code}).then(function(d){
      if (!d || !d.success) {
        msg((d && d.message) || L.net);
        resetBtn();
        if (saved && code === saved && /expired|imekwisha|exhaust|limekwisha|blocked|imezuiwa|omada/i.test((d&&d.message)||'')) forget();
        return;
      }
      try { if (!$('remember') || $('remember').checked) localStorage.setItem('sky_voucher', code); } catch(e){}
      activateSession(code, function(ok){
        if (!ok) { msg(L.sessionFailed); resetBtn(); return; }
        if (!submitAuthForm(code, d.authUrl || AUTH)) { msg(L.noCtrl); resetBtn(); }
      });
    }).catch(function(){ msg(L.net); resetBtn(); });
  };

  window.forget = function(){
    try { localStorage.removeItem('sky_voucher'); } catch(e){}
    saved = null;
    if ($('resumeCard')) $('resumeCard').classList.add('hide');
  };

  window.pick = function(el){
    var list = document.querySelectorAll('.pkg');
    for (var i=0;i<list.length;i++) list[i].classList.remove('on');
    el.classList.add('on'); pkgId = el.dataset.id;
  };

  window.buy = function(){
    clearMsg();
    if (!pkgId) { msg(L.pick); return; }
    var p = ($('phone').value || '').replace(/\D/g, '');
    if (!/^(0|255)?[67]\d{8}$/.test(p)) { msg(L.phone); return; }
    $('btnPay').disabled = true;
    api('buy', {package_id: pkgId, phone: p}).then(function(d){
      $('btnPay').disabled = false;
      if (!d.success) { msg(d.message); return; }
      currentRef = d.ref;
      $('buyForm').classList.add('hide');
      $('waitBox').classList.remove('hide');
      $('orderRef').textContent = 'Ref: ' + d.ref;
      $('waitMsg').textContent = d.message || L.waiting;
      if (d.mode === 'manual') {
        $('payInstr').style.display = 'block';
        $('payInstr').textContent = (d.amount ? d.amount + ' → ' : '') + (d.instructions || '') + ' • Ref: ' + d.ref;
      } else { $('payInstr').style.display = 'none'; }
      poll(d.ref, 0);
    }).catch(function(err){ $('btnPay').disabled = false; console.error('Buy error:', err); msg(L.net); });
  };

  window.iPaid = function(){
    if (!currentRef) return;
    var b = $('btnIPaid');
    if (b) { b.disabled = true; b.textContent = '⏳ ' + L.processing; }
    api('ipaid', {ref: currentRef}).then(function(d){
      if (b) { b.disabled = false; b.textContent = '✓ ' + L.ipaid; }
      if (d.success && d.status === 'paid' && d.code) { handlePaymentSuccess(d.code, d.authUrl); return; }
      msg(d.message || L.waiting, 'info');
    }).catch(function(){ if (b) { b.disabled = false; b.textContent = '✓ ' + L.ipaid; } msg(L.net); });
  };

  function handlePaymentSuccess(code, authUrl){
    if (autoConnectDone) return;
    autoConnectDone = true;

    $('waitBox').classList.add('hide');
    $('paidBox').classList.remove('hide');
    $('paidCode').textContent = code;
    if ($('paidStatus')) $('paidStatus').textContent = L.autoConnect;
    try { localStorage.setItem('sky_voucher', code); } catch(e){}

    if (authUrl && validAuthUrl(authUrl)) AUTH = authUrl;

    activateSession(code, function(ok){
      if (!ok) {
        msg(L.sessionFailed, 'err');
        if ($('paidStatus')) $('paidStatus').textContent = L.sessionFailed;
        return;
      }
      if ($('paidStatus')) $('paidStatus').textContent = L.redirecting;
      setTimeout(function(){
        if (!submitAuthForm(code, AUTH)) {
          msg(L.noCtrl, 'err');
          if ($('paidStatus')) $('paidStatus').textContent = L.sessionFailed;
        }
      }, 1500);
    });
  }

  function poll(ref, n){
    clearTimeout(pollT);
    if (n > 200) return;
    if (autoConnectDone) return;
    pollT = setTimeout(function(){
      api('order', {ref: ref}).then(function(d){
        if (!d.success) { poll(ref, n + 1); return; }
        if (d.status === 'paid' && d.code) { handlePaymentSuccess(d.code, d.authUrl); return; }
        if (d.status === 'failed' || d.status === 'cancelled') { resetBuy(); msg(L.fail); return; }
        if (d.status === 'expired') { resetBuy(); msg(L.exp); return; }
        poll(ref, n + 1);
      }).catch(function(err){ console.warn('Poll error:', err); poll(ref, n + 1); });
    }, 3000);
  }

  window.resetBuy = function(){
    clearTimeout(pollT);
    autoConnectDone = false;
    $('buyForm').classList.remove('hide');
    $('waitBox').classList.add('hide');
    $('paidBox').classList.add('hide');
  };

  if ($('code')) $('code').addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); connect(this.value); } });
  if ($('phone')) $('phone').addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); buy(); } });

  function fillDone(code){
    api('check', {code: code}).then(function(d){
      if (d && d.success) {
        if ($('doneLeft')) $('doneLeft').textContent = d.remaining_text || '—';
        if ($('doneData')) $('doneData').textContent = L.dataLbl + ': ' + (d.data_left || '—');
      }
    }).catch(function(){});
  }

  if ($('doneCard')) {
    var params = new URLSearchParams(location.search);
    var dcode = norm(params.get('code') || params.get('voucher') || saved || '');
    if (dcode) fillDone(dcode);
  }

  if (saved && $('resumeCard')) {
    api('check', {code: saved}).then(function(d){
      if (d.success) {
        $('resumeCode').textContent = saved;
        $('resumeLeft').textContent = d.remaining_text;
        $('resumeCard').classList.remove('hide');
      } else { forget(); }
    }).catch(function(){});
  }

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function(){ navigator.serviceWorker.register(BASE + '?pwa=sw').catch(function(){}); });
  }
})();
</script>
</body>
</html>