<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Session Manager Page - Loaded from external file
 * 
 * Sellers can view all active WiFi sessions, adjust time when routers are offline,
 * disconnect/block devices, and view adjustment history
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE TIME ADJUSTMENT
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adjust_time'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    $minutes = intval($_POST['minutes'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    
    if ($sessionId && $minutes != 0) {
        $result = $sessionManager->adjustSessionTime($sessionId, $userId, $minutes, $reason);
        if ($result['success']) {
            $msg = '<div class="alert alert-success">
                <i class="fas fa-check-circle"></i> ' . $result['message'] . '
                <br><small>Old: ' . date('d M H:i', strtotime($result['old_expiry'])) . ' &rarr; New: ' . date('d M H:i', strtotime($result['new_expiry'])) . '</small>
            </div>';
        } else {
            $msg = '<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> ' . htmlspecialchars($result['message']) . '</div>';
        }
    } else {
        $msg = '<div class="alert alert-warning">Invalid adjustment parameters</div>';
    }
}

// ============================================
// HANDLE BULK ADJUSTMENT
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_adjust'])) {
    $sessionIds = isset($_POST['session_ids']) ? $_POST['session_ids'] : [];
    $minutes = intval($_POST['bulk_minutes'] ?? 0);
    $reason = trim($_POST['bulk_reason'] ?? 'Bulk adjustment');
    
    if (!empty($sessionIds) && $minutes != 0) {
        $result = $sessionManager->bulkAdjustSessions($sessionIds, $userId, $minutes, $reason);
        $msg = '<div class="alert alert-' . ($result['success_count'] > 0 ? 'success' : 'warning') . '">
            <i class="fas fa-check-circle"></i> Adjusted <strong>' . $result['success_count'] . '</strong> session(s) successfully.
            ' . ($result['fail_count'] > 0 ? $result['fail_count'] . ' failed.' : '') . '
        </div>';
    } else {
        $msg = '<div class="alert alert-warning">Please select at least one session</div>';
    }
}

// ============================================
// HANDLE DISCONNECT SESSION
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['disconnect_session'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    $reason = trim($_POST['disconnect_reason'] ?? 'Manual disconnect');
    if ($sessionId) {
        $result = $sessionManager->disconnectDevice($sessionId, $userId, $reason);
        $msg = $result['success'] 
            ? '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $result['message'] . '</div>'
            : '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
    }
}

// ============================================
// HANDLE BLOCK DEVICE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['block_session'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    $reason = trim($_POST['block_reason'] ?? '');
    if ($sessionId) {
        $result = $sessionManager->blockDevice($sessionId, $userId, $reason);
        $msg = $result['success'] 
            ? '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $result['message'] . '</div>'
            : '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
    }
}

// ============================================
// HANDLE UNBLOCK DEVICE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unblock_session'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    if ($sessionId) {
        $result = $sessionManager->unblockDevice($sessionId, $userId);
        $msg = $result['success'] 
            ? '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $result['message'] . '</div>'
            : '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
    }
}

// ============================================
// HANDLE EXPIRE SESSION
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['expire_session'])) {
    $sessionId = intval($_POST['session_id'] ?? 0);
    if ($sessionId) {
        $stmt = $conn->prepare("
            UPDATE wifi_sessions ws
            JOIN routers r ON ws.router_id = r.id
            SET ws.status = 'expired', ws.session_end = NOW(), ws.disconnect_reason = 'Manually expired'
            WHERE ws.id = ? AND r.user_id = ?
        ");
        $stmt->bind_param("ii", $sessionId, $userId);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $msg = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Session expired successfully</div>';
        } else {
            $msg = '<div class="alert alert-danger">Failed to expire session</div>';
        }
    }
}

// ============================================
// FETCH FILTERS
// ============================================
$filter = $_GET['filter'] ?? 'all';
$routerFilter = intval($_GET['router'] ?? 0);
$searchTerm = trim($_GET['search'] ?? '');

// ============================================
// FETCH SESSIONS
// ============================================
if ($filter === 'offline') {
    $sessions = $sessionManager->getAdjustableSessions($userId);
} else {
    $sessions = $sessionManager->getActiveSessions($userId, $routerFilter ?: null);
}

// Apply search filter
if ($searchTerm) {
    $sessions = array_filter($sessions, function($s) use ($searchTerm) {
        $searchLower = strtolower($searchTerm);
        return 
            stripos($s['mac_address'] ?? '', $searchTerm) !== false ||
            stripos($s['device_name'] ?? '', $searchTerm) !== false ||
            stripos($s['voucher_code'] ?? '', $searchTerm) !== false ||
            stripos($s['user_name'] ?? '', $searchTerm) !== false ||
            stripos($s['user_phone'] ?? '', $searchTerm) !== false;
    });
    $sessions = array_values($sessions);
}

// ============================================
// FETCH STATS
// ============================================
$stats = $sessionManager->getSessionStats($userId);

// ============================================
// FETCH ROUTERS FOR FILTER
// ============================================
$routers = $router->getRouters($userId);

// Get adjustment history (last 10)
$recentAdjustments = $sessionManager->getAdjustmentHistory($userId, 10);

?>

<!-- ============================================ -->
<!-- SESSION MANAGER HEADER                      -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-clock"></i> <?php echo t('session_manager'); ?></h2>
        <small class="text-muted">Monitor active WiFi sessions and adjust time when routers are offline</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a href="?page=sessions&filter=offline" class="btn btn-sm <?php echo $filter === 'offline' ? 'btn-warning' : 'btn-outline-warning'; ?>">
            <i class="fas fa-exclamation-triangle"></i> <?php echo t('offline'); ?>
            <?php if ($stats['offline_router_sessions'] > 0): ?>
            <span class="badge bg-dark text-white ms-1"><?php echo $stats['offline_router_sessions']; ?></span>
            <?php endif; ?>
        </a>
        <a href="?page=sessions&filter=all" class="btn btn-sm <?php echo $filter === 'all' ? 'btn-primary' : 'btn-outline-primary'; ?>">
            <i class="fas fa-list"></i> <?php echo t('all_sessions'); ?>
        </a>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- SESSION STATS GRID                          -->
<!-- ============================================ -->
<div class="session-stats-grid mb-4">
    <div class="session-stat-card">
        <div class="value text-primary"><?php echo number_format($stats['active_sessions']); ?></div>
        <div class="label"><?php echo t('active_sessions'); ?></div>
    </div>
    <div class="session-stat-card">
        <div class="value text-warning"><?php echo number_format($stats['offline_router_sessions']); ?></div>
        <div class="label"><?php echo t('offline'); ?> <?php echo t('sessions'); ?></div>
    </div>
    <div class="session-stat-card">
        <div class="value text-info"><?php echo number_format($stats['today_sessions']); ?></div>
        <div class="label"><?php echo t('today'); ?> <?php echo t('sessions'); ?></div>
    </div>
    <div class="session-stat-card">
        <div class="value text-success"><?php echo number_format($stats['total_adjustments']); ?></div>
        <div class="label"><?php echo t('adjust_time'); ?> Total</div>
    </div>
</div>

<!-- ============================================ -->
<!-- OFFLINE ROUTER ALERT                        -->
<!-- ============================================ -->
<?php if ($filter === 'offline' && count($sessions) > 0): ?>
<div class="alert alert-warning mb-4">
    <h5 class="alert-heading"><i class="fas fa-exclamation-triangle"></i> <?php echo t('offline_router_notice'); ?></h5>
    <p class="mb-2">These sessions are on routers that are currently offline. You can manually adjust their time to compensate for the outage.</p>
    <small class="text-muted">Tip: When you extend time, the customer's session will be automatically updated when the router comes back online.</small>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- FILTERS                                     -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-end">
            <input type="hidden" name="page" value="sessions">
            <input type="hidden" name="filter" value="<?php echo htmlspecialchars($filter); ?>">
            
            <div class="col-md-4 col-6">
                <label class="form-label small mb-1"><i class="fas fa-search"></i> <?php echo t('search'); ?></label>
                <input type="text" name="search" class="form-control form-control-sm" 
                       placeholder="MAC, name, voucher, phone..." value="<?php echo htmlspecialchars($searchTerm); ?>">
            </div>
            
            <div class="col-md-4 col-6">
                <label class="form-label small mb-1"><i class="fas fa-wifi"></i> <?php echo t('router'); ?></label>
                <select name="router" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="0"><?php echo t('all_routers'); ?></option>
                    <?php foreach ($routers as $r): ?>
                    <option value="<?php echo $r['id']; ?>" <?php echo $routerFilter == $r['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($r['device_name']); ?>
                        <?php if ($r['status'] !== 'online'): ?>
                        <span>(<?php echo $r['status']; ?>)</span>
                        <?php endif; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-4 col-12 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">
                    <i class="fas fa-filter"></i> <?php echo t('filter'); ?>
                </button>
                <a href="?page=sessions" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-times"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<!-- ============================================ -->
<!-- ACTIVE SESSIONS LIST                        -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="mb-0">
            <i class="fas fa-list"></i> 
            <?php echo $filter === 'offline' ? 'Offline Router Sessions' : t('active_sessions'); ?>
            <small class="text-muted ms-2">(<?php echo count($sessions); ?>)</small>
        </h5>
        <?php if (count($sessions) > 0): ?>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="selectAllSessions" onchange="toggleAllSessions(this)">
            <label class="form-check-label small" for="selectAllSessions"><?php echo t('select_all'); ?></label>
        </div>
        <?php endif; ?>
    </div>
    <div class="card-body p-0">
        <?php if (count($sessions) > 0): ?>
            <form method="POST" id="bulkAdjustForm">
                <?php foreach ($sessions as $session): 
                    $minutesRemaining = intval($session['minutes_remaining'] ?? 0);
                    $isExpired = $minutesRemaining <= 0;
                    $isCritical = $minutesRemaining > 0 && $minutesRemaining <= 5;
                    $isWarning = $minutesRemaining > 5 && $minutesRemaining <= 15;
                    $routerOffline = (($session['router_status'] ?? 'online') !== 'online');
                    $timeClass = $isExpired ? 'critical' : ($isCritical ? 'critical' : ($isWarning ? 'warning' : 'good'));
                    
                    $durationPercent = 0;
                    if (!empty($session['package_duration']) && $session['package_duration'] > 0) {
                        $durationPercent = min(100, max(0, ($minutesRemaining / $session['package_duration']) * 100));
                    }
                ?>
                <div class="session-card <?php echo $routerOffline ? 'offline-router' : ''; ?>" data-router-id="<?php echo $session['router_id']; ?>">
                    <!-- Session Header -->
                    <div class="session-header">
                        <div class="d-flex align-items-start gap-2 flex-grow-1" style="min-width:0;">
                            <input type="checkbox" name="session_ids[]" value="<?php echo $session['id']; ?>" 
                                   class="session-checkbox mt-1 session-select" onchange="updateBulkBar()">
                            <div style="min-width:0;">
                                <div class="fw-semibold d-flex align-items-center gap-2 flex-wrap">
                                    <i class="fas fa-laptop text-primary"></i>
                                    <?php echo htmlspecialchars($session['device_name'] ?? 'Unknown Device'); ?>
                                    
                                    <?php if ($routerOffline): ?>
                                    <span class="offline-badge">
                                        <i class="fas fa-wifi-slash"></i> <?php echo t('offline'); ?> Router
                                    </span>
                                    <?php else: ?>
                                    <span class="online-badge">
                                        <i class="fas fa-wifi"></i> <?php echo t('online'); ?>
                                    </span>
                                    <?php endif; ?>
                                    
                                    <?php if (($session['is_manually_adjusted'] ?? 0) > 0): ?>
                                    <span class="badge bg-warning text-dark" style="font-size:0.65rem;">
                                        <i class="fas fa-edit"></i> Adjusted <?php echo $session['adjustment_count']; ?>x
                                    </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="text-muted small mt-1">
                                    <i class="fas fa-network-wired"></i> 
                                    <code><?php echo htmlspecialchars($session['mac_address']); ?></code>
                                    <?php if (!empty($session['ip_address'])): ?>
                                    &middot; IP: <?php echo htmlspecialchars($session['ip_address']); ?>
                                    <?php endif; ?>
                                    <?php if (!empty($session['voucher_code'])): ?>
                                    &middot; <i class="fas fa-ticket-alt"></i> <code><?php echo htmlspecialchars($session['voucher_code']); ?></code>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Time Remaining -->
                        <div class="text-end flex-shrink-0">
                            <div class="time-remaining <?php echo $timeClass; ?>">
                                <?php if ($isExpired): ?>
                                    <i class="fas fa-hourglass-end"></i> <?php echo t('expired'); ?>
                                <?php else: ?>
                                    <i class="fas fa-hourglass-half"></i> <?php echo $minutesRemaining; ?>m
                                <?php endif; ?>
                            </div>
                            <small class="text-muted"><?php echo t('time_remaining'); ?></small>
                        </div>
                    </div>
                    
                    <!-- Progress Bar -->
                    <?php if (!empty($session['package_duration']) && $session['package_duration'] > 0): ?>
                    <div class="progress mt-2 mb-2" style="height:4px;">
                        <div class="progress-bar bg-<?php echo $isExpired ? 'danger' : ($isCritical ? 'danger' : ($isWarning ? 'warning' : 'success')); ?>" 
                             style="width: <?php echo $durationPercent; ?>%"></div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Session Info Grid -->
                    <div class="session-info mt-2">
                        <div class="info-item">
                            <i class="fas fa-user"></i>
                            <?php echo htmlspecialchars($session['user_name'] ?? 'Guest'); ?>
                        </div>
                        <?php if (!empty($session['user_phone'])): ?>
                        <div class="info-item">
                            <i class="fas fa-phone"></i>
                            <?php echo htmlspecialchars($session['user_phone']); ?>
                        </div>
                        <?php endif; ?>
                        <div class="info-item">
                            <i class="fas fa-wifi"></i>
                            <?php echo htmlspecialchars($session['router_name'] ?? 'Unknown'); ?>
                            <?php if (!empty($session['router_status'])): ?>
                            <span class="badge bg-<?php echo $session['router_status'] === 'online' ? 'success' : 'danger'; ?>" style="font-size:0.6rem;">
                                <?php echo $session['router_status']; ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($session['package_name'])): ?>
                        <div class="info-item">
                            <i class="fas fa-box"></i>
                            <?php echo htmlspecialchars($session['package_name']); ?>
                        </div>
                        <?php endif; ?>
                        <div class="info-item">
                            <i class="fas fa-play text-success"></i>
                            <?php echo date('d M H:i', strtotime($session['session_start'])); ?>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-stop text-danger"></i>
                            <?php echo date('d M H:i', strtotime($session['session_end'])); ?>
                        </div>
                    </div>
                    
                    <!-- Quick Time Adjustment -->
                    <div class="adjustment-form mt-3">
                        <div class="d-flex flex-wrap gap-2 align-items-center">
                            <span class="small text-muted me-1">
                                <i class="fas fa-clock"></i> <?php echo t('adjust_time'); ?>:
                            </span>
                            
                            <!-- Quick Add -->
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <input type="hidden" name="minutes" value="15">
                                <input type="hidden" name="reason" value="Quick extend +15m">
                                <button type="submit" name="adjust_time" class="btn btn-sm btn-outline-success time-adjust-btn" 
                                        onclick="return confirm('Extend this session by 15 minutes?');">
                                    +15m
                                </button>
                            </form>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <input type="hidden" name="minutes" value="30">
                                <input type="hidden" name="reason" value="Quick extend +30m">
                                <button type="submit" name="adjust_time" class="btn btn-sm btn-outline-success time-adjust-btn" 
                                        onclick="return confirm('Extend this session by 30 minutes?');">
                                    +30m
                                </button>
                            </form>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <input type="hidden" name="minutes" value="60">
                                <input type="hidden" name="reason" value="Quick extend +1hr">
                                <button type="submit" name="adjust_time" class="btn btn-sm btn-outline-success time-adjust-btn" 
                                        onclick="return confirm('Extend this session by 1 hour?');">
                                    +1h
                                </button>
                            </form>
                            
                            <!-- Quick Reduce -->
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <input type="hidden" name="minutes" value="-15">
                                <input type="hidden" name="reason" value="Quick reduce -15m">
                                <button type="submit" name="adjust_time" class="btn btn-sm btn-outline-danger time-adjust-btn" 
                                        onclick="return confirm('Reduce this session by 15 minutes?');">
                                    -15m
                                </button>
                            </form>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <input type="hidden" name="minutes" value="-30">
                                <input type="hidden" name="reason" value="Quick reduce -30m">
                                <button type="submit" name="adjust_time" class="btn btn-sm btn-outline-danger time-adjust-btn" 
                                        onclick="return confirm('Reduce this session by 30 minutes?');">
                                    -30m
                                </button>
                            </form>
                            
                            <!-- Custom Adjust -->
                            <button type="button" class="btn btn-sm btn-outline-info time-adjust-btn" 
                                    data-bs-toggle="modal" data-bs-target="#customAdjustModal<?php echo $session['id']; ?>">
                                <i class="fas fa-edit"></i> Custom
                            </button>
                            
                            <!-- Action Menu -->
                            <div class="dropdown ms-auto">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <button class="dropdown-item" type="button" 
                                                data-bs-toggle="modal" data-bs-target="#viewDetailsModal<?php echo $session['id']; ?>">
                                            <i class="fas fa-info-circle"></i> View Details
                                        </button>
                                    </li>
                                    <li>
                                        <button class="dropdown-item text-warning" type="button"
                                                data-bs-toggle="modal" data-bs-target="#disconnectModal<?php echo $session['id']; ?>">
                                            <i class="fas fa-plug"></i> <?php echo t('disconnect_device'); ?>
                                        </button>
                                    </li>
                                    <li>
                                        <button class="dropdown-item text-danger" type="button"
                                                data-bs-toggle="modal" data-bs-target="#blockModal<?php echo $session['id']; ?>">
                                            <i class="fas fa-ban"></i> <?php echo t('block_device'); ?>
                                        </button>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                            <button type="submit" name="expire_session" class="dropdown-item text-danger"
                                                    onclick="return confirm('Expire this session immediately?');">
                                                <i class="fas fa-hourglass-end"></i> Expire Now
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- ============================================ -->
                <!-- CUSTOM ADJUST MODAL                          -->
                <!-- ============================================ -->
                <div class="modal fade" id="customAdjustModal<?php echo $session['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="fas fa-clock"></i> <?php echo t('manual_time_adjustment'); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="alert alert-info">
                                        <strong><?php echo htmlspecialchars($session['device_name'] ?? 'Device'); ?></strong><br>
                                        <small>MAC: <code><?php echo htmlspecialchars($session['mac_address']); ?></code></small><br>
                                        <small>Current expiry: <strong><?php echo date('d M Y H:i', strtotime($session['session_end'])); ?></strong></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('adjustment_amount'); ?> (<?php echo t('minutes'); ?>)</label>
                                        <input type="number" name="minutes" class="form-control" value="15" required>
                                        <small class="text-muted">Positive = extend, Negative = reduce</small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('adjustment_reason'); ?></label>
                                        <textarea name="reason" class="form-control" rows="2" 
                                                  placeholder="e.g., Router was offline for 30 minutes"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                    <button type="submit" name="adjust_time" class="btn btn-primary">
                                        <i class="fas fa-save"></i> <?php echo t('adjust_time'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- ============================================ -->
                <!-- VIEW DETAILS MODAL                           -->
                <!-- ============================================ -->
                <div class="modal fade" id="viewDetailsModal<?php echo $session['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title"><i class="fas fa-info-circle"></i> Session Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="stat-row">
                                    <span>Session ID:</span>
                                    <strong>#<?php echo $session['id']; ?></strong>
                                </div>
                                <div class="stat-row">
                                    <span>Device:</span>
                                    <strong><?php echo htmlspecialchars($session['device_name'] ?? 'Unknown'); ?></strong>
                                </div>
                                <div class="stat-row">
                                    <span>MAC Address:</span>
                                    <code><?php echo htmlspecialchars($session['mac_address']); ?></code>
                                </div>
                                <div class="stat-row">
                                    <span>IP Address:</span>
                                    <code><?php echo htmlspecialchars($session['ip_address'] ?? '-'); ?></code>
                                </div>
                                <div class="stat-row">
                                    <span>User:</span>
                                    <strong><?php echo htmlspecialchars($session['user_name'] ?? 'Guest'); ?></strong>
                                </div>
                                <?php if (!empty($session['user_phone'])): ?>
                                <div class="stat-row">
                                    <span>Phone:</span>
                                    <strong><?php echo htmlspecialchars($session['user_phone']); ?></strong>
                                </div>
                                <?php endif; ?>
                                <div class="stat-row">
                                    <span>Router:</span>
                                    <strong><?php echo htmlspecialchars($session['router_name'] ?? '-'); ?></strong>
                                </div>
                                <div class="stat-row">
                                    <span>Package:</span>
                                    <strong><?php echo htmlspecialchars($session['package_name'] ?? '-'); ?></strong>
                                </div>
                                <?php if (!empty($session['voucher_code'])): ?>
                                <div class="stat-row">
                                    <span>Voucher:</span>
                                    <code><?php echo htmlspecialchars($session['voucher_code']); ?></code>
                                </div>
                                <?php endif; ?>
                                <div class="stat-row">
                                    <span>Started:</span>
                                    <span><?php echo date('d M Y H:i', strtotime($session['session_start'])); ?></span>
                                </div>
                                <div class="stat-row">
                                    <span>Expires:</span>
                                    <span><?php echo date('d M Y H:i', strtotime($session['session_end'])); ?></span>
                                </div>
                                <div class="stat-row">
                                    <span>Time Remaining:</span>
                                    <span class="<?php echo $timeClass; ?>">
                                        <?php echo $minutesRemaining > 0 ? $minutesRemaining . ' minutes' : 'Expired'; ?>
                                    </span>
                                </div>
                                <?php if (($session['is_manually_adjusted'] ?? 0) > 0): ?>
                                <div class="stat-row">
                                    <span>Manual Adjustments:</span>
                                    <span class="badge bg-warning text-dark"><?php echo $session['adjustment_count']; ?>x</span>
                                </div>
                                <?php endif; ?>
                                <div class="stat-row">
                                    <span>Status:</span>
                                    <span class="badge bg-success"><?php echo $session['status']; ?></span>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- ============================================ -->
                <!-- DISCONNECT MODAL                             -->
                <!-- ============================================ -->
                <div class="modal fade" id="disconnectModal<?php echo $session['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="fas fa-plug text-warning"></i> <?php echo t('disconnect_device'); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to disconnect <strong><?php echo htmlspecialchars($session['device_name'] ?? 'this device'); ?></strong>?</p>
                                    <p class="text-muted small">The session will end immediately and the device will need a new voucher to reconnect.</p>
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('reason'); ?> (<?php echo t('optional'); ?>)</label>
                                        <input type="text" name="disconnect_reason" class="form-control" 
                                               placeholder="e.g., Maintenance" value="Manual disconnect">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                    <button type="submit" name="disconnect_session" class="btn btn-warning">
                                        <i class="fas fa-plug"></i> <?php echo t('disconnect_device'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- ============================================ -->
                <!-- BLOCK MODAL                                  -->
                <!-- ============================================ -->
                <div class="modal fade" id="blockModal<?php echo $session['id']; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="fas fa-ban text-danger"></i> <?php echo t('block_device'); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="alert alert-danger">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        <strong>Warning:</strong> Blocking this device will prevent it from reconnecting until manually unblocked.
                                    </div>
                                    <p>Block <strong><?php echo htmlspecialchars($session['mac_address']); ?></strong>?</p>
                                    <div class="mb-3">
                                        <label class="form-label"><?php echo t('reason'); ?></label>
                                        <textarea name="block_reason" class="form-control" rows="2" 
                                                  placeholder="e.g., Terms violation"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                                    <button type="submit" name="block_session" class="btn btn-danger">
                                        <i class="fas fa-ban"></i> <?php echo t('block_device'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <?php endforeach; ?>
                
                <!-- ============================================ -->
                <!-- BULK ACTIONS BAR                             -->
                <!-- ============================================ -->
                <div class="bulk-actions-bar" id="bulkActionsBar" style="display:none;">
                    <div>
                        <span id="selectedCount">0</span> session(s) selected
                    </div>
                    <div class="d-flex gap-2 flex-wrap">
                        <span class="small text-muted align-self-center me-2">Bulk adjust:</span>
                        <button type="button" class="btn btn-sm btn-outline-success" onclick="setBulkMinutes(15)">+15m</button>
                        <button type="button" class="btn btn-sm btn-outline-success" onclick="setBulkMinutes(30)">+30m</button>
                        <button type="button" class="btn btn-sm btn-outline-success" onclick="setBulkMinutes(60)">+1h</button>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="setBulkMinutes(-15)">-15m</button>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="setBulkMinutes(-30)">-30m</button>
                        <button type="submit" name="bulk_adjust" class="btn btn-sm btn-primary" onclick="return confirmBulkAdjust();">
                            <i class="fas fa-check"></i> <?php echo t('apply_to_selected'); ?>
                        </button>
                    </div>
                </div>
                <input type="hidden" name="bulk_minutes" id="bulkMinutes" value="15">
                <input type="hidden" name="bulk_reason" id="bulkReason" value="Bulk adjustment">
            </form>
        <?php else: ?>
            <div class="empty-state py-5">
                <i class="fas fa-clock"></i>
                <h5><?php echo t('no_data'); ?></h5>
                <p>
                    <?php if ($filter === 'offline'): ?>
                        No sessions on offline routers. All routers are online!
                    <?php elseif ($searchTerm || $routerFilter): ?>
                        No sessions match your filters. <a href="?page=sessions">Clear filters</a>
                    <?php else: ?>
                        No active WiFi sessions at the moment.
                    <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================ -->
<!-- RECENT ADJUSTMENTS HISTORY                  -->
<!-- ============================================ -->
<?php if (count($recentAdjustments) > 0): ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="fas fa-history text-info"></i> <?php echo t('time_adjustment_log'); ?></h5>
        <a href="?page=adjustments" class="btn btn-sm btn-outline-primary">
            <?php echo t('view_all'); ?> <i class="fas fa-arrow-right"></i>
        </a>
    </div>
    <div class="card-body">
        <?php foreach ($recentAdjustments as $adj): ?>
        <div class="adjustment-history-item">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="fw-semibold">
                        <?php echo htmlspecialchars($adj['device_name'] ?? 'Unknown Device'); ?>
                        <code class="ms-2"><?php echo htmlspecialchars($adj['mac_address']); ?></code>
                    </div>
                    <div class="text-muted small mt-1">
                        <i class="fas fa-wifi"></i> <?php echo htmlspecialchars($adj['router_name']); ?>
                        <?php if (!empty($adj['voucher_code'])): ?>
                        &middot; <i class="fas fa-ticket-alt"></i> <?php echo htmlspecialchars($adj['voucher_code']); ?>
                        <?php endif; ?>
                        <?php if (!empty($adj['router_was_offline'])): ?>
                        &middot; <span class="text-warning"><i class="fas fa-exclamation-triangle"></i> Router was offline</span>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($adj['reason'])): ?>
                    <div class="text-muted small mt-1">
                        <i class="fas fa-comment"></i> <?php echo htmlspecialchars($adj['reason']); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="text-end">
                    <div class="<?php echo $adj['adjustment_minutes'] >= 0 ? 'adjustment-positive' : 'adjustment-negative'; ?>">
                        <?php echo $adj['adjustment_minutes'] >= 0 ? '+' : ''; ?><?php echo $adj['adjustment_minutes']; ?> <?php echo t('minutes'); ?>
                    </div>
                    <div class="text-muted small">
                        <?php echo date('d M H:i', strtotime($adj['created_at'])); ?>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-1 small text-muted">
                <span><i class="fas fa-arrow-right"></i> <?php echo date('H:i', strtotime($adj['old_expiry'])); ?> &rarr; <?php echo date('H:i', strtotime($adj['new_expiry'])); ?></span>
                <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($adj['adjusted_by_name'] ?? 'System'); ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- AUTO-REFRESH SCRIPT                         -->
<!-- ============================================ -->
<script>
// Auto-refresh every 60 seconds (only if not in a form)
(function() {
    let refreshTimer = setInterval(function() {
        // Don't refresh if user is in a modal or focused on an input
        if (document.querySelector('.modal.show')) return;
        if (document.activeElement && 
            (document.activeElement.tagName === 'INPUT' || 
             document.activeElement.tagName === 'TEXTAREA' || 
             document.activeElement.tagName === 'SELECT')) return;
        
        // Only auto-refresh the "all" filter view
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('filter') === 'offline') return;
        if (urlParams.get('search')) return;
        
        // Silent refresh
        fetch(window.location.href, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(res => res.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newContent = doc.querySelector('.card-body.p-0');
                const oldContent = document.querySelector('.card-body.p-0');
                if (newContent && oldContent) {
                    // Only update if content changed (avoid cursor jump)
                    const newHTML = newContent.innerHTML;
                    if (oldContent.innerHTML.length !== newHTML.length) {
                        // Skip refresh to avoid disrupting user
                    }
                }
            })
            .catch(() => {});
    }, 60000);
})();

// Toggle all sessions checkboxes
function toggleAllSessions(checkbox) {
    document.querySelectorAll('.session-select').forEach(cb => cb.checked = checkbox.checked);
    updateBulkBar();
}

// Update bulk actions bar visibility
function updateBulkBar() {
    const checked = document.querySelectorAll('.session-select:checked');
    const bar = document.getElementById('bulkActionsBar');
    const count = document.getElementById('selectedCount');
    if (bar) bar.style.display = checked.length > 0 ? 'flex' : 'none';
    if (count) count.textContent = checked.length;
}

// Set bulk minutes value
function setBulkMinutes(minutes) {
    document.getElementById('bulkMinutes').value = minutes;
    const action = minutes >= 0 ? 'extend' : 'reduce';
    document.getElementById('bulkReason').value = 'Bulk ' + action + ' ' + Math.abs(minutes) + ' minutes';
}

// Confirm bulk adjust
function confirmBulkAdjust() {
    const checked = document.querySelectorAll('.session-select:checked');
    const minutes = parseInt(document.getElementById('bulkMinutes').value);
    if (checked.length === 0) {
        alert('Please select at least one session');
        return false;
    }
    const action = minutes >= 0 ? 'extend' : 'reduce';
    return confirm(action.charAt(0).toUpperCase() + action.slice(1) + ' ' + checked.length + ' session(s) by ' + Math.abs(minutes) + ' minutes?');
}
</script>