#!/bin/sh
# Polls the web app for queued kicks (expired time, data cap, seller "Disconnect"/"Block")
# and sends RFC 5176 Disconnect-Request to the Omada controller / NAS.
# If your controller does not support RADIUS disconnect messages, sessions still end at Session-Timeout.
[ "${DAE_ENABLED:-1}" = "1" ] || { echo "[dae] disabled"; exit 0; }
API="$SKY_SITE_URL/index.php"; KEY="$SKY_RADIUS_API_KEY"
PORT="${DAE_PORT:-3799}"; INTERVAL="${DAE_INTERVAL:-15}"; SECRET="${DAE_SECRET:-$RADIUS_SECRET}"
TAB="$(printf '\t')"
echo "[dae] worker started (every ${INTERVAL}s, port ${PORT})"
while true; do
  curl -fsS --max-time 15 "$API?radius=dae_queue&key=$KEY" 2>/dev/null > /tmp/dae.tsv || : > /tmp/dae.tsv
  while IFS="$TAB" read -r id user mac sess nas fip; do
    [ -z "$id" ] && continue
    [ "$user" = "-" ] && user=""; [ "$mac" = "-" ] && mac=""; [ "$sess" = "-" ] && sess=""
    [ "$nas" = "-" ] && nas=""; [ "$fip" = "-" ] && fip=""
    target="${DAE_TARGET:-$nas}"
    if [ -z "$target" ]; then ok=0; res="no NAS IP"; else
      attrs="User-Name = \"$user\""
      [ -n "$sess" ] && attrs="$attrs, Acct-Session-Id = \"$sess\""
      [ -n "$mac" ]  && attrs="$attrs, Calling-Station-Id = \"$mac\""
      [ -n "$fip" ]  && attrs="$attrs, Framed-IP-Address = $fip"
      out=$(echo "$attrs" | radclient -r 2 -t 3 "$target:$PORT" disconnect "$SECRET" 2>&1)
      if echo "$out" | grep -q "Disconnect-ACK"; then ok=1; else ok=0; fi
      res=$(echo "$out" | tail -n 1 | tr -c 'A-Za-z0-9 ._:-' ' ' | cut -c1-120)
    fi
    echo "[dae] job $id $user $mac -> $target ok=$ok"
    curl -fsS --max-time 10 -G "$API" --data-urlencode "radius=dae_ack" --data-urlencode "key=$KEY" \
      --data-urlencode "id=$id" --data-urlencode "ok=$ok" --data-urlencode "result=$res" >/dev/null 2>&1 || true
  done < /tmp/dae.tsv
  sleep "$INTERVAL"
done
