<?php
/**
 * browserauth.php — SkyTanza WiFi captive-portal login hand-off  (v3)
 * Shared hosting compatible (cPanel / DirectAdmin / Plesk).
 *
 * Reached at BOTH of these URLs (see .htaccess companion files):
 *   https://wifi.skytanzania.co.tz/portal/radius/browserauth
 *   https://wifi.skytanzania.co.tz/portal/radius/browserauth.php
 *
 * v3 — fixes {"error":"authorization_failed"} (Omada answered 404 on
 *      /openapi/v1/.../hotspot/portal/clients/{mac}/authorize):
 *   - That Open API path does not exist. For an SSID whose portal uses
 *     "External RADIUS Server", TP-Link's documented flow is: the phone's browser
 *     POSTs the login form to the controller's  /portal/radius/browserauth
 *     (portal port 8843) with authType=2. The controller then checks the voucher
 *     with your RADIUS server and lets the phone online.
 *   - This script now receives your portal form, builds that exact request, and
 *     sends the phone straight to the controller through
 *     https://omada.skytanzania.co.tz/portal/... (nginx → 8843, valid certificate,
 *     no SSL warning on phones). No Open API token is needed for logins.
 *   - Accepts the voucher as username/password, or as voucher / code / pin.
 *   - ?diag=DIAG_KEY checks that the controller's login endpoint is reachable.
 *
 * Requires PHP 7.4+ (curl only needed for ?diag).
 */

declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set('log_errors', '1');
ini_set('error_log', __DIR__.'/browserauth.log');   // shared hosting: log next to the file

// ============================================================================
// EDIT THESE VALUES
// ============================================================================

// Controller login endpoint, through the nginx proxy on the VPS (omada-proxy.conf → port 8843)
const OMADA_PORTAL_AUTH_URL = 'https://omada.skytanzania.co.tz/portal/radius/browserauth';

// 2 = portal Authentication Type "External RADIUS Server"
// 8 = portal Authentication Type "Hotspot" with RADIUS
const OMADA_PORTAL_AUTH_TYPE = 2;

// Voucher-only login (one code box): send the code as both username and password.
// Set false if your RADIUS users have a separate password field.
const VOUCHER_AS_PASSWORD = true;

// Where phones go after a successful login when Omada sends no originUrl
const DEFAULT_REDIRECT = 'https://wifi.skytanzania.co.tz/portal/thanks';

// Diagnostics: open https://wifi.skytanzania.co.tz/portal/radius/browserauth?diag=<this key>
const DIAG_KEY = 'sky-SKY9919-7Q2xR9';

const SITE_TITLE = 'SkyTanza WiFi';
// ============================================================================


// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------
function ba_log(string $m): void { error_log('[browserauth] '.$m); }

function ba_json(int $code, array $body): void {
    http_response_code($code);
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function ba_e(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

/** First non-empty value among several possible parameter names. */
function ba_param(array $p, array $names): string {
    foreach ($names as $n) {
        if (isset($p[$n]) && is_scalar($p[$n])) {
            $v = trim((string)$p[$n]);
            if ($v !== '') return $v;
        }
    }
    return '';
}

/** Small mobile-friendly page (light/dark). $inner is trusted HTML. */
function ba_page(int $code, string $heading, string $inner, string $extraHead = ''): void {
    http_response_code($code);
    header('Content-Type: text/html; charset=UTF-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    $t = ba_e(SITE_TITLE);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<meta name="referrer" content="no-referrer">'
       . "<title>$t</title>$extraHead<style>"
       . ':root{--bg:#f4f6fb;--card:#fff;--fg:#14213d;--mut:#5b6478;--acc:#0b6bcb;--err:#c62828}'
       . '@media (prefers-color-scheme:dark){:root{--bg:#0f1420;--card:#182033;--fg:#e8ecf5;--mut:#9aa5bd;--acc:#4ea1ff;--err:#ff6b6b}}'
       . '*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;'
       . 'background:var(--bg);color:var(--fg);font:17px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:16px}'
       . '.card{background:var(--card);border-radius:16px;padding:28px 22px;max-width:380px;width:100%;text-align:center;'
       . 'box-shadow:0 8px 30px rgba(0,0,0,.12)}h1{font-size:1.25rem;margin:0 0 8px}p{color:var(--mut);margin:6px 0 18px}'
       . '.spin{width:42px;height:42px;margin:6px auto 16px;border:4px solid var(--mut);border-top-color:var(--acc);'
       . 'border-radius:50%;animation:s 0.9s linear infinite}@keyframes s{to{transform:rotate(360deg)}}'
       . 'button,a.btn{display:inline-block;background:var(--acc);color:#fff;border:0;border-radius:10px;padding:12px 22px;'
       . 'font:inherit;font-weight:600;text-decoration:none;cursor:pointer}.err{color:var(--err)}'
       . '</style></head><body><main class="card"><h1>'.ba_e($heading).'</h1>'.$inner.'</main></body></html>';
    exit;
}


// ---------------------------------------------------------------------------
// Diagnostics: ?diag=DIAG_KEY
// ---------------------------------------------------------------------------
function ba_diag(): void {
    $out = [
        'php'           => PHP_VERSION,
        'curl'          => extension_loaded('curl'),
        'auth_url'      => OMADA_PORTAL_AUTH_URL,
        'auth_type'     => OMADA_PORTAL_AUTH_TYPE,
    ];
    if (!extension_loaded('curl')) {
        $out['verdict'] = 'curl is off, so the check cannot run (logins still work). Enable curl in cPanel → Select PHP Version → Extensions.';
        ba_json(200, $out);
    }
    $ch = curl_init(OMADA_PORTAL_AUTH_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_NOBODY         => false,
        CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_SSL_VERIFYPEER => true,    // phones verify the certificate too
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4,
    ]);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errno  = curl_errno($ch);
    $error  = curl_error($ch);
    curl_close($ch);

    $out['endpoint_http_status'] = $status;
    $out['endpoint_error']       = $errno ? "$error (errno $errno)" : null;
    $out['endpoint_reply']       = is_string($body) ? substr(trim($body), 0, 160) : null;

    if ($status === 0) {
        $out['verdict'] = 'Login endpoint NOT reachable. Check the /portal/ block in omada-proxy.conf on the VPS, '
                        . 'run "nginx -t && systemctl reload nginx", and that the controller portal port 8843 is up.';
    } elseif ($status === 502 || $status === 504) {
        $out['verdict'] = 'nginx answers but cannot reach the controller portal port (8843) on the VPS. '
                        . 'Check: curl -k https://127.0.0.1:8843/ on the VPS.';
    } else {
        $out['verdict'] = 'Login endpoint reachable with a valid certificate. Phones also need 65.109.35.14 in the '
                        . 'portal\'s Pre-Authentication Access list. Then test a real voucher.';
    }
    ba_json(200, $out);
}


// ===========================================================================
// MAIN
// ===========================================================================
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '';

// Health probe: /portal/radius/browserauth?ping=1 → proves file is reachable
if (isset($_GET['ping'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    echo json_encode([
        'ok'        => true,
        'file'      => __FILE__,
        'path'      => $path,
        'php'       => PHP_VERSION,
        'time'      => date('c'),
        'auth_url'  => OMADA_PORTAL_AUTH_URL,
        'auth_type' => OMADA_PORTAL_AUTH_TYPE,
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

// Diagnostics: /portal/radius/browserauth?diag=DIAG_KEY
if (isset($_GET['diag'])) {
    if (!is_string($_GET['diag']) || !hash_equals(DIAG_KEY, $_GET['diag'])) ba_json(403, ['error'=>'forbidden']);
    ba_diag();
}

try {
    $p = array_merge($_GET, $_POST);

    // Values Omada put on the portal URL — forwarded exactly as Omada sent them
    $clientMac  = ba_param($p, ['clientMac', 'client_mac', 'clientmac']);
    $clientIp   = ba_param($p, ['clientIp', 'clientIP', 'client_ip']);
    $apMac      = ba_param($p, ['apMac', 'ap_mac', 'ap']);
    $gatewayMac = ba_param($p, ['gatewayMac', 'GatewayMac', 'gateway_mac']);
    $ssid       = ba_param($p, ['ssidName', 'ssid']);
    $radioId    = ba_param($p, ['radioId', 'radio_id']);
    $vid        = ba_param($p, ['vid', 'vlanId']);
    $origin     = ba_param($p, ['originUrl', 'originalUrl', 'redirectUrl', 'redirect_url', 'url']);

    // Login details from your portal form
    $username = ba_param($p, ['username', 'user', 'voucher', 'voucher_code', 'code', 'pin']);
    $password = ba_param($p, ['password', 'pass', 'pwd']);
    if ($password === '' && VOUCHER_AS_PASSWORD) $password = $username;

    // Sanity checks on the MAC (compare in a normalised form, send the original)
    $macNorm = strtoupper(str_replace('-', ':', $clientMac));
    if ($clientMac === '' || !preg_match('/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/', $macNorm)) {
        ba_log('missing/bad clientMac — keys received: '.implode(',', array_keys($p)));
        ba_page(400, 'Please reconnect',
            '<p class="err">We could not identify your device.</p>'
          . '<p>Turn WiFi off and on again, then open any website to get the login page.</p>');
    }
    if ($apMac === '' && $gatewayMac === '') {
        ba_log("missing apMac for $macNorm — the portal form must forward apMac from the Omada URL");
        ba_page(400, 'Please reconnect',
            '<p class="err">The login page is missing access point details.</p>'
          . '<p>Turn WiFi off and on again, then open any website to get the login page.</p>');
    }
    if ($username === '') {
        ba_page(400, 'Voucher required',
            '<p class="err">Please enter your voucher code.</p>'
          . '<p><a class="btn" href="javascript:history.back()">Go back</a></p>');
    }

    $missing = [];
    if ($ssid === '')    $missing[] = 'ssidName';
    if ($radioId === '') $missing[] = 'radioId';
    if ($vid === '')     $missing[] = 'vid';
    if ($missing) ba_log("warning: $macNorm login without ".implode(', ', $missing)
                        .' — make the portal form forward these from the Omada URL');

    $fields = [
        'clientMac'  => $clientMac,
        'clientIp'   => $clientIp,
        'ssidName'   => $ssid,
        'radioId'    => $radioId,
        'vid'        => $vid,
        'authType'   => (string)OMADA_PORTAL_AUTH_TYPE,
        'originUrl'  => $origin !== '' ? $origin : DEFAULT_REDIRECT,
        'username'   => $username,
        'password'   => $password,
    ];
    // Omada: apMac and gatewayMac must not be sent together
    if ($apMac !== '') $fields['apMac'] = $apMac; else $fields['gatewayMac'] = $gatewayMac;
    $fields = array_filter($fields, function ($v) { return $v !== ''; });

    ba_log("login hand-off: client=$macNorm ap=".($apMac ?: "gw:$gatewayMac")." ssid=$ssid radio=$radioId vid=$vid "
          .'voucher='.substr($username, 0, 3).'***');

    // Auto-submitting form: the phone's own browser POSTs to the controller,
    // which checks the voucher with RADIUS and then redirects to originUrl.
    $inputs = '';
    foreach ($fields as $k => $v) {
        $inputs .= '<input type="hidden" name="'.ba_e($k).'" value="'.ba_e($v).'">';
    }
    ba_page(200, 'Connecting…',
        '<div class="spin" aria-hidden="true"></div><p>Checking your voucher, please wait.</p>'
      . '<form id="f" method="post" action="'.ba_e(OMADA_PORTAL_AUTH_URL).'" accept-charset="UTF-8">'.$inputs
      . '<noscript><button type="submit">Continue</button></noscript></form>'
      . '<script>document.getElementById("f").submit();</script>');

} catch (Throwable $e) {
    ba_log('uncaught: '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine());
    ba_page(500, 'Something went wrong', '<p class="err">Please try again in a moment.</p>');
}