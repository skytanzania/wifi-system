<?php
/**
 * SKYTANZA WIFI MONETIZATION SYSTEM
 * Analytics Page - Loaded from external file
 * 
 * Detailed user/seller analytics with revenue trends, package performance,
 * top customers, router analytics, and export capabilities
 * 
 * Context variables from index.php:
 * $auth, $voucher, $router, $transaction, $payment, $sonicPayout,
 * $notificationManager, $messageManager, $supportManager, $customerManager,
 * $sessionManager, $conn, $db, $currentLang, $currentTheme, $page,
 * SITE_NAME, SITE_URL, CURRENCY, ADMIN_EMAIL, WITHDRAWAL_FEE_PERCENT,
 * SONIC_PESA_MIN_PAYOUT
 */

// Require seller or admin
$auth->requireSeller();

$userId = $_SESSION['user_id'];
$user = $auth->getUser();

$msg = '';

// ============================================
// HANDLE FLASH MESSAGES
// ============================================
if (!empty($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// ============================================
// HANDLE CSV EXPORT
// ============================================
if (isset($_GET['export'])) {
    $exportType = $_GET['export'];
    $days = intval($_GET['range'] ?? 7);
    if ($days < 1 || $days > 365) $days = 7;
    
    while (ob_get_level() > 0) ob_end_clean();
    
    if ($exportType === 'daily_sales') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="daily_sales_' . date('Y-m-d') . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT DATE(created_at) as sale_date, 
                   COUNT(*) as total_sales, 
                   COALESCE(SUM(amount), 0) as revenue
            FROM payments 
            WHERE seller_id = ? AND payment_status = 'completed' 
            AND created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            GROUP BY DATE(created_at) 
            ORDER BY sale_date DESC
        ");
        $stmt->bind_param("ii", $userId, $days);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Date', 'Total Sales', 'Revenue (TZS)']);
        foreach ($rows as $row) {
            fputcsv($output, [$row['sale_date'], $row['total_sales'], $row['revenue']]);
        }
        fclose($output);
        exit;
    }
    
    if ($exportType === 'top_packages') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="top_packages_' . date('Y-m-d') . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT p.name as package_name, 
                   COUNT(pay.id) as sales_count, 
                   COALESCE(SUM(pay.amount), 0) as revenue
            FROM packages p
            LEFT JOIN vouchers v ON v.package_id = p.id
            LEFT JOIN payments pay ON pay.voucher_id = v.id AND pay.payment_status = 'completed'
            WHERE p.seller_id = ?
            GROUP BY p.id
            ORDER BY revenue DESC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Package', 'Sales Count', 'Revenue (TZS)']);
        foreach ($rows as $row) {
            fputcsv($output, [$row['package_name'], $row['sales_count'], $row['revenue']]);
        }
        fclose($output);
        exit;
    }
    
    if ($exportType === 'top_customers') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="top_customers_' . date('Y-m-d') . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT phone_number, COUNT(*) as purchases, 
                   COALESCE(SUM(amount), 0) as total_spent,
                   MAX(created_at) as last_purchase
            FROM payments 
            WHERE seller_id = ? AND payment_status = 'completed' AND phone_number IS NOT NULL
            GROUP BY phone_number
            ORDER BY total_spent DESC
            LIMIT 100
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Phone Number', 'Purchases', 'Total Spent (TZS)', 'Last Purchase']);
        foreach ($rows as $row) {
            fputcsv($output, [$row['phone_number'], $row['purchases'], $row['total_spent'], $row['last_purchase']]);
        }
        fclose($output);
        exit;
    }
    
    if ($exportType === 'router_performance') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="router_performance_' . date('Y-m-d') . '.csv"');
        
        $stmt = $conn->prepare("
            SELECT r.device_name as router_name, r.ssid, r.status,
                   COUNT(DISTINCT pay.id) as total_sales,
                   COALESCE(SUM(pay.amount), 0) as revenue,
                   (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id AND ws.status = 'active') as active_sessions,
                   (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id) as total_sessions
            FROM routers r
            LEFT JOIN packages p ON p.router_id = r.id
            LEFT JOIN vouchers v ON v.package_id = p.id
            LEFT JOIN payments pay ON pay.voucher_id = v.id AND pay.payment_status = 'completed'
            WHERE r.user_id = ?
            GROUP BY r.id
            ORDER BY revenue DESC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Router', 'SSID', 'Status', 'Total Sales', 'Revenue (TZS)', 'Active Sessions', 'Total Sessions']);
        foreach ($rows as $row) {
            fputcsv($output, [
                $row['router_name'], $row['ssid'], $row['status'],
                $row['total_sales'], $row['revenue'], $row['active_sessions'], $row['total_sessions']
            ]);
        }
        fclose($output);
        exit;
    }
}

// ============================================
// FILTERS
// ============================================
$range = intval($_GET['range'] ?? 7);
if (!in_array($range, [7, 30, 90, 365])) $range = 7;

// ============================================
// OVERALL STATS
// ============================================
$totalEarnings = 0;
$totalSales = 0;
$totalVouchers = 0;
$totalRouters = 0;
$onlineRouters = 0;
$totalCustomers = 0;
$activeSessions = 0;
$avgSessionDuration = 0;

try {
    $res = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE seller_id = $userId AND payment_status = 'completed'");
    if ($res) $totalEarnings = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM payments WHERE seller_id = $userId AND payment_status = 'completed'");
    if ($res) $totalSales = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM vouchers WHERE seller_id = $userId");
    if ($res) $totalVouchers = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM routers WHERE user_id = $userId");
    if ($res) $totalRouters = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM routers WHERE user_id = $userId AND status = 'online'");
    if ($res) $onlineRouters = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(DISTINCT phone_number) as total FROM payments WHERE seller_id = $userId AND phone_number IS NOT NULL AND payment_status = 'completed'");
    if ($res) $totalCustomers = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COUNT(*) as total FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = $userId AND ws.status = 'active'");
    if ($res) $activeSessions = $res->fetch_assoc()['total'];
    
    $res = $conn->query("SELECT COALESCE(AVG(duration_minutes), 0) as avg_dur FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = $userId AND ws.duration_minutes > 0");
    if ($res) $avgSessionDuration = $res->fetch_assoc()['avg_dur'];
} catch (Throwable $e) {}

// ============================================
// PERIOD COMPARISON (current period vs previous period)
// ============================================
$periodRevenue = 0;
$periodSales = 0;
$periodCustomers = 0;
$prevPeriodRevenue = 0;
$prevPeriodSales = 0;

try {
    $stmt = $conn->prepare("
        SELECT COALESCE(SUM(amount), 0) as revenue, COUNT(*) as sales, COUNT(DISTINCT phone_number) as customers
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
    ");
    $stmt->bind_param("ii", $userId, $range);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $periodRevenue = $row['revenue'];
    $periodSales = $row['sales'];
    $periodCustomers = $row['customers'];
    
    // Previous period
    $stmt = $conn->prepare("
        SELECT COALESCE(SUM(amount), 0) as revenue, COUNT(*) as sales
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
        AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
    ");
    $doubleRange = $range * 2;
    $stmt->bind_param("iii", $userId, $doubleRange, $range);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $prevPeriodRevenue = $row['revenue'];
    $prevPeriodSales = $row['sales'];
} catch (Throwable $e) {}

// Calculate growth
$revenueGrowth = $prevPeriodRevenue > 0 ? round((($periodRevenue - $prevPeriodRevenue) / $prevPeriodRevenue) * 100, 1) : ($periodRevenue > 0 ? 100 : 0);
$salesGrowth = $prevPeriodSales > 0 ? round((($periodSales - $prevPeriodSales) / $prevPeriodSales) * 100, 1) : ($periodSales > 0 ? 100 : 0);

// ============================================
// REVENUE BY PACKAGE
// ============================================
$revenueByPackage = [];
try {
    $stmt = $conn->prepare("
        SELECT p.id, p.name, p.price, 
               COUNT(DISTINCT pay.id) as sales_count,
               COALESCE(SUM(pay.amount), 0) as revenue,
               (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id) as voucher_count,
               (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = 'available') as available_count,
               (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = 'used') as used_count
        FROM packages p
        LEFT JOIN vouchers v ON v.package_id = p.id
        LEFT JOIN payments pay ON pay.voucher_id = v.id AND pay.payment_status = 'completed'
        WHERE p.seller_id = ?
        GROUP BY p.id
        ORDER BY revenue DESC
        LIMIT 10
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $revenueByPackage = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// REVENUE BY ROUTER
// ============================================
$revenueByRouter = [];
try {
    $stmt = $conn->prepare("
        SELECT r.id, r.device_name, r.ssid, r.status,
               COUNT(DISTINCT pay.id) as sales_count,
               COALESCE(SUM(pay.amount), 0) as revenue,
               (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id AND ws.status = 'active') as active_sessions,
               (SELECT COUNT(*) FROM wifi_sessions ws WHERE ws.router_id = r.id) as total_sessions,
               (SELECT COUNT(*) FROM packages p WHERE p.router_id = r.id) as package_count
        FROM routers r
        LEFT JOIN packages p ON p.router_id = r.id
        LEFT JOIN vouchers v ON v.package_id = p.id
        LEFT JOIN payments pay ON pay.voucher_id = v.id AND pay.payment_status = 'completed'
        WHERE r.user_id = ?
        GROUP BY r.id
        ORDER BY revenue DESC
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $revenueByRouter = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// DAILY SALES TREND
// ============================================
$dailySales = [];
$salesMap = [];
try {
    $stmt = $conn->prepare("
        SELECT DATE(created_at) as sale_date, 
               COUNT(*) as count, 
               COALESCE(SUM(amount), 0) as revenue
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        GROUP BY DATE(created_at)
        ORDER BY sale_date ASC
    ");
    $stmt->bind_param("ii", $userId, $range);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    foreach ($rows as $row) {
        $salesMap[$row['sale_date']] = [
            'count' => $row['count'],
            'revenue' => $row['revenue']
        ];
    }
} catch (Throwable $e) {}

// Build chart data
$chartLabels = [];
$chartValues = [];
$chartCounts = [];

for ($i = $range - 1; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chartLabels[] = date($range <= 7 ? 'D' : ($range <= 30 ? 'd M' : 'd/m'), strtotime($date));
    $chartValues[] = $salesMap[$date]['revenue'] ?? 0;
    $chartCounts[] = $salesMap[$date]['count'] ?? 0;
}

$maxChartValue = max(array_merge([1], $chartValues));

// ============================================
// TOP CUSTOMERS
// ============================================
$topCustomers = [];
try {
    $stmt = $conn->prepare("
        SELECT phone_number, COUNT(*) as purchases, 
               COALESCE(SUM(amount), 0) as total_spent,
               MAX(created_at) as last_purchase,
               MIN(created_at) as first_purchase
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed' AND phone_number IS NOT NULL
        GROUP BY phone_number
        ORDER BY total_spent DESC
        LIMIT 15
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $topCustomers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// PEAK HOURS
// ============================================
$peakHours = [];
try {
    $stmt = $conn->prepare("
        SELECT HOUR(created_at) as hour_of_day, 
               COUNT(*) as count,
               COALESCE(SUM(amount), 0) as revenue
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        GROUP BY HOUR(created_at)
        ORDER BY count DESC
        LIMIT 8
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $peakHours = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// DEVICE BREAKDOWN
// ============================================
$deviceBreakdown = [];
try {
    $stmt = $conn->prepare("
        SELECT 
            CASE 
                WHEN device_name LIKE '%phone%' OR device_name LIKE '%mobile%' OR device_name LIKE '%android%' OR device_name LIKE '%iphone%' THEN 'Mobile'
                WHEN device_name LIKE '%laptop%' OR device_name LIKE '%macbook%' OR device_name LIKE '%pc%' THEN 'Laptop'
                WHEN device_name LIKE '%tablet%' OR device_name LIKE '%ipad%' THEN 'Tablet'
                ELSE 'Other'
            END as device_category,
            COUNT(*) as count
        FROM wifi_sessions ws
        JOIN routers r ON ws.router_id = r.id
        WHERE r.user_id = ?
        GROUP BY device_category
        ORDER BY count DESC
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $deviceBreakdown = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {}

// ============================================
// NEW CUSTOMERS THIS PERIOD
// ============================================
$newCustomers = 0;
try {
    $stmt = $conn->prepare("
        SELECT COUNT(DISTINCT phone_number) as total
        FROM payments
        WHERE seller_id = ? AND payment_status = 'completed'
        AND phone_number NOT IN (
            SELECT DISTINCT phone_number FROM payments 
            WHERE seller_id = ? AND payment_status = 'completed'
            AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
        )
        AND phone_number IS NOT NULL
    ");
    $stmt->bind_param("iii", $userId, $userId, $range);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $newCustomers = $row['total'] ?? 0;
} catch (Throwable $e) {}

// ============================================
// CONVERSION METRICS
// ============================================
$totalUniqueCustomers = 0;
try {
    $res = $conn->query("SELECT COUNT(DISTINCT phone_number) as c FROM payments WHERE seller_id = $userId AND phone_number IS NOT NULL AND payment_status = 'completed'");
    if ($res) $totalUniqueCustomers = $res->fetch_assoc()['c'];
} catch (Throwable $e) {}

// Average purchase value
$avgPurchaseValue = $totalSales > 0 ? $totalEarnings / $totalSales : 0;

// Total data used
$totalDataUsed = 0;
try {
    $res = $conn->query("SELECT COALESCE(SUM(data_used_mb), 0) as total FROM wifi_sessions ws JOIN routers r ON ws.router_id = r.id WHERE r.user_id = $userId");
    if ($res) $totalDataUsed = $res->fetch_assoc()['total'];
} catch (Throwable $e) {}

// Format helpers
function formatDuration($minutes) {
    $minutes = intval($minutes);
    if ($minutes < 60) return $minutes . 'm';
    if ($minutes < 1440) return round($minutes / 60, 1) . 'h';
    return round($minutes / 1440, 1) . 'd';
}

function formatData($mb) {
    if ($mb < 1024) return round($mb, 0) . ' MB';
    if ($mb < 1024 * 1024) return round($mb / 1024, 1) . ' GB';
    return round($mb / 1024 / 1024, 2) . ' TB';
}

function growthClass($pct) {
    if ($pct > 0) return 'text-success';
    if ($pct < 0) return 'text-danger';
    return 'text-muted';
}

function growthIcon($pct) {
    if ($pct > 0) return 'arrow-up';
    if ($pct < 0) return 'arrow-down';
    return 'minus';
}

?>

<!-- ============================================ -->
<!-- ANALYTICS HEADER                            -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-0"><i class="fas fa-chart-bar"></i> <?php echo t('analytics'); ?></h2>
        <small class="text-muted">Deep insights into your WiFi business performance</small>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <div class="dropdown">
            <button class="btn btn-outline-success btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-download"></i> <?php echo t('export_report'); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="?page=analytics&export=daily_sales&range=<?php echo $range; ?>">
                    <i class="fas fa-chart-line text-primary"></i> Daily Sales Report
                </a></li>
                <li><a class="dropdown-item" href="?page=analytics&export=top_packages&range=<?php echo $range; ?>">
                    <i class="fas fa-box text-success"></i> Packages Report
                </a></li>
                <li><a class="dropdown-item" href="?page=analytics&export=top_customers&range=<?php echo $range; ?>">
                    <i class="fas fa-users text-info"></i> Customers Report
                </a></li>
                <li><a class="dropdown-item" href="?page=analytics&export=router_performance&range=<?php echo $range; ?>">
                    <i class="fas fa-network-wired text-warning"></i> Routers Report
                </a></li>
            </ul>
        </div>
        <a href="?page=dashboard" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo t('back_to_dashboard'); ?>
        </a>
    </div>
</div>

<?php echo $msg; ?>

<!-- ============================================ -->
<!-- TIME RANGE SELECTOR                         -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-body py-3">
        <div class="d-flex flex-wrap align-items-center gap-2">
            <span class="text-muted small me-2">
                <i class="fas fa-calendar-alt"></i> <?php echo t('date_range'); ?>:
            </span>
            <a href="?page=analytics&range=7" 
               class="btn btn-sm <?php echo $range === 7 ? 'btn-primary' : 'btn-outline-primary'; ?>">
                <?php echo t('last_7_days'); ?>
            </a>
            <a href="?page=analytics&range=30" 
               class="btn btn-sm <?php echo $range === 30 ? 'btn-primary' : 'btn-outline-primary'; ?>">
                <?php echo t('last_30_days'); ?>
            </a>
            <a href="?page=analytics&range=90" 
               class="btn btn-sm <?php echo $range === 90 ? 'btn-primary' : 'btn-outline-primary'; ?>">
                <?php echo t('last_90_days'); ?>
            </a>
            <a href="?page=analytics&range=365" 
               class="btn btn-sm <?php echo $range === 365 ? 'btn-primary' : 'btn-outline-primary'; ?>">
                <i class="fas fa-calendar"></i> 1 Year
            </a>
            
            <div class="ms-auto">
                <span class="badge bg-secondary">
                    <i class="fas fa-info-circle"></i> Comparing to previous <?php echo $range; ?> days
                </span>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- MAIN PERIOD STATS (with growth)             -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card">
            <div class="metric-label"><i class="fas fa-money-bill-wave text-success"></i> <?php echo t('revenue'); ?></div>
            <div class="metric-value"><?php echo CURRENCY . ' ' . number_format($periodRevenue, 0); ?></div>
            <div class="d-flex align-items-center gap-2 small">
                <span class="<?php echo growthClass($revenueGrowth); ?>">
                    <i class="fas fa-<?php echo growthIcon($revenueGrowth); ?>"></i>
                    <?php echo abs($revenueGrowth); ?>%
                </span>
                <span class="text-muted">vs last period</span>
            </div>
        </div>
    </div>
    
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card">
            <div class="metric-label"><i class="fas fa-shopping-bag text-primary"></i> <?php echo t('total_sales'); ?></div>
            <div class="metric-value text-primary"><?php echo number_format($periodSales); ?></div>
            <div class="d-flex align-items-center gap-2 small">
                <span class="<?php echo growthClass($salesGrowth); ?>">
                    <i class="fas fa-<?php echo growthIcon($salesGrowth); ?>"></i>
                    <?php echo abs($salesGrowth); ?>%
                </span>
                <span class="text-muted">vs last period</span>
            </div>
        </div>
    </div>
    
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card">
            <div class="metric-label"><i class="fas fa-users text-info"></i> <?php echo t('new_customers'); ?></div>
            <div class="metric-value text-info"><?php echo number_format($newCustomers); ?></div>
            <div class="small text-muted">
                <?php echo number_format($periodCustomers); ?> total active
            </div>
        </div>
    </div>
    
    <div class="col-6 col-md-3 mb-3">
        <div class="analytics-card">
            <div class="metric-label"><i class="fas fa-shopping-cart text-warning"></i> Avg. Purchase</div>
            <div class="metric-value text-warning" style="font-size:1.3rem;">
                <?php echo CURRENCY . ' ' . number_format($avgPurchaseValue, 0); ?>
            </div>
            <div class="small text-muted">
                Per transaction
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- ALL-TIME STATS                              -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('total_earnings'); ?></h6>
                    <h4 class="fw-bold mb-0"><?php echo CURRENCY . ' ' . number_format($totalEarnings, 0); ?></h4>
                    <small style="opacity:0.85;">All time</small>
                </div>
                <i class="fas fa-crown" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card success">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('total_customers'); ?></h6>
                    <h4 class="fw-bold mb-0"><?php echo number_format($totalUniqueCustomers); ?></h4>
                    <small style="opacity:0.85;">Unique buyers</small>
                </div>
                <i class="fas fa-users" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card info">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1"><?php echo t('active_sessions'); ?></h6>
                    <h4 class="fw-bold mb-0"><?php echo number_format($activeSessions); ?></h4>
                    <small style="opacity:0.85;">
                        Avg: <?php echo formatDuration($avgSessionDuration); ?>
                    </small>
                </div>
                <i class="fas fa-clock" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-3">
        <div class="card p-3 stat-card warning">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1">Data Used</h6>
                    <h4 class="fw-bold mb-0"><?php echo formatData($totalDataUsed); ?></h4>
                    <small style="opacity:0.85;">Total traffic</small>
                </div>
                <i class="fas fa-database" style="font-size:1.5rem;opacity:0.7;"></i>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- REVENUE CHART                               -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="mb-0">
            <i class="fas fa-chart-line text-primary"></i> 
            <?php echo t('revenue_chart'); ?> — Last <?php echo $range; ?> Days
        </h6>
        <div class="d-flex gap-3 small">
            <span><i class="fas fa-circle text-primary"></i> Revenue</span>
        </div>
    </div>
    <div class="card-body">
        <?php if (array_sum($chartValues) > 0): ?>
            <div class="chart-bar" style="height: 200px;">
                <?php foreach ($chartValues as $i => $val): 
                    $heightPct = ($val / $maxChartValue) * 100;
                ?>
                <div class="bar" 
                     style="height: <?php echo max($heightPct, 2); ?>%; background: linear-gradient(to top, var(--primary), var(--primary-light));"
                     title="<?php echo $chartLabels[$i]; ?>: <?php echo CURRENCY . ' ' . number_format($val, 0); ?> (<?php echo $chartCounts[$i]; ?> sales)">
                </div>
                <?php endforeach; ?>
            </div>
            <div class="d-flex justify-content-between mt-3 small text-muted">
                <span><?php echo $chartLabels[0] ?? ''; ?></span>
                <?php if (count($chartLabels) > 2): ?>
                <span><?php echo $chartLabels[floor(count($chartLabels) / 2)]; ?></span>
                <?php endif; ?>
                <span><?php echo end($chartLabels) ?: ''; ?></span>
            </div>
            
            <!-- Summary Row -->
            <div class="row mt-4 pt-3 border-top" style="border-color:var(--border-color) !important;">
                <div class="col-4 text-center">
                    <div class="text-muted small">Total Revenue</div>
                    <div class="fw-bold text-primary"><?php echo CURRENCY . ' ' . number_format(array_sum($chartValues), 0); ?></div>
                </div>
                <div class="col-4 text-center">
                    <div class="text-muted small">Total Sales</div>
                    <div class="fw-bold text-success"><?php echo number_format(array_sum($chartCounts)); ?></div>
                </div>
                <div class="col-4 text-center">
                    <div class="text-muted small">Best Day</div>
                    <div class="fw-bold text-info">
                        <?php echo CURRENCY . ' ' . number_format($maxChartValue, 0); ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="empty-state py-5">
                <i class="fas fa-chart-line"></i>
                <p><?php echo t('no_analytics_data'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================ -->
<!-- PACKAGE & ROUTER ANALYTICS                  -->
<!-- ============================================ -->
<div class="row mb-4">
    <!-- Top Packages -->
    <div class="col-lg-6 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-box text-success"></i> <?php echo t('revenue_by_package'); ?></h6>
                <a href="?page=analytics&export=top_packages&range=<?php echo $range; ?>" class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($revenueByPackage) > 0): 
                    $maxPkgRevenue = max(array_merge([1], array_column($revenueByPackage, 'revenue')));
                ?>
                    <?php foreach ($revenueByPackage as $pkg): 
                        $pct = ($pkg['revenue'] / $maxPkgRevenue) * 100;
                    ?>
                    <div class="p-3 border-bottom" style="border-color:var(--border-color) !important;">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <div style="min-width:0;flex:1;">
                                <div class="fw-semibold text-truncate">
                                    <i class="fas fa-box text-success"></i>
                                    <?php echo htmlspecialchars($pkg['name']); ?>
                                </div>
                                <small class="text-muted">
                                    <?php echo CURRENCY . ' ' . number_format($pkg['price'], 0); ?> · 
                                    <?php echo $pkg['sales_count']; ?> sales · 
                                    <?php echo $pkg['voucher_count']; ?> vouchers
                                </small>
                            </div>
                            <div class="text-end ms-2">
                                <div class="fw-bold text-success"><?php echo CURRENCY . ' ' . number_format($pkg['revenue'], 0); ?></div>
                            </div>
                        </div>
                        <div class="progress" style="height:4px;">
                            <div class="progress-bar bg-success" style="width: <?php echo $pct; ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <i class="fas fa-box"></i>
                        <p class="small mb-0">No packages yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Router Performance -->
    <div class="col-lg-6 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-network-wired text-warning"></i> <?php echo t('revenue_by_router'); ?></h6>
                <a href="?page=analytics&export=router_performance&range=<?php echo $range; ?>" class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($revenueByRouter) > 0): 
                    $maxRouterRevenue = max(array_merge([1], array_column($revenueByRouter, 'revenue')));
                ?>
                    <?php foreach ($revenueByRouter as $rt): 
                        $pct = ($rt['revenue'] / $maxRouterRevenue) * 100;
                        $isOnline = ($rt['status'] === 'online');
                    ?>
                    <div class="p-3 border-bottom" style="border-color:var(--border-color) !important;">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <div style="min-width:0;flex:1;">
                                <div class="fw-semibold text-truncate">
                                    <span class="router-status-indicator <?php echo $rt['status']; ?>"></span>
                                    <?php echo htmlspecialchars($rt['device_name']); ?>
                                </div>
                                <small class="text-muted">
                                    <?php echo $rt['sales_count']; ?> sales · 
                                    <?php echo $rt['active_sessions']; ?> active · 
                                    <?php echo $rt['package_count']; ?> packages
                                </small>
                            </div>
                            <div class="text-end ms-2">
                                <div class="fw-bold text-warning"><?php echo CURRENCY . ' ' . number_format($rt['revenue'], 0); ?></div>
                            </div>
                        </div>
                        <div class="progress" style="height:4px;">
                            <div class="progress-bar bg-warning" style="width: <?php echo $pct; ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <i class="fas fa-network-wired"></i>
                        <p class="small mb-0">No routers yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- CUSTOMER ANALYTICS & PEAK HOURS             -->
<!-- ============================================ -->
<div class="row mb-4">
    <!-- Top Customers -->
    <div class="col-lg-7 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-crown text-warning"></i> <?php echo t('top_customers'); ?></h6>
                <a href="?page=analytics&export=top_customers&range=<?php echo $range; ?>" class="btn btn-sm btn-outline-success">
                    <i class="fas fa-download"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (count($topCustomers) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th style="width:40px;">#</th>
                                    <th><?php echo t('phone'); ?></th>
                                    <th><?php echo t('purchases'); ?></th>
                                    <th><?php echo t('total_spent'); ?></th>
                                    <th><?php echo t('last_purchase'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($topCustomers as $i => $cust): 
                                    $rankClass = $i === 0 ? 'gold' : ($i === 1 ? 'silver' : ($i === 2 ? 'bronze' : 'normal'));
                                ?>
                                <tr>
                                    <td>
                                        <div class="rank <?php echo $rankClass; ?>" style="width:24px;height:24px;font-size:0.75rem;">
                                            <?php echo $i + 1; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <i class="fas fa-phone text-info"></i>
                                        <strong><?php echo htmlspecialchars($cust['phone_number']); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo $cust['purchases']; ?></span>
                                    </td>
                                    <td>
                                        <strong class="text-success"><?php echo CURRENCY . ' ' . number_format($cust['total_spent'], 0); ?></strong>
                                    </td>
                                    <td>
                                        <small class="text-muted">
                                            <?php 
                                            $diff = time() - strtotime($cust['last_purchase']);
                                            if ($diff < 86400) echo 'Today';
                                            elseif ($diff < 604800) echo floor($diff / 86400) . 'd ago';
                                            else echo date('d M Y', strtotime($cust['last_purchase']));
                                            ?>
                                        </small>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <i class="fas fa-users"></i>
                        <p class="small mb-0">No customer data yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Peak Hours & Device Breakdown -->
    <div class="col-lg-5 mb-3">
        <!-- Peak Hours -->
        <div class="card mb-3">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-clock text-info"></i> <?php echo t('peak_hours'); ?></h6>
            </div>
            <div class="card-body">
                <?php if (count($peakHours) > 0): 
                    $maxPeak = max(array_column($peakHours, 'count'));
                ?>
                    <?php foreach ($peakHours as $ph): 
                        $pct = ($ph['count'] / $maxPeak) * 100;
                    ?>
                    <div class="mb-2">
                        <div class="d-flex justify-content-between align-items-center small mb-1">
                            <span>
                                <i class="fas fa-clock text-muted"></i>
                                <?php echo str_pad($ph['hour_of_day'], 2, '0', STR_PAD_LEFT); ?>:00 - 
                                <?php echo str_pad($ph['hour_of_day'] + 1, 2, '0', STR_PAD_LEFT); ?>:00
                            </span>
                            <span class="badge bg-info"><?php echo $ph['count']; ?> sales</span>
                        </div>
                        <div class="progress" style="height:4px;">
                            <div class="progress-bar bg-info" style="width: <?php echo $pct; ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state py-3">
                        <i class="fas fa-clock"></i>
                        <p class="small mb-0">No data yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Device Breakdown -->
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-laptop text-primary"></i> <?php echo t('device_breakdown'); ?></h6>
            </div>
            <div class="card-body">
                <?php if (count($deviceBreakdown) > 0): 
                    $totalDevices = array_sum(array_column($deviceBreakdown, 'count'));
                    $colors = ['Mobile' => 'primary', 'Laptop' => 'success', 'Tablet' => 'info', 'Other' => 'secondary'];
                ?>
                    <?php foreach ($deviceBreakdown as $dev): 
                        $pct = $totalDevices > 0 ? round(($dev['count'] / $totalDevices) * 100) : 0;
                        $color = $colors[$dev['device_category']] ?? 'primary';
                    ?>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <i class="fas fa-<?php 
                                echo $dev['device_category'] === 'Mobile' ? 'mobile-alt' : 
                                    ($dev['device_category'] === 'Laptop' ? 'laptop' : 
                                    ($dev['device_category'] === 'Tablet' ? 'tablet-alt' : 'question')); 
                            ?> text-<?php echo $color; ?>"></i>
                            <span class="small"><?php echo $dev['device_category']; ?></span>
                        </div>
                        <div>
                            <span class="badge bg-<?php echo $color; ?>"><?php echo $dev['count']; ?></span>
                            <small class="text-muted ms-1"><?php echo $pct; ?>%</small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state py-3">
                        <i class="fas fa-laptop"></i>
                        <p class="small mb-0">No device data yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- KEY METRICS SUMMARY                         -->
<!-- ============================================ -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h6 class="mb-0"><i class="fas fa-tachometer-alt text-primary"></i> Key Performance Metrics</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-6 col-md-3 mb-3">
                <div class="text-center p-3 rounded" style="background:var(--bg-body);">
                    <div class="text-muted small mb-1">
                        <i class="fas fa-users"></i> <?php echo t('total_customers'); ?>
                    </div>
                    <div class="fw-bold" style="font-size:1.5rem;"><?php echo number_format($totalUniqueCustomers); ?></div>
                    <small class="text-muted">All-time unique buyers</small>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3">
                <div class="text-center p-3 rounded" style="background:var(--bg-body);">
                    <div class="text-muted small mb-1">
                        <i class="fas fa-money-bill-wave"></i> Avg. Purchase Value
                    </div>
                    <div class="fw-bold text-success" style="font-size:1.3rem;">
                        <?php echo CURRENCY . ' ' . number_format($avgPurchaseValue, 0); ?>
                    </div>
                    <small class="text-muted">Per transaction</small>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3">
                <div class="text-center p-3 rounded" style="background:var(--bg-body);">
                    <div class="text-muted small mb-1">
                        <i class="fas fa-clock"></i> <?php echo t('avg_session_duration'); ?>
                    </div>
                    <div class="fw-bold text-info" style="font-size:1.3rem;">
                        <?php echo formatDuration($avgSessionDuration); ?>
                    </div>
                    <small class="text-muted">Average session length</small>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-3">
                <div class="text-center p-3 rounded" style="background:var(--bg-body);">
                    <div class="text-muted small mb-1">
                        <i class="fas fa-ticket-alt"></i> <?php echo t('total_vouchers'); ?>
                    </div>
                    <div class="fw-bold text-warning" style="font-size:1.5rem;"><?php echo number_format($totalVouchers); ?></div>
                    <small class="text-muted">Total vouchers created</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- INSIGHTS PANEL                              -->
<!-- ============================================ -->
<div class="row mb-4">
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-lightbulb text-warning"></i> Business Insights</h6>
            </div>
            <div class="card-body">
                <?php
                $insights = [];
                
                if ($revenueGrowth > 20) {
                    $insights[] = ['success', 'arrow-up', 'Excellent growth! Revenue is up ' . $revenueGrowth . '% compared to last period.'];
                } elseif ($revenueGrowth > 0) {
                    $insights[] = ['success', 'arrow-up', 'Steady growth. Revenue increased by ' . $revenueGrowth . '%.'];
                } elseif ($revenueGrowth < -20) {
                    $insights[] = ['danger', 'arrow-down', 'Revenue dropped ' . abs($revenueGrowth) . '%. Consider running promotions.'];
                } elseif ($revenueGrowth < 0) {
                    $insights[] = ['warning', 'arrow-down', 'Slight revenue decline of ' . abs($revenueGrowth) . '%.'];
                } else {
                    $insights[] = ['info', 'minus', 'Stable revenue. Consider growth strategies.'];
                }
                
                if ($newCustomers > 0 && $periodCustomers > 0) {
                    $newPct = round(($newCustomers / $periodCustomers) * 100);
                    if ($newPct > 30) {
                        $insights[] = ['success', 'user-plus', $newPct . '% of your customers are new. Great acquisition!'];
                    } else {
                        $insights[] = ['info', 'users', 'Customer retention is strong — ' . (100 - $newPct) . '% are repeat buyers.'];
                    }
                }
                
                if ($activeSessions > 0) {
                    $insights[] = ['info', 'wifi', 'You have ' . $activeSessions . ' active session(s) right now.'];
                }
                
                if ($onlineRouters < $totalRouters && $totalRouters > 0) {
                    $offline = $totalRouters - $onlineRouters;
                    $insights[] = ['warning', 'exclamation-triangle', $offline . ' router(s) offline. Check connectivity.'];
                }
                
                if ($totalVouchers > 0 && $totalSales > 0) {
                    $sellThrough = round(($totalSales / $totalVouchers) * 100);
                    if ($sellThrough < 30) {
                        $insights[] = ['warning', 'ticket-alt', 'Only ' . $sellThrough . '% sell-through rate. Consider generating more or adjusting pricing.'];
                    } elseif ($sellThrough > 70) {
                        $insights[] = ['success', 'check', $sellThrough . '% sell-through rate. Excellent inventory turnover!'];
                    }
                }
                
                if (empty($insights)) {
                    $insights[] = ['info', 'info-circle', 'Add more routers and packages to generate business insights.'];
                }
                ?>
                
                <?php foreach ($insights as $insight): 
                    [$type, $icon, $text] = $insight;
                ?>
                <div class="d-flex align-items-start gap-2 mb-3">
                    <div class="bg-<?php echo $type; ?> bg-opacity-10 text-<?php echo $type; ?>" 
                         style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                        <i class="fas fa-<?php echo $icon; ?>"></i>
                    </div>
                    <div class="small"><?php echo htmlspecialchars($text); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="fas fa-chart-pie text-info"></i> Quick Summary</h6>
            </div>
            <div class="card-body">
                <div class="stat-row">
                    <span><i class="fas fa-money-bill-wave text-success"></i> Total Revenue</span>
                    <strong><?php echo CURRENCY . ' ' . number_format($totalEarnings, 0); ?></strong>
                </div>
                <div class="stat-row">
                    <span><i class="fas fa-shopping-bag text-primary"></i> Total Sales</span>
                    <strong><?php echo number_format($totalSales); ?></strong>
                </div>
                <div class="stat-row">
                    <span><i class="fas fa-users text-info"></i> Unique Customers</span>
                    <strong><?php echo number_format($totalUniqueCustomers); ?></strong>
                </div>
                <div class="stat-row">
                    <span><i class="fas fa-wifi text-primary"></i> Total Routers</span>
                    <strong><?php echo $totalRouters; ?> (<?php echo $onlineRouters; ?> online)</strong>
                </div>
                <div class="stat-row">
                    <span><i class="fas fa-box text-success"></i> Total Packages</span>
                    <strong><?php echo count($revenueByPackage); ?></strong>
                </div>
                <div class="stat-row">
                    <span><i class="fas fa-ticket-alt text-warning"></i> Total Vouchers</span>
                    <strong><?php echo number_format($totalVouchers); ?></strong>
                </div>
                <div class="stat-row">
                    <span><i class="fas fa-laptop text-primary"></i> Active Sessions</span>
                    <strong><?php echo number_format($activeSessions); ?></strong>
                </div>
                <div class="stat-row">
                    <span><i class="fas fa-database text-info"></i> Total Data Used</span>
                    <strong><?php echo formatData($totalDataUsed); ?></strong>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Chart bar animations on load
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.chart-bar .bar').forEach((bar, i) => {
        const targetHeight = bar.style.height;
        bar.style.height = '0';
        setTimeout(() => {
            bar.style.transition = 'height 0.6s ease';
            bar.style.height = targetHeight;
        }, i * 30);
    });
});

// Copy phone numbers on click
document.querySelectorAll('td strong').forEach(el => {
    if (/^\+?[0-9]{10,}/.test(el.textContent.trim())) {
        el.style.cursor = 'pointer';
        el.title = 'Click to copy';
        el.addEventListener('click', function() {
            navigator.clipboard.writeText(this.textContent.trim()).then(() => {
                const original = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check text-success"></i> Copied!';
                setTimeout(() => {
                    this.innerHTML = original;
                }, 1000);
            });
        });
    }
});
</script>