# SkyTanza WiFi — Omada EAP225 + RADIUS setup

```
Phone ─WiFi─► EAP225 ─► Omada Controller ──RADIUS (LAN)──► FreeRADIUS box ──HTTPS──► index.php (shared hosting)
   └──────────── captive portal (HTTPS) ───────────────────────────────────────────────► index.php?page=portal
```

Shared hosting cannot run a RADIUS server (RADIUS needs UDP ports 1812/1813). So a small
FreeRADIUS box runs **at the site** (any always-on Linux PC, mini-PC or Raspberry Pi) or on a VPS.
It needs **no public IP and no port forwarding** — it only makes outgoing HTTPS calls to your hosting.
All decisions (vouchers, time, data, speed, blocks) are made by `index.php`.

## 1. Shared hosting (cPanel)
1. Upload `index.php` to the subdomain folder (e.g. `wifi.skytanzania.co.tz`). Make sure HTTPS works.
2. Create `config.local.php` next to it with your secrets (long random values):
   ```php
   <?php
   define('DB_PASS', 'your-db-password');
   define('APP_SECRET', '...');
   define('RADIUS_API_KEY', '...');          // FreeRADIUS uses this to call the app
   define('CRON_SECRET', '...');
   define('PAYMENT_WEBHOOK_SECRET', '...');
   define('SONIC_PESA_API_KEY', '...');      // rotate the keys that were in the old file
   define('SONIC_PESA_API_SECRET', '...');
   ```
3. Open the site → tables are created automatically. Log in `admin` / `Admin@123` and **change the password**.
4. Admin → **RADIUS Setup** shows the ready `.env` for step 2.
5. Cron is optional (housekeeping runs automatically on RADIUS traffic). For payout reconciliation add a
   cPanel cron every 5 min: `wget -qO- "https://YOUR_SITE/index.php?cron=run&secret=CRON_SECRET"`.

## 2. FreeRADIUS box (Docker)
```bash
cp .env.example .env      # paste values from the RADIUS Setup page
docker compose up -d --build
docker logs -f skytanza-radius     # expect: "Web app reachable"
```
Test: `docker exec skytanza-radius radtest CODE CODE 127.0.0.1 0 YOUR_RADIUS_SECRET` → `Access-Accept`.

## 3. Omada Controller (v5.3+)
1. **Settings → Profiles → RADIUS Profile**: server = FreeRADIUS box IP, port 1812, secret = `RADIUS_SECRET`;
   enable accounting (1813, interim 60 s).
2. **Settings → Authentication → Portal**: your SSID → **External RADIUS Server** → that profile →
   **PAP** → **External Web Portal** = `https://YOUR_SITE/index.php?page=portal`.
3. **Pre-Authentication Access**: allow your site's domain (and its IP).
4. In the web app → **Omada EAP225 → Add**: AP MAC, SSID. If the portal says "not linked to the
   controller", set **Controller Portal URL** (e.g. `http://192.168.0.10:8088`).

## Notes
- **Disconnect (kick)**: the worker sends RFC 5176 Disconnect-Request to the controller on port 3799.
  If your controller version does not support it, set `DAE_ENABLED=0`; sessions still end at Session-Timeout,
  and blocked devices/vouchers can't log in again.
- **Cloud controller**: RADIUS then comes from the internet, so run FreeRADIUS on a VPS and set
  `OMADA_NETWORK` to the controller's egress IP.
- **Mobile money**: with `SONIC_PESA_COLLECT_ENDPOINT` empty, the portal shows your Lipa Namba; you tap
  **Confirm paid** in Orders and the customer's phone connects automatically. Set the endpoint once Sonic Pesa
  confirms their collection API; the webhook is `https://YOUR_SITE/index.php?webhook=payment&secret=PAYMENT_WEBHOOK_SECRET`.
- Old tables (`routers`, `packages`, `vouchers`, `wifi_sessions`) are left untouched; the new system uses `hs_*` tables.
