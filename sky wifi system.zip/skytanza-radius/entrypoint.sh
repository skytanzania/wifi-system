#!/bin/sh
set -e
: "${SKY_SITE_URL:?Set SKY_SITE_URL in .env}"
: "${SKY_RADIUS_API_KEY:?Set SKY_RADIUS_API_KEY in .env}"
: "${RADIUS_SECRET:?Set RADIUS_SECRET in .env}"
: "${OMADA_NETWORK:=192.168.0.0/24}"
export OMADA_NETWORK
# Quick reachability check of the web app (does not stop startup)
if curl -fsS --max-time 10 "$SKY_SITE_URL/index.php?radius=ping&key=$SKY_RADIUS_API_KEY" >/dev/null; then
  echo "[skytanza] Web app reachable: $SKY_SITE_URL"
else
  echo "[skytanza] WARNING: cannot reach $SKY_SITE_URL/index.php?radius=ping — check URL, key and internet"
fi
/usr/local/bin/dae-worker.sh &
if [ "${DEBUG:-0}" = "1" ]; then exec freeradius -X; else exec freeradius -f -l stdout; fi
